import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class CimulateDealsSpider(GetDealsProducts):
    name = 'cimulatedeals'
    handle_httpstatus_list = [401, 404]
    Sitename = 'RallyHouse'
    siteurl = 'https://www.rallyhouse.com'

    base_api = "https://prod.search.cimulate.ai/api/v1/search"

    custom_headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Referer": "https://www.rallyhouse.com/",
    "Content-Type": "application/json",
    "x-cimulate-api-key": "6b3a85f6-e563-403e-b3c4-4cd9317a6736",
    "Origin": "https://www.rallyhouse.com",
    "Connection": "keep-alive",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
    "Priority": "u=4",
    "TE": "trailers"
}


    def start_requests(self):
        payload = {
            "include_facets": True,
            "page": 1,
            "page_size": 60,
            "query": "deal",
            "exclude_facet_filters": {},
            "facet_filters": {
                "currently_unavailable": ["no"],
                "hot_market": ["no"],
                "availability_groups": ["all"],
                "facet_promotions": ["Clearance"]
            },
            "range_filters": [],
            "session_data": {"session_id": "VALID_SESSION_ID_HERE"}
        }

        yield scrapy.Request(
            url=self.base_api,
            method="POST",
            headers=self.custom_headers,
            body=json.dumps(payload),
            callback=self.parse,
            meta={'page': 1, 'payload': payload}
        )

    def parse(self, response):
        if response.status == 401:
            self.logger.error("Unauthorized (401) - Check headers / API key / session")
            return

        try:
            json_data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON decode failed: {e}")
            return

        hits = json_data.get("hits", [])
        page = response.meta['page']
        self.logger.info(f"Page {page}: Found {len(hits)} products")

        for product in hits:
            item = couponsDealsItem()
            item['Title'] = product.get('name', '').strip()
            item['SourceUrl'] = product.get('product_url', '')
            item['SalePrice'] = product.get('price', '')
            item['Price'] = product.get('original_price', '')
            item['Image'] = product.get('image', '')
            item['Offer'] = ""

            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        if len(hits) > 0:
            next_page = page + 1
            payload = response.meta['payload']
            payload['page'] = next_page
            yield scrapy.Request(
                url=self.base_api,
                method="POST",
                headers=self.custom_headers,
                body=json.dumps(payload),
                callback=self.parse,
                meta={'page': next_page, 'payload': payload}
            )
