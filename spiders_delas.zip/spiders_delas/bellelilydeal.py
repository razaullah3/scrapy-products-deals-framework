from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bellelilydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bellelilydeal'
    start_urls = ['https://www.bellelily.com/sale-t-446']
    Sitename = 'Bellelily'
    siteurl = 'https://www.bellelily.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//ul[@id="dirProList"]/li'
        titalxpath = './/p[@class="gcard-name text-truncate"]/a/text()'
        imagexpath = './/img[@class="gcardImgHover gcard-img img-fluid lazyloaded fadeIn"]//@src'
        pricexpath = './/span[@class="gcard-price__old d-none d-lg-inline-block"]/text()'
        price2xpath = './/span[@class="gcard-price__current "]/text()'
        otherxpath = ''
        nextpage = '//li[@class="page-item next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })