from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
from urllib.parse import urljoin

class renttherunwaySpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'renttherunway'
    start_urls = ['https://www.renttherunway.com/clearance/products']
    Sitename = 'renttherunway'
    siteurl = 'https://www.renttherunway.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//ul[@class="grid_grid__A_DHH tile-gap"]//li[contains(@class,"animate-fadeIn")]'
        titalxpath = './/div[@class="label_label__de6QB"]//p[@class="label_label__subtitle__LJkjz"]/text()'
        imagexpath = './/div[@class="tile_tile__v4Xtq tile-rounded"]//img[@class="tile_tile__image__Rz8or tile_visible__6Q2R4"]/@src'
        pricexpath = './/div[@class="label_label__prices__urgent__zbrPr"]//p/text()'
        price2xpath = './/div[@class="label_label__prices__Ly4J2 label_label__prices__discounted__AHrJz"]//p/text()'
        otherxpath = ''

        # Loop through all pages (1 to 35)
        for page_number in range(1, 36):
            if page_number == 1:
                page_url = self.start_urls[0]  # first page
            else:
                page_url = f"{self.start_urls[0]}?page={page_number}"

            yield response.follow(page_url, callback=self.Data_Collector, meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': '',  # handled by loop
                'categorypage': categorypage
            })
