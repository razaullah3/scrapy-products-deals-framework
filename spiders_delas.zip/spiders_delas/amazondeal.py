from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class lionelstoredealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'Amazon'
    start_urls = ['https://www.amazon.com/gp/goldbox?promotionsSearchLastSeenAsin=B0D1YQKDML&promotionsSearchStartIndex=0&promotionsSearchPageSize=60']
    Sitename = 'Amazon'
    siteurl = 'https://www.amazon.com'

    # ✅ Custom headers for all requests
    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
        }
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[contains(@class, "dcl-carousel-element")]'
        titalxpath = './/span[contains(@class, "dcl-product-label")]/span/text()'
        imagexpath = './/img[contains(@class, "dcl-dynamic-image")]/@src'
        pricexpath = './/span[contains(@class, "dcl-product-price-new")]//span[@class="a-offscreen"]/text()'
        price2xpath = './/span[contains(@class, "dcl-product-price-old")]//span[@class="a-offscreen"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
