import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class betseyjohnsondealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'betseyjohnsondeal'
    start_urls = ['https://betseyjohnson.com/collections/sale-clearance']
    Sitename = 'Betsey Johnson'
    siteurl = 'https://betseyjohnson.com'

    def start_requests(self):
        api_url = 'https://search-v3joil6oqa-uc.a.run.app/search/categories_navigation?q=&page_num=1&store_id=2371878977&UUID=dfa258f3-4309-4113-b883-8445ba08c64e&cdn_cache_key=1666350542&sort_by=relevency&facets_required=0&related_search=1&with_product_attributes=1&category_id=260925063233&category_url=%2Fcollections%2Fsale-clearance'
        yield scrapy.Request(url=api_url)

    def parse(self, response):
        for req in self.getproducts(response):
            yield req

        listing_json = json.loads(response.text)
        total_page = listing_json['total_p']

        page = 2
        while int(total_page) >= page:
            api_url = f'https://search-v3joil6oqa-uc.a.run.app/search/categories_navigation?q=&page_num={str(page)}&store_id=2371878977&UUID=dfa258f3-4309-4113-b883-8445ba08c64e&cdn_cache_key=1666350542&sort_by=relevency&facets_required=0&related_search=1&with_product_attributes=1&category_id=260925063233&category_url=%2Fcollections%2Fsale-clearance'
            yield response.follow(api_url, callback=self.getproducts, dont_filter=True)
            page += 1

    def getproducts(self, response):
        item = couponsDealsItem()

        listing_json = json.loads(response.text)
        for m in listing_json['items']:
            item['Title'] = m['l']
            item['Image'] = m['t']

            price = m['p_c']
            if price:
                item['Price'] = f"${price}"
            else:
                item['Price'] = ''

            item['SalePrice'] = f"${m['p']}"
            item['Offer'] = ''
            item['SourceUrl'] = self.siteurl + m['u']
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item
