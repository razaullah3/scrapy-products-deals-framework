from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class rawpawspetfooddealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'rawpawspetfooddeal'
    start_urls = ['https://www.rawpawspetfood.com/bundle-deals-s/449.htm?searching=Y&sort=5&cat=449&show=400']
    Sitename = 'Raw Paws Pet Food'
    siteurl = 'https://www.rawpawspetfood.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="v-product"]'
        titalxpath = './/a[contains(@class,"product__title")]/text()'
        imagexpath = './/a[@class="v-product__img"]/img/@src'
        pricexpath = '.'
        price2xpath = './/font[@class="pricecolor colors_productprice"]/div/b/text()'
        otherxpath = ''
        nextpage = '//button[@class="btn next_page_img btn-default btn-sm btn_nextpage"]/@onclick'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })