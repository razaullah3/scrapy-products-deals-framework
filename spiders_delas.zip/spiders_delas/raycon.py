from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class rayconSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'raycon'
    start_urls = ['https://rayconglobal.com/collections/special']
    Sitename = 'rayconglobal'
    siteurl = 'https://rayconglobal.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ✅ XPaths for products
        divxpath = "//div[contains(@class,'grid__wrap')]"
        titalxpath = ".//h4[@class='grid__title h3']/a/text()"
        imagexpath = ".//div[@class='grid__image--primary']/a/img[contains(@class,'grid__image')]/@data-src"

        pricexpath = ".//span[@data-product-price]//span[@class='money']/text()"
        price2xpath = ".//span[@data-product-compare-at-price]//span[@class='money']/text()"
        otherxpath = ''

        # ✅ Pagination (next page)
        nextpage = response.xpath("//link[@rel='next']/@href").get()
        if nextpage:
            if not nextpage.startswith('http'):
                nextpage = self.siteurl + nextpage

        # ✅ Send meta for Data_Collector
        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imageprefix': 'https:',  # ✅ Add https for images if missing
                'imagexpath': imagexpath,
                'sourceprefix': 'https:',  # ✅ Add https for source URLs if missing
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
