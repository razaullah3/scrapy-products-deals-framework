import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class JCrewDealsSpider(GetDealsProducts):
    name = 'jcrewdeals'
    handle_httpstatus_list = [404]
    Sitename = 'J.Crew'
    siteurl = 'https://www.jcrew.com'

    base_api = (
        "https://ac.cnstrc.com/search/deals?"
        "c=ciojs-client-2.51.0&key=key_nu9b76kKatVvDK9C"
        "&i=2123f9f7-eab1-4939-bf09-39b7109b8cc4&s=1"
        "&page={page}"
        "&num_results_per_page=60"
    )

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://factory.jcrew.com",
        "Connection": "keep-alive",
        "Referer": "https://factory.jcrew.com/",
    }

    def start_requests(self):
        url = self.base_api.format(page=1)
        yield scrapy.Request(
            url=url,
            callback=self.parse,
            headers=self.custom_headers,
            meta={'page': 1}
        )

    def parse(self, response):
        try:
            json_data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON decode failed: {e}")
            return

        results = json_data.get("response", {}).get("results", [])
        page = response.meta['page']
        self.logger.info(f"Page {page}: Found {len(results)} results")

        for r in results:  # iterate over the list
            pdata = r.get("data", {})  # data object inside each result

            item = couponsDealsItem()
            item['Title'] = r.get('value', '').strip()  # value is inside each result, not data
            item['SourceUrl'] = pdata.get('url', '')
            item['SalePrice'] = pdata.get('price', '')
            item['Price'] = pdata.get('listPrice', '')
            item['Image'] = pdata.get('image_url', '')
            item['Offer'] = ""

            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        if len(results) > 0:
            next_page = page + 1
            next_url = self.base_api.format(page=next_page)
            yield scrapy.Request(
                url=next_url,
                callback=self.parse,
                headers=self.custom_headers,
                meta={'page': next_page}
            )
