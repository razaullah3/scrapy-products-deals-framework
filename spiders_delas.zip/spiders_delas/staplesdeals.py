import scrapy
import json
import datetime
from ..items import couponsDealsItem


class StaplesDealsSpider(scrapy.Spider):
    name = "staples"
    allowed_domains = ["staples.com", "www.staples.com"]
    Sitename = "Staples"
    siteurl = "https://www.staples.com"

    def start_requests(self):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Origin": "https://www.staples.com",
            "Connection": "keep-alive",
            "DNT": "1",
            "Sec-GPC": "1",
        }

        # Staples deals API (example endpoint)
        url = "https://www.staples.com/api/v1/deals?category=all&limit=100"
        yield scrapy.Request(url=url, headers=headers, callback=self.parse)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        results = data.get("products", [])  # Adjust depending on JSON structure
        if not results:
            self.logger.info("No deals found.")
            return

        self.logger.info(f"Found {len(results)} products")

        for prod in results:
            item = couponsDealsItem()

            item["Title"] = prod.get("title", "").strip()
            item["SourceUrl"] = prod.get("product_url", "")
            item["Image"] = prod.get("image_url", "")
            item["Price"] = prod.get("regular_price", "")
            item["SalePrice"] = prod.get("sale_price", "")
            item["Offer"] = prod.get("offer", "")
            item["Framework"] = "3"
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"

            yield item
