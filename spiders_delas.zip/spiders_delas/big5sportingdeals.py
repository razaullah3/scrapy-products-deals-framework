from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class big5dealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'big5dealdeal'
    start_urls = ['https://www.big5sportinggoods.com/store/browse/_/N-aZ2Z3']
    Sitename = 'Big 5 Sporting Goods'
    siteurl = 'https://www.big5sportinggoods.com'


    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Cookie": "JSESSIONID=3cuaF4NGto9qNGIKkDppnfv_5oHSQBWJ0rPbA36X.prod_store01-2; AKA_A2=A; _ga_WPYPEBLRC8=GS2.1.s1763713365$o1$g1$t1763713366$j59$l0$h0; _ga=GA1.1.2141211558.1763713365; sailthru_pageviews=1; user-data=%7B%22cartCount%22%3A%220%22%2C%22statusValue%22%3A%222%22%2C%22firstname%22%3A%22%22%2C%22lastname%22%3A%22%22%2C%22greeting%22%3A%22%3F%3F%3Faccount.greeting%3F%3F%3F%22%7D; _gcl_au=1.1.203809169.1763713366; BVBRANDID=5dd42b5f-4116-4393-af0d-10f50b4fda71; BVBRANDSID=5dba1213-f359-4b4b-bfe6-5e0569783654; sailthru_content=d1b033e8d11333604e025c12deea75b6; sailthru_visitor=5304e7b0-6ea0-4b7b-8b57-eedacd500ba5; OptanonConsent=isGpcEnabled=1&datestamp=Fri+Nov+21+2025+13%3A22%3A50+GMT%2B0500+(Pakistan+Standard+Time)&version=202307.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=6cfefb1a-226a-4aaa-836f-39a3106c913b&interactionCount=1&landingPath=https%3A%2F%2Fwww.big5sportinggoods.com%2Fstore%2Fbrowse%2F_%2FN-aZ2Z3&groups=C0002%3A0%2CC0004%3A0%2CC0003%3A0",
        
    }


    custom_settings = {
        "DEFAULT_REQUEST_HEADERS": headers
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//ul[@class="product-grid"]/li'
        titalxpath = './/h2[@class="product-name"]/text()'
        imagexpath = './/source[@class="s-main-image lazyLoad lazy-loaded"]/@srcset'
        pricexpath = './/div[@class="original-price"]/text()'
        price2xpath = './/div[@class="sale-price"]/text() | //div[@class="supervalue-price"]/text()'
        otherxpath = './/span[@class="price-divider"]/text()'
        nextpage = '//li/a[@aria-label="Next Page"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })