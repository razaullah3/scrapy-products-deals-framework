from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy
import validators
import re
import string
from datetime import datetime
from scrapy.http import HtmlResponse


class jegsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'jegsdeal'
    start_urls = ['https://www.jegs.com/p/JEGS/JEGS-GM-Dash-Pads/9890244/10002/-1']
    Sitename = 'JEGS'
    siteurl = 'https://www.jegs.com'

    # Use the provided headers
    custom_settings = {
        'DOWNLOAD_DELAY': 2,
        'RETRY_ENABLED': True,
        'RETRY_TIMES': 5,
        'COOKIES_ENABLED': True,
        'ROBOTSTXT_OBEY': False,
        'FEED_EXPORT_ENCODING': 'utf-8',
        'DOWNLOADER_MIDDLEWARES': {
            'scrapy.downloadermiddlewares.httpcompression.HttpCompressionMiddleware': 810,
        },
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Alt-Used': 'www.jegs.com',
            'Connection': 'keep-alive',
            'Cookie': 'cf_clearance=WeLL8d8LkFDtGxo6ezjbTM8oCMyojOxj1ytqg8CfyGQ-1746762485-1.2.1.1-zsN3uQLRtxX1dcq1ovXdmvD0ixngHLFF5jsYXJd1cCsKhIfe1VXPFm5IObEKtLrGmBcUf6AfrUh05TBkNAofcXJBXpt6yCQXvPDDMGjD7zp98KN3wLWAY7V0vMRET._mtl4MlnG4Zw7aREdRx8OhKZEEu1CVCn4ELEh3YfPye9VFxy4PE.qXnzFpc5LP2mWD5ufnDoHwnLR7XP25fQ78vj4YfRTFrgwQIan.aQbNKIyBTRcidxp0njNxfLG8UyrdeBiHRK_OGSkSidc1saOC9FBigzGM1ghXHt1BBAM3s32MO7FB10V8FuClf5N4N0REgqJyv326HG2hGgXRuC0PdwXnCFR.uvRC3wcFfpJ5o9sjAjVt5liRjCV5Z8ccYE4C',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        }
    }

    def start_requests(self):
        headers = self.custom_settings.get('DEFAULT_REQUEST_HEADERS', {})

        yield scrapy.Request(
            url=self.start_urls[0],
            headers=headers,
            callback=self.parse,
            encoding='utf-8',
            meta={'handle_httpstatus_list': self.handle_httpstatus_list}
        )

    def parse(self, response):
        """Initial parse method to set up data collection"""
        self.logger.info(f"Response status: {response.status}")

        if response.status == 403 or response.status == 503:
            self.logger.error("Access denied - possible Cloudflare protection")
            return

        try:
            # Save response for debugging
            self.debug_response(response)

            # Initialize item for DB storage
            item = couponsDealsItem()
            item['getDoc'] = 'True'
            item['SiteName'] = self.Sitename
            yield item

            # Reset getDoc for subsequent items
            item['getDoc'] = ''

            # Define XPaths for data extraction
            categorypage = ''
            subcategorypage = ''
            attribute = ''
            divxpath = '//div[contains(@class, "product-grid-item") or contains(@class, "SKU-product-container")]'
            titalxpath = './/h2[contains(@class, "product-name")]/a/text() | .//div[@id="product-title-wrap"]//h2/span[2]/text()'
            imagexpath = './/img[contains(@class, "product-image")]/@src | .//div[@class="resultBgImg hp-image"]/@data-img'
            pricexpath = './/span[contains(@class, "list-price")]/text() | .//div[contains(@class,"product-cta-wrap")]//div[@id="list-price"]/text()'
            price2xpath = './/span[contains(@class, "sale-price")]/text() | .//div[contains(@class,"product-cta-wrap")]//div[@id="price"]/text()'
            otherxpath = './/span[contains(@class, "savings")]/text() | .//div[contains(@class,"product-cta-wrap")]//div[@id="price-savings"]/text()'
            nextpage = '//a[@class="arrow"]/@href'

            # Pass to Data_Collector method from parent class
            yield response.follow(
                response.url,
                callback=self.Data_Collector,
                headers=self.custom_settings.get('DEFAULT_REQUEST_HEADERS', {}),
                meta={
                    'url': self.siteurl,
                    'sname': self.Sitename,
                    'attribute': attribute,
                    'divxpath': divxpath,
                    'titalxpath': titalxpath,
                    'imagexpath': imagexpath,
                    'pricexpath': pricexpath,
                    'price2xpath': price2xpath,
                    'otherxpath': otherxpath,
                    'subcategorypage': subcategorypage,
                    'nextpage': nextpage,
                    'categorypage': categorypage
                },
                dont_filter=True
            )

        except Exception as e:
            self.logger.error(f"Failed to process response: {str(e)}")

    def debug_response(self, response):
        """Helper method to save the response HTML for debugging"""
        try:
            filename = f"debug_{self.name}.html"
            with open(filename, 'wb') as f:
                f.write(response.body)
            self.logger.info(f'Saved debug response to {filename}')

            try:
                with open(f"debug_{self.name}_text.txt", 'w', encoding='utf-8') as f:
                    if hasattr(response, 'text'):
                        f.write(response.text[:2000])  # Save first 2000 chars for inspection
                        self.logger.info(f'Saved debug text response')
                    else:
                        f.write(f"Response does not have text attribute. Headers: {response.headers}")
                        self.logger.info(f'Response does not have text attribute')
            except Exception as e:
                self.logger.error(f"Could not save text version: {str(e)}")
        except Exception as e:
            self.logger.error(f"Error saving debug file: {str(e)}")