from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class worldwidestereodealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'worldwidestereodeal'
    start_urls = ['https://www.worldwidestereo.com/categories/sale?in_stock%5B%5D=true']
    Sitename = 'World Wide Stereo'
    siteurl = 'https://www.worldwidestereo.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product-grid__cell"]'
        titalxpath = './/p[@class="product-summary__name"]//text()'
        imagexpath = './/img/@src'
        pricexpath = './/p[@class="product-summary__strike product-pricing__old"]/s[@class="product-pricing__price-digit"]/text() | .//p[@class="product-summary__strike product-pricing__old"]/s[not(@class)]/text()'
        price2xpath = './/p[@class="product-summary__price"]/span[1]/text()'
        otherxpath = ''
        nextpage = '//a[contains(@class,"pagination__button--next")]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })