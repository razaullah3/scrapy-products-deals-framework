from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class alphabetdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'tmobile'
    start_urls = ['https://www.t-mobile.com/offers?INTNAV=tNav%3ADeals%3AAll']
    Sitename = 't-mobile'
    siteurl = 'https://www.t-mobile.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '//a[contains(@data-analytics-click, "Button Click|More")]/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="upf-productCard__content"]'
        titalxpath = './/span[@class="upf-productCard__title--brand"]/text() | //h3[@class="upf-productCard__title--model"]/text()'
        imagexpath = './/img[@class="upf-productCard__image--asset"]/@src'
        pricexpath = './/span[@x-text="pricing.payInFull"]/text()'
        price2xpath = ''
        otherxpath = './/span[@class="offdisc"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })