from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class hip2saveSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'hip2save'
    start_urls = ['https://hip2save.com/']
    Sitename = 'hip2save'
    siteurl = 'https://hip2save.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ===== YOUR XPATHS HERE =====
        divxpath = '//article'  
        titalxpath = './/h5[@class="entry-title"]/a/text()'
        imagexpath = './/div[contains(@class,"post-image")]//a//img/@src'
        pricexpath = ".//*[contains(text(), '$')]/text()"   # all $ values
        price2xpath = ''  # Not available on Hip2Save posts
        otherxpath = ''   # Not available
        nextpage = '//a[@class="next page-numbers"]/@href'
        # ============================

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
