import scrapy
import datetime
from ..items import couponsDealsItem


class SlickdealSpider(scrapy.Spider):
    name = 'slickdeal'
    sitename = 'Slickdeal'
    siteurl = 'https://slickdeals.net'
    base_url = 'https://slickdeals.net/deals/'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Referer': 'https://slickdeals.net/',
        'Upgrade-Insecure-Requests': '1'
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_url,
            callback=self.parse,
            headers=self.headers,
            meta={'page': 1},
            dont_filter=True
        )

    def parse(self, response):
        current_page = response.meta.get('page', 1)
        self.logger.info(f"Processing Slickdeals page {current_page}")

        # Deals container
        deals = response.xpath('//div[@class="dealRow"]')
        if not deals:
            self.logger.warning(f"No deals found on page {current_page}")
            return

        self.logger.info(f"Found {len(deals)} deals on page {current_page}")

        for deal in deals:
            title = deal.xpath('.//div[@class="dealTitle"]//a/text()').get()
            link = deal.xpath('.//div[@class="dealTitle"]//a/@href').get()
            image = deal.xpath('.//img/@src').get()

            if link:
                deal_url = response.urljoin(link)
                yield response.follow(
                    deal_url,
                    callback=self.parse_detail,
                    headers=self.headers,
                    meta={
                        'title': title,
                        'image': image,
                        'sname': self.sitename
                    }
                )

        # Pagination
        next_page = response.xpath('//div//a[@class="button"]/@href').get()
        if next_page:
            next_page_url = response.urljoin(next_page)
            self.logger.info(f"Moving to next page: {next_page_url}")
            yield scrapy.Request(
                url=next_page_url,
                callback=self.parse,
                headers=self.headers,
                meta={'page': current_page + 1},
                dont_filter=True
            )

    def parse_detail(self, response):
        current_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Create item with defaults
        item = couponsDealsItem()
        item['Title'] = 'N/A'
        item['Description'] = 'N/A'
        item['Price'] = None
        item['SalePrice'] = None
        item['Discount'] = None
        item['Offer'] = None
        item['PercentageOff'] = None
        item['Image'] = 'N/A'
        item['Category'] = None
        item['SubCategory'] = None
        item['SubSubCategory'] = None
        item['Type'] = 'Deal'
        item['SubType'] = None
        item['Code'] = None
        item['Color'] = None
        item['Size'] = None
        item['Specs'] = None
        item['Quantity'] = None
        item['ShippingFee'] = None
        item['SiteName'] = response.meta.get('sname', self.sitename)
        item['SiteURL'] = self.siteurl
        item['SourceUrl'] = response.url
        item['StartTime'] = None
        item['EndTime'] = None
        item['DateAdded'] = current_date
        item['DateUpdated'] = current_date
        item['Status'] = 'active'
        item['ProductUrl'] = response.url
        item['ProductUrlDate'] = current_date
        item['Sold'] = None
        item['Online'] = 1
        item['City'] = None
        item['State'] = None
        item['Zip'] = None
        item['Rating'] = None
        item['PromotionalText'] = 'Deal'
        item['Framework'] = 'Scrapy'
        item['BrandName'] = None
        item['SiteType'] = 'dealsite'
        item['Logo'] = None
        item['Featured'] = 0

        # Pipeline flags
        item['dealpage'] = 'True'
        item['getDoc'] = None
        item['itempage'] = None
        item['urlpage'] = None
        item['alllogs'] = 'true'
        item['Preority'] = None

        # Fill with scraped meta
        item['Title'] = response.meta.get('title', 'N/A')
        item['Image'] = response.meta.get('image', 'N/A')

        # Extract prices
        Price = response.xpath('//h2[@class="dealDetailsMainBlock__finalPrice"]/text()').get()
        SalePrice = response.xpath('//h3[@class="dealDetailsMainBlock__listPrice"]/text()').get()

        if Price:
            item['SalePrice'] = Price.strip()
        if SalePrice:
            item['Price'] = SalePrice.strip()

        # Calculate discount percentage if both exist
        try:
            if item['Price'] and item['SalePrice']:
                regular = float(item['Price'].replace('$', '').replace(',', ''))
                final = float(item['SalePrice'].replace('$', '').replace(',', ''))
                if regular > final:
                    discount_percentage = round(((regular - final) / regular) * 100)
                    item['PercentageOff'] = discount_percentage
                    item['Discount'] = f"{discount_percentage}% OFF"
                    item['Offer'] = f"Save {discount_percentage}%"
        except Exception as e:
            self.logger.warning(f"Discount calculation failed: {e}")

        # Debug log
        self.logger.info(f"Processed deal: {item['Title']}")
        self.logger.info(f"Price: {item['Price']}, SalePrice: {item['SalePrice']}")
        self.logger.info(f"Image: {item['Image']}")
        self.logger.info(f"URL: {item['SourceUrl']}")

        yield item
