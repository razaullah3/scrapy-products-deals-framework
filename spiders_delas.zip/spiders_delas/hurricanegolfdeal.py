import scrapy
from scrapy import Request
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class hurricanegolfdealSpider(GetDealsProducts):
    handle_httpstatus_list = [403, 404]
    name = 'hurricanegolfdeal'
    start_urls = ['https://www.hurricanegolf.com/deal-of-the-week']
    Sitename = 'Hurricane Golf'
    siteurl = 'https://www.hurricanegolf.com'

    def start_requests(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Connection': 'keep-alive',
        }
        for url in self.start_urls:
            yield Request(url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        if response.status == 403:
            self.logger.error('Access Forbidden - Your IP or headers may be blocked.')
            return

        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="item last"]'
        titalxpath = './/h2/a/text()'
        imagexpath = './/a/img/@src'
        pricexpath = './/span[contains(@id,"old")]/text()'
        price2xpath = './/p[@class="special-price"]//span[@class="price"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        }, headers=self.headers, dont_filter=True)
