from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class ajmadisondealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'ajmadisondeal'
    start_urls = ['https://www.ajmadison.com/c/?q=deal&page=1']
    Sitename = 'ajmadisondeal'
    siteurl = 'https://www.ajmadison.com'

    # --------------------- CUSTOM HEADERS ---------------------
    custom_settings = {
        "DEFAULT_REQUEST_HEADERS": {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Priority": "u=0",
        }
    }
    # ----------------------------------------------------------

    def parse(self, response):
        # ----------------------- INIT ITEM -----------------------
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ----------------------- XPATHS -------------------------
        divxpath = '//div[@class="ListPage_main__VBdmx"]//article[contains(@class,"GridHit_item-wrapper")]'
        titalxpath = './/a[contains(@class,"GridItemH")]/text()'
        imagexpath = './/img[contains(@class,"ImageSection_image")]/@src'
        pricexpath = './/div[contains(@class,"GridItemHit_price-after-saving")]/text()'
        price2xpath = './/div[contains(@class,"GridItemHit_price-list__Vyv2I")]/text()'
        otherxpath = ''

        # ---------------- DATA COLLECTOR CALL ------------------
        yield response.follow(
            response.url,
            callback=self.Data_Collector,  # Scrapy automatically passes `response`
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'categorypage': categorypage
            }
        )

        # ---------------- PAGINATION ----------------------------
        # extract current page number
        try:
            current_page = int(response.url.split("&page=")[-1])
        except:
            current_page = 1

        # next page URL
        next_page_number = current_page + 1
        next_url = f"https://www.ajmadison.com/c/?q=deal&page={next_page_number}"

        # check if next page exists (optional: based on presence of products)
        has_next = response.xpath('//div[@class="ListPage_main__VBdmx"]//article[contains(@class,"GridHit_item-wrapper")]')
        if has_next:
            # generate request for next page dynamically
            yield response.follow(
                next_url,
                callback=self.parse
            )
