import scrapy
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class canondealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'canondeal'
    start_urls = ['https://www.usa.canon.com/shop/deals-home']
    Sitename = 'Canon'
    siteurl = 'https://www.usa.canon.com/'

    # ✅ Exact same headers applied globally to all requests
    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Cookie': 'mage-cache-storage=%7B%7D; is_visited=1; AKA_A2=A; _abck=3CC611ACAF8A0B0B231C00E0B2A7C2B6~-1~YAAQN54QAnkiTy+aAQAAJfiaUw4e1edAawKQxixuMXgzDGf6xwfLGvcJuAcDhkbN1jXXbo76jUb2iwPds6I2Kytbj/9HRpFdQA1desoewQxqEuePxqXgGxJHSflONseDSn0vJx1etuSGABurfnfSmUBhP/gz78BU102nhdHMh1G/ojTAe3DMGVOZyg9HjvTNUwYn/cQXPptMD5uIdsQIktEVQmJNKASXHaSjnrbFmo1LTbPve9JAhNdtLYDfMTqCe/WTD9UhJ8k183IBC5A2MOBifW6BefbAQVxoaLBVxgAdMolWSUFL2ZQLn/6Ykp73Bh17FMl2ztShOjn3J9tTDgJQnV/dVjPi+P6IyzIr0/7NB+2t8d73lR16treeq1tHAN+Yojfz8mVU70Jp6W63vcWixw7WUOsi9w9lkcNOaZCE7Ah/6CU0MvPhfuZsW50SNvOnzfTIx+q6SkdOB9294BkLCWauIZo22TeOWKt4bS05KE6PrNa2cQJ9wx8obG6+c0DomkIGQeXUDXNY5Wlmf6TL2RdZOXz1HBQ6sB1Bc3r2PiR5y8aouYjukPK3Cft3+I2z8mlAqNz8nEaO3ZDBtG5pkV3DrTtAj2WIGOVIdc8=~-1~-1~-1~AAQAAAAE%2f%2f%2f%2f%2f9CvRVvnpuA%2fmASOBuLoC3upQoxgxsHe7dQzpoXtSbvBCqrkzgkwFDl%2flE8ILjFn7WvFBQsqSRjMVPtruQnNJvlMi6XFeRf28Vg9~-1; ak_bmsc=912CBC763DD43A684CB74F4DDD1807DE~000000000000000000000000000000~YAAQN54QAn8iTy+aAQAAAvmaUx2FSu2T2GJqqD8Qj47Uxrukk6Vw9ZV7i/m3n8T2zZElHcKiN+F+vc5mlphJjk1TgGbzoK9BLVh3jwCk7/LsUiQxLLcRtiQq5jTm9wxp1xFd/FvjOuH3YmeJ/7gLcSdOkrxBqUPKhCHXW6/eg1pG/OHx5aNRyTyUjEi0+Cg/6sjze7C8Up+lTubmtw1i7HEiNU7kQ7qyxoRXwKDrzDHLmB841h7g9pzZgv5I3De2JhC4vPss8/29+5LxVgRpYwIWnFd0CYabXxm1Wr/hM0s6uzyeiIe56TWbwlJYmKSdeMnZLIJ8l/xjHa8FwE9YNEi1WOAMmBNW/f7vu1JDKu+PX7W78qKfL8o7+sejeOMPDspYZYpkUP9gr0k71afrfvV990RUxKFceM/wmgyIizuIufkeq0xl0Iq2AFchuaZaUPpb1w4Khn0LU5UcVCfnorc=; bm_sz=87AE7E90604F146F85F4A622A8564089~YAAQN54QAikiTy+aAQAAUu2aUx0ZsGkBcz+cC6gXP+wyZn/lvOE/40JA+yOtqx/Il0GEYHxAnxs3xHjAjJLVuEPQ57gSsrmPkAHm4SJ2BVaGcctVTSoPQNpsVmNIJP3n4hhrUoT/HiN4WhWeNe65gQP9W/9flddDNdaUGp/+jUh1d3Uq9C5kHKpA0DnA4QsWLpOP/xZHeb25n1xWgTuqAyL5+N9Y7580i2+3cj+mRHP1E+zbgGOLuMR7uQT60bZzNMpsaABlgkGz/Qp1SZd60aiy+YHa2IY1HupUHo/bMxInfPikz1z2kD1hHelqpbF6/+HsIU48LgUfWWaLwkZsgapMfTnHJ6d/PpEtiHeKs3hmlkrnNj4f7BfQ81KmHzr8Xu0mbQwJhiKiN8M=~4274485~3359792; at_check=true; mbox=session^#e66465a45c3b448b8b1474f7f6cb02c4^#1762341117; mage-cache-storage-section-invalidation={}; amzn-checkout-session={}',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'DNT': '1',
            'Sec-GPC': '1',
            'TE': 'trailers',
            'Priority': 'u=0, i',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = '//div[@class="tile-image-container"]/a/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-item-info"]'
        titalxpath = './/h3[@class="product name product-item-name"]/a/@title'
        imagexpath = './/span[@class="product-image-wrapper"]/picture/source[@type="image/webp"][1]/@srcset'
        pricexpath = './/span[@data-price-type="oldPrice"]/span/text() | //span[@class="price-wrapper "]/span/text()'
        price2xpath = './/span[@data-price-type="finalPrice"]/span/text()'
        otherxpath = ''
        nextpage = '//li[@class="item pages-item-next"]/a/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
