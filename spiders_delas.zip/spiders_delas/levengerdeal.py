import json
import scrapy
import datetime
import re
from ..items import couponsDealsItem


class levengerdealSpider(scrapy.Spider):
    handle_httpstatus_list = [404]
    name = 'levengerdeal'
    Sitename = 'Levenger'
    siteurl = 'https://www.levenger.com'

    # Use the confirmed working API endpoint directly
    api_endpoint = 'https://www.levenger.com/collections/clearance/products.json'

    def start_requests(self):
        self.logger.info(f"Starting Levenger deals spider with API endpoint: {self.api_endpoint}")
        yield scrapy.Request(
            url=self.api_endpoint,
            callback=self.parse_shopify_json
        )

    def parse_shopify_json(self, response):
        """
        Parse Shopify JSON response
        """
        try:
            data = json.loads(response.text)

            # Extract products data
            products = data.get('products', [])
            self.logger.info(f"Total number of products from Shopify JSON: {len(products)}")

            if not products:
                self.logger.warning("No products found in the response")
                return

            for product in products:
                # Check if the product is available
                available = False
                variants = product.get('variants', [])

                for variant in variants:
                    if variant.get('available', False):
                        available = True
                        break

                if not available:
                    continue

                item = couponsDealsItem()

                # Basic product information
                item['Title'] = product.get('title', '')

                # Handle image
                images = product.get('images', [])
                if images:
                    image_url = images[0].get('src', '')
                    # Ensure the image URL has the proper protocol
                    if image_url and image_url.startswith('//'):
                        image_url = 'https:' + image_url
                    item['Image'] = image_url
                else:
                    item['Image'] = ''

                # Price handling
                if variants:
                    price = variants[0].get('price', '0')
                    compare_price = variants[0].get('compare_at_price')

                    # Format sale price
                    item['SalePrice'] = f"${price}" if price else ''

                    # Format regular price if available
                    if compare_price:
                        item['Price'] = f"${compare_price}"
                    else:
                        item['Price'] = ''

                    # Calculate discount percentage if both prices are available
                    if compare_price and price and float(compare_price) > float(price):
                        discount = ((float(compare_price) - float(price)) / float(compare_price)) * 100
                        item['Offer'] = f"{int(discount)}% OFF"
                    else:
                        item['Offer'] = ''
                else:
                    item['Price'] = ''
                    item['SalePrice'] = ''
                    item['Offer'] = ''

                # URL handling
                handle = product.get('handle', '')
                if handle:
                    item['SourceUrl'] = f"{self.siteurl}/products/{handle}"
                else:
                    item['SourceUrl'] = ''

                # Standard fields
                item['Framework'] = '3'
                item['SiteName'] = self.Sitename
                item['SiteURL'] = self.siteurl
                item['DateAdded'] = datetime.datetime.now()
                item['DateUpdated'] = datetime.datetime.now()
                item['dealpage'] = 'True'

                yield item

            # Check if there are more pages by paginating through the Shopify API
            if products:
                # Get the current page number from the URL
                current_page = 1
                if 'page=' in response.url:
                    current_page = int(response.url.split('page=')[1].split('&')[0])

                # Try fetching the next page
                next_page = current_page + 1
                next_page_url = f'{self.api_endpoint}?page={next_page}'

                self.logger.info(f"Fetching next page: {next_page}")

                yield scrapy.Request(
                    url=next_page_url,
                    callback=self.parse_shopify_json,
                    dont_filter=True
                )

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse Shopify JSON response: {e}")
            self.logger.error(f"Response text: {response.text[:200]}...")  # Log part of the response for debugging

        except Exception as e:
            self.logger.error(f"Error processing Shopify JSON response: {e}")
            import traceback
            self.logger.error(traceback.format_exc())