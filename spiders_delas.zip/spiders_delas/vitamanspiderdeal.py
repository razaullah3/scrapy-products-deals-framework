import json
import scrapy
import datetime
from ..items import couponsDealsItem

class VitaminShoppeSpider(scrapy.Spider):
    name = 'vitaminshoppe_deals'
    Sitename = 'VitaminShoppe'
    siteurl = 'https://www.vitaminshoppe.com'
    start_urls = [
        'https://browse.vitaminshoppe.com/search/product/search?preferredStoreId=562&homeStore=false&path=/cl/clearance&sessionId=&format=json&rpp=200&desktopView=true&start=0'
    ]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://www.vitaminshoppe.com/',
        'Origin': 'https://www.vitaminshoppe.com',
        'Connection': 'keep-alive'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get('response', {}).get('products', [])
        self.logger.info(f"Found {len(products)} products on this page.")

        for p in products:
            item = couponsDealsItem()
            item['Title'] = p.get('displayName', '').strip()
            item['Image'] = p.get('imageUrl', '')
            pdp_url = p.get('pdpUrl', '')
            item['SourceUrl'] = self.siteurl + pdp_url if pdp_url else self.siteurl
            price_info = p.get('price', {})
            item['Price'] = price_info.get('listPrice')
            item['SalePrice'] = price_info.get('salePrice')
            item['Framework'] = '3'
            item["Offer"] = ''
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
       
