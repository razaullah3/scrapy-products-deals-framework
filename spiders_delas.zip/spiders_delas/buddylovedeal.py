from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class buddylovedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'buddylovedeal'
    start_urls = ['https://buddylove.com/collections/sale']
    Sitename = 'BuddyLove'
    siteurl = 'https://buddylove.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="filters-adjacent collection-listing"]/div/product-block'
        titalxpath = './/div[@class="product-block__title"]/text()'
        imagexpath = './/div[1]/div[1]/div[1]/a/div[1]/div[1]/div[1]/div[1]/img/@src'
        pricexpath = './/div/div/span[@class="price__was"]/text()'
        price2xpath = './/div[@class="price__default"]/span[1]/text()'
        otherxpath = ''
        nextpage = '//link[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
