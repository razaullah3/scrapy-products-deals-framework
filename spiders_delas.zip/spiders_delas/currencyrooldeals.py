
            
        

import scrapy
import json
import datetime
from ..items import couponsDealsItem


class CrunchyrollClearanceSpider(scrapy.Spider):
    name = "crunchyroll"
    allowed_domains = ["store.crunchyroll.com"]
    Sitename = "Crunchyroll"
    siteurl = "https://store.crunchyroll.com"

    limit = 48
    offset = 0

    def start_requests(self):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "correlation-id": "4b33b709-7db7-40fa-be93-e2cb3181ce61",
            "Authorization": "Bearer eyJ2ZXIiOiIxLjAiLCJqa3UiOiJzbGFzL3Byb2QvYmRnY19wcmQiLCJraWQiOiI0NDNkYzZkZi00ZjBmLTQ4ZjAtYmRiMi0yMjQ5MDcwZGFhZTciLCJ0eXAiOiJqd3QiLCJjbHYiOiJKMi4zLjQiLCJhbGciOiJFUzI1NiJ9.eyJhdXQiOiJHVUlEIiwic2NwIjoic2ZjYy5zaG9wcGVyLW15YWNjb3VudC5iYXNrZXRzIHNmY2Muc2hvcHBlci1kaXNjb3Zlcnktc2VhcmNoIGNfdGhpbmtfYW5hbHl0aWNzIHNmY2Muc2hvcHBlci1teWFjY291bnQucGF5bWVudGluc3RydW1lbnRzIHNmY2Muc2hvcHBlci1jdXN0b21lcnMubG9naW4gc2ZjYy1zaG9wcGVyLWNvbnRleHQucncgY19jb250ZW50U2xvdHNfciBjX21lcmdlV2lzaGxpc3Qgc2ZjYy5vcmRlcnMgc2ZjYy5zaG9wcGVyLWV4cGVyaWVuY2Ugc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5vcmRlcnMgc2ZjYy5zaG9wcGVyLXByb2R1Y3RsaXN0cyBzZmNjLnNob3BwZXItY3VzdG9tLW9iamVjdHMgc2ZjYy5zaG9wcGVyLXByb21vdGlvbnMgc2ZjYy5zZXNzaW9uX2JyaWRnZSBzZmNjLm9yZGVycy5ydyBlbWFpbF9zZW5kIHNmY2Muc2hvcHBlci1teWFjY291bnQucGF5bWVudGluc3RydW1lbnRzLnJ3IGNfYXBwcm9hY2hpbmdwcm9tbyBjX2NvbnRlbnRfc2xvdCBzZmNjLnNob3BwZXItbXlhY2NvdW50LnByb2R1Y3RsaXN0cyBzZmNjLnNob3BwZXItY2F0ZWdvcmllcyBzZmNjLnNob3BwZXItbXlhY2NvdW50IHNmY2Muc2hvcHBlci1teWFjY291bnQuYWRkcmVzc2VzIHNmY2Muc2hvcHBlci1wcm9kdWN0cyBjX2N1c3RvbWVyX29yZGVycyBzZmNjLnNob3BwZXItbXlhY2NvdW50LnJ3IGNfZ2VvX2NvdW50cnkgc2ZjYy5zaG9wcGVyLXN0b3JlcyBjX2N1c3RvbWVyR3JvdXBzX3Igc2ZjYy5wd2RsZXNzX2xvZ2luIHNmY2Muc2hvcHBlci1jb250ZXh0LnJ3IGNfY3VzdG9tX29iamVjdHMgc2ZjYy5zaG9wcGVyLWJhc2tldHMtb3JkZXJzIHNmY2Muc2hvcHBlci1jdXN0b21lcnMucmVnaXN0ZXIgY19jb250ZW50X2Fzc2V0IHNmY2Muc2hvcHBlci1teWFjY291bnQuYWRkcmVzc2VzLnJ3IHNmY2Muc2hvcHBlci1teWFjY291bnQucHJvZHVjdGxpc3RzLnJ3IGNfc3NvX2xvZ2luIGNfcG9wdWxhcl9zdWdnZXN0aW9uIHNmY2Muc2hvcHBlci1iYXNrZXRzLW9yZGVycy5ydyBzZmNjLnNob3BwZXItZ2lmdC1jZXJ0aWZpY2F0ZXMgc2ZjYy5zaG9wcGVyLXByb2R1Y3Qtc2VhcmNoIHNmY2MudHNfZXh0X29uX2JlaGFsZl9vZiBjX2N1c3RvbWVyX2dyb3VwIGNfcmVkZWVtR2lmdENlcnRpZmljYXRlIGNfbWVyZ2Vfd2lzaGxpc3QiLCJzdWIiOiJjYy1zbGFzOjpiZGdjX3ByZDo6c2NpZDoxYWM3NDUzYS1hNjNjLTRlNjAtOTdkMy1mZWNiOTdmMmFlYzA6OnVzaWQ6NjNmNjgxYzAtNjM4MS00MmNlLThiOWEtZGQwYjc5NWRlNTU4IiwiY3R4Ijoic2xhcyIsImlzcyI6InNsYXMvcHJvZC9iZGdjX3ByZCIsImlzdCI6MSwiZG50IjoiMCIsImF1ZCI6ImNvbW1lcmNlY2xvdWQvcHJvZC9iZGdjX3ByZCIsIm5iZiI6MTc2MTExMDM0Nywic3R5IjoiVXNlciIsImlzYiI6InVpZG86c2xhczo6dXBuOkd1ZXN0Ojp1aWRuOkd1ZXN0IFVzZXI6OmdjaWQ6YmNsSGxLbEhFVndYYVJsSGsya3FZWWtLbEo6OmNoaWQ6Q3J1bmNoeXJvbGxVUyIsImV4cCI6MTc2MTExMjE3NywiaWF0IjoxNzYxMTEwMzc3LCJqdGkiOiJDMkMtMTA1NDk5NDMxNTA4NjM2NzM4OTIzNDE5Njk4NTQzNDkxNzY0In0.4E7-VcY0y7z22cFfQlwLqbv-c5erGeHiGMWGFqEDvkcAKV8AzcZhaxcfd3lcoEiPPJrKxb_AjmdnDACCJO-8Jg",
            "Connection": "keep-alive",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "DNT": "1",
            "Sec-GPC": "1",
            "Priority": "u=0",
        }
        url = self._build_api_url(self.offset)
        yield scrapy.Request(url=url, headers=headers, callback=self.parse, meta={"offset": self.offset})

    def _build_api_url(self, offset):
        return (
            f"https://store.crunchyroll.com/mobify/proxy/api/search/shopper-search/v1/"
            f"organizations/f_ecom_bdgc_prd/product-search"
            f"?siteId=CrunchyrollUS"
            f"&refine=cgid%3Dclearance-sale"
            f"&sort=best-matches"
            f"&currency=USD"
            f"&locale=en-US"
            f"&expand=promotions%2Cvariations%2Cprices%2Cimages%2Ccustom_properties"
            f"&allImages=true&perPricebook=true&allVariationProperties=true"
            f"&offset={offset}&limit={self.limit}"
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        hits = data.get("hits", [])
        if not hits:
            self.logger.info("No more products — stopping pagination.")
            return

        self.logger.info(f"Fetched {len(hits)} products at offset {response.meta['offset']}")

        for product in hits:
            try:
                # --- Basic Info ---
                image_data = product.get("image", {})
                title = image_data.get("title") or product.get("productName", "")
                image = image_data.get("link", "")

                rep = product.get("representedProduct", {})
                url_name = rep.get("c_urlName", "")
                product_id = product.get("productId", "")
                source_url = f"https://store.crunchyroll.com/products/{url_name}-{product_id}.html"

                # --- Robust Price Extraction ---
                list_price, sale_price = self._extract_prices(product)

                item = couponsDealsItem()
                item["Title"] = title.strip()
                item["SourceUrl"] = source_url
                item["Image"] = image
                item["Price"] = list_price
                item["SalePrice"] = sale_price
                item["Offer"] = ""
                item["Framework"] = "3"
                item["SiteName"] = self.Sitename
                item["SiteURL"] = self.siteurl
                item["DateAdded"] = datetime.datetime.now()
                item["DateUpdated"] = datetime.datetime.now()
                item["dealpage"] = "True"

                yield item

            except Exception as e:
                self.logger.error(f"Error parsing product: {e}")

        # --- Pagination ---
        next_offset = response.meta["offset"] + self.limit
        next_url = self._build_api_url(next_offset)
        yield scrapy.Request(
            url=next_url,
            headers=response.request.headers,
            callback=self.parse,
            meta={"offset": next_offset},
        )

    def _extract_prices(self, product):
        """More fault-tolerant price extraction logic"""
        list_price = sale_price = None

        # 1️⃣ Try priceRanges first
        price_ranges = product.get("priceRanges", [])
        for pr in price_ranges:
            pb = pr.get("pricebook", "")
            if "list" in pb:
                list_price = pr.get("maxPrice") or pr.get("minPrice")
            elif "sale" in pb:
                sale_price = pr.get("maxPrice") or pr.get("minPrice")

        # 2️⃣ Fallback: use 'price' field (single product price)
        if not sale_price and product.get("price"):
            sale_price = product.get("price")

        # 3️⃣ Fallback: check variants' tiered prices
        if not list_price or not sale_price:
            variants = product.get("variants", [])
            for variant in variants:
                for tp in variant.get("tieredPrices", []):
                    pb = tp.get("pricebook", "")
                    if "list" in pb and not list_price:
                        list_price = tp.get("price")
                    elif "sale" in pb and not sale_price:
                        sale_price = tp.get("price")

        # 4️⃣ Final fallback: If still None, use max/min of any numeric prices found
        if not list_price or not sale_price:
            possible_prices = []
            for pr in price_ranges:
                possible_prices.extend([pr.get("maxPrice"), pr.get("minPrice")])
            numeric_prices = [p for p in possible_prices if isinstance(p, (int, float))]
            if numeric_prices:
                if not sale_price:
                    sale_price = min(numeric_prices)
                if not list_price:
                    list_price = max(numeric_prices)

        # 5️⃣ Clean up — ensure sale <= list
        if sale_price and list_price and sale_price > list_price:
            sale_price, list_price = list_price, sale_price

        return list_price, sale_price


       