import scrapy
import re
import json
import datetime
from ..items import couponsDealsItem


class SuperheroStuffDealSpider(scrapy.Spider):
    name = 'superherostuffdeal'
    sitename = 'SuperHeroStuff'
    siteurl = 'https://www.superherostuff.com'

    # Remove start_urls as we'll be generating them dynamically
    # Start with page 1 and increment until no products found
    base_url = 'https://www.superherostuff.com/clearance-sale.html'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Connection': 'keep-alive',
        'Referer': 'https://www.superherostuff.com/',
        'Cache-Control': 'max-age=0',
        'Upgrade-Insecure-Requests': '1'
    }

    def start_requests(self):
        # Start with page 1
        url = f"{self.base_url}?current_page=1"
        yield scrapy.Request(
            url=url,
            callback=self.parse,
            headers=self.headers,
            meta={
                'dont_redirect': False,
                'handle_httpstatus_list': [302, 403, 404],
                'page': 1  # Add page number to meta
            },
            dont_filter=True
        )

    def parse(self, response):
        # Extract the data from the app div
        data_page_attr = response.xpath('//div[@id="app"]/@data-page').get()
        current_page = response.meta.get('page', 1)

        if data_page_attr:
            try:
                # Parse JSON from the data-page attribute
                data = json.loads(data_page_attr)

                # Log the structure for debugging
                self.logger.info(f"Processing page {current_page}")
                self.logger.info(f"Top level keys: {list(data.keys())}")
                if 'props' in data:
                    self.logger.info(f"Props keys: {list(data['props'].keys())}")

                # Products are directly in data['props']['products']['hits']
                products = []
                if 'props' in data and 'products' in data['props'] and 'hits' in data['props']['products']:
                    products = data['props']['products']['hits']

                # If we didn't find products in the expected location, log and return
                if not products:
                    self.logger.warning(f"No products found on page {current_page}, stopping pagination")
                    return

                self.logger.info(f"Found {len(products)} products on page {current_page}")

                # Base URL for images
                image_base_url = "https://d1f322m3y2l5v3.cloudfront.net/products/thumbs/"
                current_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                for product in products:
                    # Create a new item for each product
                    item = couponsDealsItem()

                    # Fill all required fields with default values first
                    # This ensures no fields are missing
                    item['Title'] = 'N/A'
                    item['Description'] = 'N/A'
                    item['Price'] = None
                    item['SalePrice'] = None
                    item['Discount'] = None
                    item['Offer'] = None
                    item['PercentageOff'] = None
                    item['Image'] = 'N/A'
                    item['Category'] = None
                    item['SubCategory'] = None
                    item['SubSubCategory'] = None
                    item['Type'] = 'Clearance'
                    item['SubType'] = None
                    item['Code'] = None
                    item['Color'] = None
                    item['Size'] = None
                    item['Specs'] = None
                    item['Quantity'] = None
                    item['ShippingFee'] = None
                    item['SiteName'] = self.sitename
                    item['SiteURL'] = self.siteurl
                    item['SourceUrl'] = 'N/A'
                    item['StartTime'] = None
                    item['EndTime'] = None
                    item['DateAdded'] = current_date
                    item['DateUpdated'] = current_date
                    item['Status'] = 'active'
                    item['ProductUrl'] = None
                    item['ProductUrlDate'] = current_date
                    item['Sold'] = None
                    item['Online'] = 1
                    item['City'] = None
                    item['State'] = None
                    item['Zip'] = None
                    item['Rating'] = None
                    item['PromotionalText'] = 'Clearance Sale'
                    item['Framework'] = 'Scrapy'
                    item['BrandName'] = None
                    item['SiteType'] = 'ecommerce'
                    item['Logo'] = None
                    item['Featured'] = 0

                    # Additional fields required by pipeline
                    item['dealpage'] = 'True'  # Set to 'True' to upload as a deal product
                    item['getDoc'] = None
                    item['itempage'] = None
                    item['urlpage'] = None
                    item['alllogs'] = 'true'  # Set to log statistics
                    item['Preority'] = None

                    # Now extract and set specific product data
                    item['Title'] = product.get('name', 'N/A')

                    # Get description if available
                    description = product.get('description', 'N/A')
                    item['Description'] = description if description else 'N/A'

                    # Handle pricing
                    regular_price = product.get('price')
                    sale_price = product.get('sale_price')
                    final_price = product.get('final_price')

                    # Set Price and SalePrice
                    if sale_price is not None and sale_price != regular_price:
                        item['Price'] = regular_price
                        item['SalePrice'] = final_price

                        # Calculate percentage off if both prices exist
                        if regular_price and final_price:
                            try:
                                discount_percentage = round(((regular_price - final_price) / regular_price) * 100)
                                item['PercentageOff'] = discount_percentage
                                item['Discount'] = f"{discount_percentage}% OFF"
                                item['Offer'] = f"Save {discount_percentage}%"
                            except (TypeError, ZeroDivisionError):
                                pass
                    else:
                        item['Price'] = regular_price
                        item['SalePrice'] = final_price

                    # If one of the prices is None, set both to ensure they're not None
                    if item['Price'] is None:
                        item['Price'] = 0
                    if item['SalePrice'] is None:
                        item['SalePrice'] = item['Price']

                    # Category information
                    item['Category'] = product.get('category_name', 'N/A')

                    # Try to get subcategory if available
                    subcategory = product.get('subcategory_name', None)
                    if subcategory:
                        item['SubCategory'] = subcategory

                    # Brand information
                    item['BrandName'] = product.get('primary_brand_item_name', 'N/A')

                    # Available sizes
                    sizes = product.get('sizes', [])
                    if sizes:
                        item['Size'] = ', '.join(sizes)

                    # Colors if available
                    colors = product.get('colors', [])
                    if colors:
                        item['Color'] = ', '.join(colors)

                    # Quantity
                    item['Quantity'] = product.get('qty', 0)

                    # Rating
                    review_avg = product.get('review_avg')
                    review_count = product.get('review_count')
                    if review_avg and review_count:
                        item['Rating'] = f"{review_avg}/5 ({review_count} reviews)"

                    # Construct image URL
                    photo_url = product.get('photo_url', '')
                    if photo_url:
                        item['Image'] = f"{image_base_url}{photo_url}"

                    # Construct product URL (SourceUrl)
                    slug = product.get('slug', '')
                    if slug:
                        item['SourceUrl'] = f"{self.siteurl}/{slug}"
                        item['ProductUrl'] = item['SourceUrl']  # Also set ProductUrl

                    # Log key fields for debugging
                    self.logger.info(f"Processing product: {item['Title']}")
                    self.logger.info(f"Price: {item['Price']}, Sale Price: {item['SalePrice']}")
                    self.logger.info(f"Image: {item['Image']}")
                    self.logger.info(f"URL: {item['SourceUrl']}")

                    # Yield the item for the pipeline to process
                    yield item

                # If we have products, there might be more pages to scrape
                # Move to the next page
                next_page = current_page + 1
                next_page_url = f"{self.base_url}?current_page={next_page}"

                self.logger.info(f"Moving to next page: {next_page_url}")

                yield scrapy.Request(
                    url=next_page_url,
                    callback=self.parse,
                    headers=self.headers,
                    meta={
                        'dont_redirect': False,
                        'handle_httpstatus_list': [302, 403, 404],
                        'page': next_page
                    },
                    dont_filter=True
                )

            except json.JSONDecodeError as e:
                self.logger.error(f"Failed to parse JSON on page {current_page}: {e}")

            except Exception as e:
                self.logger.error(f"An unexpected error occurred on page {current_page}: {e}")
                self.logger.error(f"Exception details: {str(e)}")

        else:
            self.logger.error(f"No data-page attribute found in the app div on page {current_page}")