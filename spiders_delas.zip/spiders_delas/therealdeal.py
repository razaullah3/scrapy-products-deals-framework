import scrapy

from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class therealdsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'therealdeal'
    start_urls = ['https://www.therealreal.com/products?keywords=deals']
    Sitename = 'Therealdeal'
    siteurl = 'https://www.therealreal.com'

    # Define the custom headers
    custom_headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, headers=self.custom_headers)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        # Define your XPath expressions
        divxpath = '//div[@class="product-card-wrapper js-product-card-wrapper"]'
        titalxpath = './/div[@class="product-card-images "]/img[1]/@alt'
        imagexpath = './/div[@class="product-card-images "]/img[1]/@src'
        pricexpath = './/div[@class="product-price-info__strike-through-price"]/text()'
        price2xpath = './/div[@class="product-price-info__reduced-price"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.custom_headers,
            meta={
                'categorypage': categorypage,
                'subcategorypage': subcategorypage,
                'attribute': attribute,
                'url': self.siteurl,
                'sname': self.Sitename,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'nextpage': nextpage
            },
            dont_filter=True
        )
