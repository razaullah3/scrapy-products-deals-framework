from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class unshydealSpider(GetDealsProducts):
    name = 'unshydeal'
    start_urls = ['https://unshy.com/collections/clothing-under-10', 'https://unshy.com/collections/flash-sale']
    Sitename = 'UnShy'
    siteurl = 'https://unshy.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="row webkit-row"]/div'
        titalxpath = './/h4/a/text()'
        imagexpath = './/img[1]/@data-src'
        pricexpath = './/span[@class="money compare-price"]/text()'
        price2xpath = './/span[@class="money"]/text()'
        otherxpath = ''
        nextpage = '//span[@class="next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })