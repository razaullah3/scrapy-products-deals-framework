import scrapy
import json
import datetime
from ..items import couponsDealsItem


class AeoClearanceSpider(scrapy.Spider):
    name = 'aeo_clearance'
    handle_httpstatus_list = [404]

    # Base API URL
    base_url = 'https://www.ae.com/ugp-api/cstr/v1/search?query=clearance&resultsPerPage=60&us=ae'

    # Custom headers (exactly as provided)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.ae.com/us/en/s/clearance",
        "aelang": "en_US",
        "aesite": "AEO_US",
        "authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ1MW01N0RmbXRjNXd5b1FHX1Y2bWdEaFdVWVVFcW40bUtCa29zWWxtR25NIn0.eyJleHAiOjE3NjEyMTIzMjQsImlhdCI6MTc2MTIxMDUyNCwianRpIjoiN2E0Zjg4YzAtY2IyOC00ZGI3LThhNDYtYmNkMjkzNWQ3ODNhIiwiaXNzIjoiaHR0cHM6Ly9hdXRoLmFlLmNvbS9yZWFsbXMvQUdXQSIsInN1YiI6IjJiNzBmM2FiLTZlMTktNGY5My1hMDQ5LTQxNTA4YWYyYmNiNyIsInR5cCI6IkJlYXJlciIsImF6cCI6IjIwZTQyNjkwLTg5M2EtNDgwMy04OWU3LTg5YmZiNGViZjJmZSIsInNjb3BlIjoiIiwib3JkZXJJZCI6WyIzMmEwZjAyMy00N2ExLTRmMTItODBiMC1lOGYyMzE1YWM5MmUiXSwicHJvZmlsZUlkIjpbIjk5OTJiM2U0LWU1OTUtNDU0MS04ZTIyLTRkNjk3NGU0ODMwNCJdLCJ1c2VyX2NyZWF0ZWRfYXQiOjE3NTgxNjQwMjAzOTAsInNjb3BlIjoiZ3Vlc3QifQ.RJN2BCV0jrJNypw3Hm7T3kGMRDzZX8qzqMUjpjab5ljkhKzHta9QoYcjhqfrOIhIbAm6vYfaBZVEysrtgTWw7zfRo5lVI7WNmXQbvCQ9017KHkn0NxnJ7DnDS5YhfuREYpuxvEUPAsPOmjXBbB4RUjp8YqVGWs_SAbdN-BQ7-BLwV33uuBj-PkqnGDLJ0SFHwnkOnFmoHUuioshz0WrLr_QtCPMSkp0VXxA4CFJ0SbN9ngvdUEviC_Ma4B9iObnGsEPP6cxu7Gl_utLabUuAjqd9GDbZ91FASkKRhKBHaZ1PtnpJ273kMUgpyKK-wzj8Wdvcbw-xCadh9BWNsz80og",
        "content-type": "application/json",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    def start_requests(self):
        """Start with page 1"""
        url = f"{self.base_url}&page=1"
        yield scrapy.Request(
            url=url,
            headers=self.headers,
            callback=self.parse,
            meta={'page': 1}
        )

    def parse(self, response):
        """Parse API JSON response"""
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON response")
            return

        included = data.get('included', [])
        self.logger.info(f"Found {len(included)} products on page {response.meta.get('page')}")

        for product in included:
            attributes = product.get('attributes', {})
            prices = attributes.get('prices', {})

            item = couponsDealsItem()
            item['Title'] = attributes.get('displayName', '')
            item['SourceUrl'] = "https://www.ae.com" + attributes.get('productUrl', '')
            item['Image'] = attributes.get('imageUrl', '')
            item['Price'] = prices.get('maxListPrice', '')
            item['SalePrice'] = prices.get('maxSalePrice', '')

            # Metadata
            now = datetime.datetime.now()
            item['Framework'] = '3'
            item['Offer'] = ''
            item['SiteName'] = 'American Eagle'
            item['SiteURL'] = 'https://www.ae.com/'
            item['DateAdded'] = now
            item['DateUpdated'] = now

            # Pipeline flags
            item['dealpage'] = 'True'
            item['getDoc'] = 'True'
            item['itempage'] = 'false'
            item['urlpage'] = 'false'
            item['alllogs'] = 'false'
            item['Category'] = 'Clearance'
            item['SubCategory'] = ''

            yield item

        # Pagination logic — continue while results are returned
        page = response.meta.get('page', 1)
        if included:  # if page still has results
            next_page = page + 1
            next_url = f"{self.base_url}&page={next_page}"
            yield scrapy.Request(
                url=next_url,
                headers=self.headers,
                callback=self.parse,
                meta={'page': next_page}
            )
