import scrapy
import json
import datetime
from ..items import couponsDealsItem


class WilliamsSonomaDealSpider(scrapy.Spider):
    name = 'williams_sonoma_deal'

    # Base API endpoint (you can adjust offset dynamically)
    base_api = (
        "https://ac.cnstrc.com/browse/group_id/view-all-sale?"
        "c=ciojs-client-2.66.0&key=key_PysinTjKriGSD1Zl&i=c7d62711-a6f0-444a-a44f-8e7c11e96eb1&s=1"
        "&offset={offset}&num_results_per_page=20&&sort_order=descending"
        "&fmt_options%5Bhidden_facets%5D=smartDeskFeatures"
        "&pre_filter_expression=%7B%22or%22%3A%5B%7B%22or%22%3A%5B%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A0711%22%7D%2C%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A0950%22%7D%2C%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A6298%22%7D%2C%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A6310%22%7D%5D%7D%2C%7B%22or%22%3A%5B%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_CMO%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_SS%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DEFAULT%22%7D%5D%7D%5D%7D&_dt=1761816953255"
    )

    batch_size = 20

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.williams-sonoma.com/",
        "Origin": "https://www.williams-sonoma.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4",
        "TE": "trailers",
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_api.format(offset=0),
            method="GET",
            headers=self.custom_headers,
            callback=self.parse,
            meta={"offset": 0},
        )

    def parse(self, response):
        offset = response.meta.get("offset", 0)

        try:
            data = json.loads(response.text)
            results = data.get("response", {}).get("results", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        total_products = 0
        for product in results:
            total_products += 1
            data_field = product.get("data", {})
            yield self.extract_product_item(data_field)

        # Pagination — continue if there were results
        if total_products > 0:
            next_offset = offset + self.batch_size
            next_url = self.base_api.format(offset=next_offset)
            yield scrapy.Request(
                url=next_url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse,
                meta={"offset": next_offset},
            )

    def extract_product_item(self, data):
        """Extract product data into couponsDealsItem"""
        item = couponsDealsItem()

        # Required fields
        item['SourceUrl'] = data.get("url", "")
        item['Title'] = data.get("title", "")
        item['SalePrice'] = data.get("salePriceMax", "")
        item['Price'] = data.get("regularPriceMax", "")
        item['Image'] = data.get("leaderSkuImage", "")

        # Optional calculated discount
        try:
            sale = float(data.get("salePriceMax", 0))
            reg = float(data.get("regularPriceMax", 0))
            if reg > sale > 0:
                discount = round(((reg - sale) / reg) * 100, 1)
                item['Offer'] = f"{discount}% off"
            else:
                item['Offer'] = ""
        except:
            item['Offer'] = ""

        # Static metadata
        item['SiteName'] = "Williams Sonoma"
        item['SiteURL'] = "https://www.williams-sonoma.com"
        item['Framework'] = "3"
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = "True"

        return item
