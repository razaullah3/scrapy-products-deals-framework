from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
from scrapy import Request

class stethoscopedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'stethoscopedeal'
    start_urls = ['https://www.stethoscope.com/other-products/deal-of-the-day/']
    Sitename = 'Stethoscope'
    siteurl = 'https://www.stethoscope.com'

    def start_requests(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Referer": "https://www.stethoscope.com/",
            "Connection": "keep-alive",
        }

        for url in self.start_urls:
            yield Request(url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'true'  # Fixed case
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//ul[contains(@class, "productGrid")]/li'  # Updated XPath
        titalxpath = './/h4[@class="card-title"]/a/text()'  # Updated XPath
        imagexpath = './/a[@class="image-link desktop"]/img[1]/@src'  # Updated XPath
        pricexpath = ''  # Updated XPath
        price2xpath = './/span[contains(@class, "price--withoutTax")]/text()'  # Updated XPath
        otherxpath = ''
        nextpage = response.xpath('//a[contains(@class, "pagination-next")]/@href').get()  # Pagination

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        }, headers=self.headers, dont_filter=True)

        # Follow next page if it exists
        if nextpage:
            yield response.follow(nextpage, callback=self.parse, headers=self.headers)