import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class BuybuybabydealsSpider(GetDealsProducts):
    name = 'buybuybabydeals'
    start_urls = ['https://buybuybaby.bedbathandbeyond.com/On-Sale,/sale,/results.html']
    sitename = 'buybuy BABY'
    siteurl = 'https://buybuybaby.bedbathandbeyond.com'  # Fixed base URL

    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Cookie': 'bm_ss=ab8e18ef4e; _abck=A9259A3F92A456AB07E9CAA89D3C39BD~0~YAAQiWvcF5qNaCyZAQAAi6cbLg7cPK5J2o0hIEjbe7u3TukS7PWhVuDrZmsi8pZU//M6R0H+gAdQXpfbrw9PoyyX5FGmmCxN2tfRhw/cJ2d6ZOJORo7g0jPAacSMmtG8piOBd33eM8W02C/Q5NO5RjtZxMsLUeAEWp1xEfC57tEAkQn0aRQuUmAV+IvJN8ZBrpdWat3EltDyxyFYkq9dyJSjAuuDxKLd5kzHPbL/jxs7nLMIyvGrI6cWwOIcVaU8F/Jdaoz70PzETukKZv3v/GqsIY+1ZJRKoeZq4g9cADh9ql7qqWPlXFjy1zRag2OEP2badPQ/YmlqPjmAdJSauE2pU5L6BjLiSbYclISeuLlLSYTI5qT8nx8RBGBOqpmGxRjQHeIwN+BrGwV5uJfIaeqbuEPZ7eHYI13m46lbUZj9U5AITwY2IByMyc2HuNE3X8BRRyiz0fgITn1FXp1bKutpULx6WUvOWtJ2KgmX2Ll6S2VFjoTJGzz6mXC6AVVcno9ooD3eDOi2FtwiECIibaJkV5XrjST0IKgrwVw15dbk0h9Hi7siGJhCavR7T0PfOfWNuf99MO52Ab0cYjvh9p4c+3GxGBwlqY2ucWnJcaUkMAB5NS4iNw/Cn+VfdPkRYfo87ekmvxqiuLfnNdGR4//la4mmJO9v~-1~-1~-1~~; ak_bmsc=6F20F805562E6FE72F30EA1150E92658~000000000000000000000000000000~YAAQiWvcFy98aCyZAQAA318bLh1Tkvn0YM7Rs2DvBhFdDVhkmzJ1U5Tv91x6udMbC/lSRNprDj964BaAGK5rAcIxGSoOfWNqDYCn5rI0BEyQP0vhGrZntTOl4gT++zw0Exr013ZFt+Xpt4oFeFPRNh4UIE5DLK/yiATmELXyjYz18ZO2gFdYbRh3r/4N/TJ+O4VSKF1KFxRK7PYBP2oZs12mm2iJAUGGqXFF9LP4Hqw8Nj34CFOK+8DGdCY1EJ+KISX+lz4bTbqHKSAgI7p4hVPl6lGaEaAyxGYwD2XuehjInOpIbUKupSASefmSYv339ye3BS8QiyqdWD2ThP9kOKPMBbHen0BhyXHUcN2MmYmAk/D9eVl6QmKe5YBP+vM7eKnSdhIlwpxFWNeu1Z10/hcO5qTpaoJWO8ZfY+G4AYkztmBAfh3G8bAOaACxdGxlbP1IDOk2qGAhwSV1T3A8V483+e3ftryoFC4IMAC7bgWv8P1rcFmcHMC5XAGjVc6QEh9k+fOUAaZBu+UYOURxvqRQZgVF; bm_s=YAAQiWvcFwZ6aCyZAQAAk1UbLgSvqn7Bi7AEIpAymzpL+1d3fUVo3lUE2rK7RK2RiFTnXP64EDZN7YzJ3Ng530Ki8CHgcvZfRkY1K4i2DiAPNEEM+h8T30VlEox6eCGrpbOT7zGH8cvLA7XZOVG9GBxgbhGkt2sU/UbGWCsMklC8wqsZMrtccxmiqdPmPMDg+coKApe7UGNmFBfifxv4G5siGmsZzUxPQyyLVmqXWpE8yU6zL/wsdwXi4GkT74l03pcwyxFnYHEY4cCSglecgi1C+Ght95Cm/MybNkdNFgToPZR5NMxuZvV06mhitOMKjx5En2U4nkw20lbHI27HfpF+cfzmTxRJlbAfCkxNWA3aRbXw2T8C5yEMrEvAlnG0q5yVkuqfRG3FqrKYzdwAlHYcM+NKgXZjlzcwlMpoezCEvbGOKysWGVaDxGrCi9Du288YHGtwcvTRZJOxXnFFiHchJehK+OQrG7IQfqFCr0uto+rHFB/7/tBr7N+LMkCrc4FeivFwHP+oLsj3znX4Lh0VGxoBgpZHCZwW0BuOj35cVGq6uVIeYK7/QX7XgMQA2RZZAWXxAfbRKDoFCc2wZDM=; bm_so=8391C425485A80AC21817EB05FB2EA7A5840E038432553AB7FE24FC5FE8AEB72~YAAQiWvcF+11aCyZAQAAbT8bLgSXPeyCilLiUrNFc7Dg7sfx06FFoHVKQC5WlQKbYVGq3KGah51YNVClxbtvf0oLuT2v9yLcHsYyn/67vSmkKVKlFGOClIE5lSRpKl+Ttv/xGlk2rWqtoZr5ACzOS5FR+tAb6rBualkX9BGuw8fNGOgsS7X6tDigqOdtA+iEylv/qZfb+gDDpNRp+V3+9GKYnyAqN14McUG57sqWDIBKzfUdnEZlkGt8FNbERF6Rxih9BYgAzxylg0JViOTsnEBU67RsNsPPCn59gRSag/LbC2UKq+D1ute04FbEwFZ7Q1Em9S40W5MrZTlCVqaVguCtaiJOGTV9bZm/miG6ryKgPPFpn15SyvBmBka+QTTKRjZIGw0kySxNdjcKtty8oSEVzMXJHA0p0St4nG5VHqG0RVKRSNmb7T2eCxzPHWQLOJ9k3vZYGN/W1xxs2XqXcQAE4SQwGwU2; bm_sz=3D2CB0AEDC7AB43A34F48BC0CB4F75DC~YAAQiWvcFwl6aCyZAQAAk1UbLh3EoJOhMOGl4pEED9sjcoNNO9Rf4pKJXy3JuIWNX1ZIOrE66SZlq4KTJggfieh6Xhzlbh7G1RKHSMcoKij1qrVOlwQCCncSMe8lxFDBvVqTRs5YVvvIx0V2911yxqZvYwZClSDfQPcusf9k6leWzVRwhl9DVEQPaTby/aS2dKgMLVucBty5Y+I8XHcVPwPnK3dpetdeppD7yoF4TTE0huu3wBzKUcPoq650WcyVbu2cqJn9sr1s8BhLqBwpYXRgyggrWyl6wi1MM6KV5kJiYxtC06LcPnoVQ0rkligEULoVe+sIHSBpyEliJbs0QQsCN6iqEe1Eds5t8PZIgGFrCcfSHBFA4ghaE80AQGDrorMwie1tXF8eJx1KILDNQZM8ZXzHMskaYWb31WY=~4273206~4604486; mxclastvisit=20250909; ostk_aggr_year=country^US|currency^USD|language^en|mxcuserseed^4918344614801193701; ostk_aggr_session=sessstrt^1757415166810|billingcountry^US|gcr^false|cart.item-count^0|dlp^k|postal^56972; ostk_campaign=""; se_list=se_list^0|2|181|55|; ostk_aggr_year2=""; mxcsurftype=2; bm_mi=F5042A9AC63358EA4D774AAABA27339D~YAAQiWvcFwV6aCyZAQAAk1UbLh15smRjPcJK0LmBkQzUrgCEfU8Wcd4AmJsSxqwyExOjY4nbvTS3/MRw+Al1gXkz9PFPF2UgufRdao6ElXJixspdkCu36TBPaElM6Y0VqMQEU1VSs82RjSbX3G2cA7b+uT41+K0UxBlnJGf5FEfMJj7UMSwP9xgcHao4E5Vg4bDy/1HD2HfAa0jZhjObT0uergFJg4NB99WdZoKd3c17OJ7piWFAAaseOikk2ZGTP+aqyfrsipJnYG+lS8lpAKlv+bk1eq3hW4EPO/XbFXHLyWi2uCi5rEs6WdE1Iw8OhtOkW4dwNVW0N5m+m9LT7Z18/uCl3pj5hVztO4oPyqx6lw==~1; bm_sv=4BF82ACC622349314B83480A44B814FF~YAAQiWvcFwh6aCyZAQAAk1UbLh1mmoKg9iI/Y4z1yAwVRkfSEeG3zzNTWyNhZ7DzT96V/iKCTuxKmaK0fjD6xeFRQiZlbF/M6d0sPxJQnZ+s8am37Tb9V3g4DOmRXmuud/QdDbUmowv850gQinnMZvjj2lQwPbr36mlMuL90B/zVb6+z4kaAgcTogPdRTBBnOC9QxaY7p6MSls34nirswComK2GBthqWuwO6FCtzkjaOze6qpL5mPpCKZ6n0NV+U4lGJgb46dkPNdg==~1; _gcl_au=1.1.1331878806.1757415171; _ga_8MPQ3CZZFH=GS2.1.s1757415171^$o1^$g0^$t1757415242^$j60^$l0^$h303223824; _ga=GA1.1.445902614.1757415171; FPID=FPID2.2.dSA8gzJwlnJpL4vycLgbT9J6WMNwz0gEBaU08d6Wmuw%3D.1757415171; FPLC=bEh09il%2BGzJ4aQE8dUn5Wr7mNKOsXzHkzUl6VmdtIk74Zl9aTHhqDdAaPMCHy0d0pSM3Xp55TNJWsbXJsw7R19%2Fqp5vLRPLXlWKLdGdFeUgJlC9Rf5FG9alEJO0BjA%3D%3D; FPGSID=1.1757415170.1757415242.G-8MPQ3CZZFH.r87s97Sj7F36UBCjKaUT0A; FPAU=1.1.1331878806.1757415171; _gtmeec=e30%3D; _fbp=fb.1.1757415174716.89659265849999756',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Priority': 'u=0, i',
        }
    }

    def parse(self, response):
        self.logger.info(f"Parsing URL: {response.url}")
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.sitename
        yield item

        # Define xpath configurations for data extraction
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//article[@class="productTile_productTile__fCG1W"]'
        titalxpath = './/div[@class="title_wrapper__NBeDj"]/p/text()'
        imagexpath = './/img[@class="progressiveImageLoader_img__gxTI_ progressiveImageLoader_loaded__g9tpd"]/@src'
        pricexpath = './/span[@class="compPriceTooltipTrigger price_comparisonPrice__Ll1XF price_hasTooltip__YNPKN"]/text()'
        price2xpath = './/div[@class="currentPrice price_price__RsJly price_sale__nO5AK"]/text()[3]|//div[@class="currentPrice price_price__RsJly"]/text()[1]'
        otherxpath = ''
        nextpage = ''  # Dynamic next page selector

        # Process first page
        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage,
        }, dont_filter=True)

        # Handle pagination dynamically
        next_page_url = response.xpath(nextpage).get()
        if next_page_url:
            yield response.follow(next_page_url, callback=self.parse, meta={
                'url': self.siteurl,
                'sname': self.sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
            }, dont_filter=True)