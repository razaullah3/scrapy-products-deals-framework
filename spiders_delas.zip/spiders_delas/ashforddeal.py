import scrapy
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class acmetoolsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [403, 404]
    name = 'acmetoolsdeal'
    start_urls = ['https://www.acmetools.com/all/?q=clearance+']
    Sitename = 'acmetools'
    siteurl = 'https://www.acmetools.com'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Connection": "keep-alive",
        "Cookie": "__pr.phnvs9=FP3MbWfwMs; _gcl_au=1.1.1932192647.1763614196; ...",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "Priority": "u=0, i",
        "TE": "trailers"
    }

    custom_settings = {
        "PLAYWRIGHT_BROWSER_TYPE": "chromium",
        "PLAYWRIGHT_DEFAULT_NAVIGATION_TIMEOUT": 0,
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
            "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
        },
        "TWISTED_REACTOR": "twisted.internet.asyncioreactor.AsyncioSelectorReactor",
        "DOWNLOAD_DELAY": 1
    }

    def parse(self, response):
        # Step 1: Yield doc info
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # Step 2: Define XPaths
        divxpath = '//div[@class="row equal-height product-grid m-md-0"]//div[@class="col-6 col-sm-4 col-lg-3 px-1"]'
        titalxpath = './/h3[@class="tile-title"]/a/text()'
        imagexpath = './/img[@class="tile-image"]/@src'
        pricexpath = './/span[@class="sales"]/text()[2]'
        price2xpath = './/span[@class="list was"]/span[@class="value"]/text()'
        otherxpath = ''
        nextpage = '//span[@class="pagination-btn-wrapper"]/a/@href'

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # Step 3: Send request to Data_Collector via Playwright with headers
        yield scrapy.Request(
            url=response.url,
            callback=self.Data_Collector,
            meta={
                'playwright': True,
                'playwright_include_page': True,
                'playwright_page_methods': [
                    ("set_extra_http_headers", [self.headers])
                ],
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
