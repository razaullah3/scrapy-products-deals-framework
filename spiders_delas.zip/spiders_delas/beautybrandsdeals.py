from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class beautybrandsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'beautybrandsdeal'
    start_urls = ['https://www.beautybrands.com/category/sale.do']
    Sitename = 'Beauty Brands'
    siteurl = 'https://www.beautybrands.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="col-6 col-sm-4"]/div'
        titalxpath = './/a[@class="link"]/text()'
        imagexpath = './/img[@class="product-tile-image tile-image lazyautosizes lazyloaded"]/@srcset'
        pricexpath = './/del[@class="strike-through list"]/span/text()'
        price2xpath = './/span[@class="sales sale-price"]/span/text()'
        otherxpath = ''
        nextpage = '//li[@class=" ml-paging-default"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })