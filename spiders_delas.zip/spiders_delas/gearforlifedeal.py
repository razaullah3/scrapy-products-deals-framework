from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class gearforlifedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'gearforlifedeal'
    start_urls = ['https://gearforlife.com/all/']
    Sitename = 'Gear For Life'
    siteurl = 'https://shop.gearforlife.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-item"]'
        titalxpath = './/h3[@class="product-item__title h5"]/a/@aria-label'
        imagexpath = './/figure[@class="product-item__img"]/a/img/@src'
        pricexpath = ''
        price2xpath = './/span[@class="price price--withoutTax"]/text()'
        otherxpath = ''
        nextpage = '//div[@class="pagination__next "]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
