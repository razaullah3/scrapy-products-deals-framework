from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class logitechdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'logitechdeal'
    start_urls = ['https://www.logitechg.com/en-us/shop/gaming-deals']
    Sitename = 'Logitechg'
    siteurl = 'https://www.logitechg.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '(//section[@class="product-grid mb-8"]/div)[1]/article'
        titalxpath = './/h2[contains(@class, "heading2 brand-title-case")]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="line-through text-gray-360 font-normal"]/text()[1]'
        price2xpath = './/div[@class="flex gap-2 "]/span[1]'
        otherxpath = './/div[@class="text-success font-bold uppercase"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })