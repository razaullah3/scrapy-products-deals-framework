from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class magiccabindealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'makemehealdeal'
    start_urls = ['https://makemeheal.com/collections/all-products']
    Sitename = 'Make Me Heal'
    siteurl = 'https://www.makemeheal.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-item product-item--vertical   1/3--tablet-and-up 1/4--desk"]'
        titalxpath = './/a[@class="product-item__title text--strong link"]/text()'
        imagexpath = './/img[@class="product-item__primary-image"]/@src'
        pricexpath = './/span[@class="price price--compare"]/text()[2]'
        price2xpath = './/div[@class="product-item__price-list price-list"]/span[@class="price price--highlight"]/text()[2] | //div[@class="product-item__price-list price-list"]/span[@class="price"]/text()[2]'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })