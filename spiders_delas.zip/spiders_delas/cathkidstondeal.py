import json
import re
import scrapy
import datetime
from ..items import couponsDealsItem


class NextDealSpider(scrapy.Spider):
    handle_httpstatus_list = [404, 403, 302, 301]
    name = 'cathkidstondeal'
    allowed_domains = ['next.co.uk']
    start_urls = ['https://www.next.co.uk/clearance/search?w=*']
    sitename = 'Next'
    siteurl = 'https://www.next.co.uk'

    # Items per page on Next website
    items_per_page = 24

    # Add custom settings for output
    custom_settings = {
        'FEEDS': {
            'next_products.json': {
                'format': 'json',
                'encoding': 'utf8',
                'indent': 4,
                'overwrite': True,
            }
        },
        'LOG_LEVEL': 'INFO',
        'DOWNLOAD_DELAY': 2,  # Add delay to avoid being blocked
        'ROBOTSTXT_OBEY': False,
        'DOWNLOADER_MIDDLEWARES': {
            'couponsDeals.middlewares.CustomProxyMiddleware': 100,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 110,
        },
        'ITEM_PIPELINES': {
            'couponsDeals.pipelines.CouponsdealsPipeline': 300,
        }
    }

    def start_requests(self):
        """Start requests with additional settings for proxy compatibility"""
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                callback=self.parse,
                meta={'dont_redirect': True, 'handle_httpstatus_list': self.handle_httpstatus_list},
                errback=self.errback_httpbin
            )

    def errback_httpbin(self, failure):
        """Handle request failures"""
        self.logger.error(f"Request failed: {failure}")

    def parse(self, response):
        """Parse the clearance page and extract product data"""
        # First check if we got a valid response
        if response.status != 200:
            self.logger.error(f"Got non-200 response: {response.status}")
            return

        # Extract the JavaScript containing the results JSON
        script_content = response.xpath("//script[contains(., 'saleclearance.pageState.results')]/text()").get()

        # Extract total number of products for pagination
        total_results_match = re.search(r'saleclearance\.pageState\.filters_TotalResults\s*=\s*(\d+)\s*;',
                                        response.text, re.DOTALL)

        total_products = 0
        if total_results_match:
            total_products = int(total_results_match.group(1))
            self.logger.info(f"Total products found: {total_products}")
        else:
            self.logger.warning("Could not find total number of products")

        # Process pagination
        current_page = self.get_current_page(response.url)
        self.logger.info(f"Processing page {current_page}")

        # Generate URLs for next pages if we have total products
        if total_products > 0:
            total_pages = (total_products + self.items_per_page - 1) // self.items_per_page
            self.logger.info(f"Total pages to scrape: {total_pages}")

            # Queue up the next page if there are more pages
            if current_page < total_pages:
                next_page_offset = current_page * self.items_per_page
                next_page_url = f"https://www.next.co.uk/clearance/search?w=*&srt={next_page_offset}"
                self.logger.info(f"Queueing next page: {next_page_url}")
                yield scrapy.Request(
                    url=next_page_url,
                    callback=self.parse,
                    meta={'dont_redirect': True, 'handle_httpstatus_list': self.handle_httpstatus_list},
                    errback=self.errback_httpbin
                )

        if not script_content:
            self.logger.error("Could not find script containing product data")
            return

        # Extract the results array using regex - more specific pattern
        results_match = re.search(r'saleclearance\.pageState\.results\s*=\s*(\[.*?\]);', script_content, re.DOTALL)

        if not results_match:
            self.logger.error("Could not extract JSON data with regex")
            return

        # Clean the JSON string
        json_str = results_match.group(1).strip()

        try:
            # Parse the JSON
            products_data = json.loads(json_str)
            self.logger.info(f"Found {len(products_data)} products on page {current_page}")

            # Process all products and yield couponsDealsItem for each
            for product in products_data:
                # Skip None products or products without required fields
                if not product or not isinstance(product, dict):
                    self.logger.warning("Skipping invalid product")
                    continue

                if 'Name' not in product:
                    self.logger.warning("Skipping product without a name")
                    continue

                item = couponsDealsItem()

                # Make sure all required fields are initialized
                self.initialize_item_fields(item)

                # Map Next product data to couponsDealsItem fields
                # Basic product information
                item['Title'] = product.get('Name', '')
                item['Description'] = product.get('Composition', '')

                # Handle price fields
                self.handle_price_fields(item, product)

                # Handle image URL
                image_url = product.get('SearchImage', '')
                if image_url:
                    item['Image'] = f"{self.siteurl}{image_url}"
                else:
                    item['Image'] = ''

                # URL handling
                item_number = product.get('ItemNumber', '')
                item['SourceUrl'] = f"{self.siteurl}/{item_number}" if item_number else ''

                # Handle brand name
                item['BrandName'] = product.get('Brand', 'Next')

                # Handle category
                item['Category'] = 'Clearance'
                if product.get('Departments') and len(product.get('Departments')) > 0:
                    item['SubCategory'] = product.get('Departments')[0]
                else:
                    item['SubCategory'] = ''

                # Set type for pipeline processing
                item['Type'] = 'Clearance'
                item['SubType'] = 'Deal'

                # Additional fields required by pipeline
                item['Framework'] = '3'
                item['SiteName'] = self.sitename
                item['SiteURL'] = self.siteurl
                item['DateAdded'] = datetime.datetime.now()
                item['DateUpdated'] = datetime.datetime.now()
                item['dealpage'] = 'True'
                item['itempage'] = 'False'  # Make sure this is set
                item['urlpage'] = 'False'  # Make sure this is set
                item['Status'] = 'Active'
                item['Code'] = ''
                item['PromotionalText'] = f"{item['Title']} - Now {item['SalePrice']}" if item['SalePrice'] else item[
                    'Title']
                item['StartTime'] = datetime.datetime.now()
                item['EndTime'] = datetime.datetime.now() + datetime.timedelta(days=30)  # Assume deals last 30 days
                item['Preority'] = '1'
                item['Featured'] = '1'
                item['City'] = ''
                item['alllogs'] = 'false'  # Changed from 'true' to avoid logging issues

                # Only yield if we have a valid title and price
                if item['Title'] and (item['Price'] or item['SalePrice']):
                    yield item

            # Create log item only on the first page
            if current_page == 1:
                self.create_log_item()

        except json.JSONDecodeError as e:
            self.logger.error(f"Error parsing JSON: {e}")
            # Log a sample of the problematic JSON string for debugging
            self.logger.error(f"Problematic JSON string sample: {json_str[:200]}...")

    def get_current_page(self, url):
        """
        Determine current page number from URL
        Page 1: No srt parameter
        Page 2: srt=24
        Page 3: srt=48
        and so on...
        """
        srt_match = re.search(r'srt=(\d+)', url)
        if not srt_match:
            return 1
        else:
            offset = int(srt_match.group(1))
            return (offset // self.items_per_page) + 1

    def create_log_item(self):
        """Create a log item to be sent to the pipeline"""
        try:
            log_item = couponsDealsItem()
            # Initialize all item fields first
            self.initialize_item_fields(log_item)

            # Then set specific fields needed for logging
            log_item['SiteName'] = self.sitename
            log_item['SiteURL'] = self.siteurl
            log_item['alllogs'] = 'true'
            log_item['getDoc'] = 'true'
            log_item['dealpage'] = 'False'
            log_item['itempage'] = 'False'
            log_item['urlpage'] = 'False'

            # Set default values for numeric fields to avoid SQL errors
            log_item['Preority'] = '0'
            log_item['Featured'] = '0'
            log_item['DateAdded'] = datetime.datetime.now()
            log_item['DateUpdated'] = datetime.datetime.now()
            log_item['Status'] = 'Log'
            log_item['Title'] = f"Log item for {self.sitename}"

            return log_item
        except Exception as e:
            self.logger.error(f"Error creating log item: {e}")
            return None

    def handle_price_fields(self, item, product):
        """Process price-related fields from the product data"""
        # Price handling
        current_price = product.get('Price', '')
        was_price = product.get('WasPrice', '')

        # Handle case where main price is missing or zero
        if not current_price or current_price == '0' or current_price == 0:
            if product.get('ItemOptions') and len(product.get('ItemOptions')) > 0:
                current_price = product.get('ItemOptions')[0].get('Price', '')

        # Was price handling
        if not was_price or was_price == '0' or was_price == 0:
            if product.get('ItemOptions') and len(product.get('ItemOptions')) > 0:
                was_price = product.get('ItemOptions')[0].get('WasPrice', '')

        # Format price strings
        item['Price'] = f"£{was_price}" if was_price else ''
        item['SalePrice'] = f"£{current_price}" if current_price else ''

        # Calculate discount
        discount = ''
        discount_pct = 0
        if product.get('SavingsPercentage'):
            discount_pct = product.get('SavingsPercentage')
            discount = f"{discount_pct}% off"
        elif was_price and current_price:
            try:
                sale_price = float(current_price)
                original_price = float(was_price)
                if original_price > 0:  # Prevent division by zero
                    discount_pct = int(((original_price - sale_price) / original_price) * 100)
                    discount = f"{discount_pct}% off"
            except (ValueError, TypeError):
                self.logger.warning("Could not calculate discount percentage")

        item['Offer'] = discount
        item['Discount'] = discount
        item['PercentageOff'] = str(discount_pct) if discount_pct else ''

    def initialize_item_fields(self, item):
        """Initialize all fields in the item to ensure none are missing"""
        # Initialize all fields with empty strings
        for field in item.fields:
            if field not in item or item[field] is None:
                item[field] = ''