from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class sauconydealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'sauconydeal'
    start_urls = ['https://www.saucony.com/en/sale/?rst=clearance']
    Sitename = 'Saucony deal'
    siteurl = 'https://www.saucony.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile"]'
        titalxpath = './/h3[@role="presentation"]/a/text()'
        imagexpath = './/div[@class="main-image"]//img/@src'
        pricexpath = './/div[@class="product-pricing "]/span'
        price2xpath = './/span[@class="product-sales-price"]/text()[2]'
        otherxpath = '.'
        nextpage = '//div[@class="load-more-row"]//button[contains(@class,"load-more-cta")]/@data-grid-url'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })