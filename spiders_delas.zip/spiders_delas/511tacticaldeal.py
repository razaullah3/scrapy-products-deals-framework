from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class five0netacticaldealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = '511tacticaldeal'
    start_urls = ['https://www.511tactical.com/deeper-deals/all-deals.html']
    Sitename = '511 Tactical '
    siteurl = 'https://www.511tactical.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[contains(@class, "item product product-item")]'
        titalxpath = './/a[@class="product-item-link"]/text()'
        imagexpath = './/img[@class="lazyload product-image-photo"]/@data-src'
        pricexpath = './/span[@data-price-type="oldPrice"]/span/text()'
        price2xpath = './/span[@data-price-type="finalPrice"]/span/text()'
        otherxpath = './/div[@class="special-price-label"]/text()'
        nextpage = '(//a[@title="Next"])[2]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })