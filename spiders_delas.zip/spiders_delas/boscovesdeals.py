import json
import scrapy
import datetime
from ..items import couponsDealsItem


class BoscovsApiSpider(scrapy.Spider):
    name = "boscovsapi"

    # ===============================
    # FULL API (NO PARAM SPLITTING)
    # ===============================
    api_url = (
        "https://search.unbxd.io/e01284e312492ace50b6cadeb566e72d/"
        "boscovs-com811221579175852/category?"
        "p-id=categoryPathId%3A%22999002897%22&facet.multiselect=true&variants=true&"
        "variants.fields=title,v_imageUrl&variants.count=1&variants.groupBy=price&"
        "fields=name,isbundle,uniqueId,price_min,boscovsexclusive,madeinusa,"
        "more_colors_available,was_price_min,imageUrl,productUrl,rating,numberreviews,"
        "saleBadge,sku,styleCode,hoverImageUrl,maxLinenLoverPrice,price_max,was_price_max,"
        "promotion_message,alternate_images&spellcheck=true&pagetype=boolean&rows=36&"
        "start={}&version=V2&uc_param=undefined&viewType=GRID&facet.version=V2"
    )

    # ===============================
    # REQUIRED CUSTOM HEADERS
    # ===============================
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.boscovs.com/",
        "unbxd-device-type": "Desktop",
        "Origin": "https://www.boscovs.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4",
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.api_url.format(0),
            headers=self.custom_headers,
            callback=self.parse_api,
            meta={"page": 0}
        )

    def parse_api(self, response):
        data = json.loads(response.text)

        products = data.get("response", {}).get("products", [])
        page = response.meta["page"]

        for p in products:
            item = couponsDealsItem()

            # Required mappings
            item["Title"] = p.get("name", "")

            # alternate_images → images
            item["Image"] = p.get("alternate_images", [])

            # Main image from imageUrl
            

            # price_max → saleprice
            item["SalePrice"] = p.get("price_max")

            # was_price_max → price
            item["Price"] = p.get("was_price_max")

            # Source URL
            prod = p.get("productUrl", "")
            item["SourceUrl"] = f"https://www.boscovs.com/{prod}"
            item["Offer"] = ""
            item["SiteURL"] = "https://www.boscovs.com"
            item["Framework"] = "3"
            item["SiteName"] = "Boscovs"
            item["dealpage"] = "True"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()

            yield item

        # ===============================
        # PAGINATION – loop until no products
        # ===============================
        if len(products) == 36:  # API returns 36 per page
            next_page = page + 1
            yield scrapy.Request(
                url=self.api_url.format(next_page),
                headers=self.custom_headers,
                callback=self.parse_api,
                meta={"page": next_page}
            )
