from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class comfrtSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'comfrt'
    start_urls = ['https://comfrt.com/collections/all-products']
    Sitename = 'comfrt'
    siteurl = 'https://comfrt.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # XPaths
        divxpath = '//div[@class="tSvIqLRS"]'
        titalxpath = './/div[@class="b1hb0tgk"]/text()'
        imagexpath = './/div[@class="tK5FSRVg"]//img/@src'
        pricexpath = './/span[@data-is-on-sale]/text()'
        
price2xpath = './/span[@class="PtH37qZj"]/text()'
       