from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bandteesdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bandteesdeal'
    start_urls = ['https://www.band-tees.com/tag/clearance/']
    Sitename = 'Band-Tees'
    siteurl = 'https://www.band-tees.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//ul[@class="products columns-3"]/li'
        titalxpath = './/h2/text()'
        imagexpath = './/img/@src'
        pricexpath = ''
        price2xpath = './/span[@class="woocommerce-Price-amount amount"]/bdi/text()'
        otherxpath = ''
        nextpage = '//a[@class="next page-numbers"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })