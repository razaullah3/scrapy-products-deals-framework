import scrapy
import json
import datetime
from ..items import couponsDealsItem

class jcpenneySpider(scrapy.Spider):
    name = 'jcpenney'
    allowed_domains = ['jcpenney.com']
    start_urls = [
        'https://search-api.jcpenney.com/v1/search-service/g/shops/shop-all-products?productGridView=medium&s1_deals_and_promotions=SALE&id=cat1007450013&responseType=organic&geoZip=77096'
    ]

    Sitename = 'JCPenney'
    siteurl = 'https://www.jcpenney.com'

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.jcpenney.com/",
        "X-CHANNEL": "desktop",
        "Origin": "https://www.jcpenney.com",
        "Connection": "keep-alive",
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, headers=self.custom_headers, callback=self.parse)

    def parse(self, response):
        self.logger.info(f"Response Status: {response.status}")

        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"❌ JSON parsing failed: {e}")
            return

        products = data.get("organicZoneInfo", {}).get("products", [])
        total_products = 0

        for p in products:
            item = couponsDealsItem()
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['Framework'] = "3"
            item['Offer'] = ""
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = "True"

            # Product info
            item['Title'] = p.get("name", "").strip()
            item['SalePrice'] = p.get("currentMin", "")
            item['Price'] = p.get("originalMin", "")
            item['SourceUrl'] = self.siteurl + p.get("pdpUrl", "")
            
            # Images (thumbnail)
            images_info = p.get("imagesInfo", {})
            thumb_image = images_info.get("thumbnailImageId", "")
            if thumb_image:
                item['Image'] = f"https://jcpmedia.com/is/image/jcp/{thumb_image}"
            else:
                item['Image'] = ""

            # Print extracted data
            print("\n====== Extracted Product ======")
            print(f"Title: {item['Title']}")
            print(f"Price: {item['Price']}")
            print(f"SalePrice: {item['SalePrice']}")
            print(f"Thumbnail: {item['Image']}")
            print(f"PDP: {item['SourceUrl']}")
            print("==============================\n")

            yield item
            total_products += 1

        self.logger.info(f"✅ Extracted {total_products} products from API.")
