from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class goodbuygearSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'goodbuygear'
    start_urls = ['https://goodbuygear.com/collections/all']
    Sitename = 'goodbuygear'
    siteurl = 'https://goodbuygear.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # No category or attribute pages
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ---------------------------
        # 🔥 UPDATED XPATHS 🔥
        # ---------------------------
        divxpath = '//div[@class="productitem__container"]'
        titalxpath = './/h2[@class="productitem--title"]/a/text()[1]'
        imagexpath = './/img[@class="productitem--image-primary"]/@src'
        pricexpath = './/div[contains(@class,"price__current price__current")]//span[@class="money"]/text()'
        price2xpath = './/div[@class="price__compare-at visible"]//span[@class="money price__compare-at--single"]/text()'
        otherxpath = ''   # No other provided
        nextpage = '//a[@aria-label="Go to next page"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
