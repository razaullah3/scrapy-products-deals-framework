from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class FirstLiteSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'firstlite'
    start_urls = ['https://firstlite.com/collections/deals']
    Sitename = 'firstlite'
    siteurl = 'https://firstlite.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # XPaths based on your input
        divxpath = '//div[@class="product-list__inner"]//product-item[contains(@class, "product-item")]'
        titalxpath = './/div[@class="product-item-meta"]/a/text()'
        imagexpath = './/div[@class="product-item__image-wrapper "]//img[1]/@srcset'
        pricexpath = './/span[@class="price price--highlight"]/b/text()'
        price2xpath = './/span[contains(@class, "price--compare")]/text()[normalize-space()]'
        otherxpath = ''  # agar koi discount ya extra info chahiye to yahan add karein
        nextpage = ''  # agar pagination handle karni hai to xpath ya url add karein

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
