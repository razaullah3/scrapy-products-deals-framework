import scrapy
import json
import datetime
from ..items import couponsDealsItem

class KohlsSaleSpider(scrapy.Spider):
    name = 'kohls_sale'
    allowed_domains = ['kohls.com', 'media.kohlsimg.com']
    start_urls = [
        "https://www.kohls.com/catalog/sale.jsp?CN=Promotions:Clearance+Promotions:Sale&BL=y&cc=sale-TN1.0-S-saleclearance&kls_sbp=46114374748850251376332475284176254297&PPP=48&WS=48&S=1&ajax=true"
    ]

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.kohls.com/",
        "Connection": "keep-alive"
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse
            )

    def parse(self, response):
        try:
            data = json.loads(response.text)
            products = data.get("products", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        if not products:
            self.logger.warning("No products found on this page.")
            return

        for product in products:
            # Loop through color variations
            for color in product.get("swatchImages", []):
                item = self.extract_product_item(product, color)
                print(json.dumps(dict(item), indent=4, default=str))  # optional debug print
                yield item

    def extract_product_item(self, product, color):
        """Extract individual product variant info."""
        item = couponsDealsItem()

        # --- Basic Info ---
        item['Title'] = product.get("productTitle", "")
        item['SiteName'] = "Kohls"
        item['SiteURL'] = "https://www.kohls.com"
        item['Framework'] = "3"
        item['dealpage'] = "True"
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()

        # --- Pricing ---
        prices = product.get("prices", [])
        if prices:
            sale_price = prices[0].get("salePrice", {})
            regular_price = prices[0].get("regularPrice", {})
            item['SalePrice'] = f"{sale_price.get('minPrice')} - {sale_price.get('maxPrice')}"
            item['Price'] = f"{regular_price.get('minPrice')} - {regular_price.get('maxPrice')}"
            item['Offer'] = prices[0].get("priceLabel", "")

        # --- Images ---
        img_url = color.get("URL") or product.get("image", {}).get("url", "")
        item['Image'] = img_url

        # --- Color ---
        

        # --- Product URL ---
        item['SourceUrl'] = f"https://www.kohls.com{product.get('seoURL', '')}"

        return item
