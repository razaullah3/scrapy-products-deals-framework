from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class secondswingdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'secondswingdeal'
    start_urls = ['https://www.2ndswing.com/catalogsearch/result/?q=deal']
    Sitename = ' 2nd Swing '
    siteurl = 'https://www.2ndswing.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//ol/li[@class="item product product-item"]'
        titalxpath = './/div[@class="p-title"]  | //div[@class="pmp-product-category"]/text()'
        imagexpath = './/img[@class="product-image-photo"]/@src'
        pricexpath = './/div[@class="was-price"]/span/span/text()'
        price2xpath = './/div[@class="current-price"]/span/text()  | //div[@class="prod-rate-price lone-price"]/span/text('
        otherxpath = ''
        nextpage = '(//a[@class="action  next"])[2]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })