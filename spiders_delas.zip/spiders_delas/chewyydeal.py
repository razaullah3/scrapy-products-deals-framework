from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class chewydealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'chewydealdeal'
    start_urls = ['https://www.chewy.com/deals/todays-deals-2723']
    Sitename = 'Chewy deal'
    siteurl = 'https://www.chewy.com/'

    headers = {

            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "DNT": "1",
            "Sec-GPC": "1",
            "Priority": "u=0, i",
            "Cookie": 'KP_UIDz-ssn=03nLUG9Ah5y928g68bD6zxkL2rPbL2NoJPxvQUULg3a17qkZUcXEC5FAkbWJyPEmucKvuEZyv8rML46J318zScAMhCJYeRAEa5J35Bn9ThTh4IfCgmQMlx7sPRz42dBYYbbhykrSQERsr8karOE7nqA9cp3WzDgBcDvoqEFAsXEgsN6vmo; KP_UIDz=03nLUG9Ah5y928g68bD6zxkL2rPbL2NoJPxvQUULg3a17qkZUcXEC5FAkbWJyPEmucKvuEZyv8rML46J318zScAMhCJYeRAEa5J35Bn9ThTh4IfCgmQMlx7sPRz42dBYYbbhykrSQERsr8karOE7nqA9cp3WzDgBcDvoqEFAsXEgsN6vmo; device-id=616cd734-a0e1-43be-954f-01d4f6b4ec02; _abck=7820B99A9FC9DCC4E5B3C49AFE1173DF~-1~YAAQyCXAF0okHYeaAQAApdKkmw6cn+7SPvFX8XuTSxvPAOKFj3TiXri+L/AP3zPPK696VD0RtilErBpqfe/g/TSThYVhZGkm70iPTkAJRsDjBwl8imlo7jYgwsgMdw9cEpPFDdTvEW9ekkwMqV/a8zdbrTtCJyRGBHO/V/obbh23jEwCrzyIVzzm5qKPhG7w1I94F1W9YrAjYl3hbKyGbsl/m0NoQLG8pCwYK6r0eKJ/XUX7hw9nUS67cjpvXZmCELyfb6ibsIoZFEB4wmtmnFaH36Or3LX0TqEjcJFKFFWfbZr9NfE4xDBU12gxSpJ5yZpJOgIlQgU2u0A0sfmEkCPEjlNE/8Fxg0Hilfzp2kBH3p7KtEhiKjt87hafO61+dHQJA0qHg3y/lah2TK7q6OygClV41IX/sOQ4i8O9OnracUZ2pp8uYb/M6e4U0R+eGnzZB4qN6MynjaWeF67Cs4kWT+4iVBC5CFNFBugI2VXhWCwpjb5Ff7yuuNM2bb1rHCnMqrwHaKXGXU4RFmR6MeWNKb+Obyhhhx7fp/YmQFhrii9IwVscfkzrdcCsXcPdaUaltOCsr2epwGuf5ZmoUQL8zWF/rY/zYr43UPkcgexwqMbKXfv0OzGuhorI/xL8MSqBHolUvStynoe7uLStAyv7c304beNaRcQ=~-1~-1~1763551105~AAQAAAAE%2f%2f%2f%2f%2f7yvZvszuaqdrnueNAhV%2fj8sUSEXXr3SOSWyXVzCcEcsf9oN1bz3s0OxD8IUEOjaoglakQLyVFMzz7APjixNyRP38uDnVNjAKr9F~1763547921; ak_bmsc=48A65B66DE9B05DDBF03A6B68DE2B9DC~000000000000000000000000000000~YAAQ0CXAFzIzE4aaAQAAQ5Gfmx1cr5ZROR0uS2msaejLjPrt5vNibs9qYjKeq6LVu1wA9cVdmDT7IiPw0Tlt8m++nM+mGcGnvQUr6aDgJ/yOoLvdHbNOnZBPZ/Zsg6/7Ya7N8xWVuzXMVJQImkjyV7Rf0ltPA47fsXmml2I2IwxSq/NS7WXqMX1xXLcz/gDAI029pAlRML4jNWITphD6NGMYvf8vImMtNo2CJMvqCBXS/F5G6+R9oYDBOfGop/kyASuJN+AMjnx6lQ+uUVt4BMiLE893P3FfJCJnX5xRmY3dMwL9wBfkJ4Ga3spJewEAfOI9Jf5N3e4BCp0wjSSEj2LC8tE5Toa9S4WIgTI9JI9kssJQnhNx9QfRw8ckfteNMlBaY3TcGmGSBjQxnsUoPsBTe1cFHHAnEpgnxvWXL10FMVNsgzFdDTFJSsPsDC6O1GxybF5jOhdSHiwwJbjO48V8vVOs56h+1KqWl4aKb7WJfx2FQ5h6wAUwOsKfhwPgtheW/5NK540=; bm_s=YAAQ0CXAF0c9E4aaAQAAW0KgmwT4gCrWNFoOX3xJKv4uIQQtT038/KwSwAaTbhh/xAp+iduqHgKvcMLUYbRDhYqc6udWHHFe2XzLdXETzwUq/OCidoDYRznOCMg9Gs2K/0oZgK9R9IpbT9a6mtZQYqjWDtf5P7GMK3OBz75g5Q2pinkO7/2VREmh6kVg1CBcR0ntXG59yM/DckfCquIU7h+RwSE3oxLnsfEs2jj3Kpub5/h68hHoUGgpkuIhAWjMddvmoTQEDqEbds8rfXi9TsSPmzDeJhg6yfQSyh2sGTueo4sUvTmlonh6BbSVSt/kPeRdc/V/+Vlx7ULMHagmyUgS2x2w1Wtyb+1VQNLxpSBfFOKV0pdTpiLeCUtt4zCb/c1wNkd4XWr6ZEE1NroFrQnbHCsdBwaDKx6Z9lyrPjrW9woDUmZFqPQTfkSE8p37ajGXugATq4JYyYUvp+JyM8ymDKjlUhu4S9a6v1ZVbNkOtdzS9roH4o32CoWPW6RWmaAw3sr8MKCcohTfKvtC4knu5kLPIKy0szePUUl5/rsILSBp6+bCH8iv4hhAN+VzndJeNL9UVModTQ==; bm_so=8BC4BDCEBC381989485F98021A3AF66F13C4812DEF19FFFD0ED87183AC4C009A~YAAQ0CXAF0g9E4aaAQAAW0KgmwUb9XfmZVOj5HqEIKLWMK3ZI+G1SeigC4b/x4UwYI9RM6iQYaylyQsqlp+0lATZu0Q80j4jFDXT3c2/kZ8/SYE6f6mMPeDKRuV3rNbQBu7LPkypXUlSMuSIiMruOtj4Pu/Gj9rXwCZ9aPTmEBYDSdphId3zHV3RMMmBM2soMZcN3ZT64neGhMajYgXJG8YJ+hzGX5QY1Eq6Ny9qIOo9eNjR9JEy+FweUY7wMzD2Jw3BpJ3fwUN2ag+hV/AtMOPAYxvS+rqbFmB8kaU/QpkI8XeQQGgZOLrddt1Fj+FBSGM4fLnxDpGEQ60aiBx/hS3JVM45Qp5nCfsV1c+rpzAE+onlqE32uKoP2YoyWG+io8jAr+11UDCgh28yckaBt8R1U0WtR5WoVEFBE5D4qb/E5zKF7yBa146971aFhMhU2blX9QzhroGI3UZbtXps; bm_sz=2A727538947FE354D358B4DFDB7B3670~YAAQ0CXAF0o9E4aaAQAAW0Kgmx0rBACKll9OGthpeggGRt/dBxZija+l7C3l7Dnamj4ZS7GE4KUYio6b435bNS2h5suCOVZLE+mIAkRiqHq4J8Wd2pcaa59ajs7uP9GoSKYj29fLgIyT+K3wPQPrpGD3XFRwhbx2PLNFUIVMe5eRhCwMIhZR1KStfzf2dCAt/nn4HXnnRtTVEunacr+l/+txgm/dIEiYC51NtC+8xjWsXYrM/jCp4BCHYHA/tUDaFysXWCmCHgADRcPZJGh9fkPUcxE1Rd9AItSY6u96oFvbmN/r9tmooZGRTx4tS1dLuVfKZpcaJ6CpoaybleqlYivpUPETbDcs92VxFIGj1SABSSfo8B9Cy4C7vOvI50K5IwnuCJHvcveViFGcaj3L6evK1lHNkfB6hKo=~3356721~3485763; pid=YTZU2Yg0RMmdg8iLEJuS9A; bm_mi=F8221E9CEF7A526665262E1C3F7ACDBA~YAAQ0CXAF0oxE4aaAQAAymufmx1eZMlpbTldm561AhF7xUpnwIZb6m1Hy0RUpNCRvRoRxsjECbiDrHpR2lFbO6KNDmeZtw1SlpOMIiy+/zA8OC7q87PhN8pFl2ZBG2GYX9rwgTCl+G2mLIpLzJN+TtedVYa3stdfYTM/8hPk9jvExnx9K+GaQg/FD34rIwaJJlNOjf8NWcQ6d+6p24emdiw0NNEF/fN/w/HL/Ff8DQ5ofWY/ENUOnWdcmoegthvZnfLeAhTqDs+Q7vn8JpJuj6L/M0wolj9nEXV7wrASrybyLm2IlRh+0LIpwOvY8VvR/VRDY+j8HxEwI2Xb8ZgjATBuxQ==~1; bm_sv=D0CA75910D3AA81605B330066FC719C8~YAAQyCXAF68wHYeaAQAAfWGlmx3H0DTluOJ8pb6xBlIGpd/zRk60V9kAczZ/g0TgsVX/Cg22p8XKQ/2CPqqxVOTX6/ADzA+TPvCvbULd73/NwtfET6tD2b+nZeJ3St5ehfvaY9wZEjhl5Iv60MlByNCbLUaxu77TG6bIvifZPRsnlSx45s6MqvnZnQziztDB4uk8XqJRJTsHFEeKqqzxtehBfQ3iytGyT/KvTvwsWr1HdHnDqUgnOVeoivxMf4jA~1; bm_lso=8BC4BDCEBC381989485F98021A3AF66F13C4812DEF19FFFD0ED87183AC4C009A~YAAQ0CXAF0g9E4aaAQAAW0KgmwUb9XfmZVOj5HqEIKLWMK3ZI+G1SeigC4b/x4UwYI9RM6iQYaylyQsqlp+0lATZu0Q80j4jFDXT3c2/kZ8/SYE6f6mMPeDKRuV3rNbQBu7LPkypXUlSMuSIiMruOtj4Pu/Gj9rXwCZ9aPTmEBYDSdphId3zHV3RMMmBM2soMZcN3ZT64neGhMajYgXJG8YJ+hzGX5QY1Eq6Ny9qIOo9eNjR9JEy+FweUY7wMzD2Jw3BpJ3fwUN2ag+hV/AtMOPAYxvS+rqbFmB8kaU/QpkI8XeQQGgZOLrddt1Fj+FBSGM4fLnxDpGEQ60aiBx/hS3JVM45Qp5nCfsV1c+rpzAE+onlqE32uKoP2YoyWG+io8jAr+11UDCgh28yckaBt8R1U0WtR5WoVEFBE5D4qb/E5zKF7yBa146971aFhMhU2blX9QzhroGI3UZbtXps^1763547568457; abTestingAnonymousPID=PiBWlQ1bROuDPuzYNMdY3g; _gcl_au=1.1.1007132405.1763547521; pageviewCount=1; ajs_anonymous_id=b849c4c4-bc31-45ff-948a-26f929d1b34a; _ga_GM4GWYGVKP=GS2.1.s1763547521^$o1^$g1^$t1763547875^$j46^$l0^$h1120021249; _ga=GA1.1.1574971876.1763547522; _iidt=hETawI5Vrgo+udE75i1HYDcugg4bsiogN7GjlF+mATTLVfBHviZb4yVbdAMFqLvSjeW5qY1g0d2jtw==; _vid_t=Cv+YtLIc6G0Erb35jPsA47aJAi6zwZHuUVdz8bk+LuiuX5hMSbo1IzNg8sScCCHln3ulfuVhU/w9BQ==; fppro_id={"rid":"1763547522459.mGWbh7","vid":"nFB5A0mpPyzaSJc2mGk5","exp":1763979522545}; _rdt_uuid=1763547525362.4662863b-1596-4143-8d4e-489845c8fa41; OptanonConsent=isGpcEnabled=1&datestamp=Wed+Nov+19+2025+15%3A19%3A31+GMT%2B0500+(Pakistan+Standard+Time)&version=202304.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&landingPath=https%3A%2F%2Fwww.chewy.com%2Fdeals%2Ftodays-deals-2723&groups=BG36%3A0%2CC0004%3A0%2CC0010%3A1%2CC0011%3A1%2CC0001%3A1%2CC0003%3A1%2CC0002%3A1; chewy-insights=',
        
    }

    custom_settings = {
        "DEFAULT_REQUEST_HEADERS": headers
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = "//div[contains(@class,'ProductListingGrid_gridContainer')]/div/div[@class='kib-product-card__content']"
        titalxpath = './/h2[@class="ProductTitle_productTitleHeading__68yQR"]/text()'
        imagexpath = './/a[@class="kib-product-image product-card-image"]/img/@src'
        pricexpath = ".//div[contains(@class,'kib-product-pricing__row')][1]/div[contains(@class,'kib-product-price--strikethrough')]/span[1]"
        price2xpath = "//div[contains(@class,'kib-product-pricing__row')][1]/div[contains(@class,'kib-product-price kib-product-price--deal kib-product-price')]/span[1]"
        otherxpath = ''
        nextpage = '//a[@aria-label="Next Page"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.headers,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
