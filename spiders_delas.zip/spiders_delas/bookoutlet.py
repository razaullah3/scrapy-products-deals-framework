import scrapy
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bookoutletdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bookoutlet'
    start_urls = ['https://bookoutlet.com/browse?q=deal']
    Sitename = 'bookoutlet'
    siteurl = 'https://bookoutlet.com'

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Connection": "keep-alive",
        "Cookie": "ConstructorioID_client_id=7b37cbea-da60-48a6-af21-a05b6186079d; ConstructorioID_session_id=1; ConstructorioID_session={\"sessionId\":1,\"lastTime\":1763540677427}; __Secure-next-auth.session-token=eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..S4uLVxEJ-vGmNdTY.USIkr6OZCzGqAo-q8ygvwnVmsOdxeE9PgOjDLWgvU2Xk1GzA3WqDwlf7UKLvGLmo0T_W8mDyp8HWNJNwFQCKmyEVZh9segHBJlDc90rS-XgKinVRqV5sd2IJxqyln5HKO_tAP5Dx10xpwW9VnHKKJXDeVa1t2KICVK3qnRZmj6DNyj3cORh8_JkApkQytS_xXT-BfwPAfk5sM8UbSHRcKtmJdb7VM_r0DLmsymZjFly_ET87MLPEm5Mh0w3paPZCb5veoxOWH0UkF2kGqGUigA2K3KWabq2w4Yt3RXuGTyEcmHUwR-jY2PJJRwnhXWAi0GiI5RTMcoHSEqJ7w4ZQla-HTl-locBxRJM2INi-WRl-nbjqyVnGAWSTJbGlfiN6PT_ASxQPmSgUdgCzqJshnLIpMuR8QevfD8sZA8GevpGDafdDcRR3DwjxOJZuAMznv5-2fHBB4SMZJK8szJjF29aQJUEulKsvzQy3yO4eSqbQds6YiZ0E5zTds8kIY45RmzEyRLqiPzEMEcawtOOiJSfYpeDLQXytf-8ffmK09gjROJqGQwihWYYISWEgiKjRq8700eOMZRuF7xn3Rn1fFnnzd54gUQMlTvN3CfzqD7HLzVFjxYJ3v-7-YHeUj4aEMtRxn9CqPp53JrqiZVUzEHzZN1mLt7KUtHizDnLj7IWx2xbiiF5Vtj0Zrv3gq8EyZo-lKD2BjG0hMd2nhlitdizv0teHG1LSopwebIvu0J1T7cSrSzskwAvuaThW00MKOAueh88luf6HhjX8HQQiWys1jJ7XDVuVG-sPUM-TM-0wKEPQEkyFVQ9Tykq_aYm4hetfpt9X0j8XrD90s3AD320OE56XsCXcFQzgYKFnMhKWDqFh_SKbIT0jepL80AV9_LYE1Eeo795UxSmU4_qMvzfkBdMxu8zRBTSrZ6bsfkSPLsnTYHoCZH_wupiR8myO_9BIXuMaR-NGbIOy5MyD0XQA2x-Hfom6aeQlSENwK-lfoaP7qwXnTE2W7Pr-hSaWplYzbj6YjjAgYDWHwaMsvJZ_5nDWWa_6WvFzCeb3JFeZDAXsV8aL4YI-yL9oRe1y5U9jUn0_Ponsu4L0p3GihQnrnDoYeQp774nWkIXgLNjhwutIHNkQ6MVF_rCwdocCckjNvCSz84Yh3u15CvlZfUYnmEFdGiSK5AlJD0IR_8yhqJaeRBXfThk-SDfCCjh1Rp_9kYsgm0aFUNvnhhmk936xl4CA-edVFZv5YyZGw8JYFRUYorGIfEROcTHRLEyg4_26v5Y-VxyEYPOszwggcKEC0b-meichyU9vA3ueeH86g_MxAmLcAoQ0qvo63ejm06mvC4ghHIQoZHg3b0V0f4qQ5SyeIuPtF3s_jvMa0MeT_ES2bMyByjLUgNWEJDusm1K1dL-1hl5M0RCWzpiWImrdrevrHnUIXSgY7_XSDevzmgO_sH47l-gM4D7hjmALGqD8Oz1DsKc1dBvLHBX4bMRHn8_FBUmpVp88Oxr4anUxv_UFF_bDyyAdWc43YXutaWP7WnRNEE2p27vX9GymkFKAIkIYDRoUUccAH7HJVth91FOLGJOOD_8o3SGyfWYl-TEMAOXEK3J1HUNgzsfalyHOeyXtXs7d8KP4hXrSVSFMm11ryjNmuu3GwATB-rKRFg.ujv9dFuAHZhOhl9fWINmHA",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "Priority": "u=0",
        "TE": "trailers"
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                headers=self.custom_headers,
                callback=self.parse
            )

    def parse(self, response):
        # Yield header item
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''

        # Define XPaths
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[contains(@class,"MuiGrid-root MuiGrid-item MuiGrid-grid-xs-6 ")]'
        titalxpath = './/p[contains(@class,"MuiTypography-root jss157 ")]/text()[1]'
        imagexpath = './/div[@class="jss169 jss171"]/img/@src'
        pricexpath = './/span[@class="jss175"]/text()'
        price2xpath = './/span[contains(@class,"jss174")]/text()'
        otherxpath = ''
        nextpage = ''  # Skip "Load More" logic

        # Call Data_Collector for first page only
        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
