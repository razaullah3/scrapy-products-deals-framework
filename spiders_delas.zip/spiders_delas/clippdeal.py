from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class clippdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'clippdealdeal'
    start_urls = ['https://www.clipp.com/category/deals?radius=35']
    Sitename = 'Clipp'
    siteurl = 'https://www.clipp.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="col-xs-12 col-sm-4  col-lg-3 lf-offer-listing--item"]'
        titalxpath = './/div[@class="cd-offer-tile--description"]/div/text()[3]'
        imagexpath = './/img[@class="hidden-xs"]/@src'
        pricexpath = './/span[@class="cd-offer-tile--full-price"]/text()'
        price2xpath = './/span[@class="cd-offer-tile--offer-price"]/text()'
        otherxpath = './/span[@class="cd-offer-tile--savings"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })