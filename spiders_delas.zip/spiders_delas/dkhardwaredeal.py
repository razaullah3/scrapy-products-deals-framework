from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy


class dkhardwaredealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'dkhardwaredeal'
    start_urls = ['https://www.dkhardware.com/search?page=1&keyword=deals&st=0&dm=0&closeout=false&f_price_price=-8825.2900390625']
    Sitename = 'DK Hard Ware'
    siteurl = 'https://www.dkhardware.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-short-wrapper"]'
        titalxpath = './/span[@class="product-card__name"]/text()'
        imagexpath = './/div[@class="responsive"]/img/@src'
        pricexpath = './/strong[@class="product-card__price-retail"]'
        price2xpath = './/p[@class="product-card__price"]/text()  | //p[@class="product-card__price product-card__price--sale"]/text()'

        otherxpath = ''
        nextpage = ''

        yield scrapy.Request(
            response.url,
            callback=self.Data_Collector,
            meta={
                   # light mode
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
