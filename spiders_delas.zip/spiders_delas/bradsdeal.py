from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy

class BradsDealSpider(GetDealsProducts):
    name = 'bradsdeal'
    handle_httpstatus_list = [404]
    start_urls = ['https://www.bradsdeals.com']
    Sitename = 'BradsDeal'
    siteurl = 'https://www.bradsdeals.com/'

    def parse(self, response):
        # 1️⃣ Extract categories
        category_xpath = '(//a[@role="menuitem"]/@href)[position() <= 30]'
        categories = response.xpath(category_xpath).getall()
        
        print(f"Found {len(categories)} categories:")
        for i, cat in enumerate(categories, 1):
            print(f"{i}: {cat}")
        
        # Example: follow all categories (or you can select one)
        for cat_url in categories:
            url = response.urljoin(cat_url)
            yield scrapy.Request(
                url=url,
                callback=self.parse_category,
                meta={'category_url': url}
            )

    def parse_category(self, response):
        # 2️⃣ Scrape deals in this category
        divxpath = '//div[@data-action-name="post-tile"]'
        deals = response.xpath(divxpath)
        for deal in deals:
            item = couponsDealsItem()
            item['Title'] = deal.xpath('//h3[@class="d-block mt-1 line-clamp-3 mb-1 display-5"]/text()').get(default='').strip()
            item['Image'] = deal.xpath('//img[@data-heap="post-tile-image--default"]/@src').get(default='')
            item['Price'] = deal.xpath('//div[@class="price-group__strikethrough text-gray-med display-5"]/text()').get(default='').strip()
            item['SalePrice'] = deal.xpath('//div[@class="price-group__price text-blue-marine display-11"]/text()').get(default='').strip()
            item['Offer'] = deal.xpath('//div[@class="price-group__percent-saved text-watermelon display-5"]/text()').get(default='').strip()
            item['SourceUrl'] = response.url
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['dealpage'] = 'True'
            
            print(item)  # Display scraped item in terminal
            yield item

        
       