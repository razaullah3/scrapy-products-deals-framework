import json
import scrapy
import datetime
import re
import logging
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bbqguysdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404, 400]  # Added 400 to handle the error
    name = 'bbqguysdeal'
    Sitename = 'BBQGuys'
    siteurl = 'https://www.bbqguys.com'

    # Base URL for regular page browsing
    start_urls = ['https://www.bbqguys.com/search?sstring=Clearance&filters=eyJ3YXlzX3RvX3Nob3AiOlsiQ2xlYXJhbmNlIl19']

    # Custom settings for better scraping performance
    custom_settings = {
        'DOWNLOAD_TIMEOUT': 30,
        'AUTOTHROTTLE_ENABLED': True,
        'AUTOTHROTTLE_START_DELAY': 1,
        'AUTOTHROTTLE_MAX_DELAY': 5,
        'RETRY_ENABLED': True,
        'RETRY_TIMES': 2,
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'ROBOTSTXT_OBEY': False,
        'CONCURRENT_REQUESTS': 4,
        'DOWNLOAD_DELAY': 1,
        'COOKIES_ENABLED': True,
        # Disable standard compression handling as we'll handle brotli manually
        'COMPRESSION_ENABLED': False,
        'DEFAULT_REQUEST_HEADERS': {
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            # Still include compression encoding to look like a browser
            'Accept-Encoding': 'gzip, deflate, br, zstd',
        }
    }

    def __init__(self, *args, **kwargs):
        super(bbqguysdealSpider, self).__init__(*args, **kwargs)
        # Check for brotli support
        try:
            import brotli
            self.has_brotli = True
            self.logger.info("Brotli support is available")
        except ImportError:
            self.has_brotli = False
            self.logger.warning("Brotli module not installed. Install with: pip install brotli")
            self.logger.warning("Compressed responses may not be handled correctly")

    def start_requests(self):
        """First load the search page to get cookies and session data"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        }

        # First visit the search page to get cookies
        yield scrapy.Request(
            url=self.start_urls[0],
            headers=headers,
            callback=self.parse_search_page,
            meta={'dont_redirect': True, 'handle_httpstatus_list': [301, 302]}
        )

    def parse_search_page(self, response):
        """After getting cookies, make the api request"""
        self.logger.info("Visited search page, now making API request")

        # Set up headers for API request - using the provided headers
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Referer': 'https://www.bbqguys.com/',
            'Content-Type': 'application/json',
            'apollographql-client-name': 'BBQGuys-Frontend',
            'apollographql-client-version': '1.0',
            'Origin': 'https://www.bbqguys.com',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site'
        }

        for cookie in response.headers.getlist('Set-Cookie'):
            self.logger.info(f"Cookie: {cookie}")

        # Direct POST request to GraphQL endpoint with proper payload
        payload = {
            "operationName": "getSearchItems",
            "variables": {
                "term": "Clearance",
                "page": 1,
                "sort": "",
                "refinements": "sstring=Clearance&filters=eyJ3YXlzX3RvX3Nob3AiOlsiQ2xlYXJhbmNlIl19",
                "pricingTierId": 0
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "930fb3d1baad707a490d0c3f4a6bc05086df739c9b5e3c0cc77e3c7bc57525b7"
                }
            }
        }

        # Copy cookies from the initial request to the API request
        yield scrapy.Request(
            url='https://graphql.bbqguys.com/',
            method='POST',
            headers=headers,
            body=json.dumps(payload),
            callback=self.parse_api_response,
            meta={'page': 1, 'cookies': response.headers.getlist('Set-Cookie'), 'dont_filter': True},
            dont_filter=True
        )

    def parse_api_response(self, response):
        """Parse the GraphQL API response and extract product data"""
        try:
            self.logger.info(f"Response status: {response.status}")
            self.logger.info(f"Response headers: {response.headers}")

            # Proper handling of compressed response
            try:
                # Try to access response.text which may fail if content is binary/compressed
                if hasattr(response, 'text') and response.text:
                    self.logger.info(f"Response body preview: {response.text[:200]}...")
                else:
                    self.logger.info("Response body is not accessible as text (possibly compressed)")
            except AttributeError:
                self.logger.info("Response is compressed or binary. Will process as JSON directly.")

            # Handle 400 error
            if response.status == 400:
                self.logger.error("Bad request error. Cannot display response content.")
                return

            # Parse the JSON response - handle compressed responses
            try:
                # First try parsing as text
                data = json.loads(response.text)
            except (json.JSONDecodeError, AttributeError):
                # If that fails, try to decompress the body first
                self.logger.info("Detected compressed response, attempting to decompress")

                try:
                    import brotli
                    try:
                        # Try to decompress with brotli if Content-Encoding is br
                        if b'br' in response.headers.get(b'Content-Encoding', b''):
                            decompressed_body = brotli.decompress(response.body)
                            self.logger.info(
                                f"Successfully decompressed brotli content, length: {len(decompressed_body)}")
                            data = json.loads(decompressed_body.decode('utf-8'))
                        else:
                            # Fall back to letting scrapy handle it
                            self.logger.info("Response not brotli-encoded, trying direct parsing")
                            data = json.loads(response.body.decode('utf-8'))
                    except Exception as decomp_err:
                        self.logger.error(f"Decompression error: {decomp_err}")
                        # Last attempt: try to process as is
                        data = json.loads(response.body.decode('utf-8', errors='ignore'))
                except ImportError:
                    self.logger.error("Brotli module not installed. Install with: pip install brotli")
                    # Try to proceed anyway
                    try:
                        data = json.loads(response.body.decode('utf-8', errors='ignore'))
                    except Exception as e:
                        self.logger.error(f"Failed to decode response after all attempts: {e}")
                        return

            # Extract products from the response
            products = data.get('data', {}).get('searchItems', {}).get('results', [])
            current_page = response.meta.get('page', 1)
            total_pages = data.get('data', {}).get('searchItems', {}).get('totalPages', 0)

            self.logger.info(f"Processing page {current_page} of {total_pages} with {len(products)} products")

            for product in products:
                # Skip if product is not available
                if not product.get('inStock', False):
                    continue

                item = couponsDealsItem()

                # Basic product information
                item['Title'] = product.get('name', '')

                # Handle image
                item['Image'] = product.get('imageUrl', '')

                # Price handling
                pricing = product.get('pricingFormatted', {})
                item['Price'] = pricing.get('retail', '')
                item['SalePrice'] = pricing.get('current', '')

                # Calculate discount percentage or use the one from API
                if pricing.get('savingsPercent'):
                    item['Offer'] = pricing.get('savingsPercent', '')
                else:
                    item['Offer'] = ''

                # URL handling
                product_url = product.get('url', '')
                if product_url:
                    full_url = f"{self.siteurl}{product_url}"
                else:
                    full_url = ''

                item['SourceUrl'] = full_url
                item['Framework'] = '3'
                item['SiteName'] = self.Sitename
                item['SiteURL'] = self.siteurl
                item['DateAdded'] = datetime.datetime.now()
                item['DateUpdated'] = datetime.datetime.now()
                item['dealpage'] = 'True'

                yield item

            # Continue fetching next page if available
            if current_page < total_pages:
                next_page = current_page + 1
                self.logger.info(f"Fetching next page: {next_page}")

                # Create the payload for next page
                payload = {
                    "operationName": "getSearchItems",
                    "variables": {
                        "term": "Clearance",
                        "page": next_page,
                        "sort": "",
                        "refinements": "sstring=Clearance&filters=eyJ3YXlzX3RvX3Nob3AiOlsiQ2xlYXJhbmNlIl19",
                        "pricingTierId": 0
                    },
                    "extensions": {
                        "persistedQuery": {
                            "version": 1,
                            "sha256Hash": "930fb3d1baad707a490d0c3f4a6bc05086df739c9b5e3c0cc77e3c7bc57525b7"
                        }
                    }
                }

                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br, zstd',
                    'Referer': 'https://www.bbqguys.com/',
                    'Content-Type': 'application/json',
                    'apollographql-client-name': 'BBQGuys-Frontend',
                    'apollographql-client-version': '1.0',
                    'Origin': 'https://www.bbqguys.com',
                    'Connection': 'keep-alive',
                    'Sec-Fetch-Dest': 'empty',
                    'Sec-Fetch-Mode': 'cors',
                    'Sec-Fetch-Site': 'same-site'
                }

                yield scrapy.Request(
                    url='https://graphql.bbqguys.com/',
                    method='POST',
                    headers=headers,
                    body=json.dumps(payload),
                    callback=self.parse_api_response,
                    meta={'page': next_page, 'dont_filter': True},
                    dont_filter=True
                )
            else:
                self.logger.info(f"Finished scraping all {total_pages} pages of BBQGuys clearance deals")

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
            try:
                self.logger.error(f"Response text preview: {response.text[:500]}")
            except AttributeError:
                self.logger.error("Cannot display response text (possibly compressed)")
                self.logger.error(f"Raw response body length: {len(response.body)}")
        except Exception as e:
            self.logger.error(f"Error processing response: {e}")
            import traceback
            self.logger.error(traceback.format_exc())

    def parse(self, response):
        """Original parse method kept for compatibility"""
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item