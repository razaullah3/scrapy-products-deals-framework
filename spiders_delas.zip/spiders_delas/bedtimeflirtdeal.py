from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bedtimeflirtdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bedtimeflirtdeal'
    start_urls = ['https://www.bedtimeflirt.com/hosiery/tights/']
    Sitename = 'Bedtime Flirt'
    siteurl = 'https://www.bedtimeflirt.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="tile revealed"]'
        titalxpath = './/div[@class="name"]/a/text()'
        imagexpath = './/a[@class="back"]/img/@src'
        pricexpath = ''
        price2xpath = './/span[@class="woocommerce-Price-amount amount"]/bdi/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })