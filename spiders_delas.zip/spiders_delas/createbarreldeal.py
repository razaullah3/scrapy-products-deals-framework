# headers issue yet to solve

import scrapy
import json
import datetime
from urllib.parse import urljoin
from ..items import couponsDealsItem
import pprint  # For pretty-printing JSON

class CrateClearanceSpider(scrapy.Spider):
    name = "crate_clearance"

    # Base URL (single page)
    base_url = "https://www.crateandbarrel.com/search?query=clearance&availability=showAll&skip=200&take=0&isModelOnly=true"
    source_domain = "https://www.crateandbarrel.com"

    # Headers for the Crate & Barrel API
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        
        "Content-Type": "application/json",
        "x-requested-with": "XMLHttpRequest",
        "Connection": "keep-alive",
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_url,
            headers=self.custom_headers,
            callback=self.parse
        )

    def parse(self, response):
        try:
            # Print first 5000 characters of the JSON for debugging
            print("\n" + "="*20 + " JSON PREVIEW " + "="*20 + "\n")
            preview_text = response.text[:5000]
            try:
                # Attempt to pretty-print JSON if possible
                preview_data = json.loads(preview_text)
                pprint.pprint(preview_data)
            except Exception:
                # Fallback: just print raw text slice
                print(preview_text)
            print("\n" + "="*60 + "\n")

            # Parse full JSON
            data = json.loads(response.text)
            minisets = data.get("minisets", [])

        except Exception as e:
            self.logger.error(f"JSON parse error: {e}")
            return

        for product in minisets:
            yield self.extract_product_item(product)

    def extract_product_item(self, p):
        item = couponsDealsItem()

        title = p.get("name", "")
        regular_price = p.get("regularPrice", "")
        current_price = p.get("currentPrice", "")
        url = urljoin(self.source_domain, p.get("navigateUrl", ""))
        image = p.get("imageUrl", "")

        item["Title"] = title
        item["Price"] = regular_price
        item["SalePrice"] = current_price
        item["Offer"] = ""
        item["SourceUrl"] = url
        item["Image"] = image

        item["SiteName"] = "Crate & Barrel"
        item["SiteURL"] = "https://www.crateandbarrel.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
