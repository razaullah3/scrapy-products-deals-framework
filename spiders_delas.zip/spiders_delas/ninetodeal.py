import scrapy
import json
import datetime
from ..items import couponsDealsItem


class NintendoDealSpider(scrapy.Spider):
    name = "nintendo_deal"

    api_url = "https://u3b6gr4ua3-2.algolianet.com/1/indexes/store_game_en_us/query?x-algolia-agent=Algolia%20for%20JavaScript%20(4.23.2)%3B%20Browser"

    # Headers required by Algolia API
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "x-algolia-api-key": "a29c6927638bfd8cee23993e51e721c9",
        "x-algolia-application-id": "U3B6GR4UA3",
        "content-type": "application/x-www-form-urlencoded",
        "Origin": "https://www.nintendo.com",
        "Referer": "https://www.nintendo.com/",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1"
    }

    # Request body for the POST request
    payload = {
        "query": "deal",
        "filters": "",
        "hitsPerPage": 40,
        "analytics": True,
        "facetingAfterDistinct": True,
        "clickAnalytics": True,
        "highlightPreTag": "^*^^",
        "highlightPostTag": "^*",
        "attributesToHighlight": ["description"],
        "facets": ["*"],
        "maxValuesPerFacet": 100,
        "page": 0
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.custom_headers,
            body=json.dumps(self.payload),
            callback=self.parse,
            meta={'page': 0}
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
            hits = data.get("hits", [])
        except Exception as e:
            self.logger.error(f"JSON parse error: {e}")
            return

        for product in hits:
            yield self.extract_product_item(product)

        # Pagination handling
        current_page = response.meta.get('page', 0)
        nb_pages = data.get("nbPages", 0)
        if current_page + 1 < nb_pages:
            next_page = current_page + 1
            next_payload = self.payload.copy()
            next_payload["page"] = next_page
            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.custom_headers,
                body=json.dumps(next_payload),
                callback=self.parse,
                meta={'page': next_page}
            )

    def extract_product_item(self, p):
        item = couponsDealsItem()

        title = p.get("title", "")
        price_info = p.get("price", {})
        final_price = price_info.get("finalPrice", "")
        reg_price = price_info.get("regPrice", "")
        amount_off = price_info.get("amountOff", "")

        url = f"https://www.nintendo.com{p.get('url', '')}"
        image = p.get("productImageSquare", "")

        item["Title"] = title
        item["SalePrice"] = final_price
        item["Price"] = reg_price
        item["Offer"] = amount_off
        item["SourceUrl"] = url
        item["Image"] = image

        # Standardized metadata fields
        item["SiteName"] = "Nintendo US"
        item["SiteURL"] = "https://www.nintendo.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
