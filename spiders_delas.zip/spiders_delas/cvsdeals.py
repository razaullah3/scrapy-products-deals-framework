import scrapy
import json
import re


class CvsProductSpider(scrapy.Spider):
    name = "cvs_product"
    allowed_domains = ["cvs.com"]
    start_urls = [
        "https://www.cvs.com/shop/merch/deals/q/All_Deals/pr?widgetID=79o3dn9g&mc=0"
    ]

    def start_requests(self):
        headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Content-Type": "application/json" ,
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1"
    # Note: Do NOT include 'Cookie': '[object Object]' — it's invalid
}


        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=headers, callback=self.parse)

    def parse(self, response):
        script_data = response.xpath('//script[contains(text(), "var productIndexData")]/text()').get()

        if script_data:
            match = re.search(r'var productIndexData\s*=\s*({.*?});?\s*$', script_data, re.DOTALL)
            if match:
                json_data = match.group(1)

                try:
                    data = json.loads(json_data)

                    for product in data.get("products", []):
                        for variant in product.get("variants", []):
                            item = {
                                "titleOverride": variant.get("titleOverride"),
                                "url": response.urljoin(variant.get("url", "")),
                                "priceEach": variant.get("priceEach"),
                                "originalPrice": variant.get("originalPrice", {}).get("value"),
                                "images": [img.get("uri") for img in variant.get("images", [])]
                            }
                            print(json.dumps(item, indent=2))
                            yield item

                except json.JSONDecodeError as e:
                    self.logger.error(f"JSON decoding failed: {e}")
        else:
            self.logger.warning("Could not find script containing productIndexData.")
