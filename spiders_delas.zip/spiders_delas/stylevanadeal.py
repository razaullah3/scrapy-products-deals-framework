from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class stylevanadealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'stylevanadeal'
    start_urls = ['https://www.stylevana.com/en_US/flash-deals/flash-deals-us.html']
    Sitename = 'Stylevana'
    siteurl = 'https://www.stylevana.com/en_US'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="item product product-item"]/div'
        titalxpath = './/a[@class="product-item-link"]/text()'
        imagexpath = './/span[@class="product-image-wrapper"]/img/@data-original'
        pricexpath = './/span[@data-price-type="rrpPrice"]/span/text()'
        price2xpath = './/span[@data-price-type="finalPrice"]/span/text()'
        otherxpath = ''
        nextpage = '( //a[@class="action  next"]/@href)[1]'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })