import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class PinkblushDealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'pinkblushdeal'
    Sitename = 'PinkBlushMaternity'
    siteurl = 'https://www.pinkblushmaternity.com'

    # BASE API (page will be appended for pagination)
    api_url = (
        "https://cie0u8.a.searchspring.io/api/search/search.json"
        "?ajaxCatalog=v3&resultsFormat=native&siteId=cie0u8"
        "&domain=https%3A%2F%2Fwww.pinkblushmaternity.com%2Fcollections%2Fmaternity-clearance"
        "&bgfilter.navigationid=110&bgfilter.cookie=maternity&q="
        "&userId=dcb039d8-5f67-4c5e-bf57-cb6b2717510b"
        "&sessionId=4eeb47ca-bb7e-46dd-926e-8a8e72760027"
        "&pageLoadId=4c15fc9f-1738-4c6e-b66c-c6da953f7bf5"
        "&noBeacon=true&intellisuggest=0"
    )

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://www.pinkblushmaternity.com",
        "Connection": "keep-alive",
        "Referer": "https://www.pinkblushmaternity.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site"
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.api_url,
            method="GET",
            headers=self.headers,
            callback=self.parse
        )

    def parse(self, response):
        listing_json = json.loads(response.text)

        # Extract products
        for req in self.getproducts(response):
            yield req

        # Handle Pagination
        pagination = listing_json.get("pagination", {})
        total_pages = pagination.get("totalPages", 1)
        current_page = pagination.get("currentPage", 1)

        for page in range(current_page + 1, total_pages + 1):
            next_url = self.api_url + f"&page={page}"

            yield scrapy.Request(
                url=next_url,
                method="GET",
                headers=self.headers,
                callback=self.getproducts,
                dont_filter=True
            )

    def getproducts(self, response):
        listing_json = json.loads(response.text)
        products = listing_json.get("results", [])

        for p in products:
            item = couponsDealsItem()

            item['Title'] = p.get("name", "")
            item['Image'] = p.get("imageUrl", "")

            # Build product URL
            product_url = p.get("producturl") or p.get("url", "")
            if product_url.startswith("/"):
                item['SourceUrl'] = self.siteurl + product_url
            else:
                item['SourceUrl'] = product_url

            # Prices
            item['SalePrice'] = p.get("price", "0")      # 26
            item['Price'] = p.get("msrp", "0")           # 58

            item['Offer'] = ""
            item['Framework'] = "3"
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = "True"

            yield item
