import scrapy
import json
import datetime
from ..items import couponsDealsItem


class ZazzleDealSpider(scrapy.Spider):
    name = "zazzle_deal"

    # ✅ Base API with page parameter
    base_api = (
        "https://www.zazzle.com/svc/z3/search/GetSearchWithProperties?"
        "cv=1&diffParameters=pg&diffProperties=ProductSearchTopIds&"
        "parameters=qs%3Ddeal%26q%3Ddeal%26HumanSearch%3DTrue%26pg%3D{page}&"
        "properties=LightProductObjects%3Dtrue%26OriginalSearchTerm%3Ddeal%26Maturity%3DG%26IsPublic%3Dtrue"
        "%26ShowFullSearchPages%3Dfalse%26LookAheadPages%3D16%26LimitTypesInSearch%3Dtrue%26MaxStoresPerPage%3D6"
        "%26IsHumanSearch%3Dtrue%26UserDefaultPageSize%3D60%26GetAggregations%3Dtrue%26LegoStoreAggregation%3Dfalse"
        "%26LegoStoreCategoryAggregation%3Dfalse%26UseCYOSearch%3Dfalse%26IgnoreCYOManual%3Dfalse%26GetGuidedSearch%3Dtrue"
        "%26IsBestSellerSearch%3Dfalse%26EnablePriceFilter%3Dfalse%26MinPrice%3D0%26MaxPrice%3D0%26ProductLimit%3D1"
        "%26DiversityMinScoreFactor%3D-1%26DiversityLimitWindowSize%3D16%26ProductDepartmentUrl%3D252536702459719117"
        "%26IsBestGuessSearch%3Dfalse%26EnableNLS%3Dfalse%26IsWeddingHeader%3Dfalse%26IsInitialWeddingEntry%3Dfalse"
        "%26IsSeeAllCategories%3Dfalse%26ShouldApplyWeddingClassBoost%3Dfalse&type=SearchResultsData&client=js"
    )

    # ✅ Headers
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.zazzle.com/s/deal",
        "X-Csrf-Token": "30f75beaed5f4acd",
        "Connection": "keep-alive",
        "Cookie": "zm=AQABAAAA0RwAABRxZKBjMF_GbqBlM5_yuUxi7GbSri2FcXyYKZQfFDzosyuJIjdywJQ9Aanok3vSqP1ghL15oIOlcuIwlPEFAegTSOBUekcFTnJMwjZJwchWohVBrytNuLHWYXLzBVOJoBie-VgR;"
                  " zs=ABC9FBE6-6A1A-42C7-9328-13110A49CDDA%7c0%7c13406360253%7cAQABAAAA0RwAABRhtfRkBL44TOx33IEEtO7IknRg_OMH5JNndnR5FkxUw6QZacbXxkhT6kgvOoQH0zGN83T0%7c;",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0",
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_api.format(page=1),
            headers=self.custom_headers,
            callback=self.parse,
            meta={"page": 1},
        )

    def parse(self, response):
        page = response.meta.get("page", 1)

        try:
            data = json.loads(response.text)
            products = data.get("data", {}).get("search", {}).get("searchResultsData", {}).get("products", [])
            last_page = data.get("data", {}).get("search", {}).get("searchResultsData", {}).get("lastPageNum", 1)
        except Exception as e:
            self.logger.error(f"Failed to parse JSON on page {page}: {e}")
            return

        if not products:
            self.logger.info(f"No products found on page {page}")
            return

        for product in products:
            yield self.extract_product_item(product)

        # ✅ Pagination
        if page < last_page:
            next_page = page + 1
            next_url = self.base_api.format(page=next_page)
            yield scrapy.Request(
                url=next_url,
                headers=self.custom_headers,
                callback=self.parse,
                meta={"page": next_page},
            )

    def extract_product_item(self, product):
        """Extract product details into couponsDealsItem"""
        item = couponsDealsItem()

        # ✅ Required fields
        item["SourceUrl"] = product.get("linkUrl", "")
        item["Title"] = product.get("titleSeo", "")
        item["Image"] = product.get("imageUrl", "")
        item["Price"] = product.get("price", "")
        item["SalePrice"] = product.get("strikeThroughInfo", {}).get("priceAdjusted", "")

        # ✅ Calculate discount if possible
        try:
            sale = float(product.get("strikeThroughInfo", {}).get("priceAdjusted", 0))
            reg = float(product.get("strikeThroughInfo", {}).get("price", 0))
            if reg > sale > 0:
                discount = round(((reg - sale) / reg) * 100, 1)
                item["Offer"] = f"{discount}% off"
            else:
                item["Offer"] = product.get("promoLabel", "")
        except Exception:
            item["Offer"] = product.get("promoLabel", "")

        # ✅ Static metadata
        item["SiteName"] = "Zazzle"
        item["SiteURL"] = "https://www.zazzle.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
