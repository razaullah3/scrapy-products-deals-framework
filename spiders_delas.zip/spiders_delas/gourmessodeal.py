from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class gourmessodealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'gourmessodeal'
    start_urls = ['https://www.gourmesso.com/collections/nespresso-machine-pods']
    Sitename = 'Gourmesso'
    siteurl = 'https://www.gourmesso.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="2 col-sp-6 col-st-6 col-3 custom-pro-card"]'
        titalxpath = './/div[@class="mt5 body2 title"]/a/text()'
        imagexpath = './/div[@class="product-card__image-holder mb15"]/a/img/@srcset'
        pricexpath = './/div[@class="price__regular body2"]/text()[1]'
        price2xpath = './/div[@class="h5"]/text()[1] | //div[@class="price__sale h5"]/text()[1]'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })