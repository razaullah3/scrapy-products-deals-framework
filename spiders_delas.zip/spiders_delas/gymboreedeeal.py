import scrapy
import json
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class GymboreedealSpider(GetDealsProducts):
    name = 'gymboreedeal'
    handle_httpstatus_list = [404]
    Sitename = 'Gymboree'
    siteurl = 'https://www.gymboree.com'

    api_url = (
        "https://search.unbxd.io/a1a16a3789804b726230012acdb74613/"
        "gymboree-com800681569331157/category"
    )

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://www.gymboree.com",
        "Connection": "keep-alive",
        "Referer": "https://www.gymboree.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "TE": "trailers",
    }

    def start_requests(self):
        start = 0
        yield scrapy.Request(
            url=self.build_url(start),
            headers=self.headers,
            meta={"start": start},
            callback=self.parse
        )

    def build_url(self, start):
        """Build paginated API URL."""
        return (
            f"{self.api_url}?start={start}&rows=90&variants=true&variants.count=0&version=V2"
            f"&stats=min_offer_price&facet.multiselect=true&selectedfacet=true&pagetype=boolean"
            f"&fields=TCPPromotions,tcp_promo_price,tcp_promotion_id,related_product_swatch_images,"
            f"productimage,alt_img,style_partno,giftcard,swatchimage,TCPProductIndUSStore,"
            f"TCPFitMessageUSSstore,TCPFit,TCPWebOnlyFlagUSStore,TCPWebOnlyFlagCanadaStore,"
            f"TCPSwatchesUSStore,top_rated,TCPSwatchesCanadaStore,product_name,TCPColor,imagename,"
            f"productid,uniqueId,favoritedcount,TCPBazaarVoiceReviewCount,categoryPath3_fq,categoryPath3,"
            f"categoryPath3_catMap,categoryPath2_catMap,product_short_description,min_list_price,"
            f"min_offer_price,TCPBazaarVoiceRating,seo_token,prodpartno,banner,facets,auxdescription,"
            f"list_of_attributes,numberOfProducts,redirect,searchMetaData,didYouMean,"
            f"TCPLoyaltyPromotionTextUSStore,TCPLoyaltyPLCCPromotionTextUSStore,TcpBossCategoryDisabled,"
            f"TcpBossProductDisabled,long_product_title,TCPOutOfStockFlagUSStore,TCPOutOfStockFlagCanadaStore,"
            f"product_type,products,low_offer_price,high_offer_price,low_list_price,high_list_price,"
            f"TCPStyleTypeUS,TCPStyleTypeCA,TCPStyleQTYCA,TCPStyleQTYUS,TCPProductIndCanadaStore,"
            f"TCPCustomSalePrice,TCPCustomListPrice,isVMPEnabled,is_hard_mark_enable,influencer_tags,"
            f"influencer_pick,variantTotal,store_specials,isHeroProduct"
            f"&p-id=categoryPathId:%22502006%22&filter=v_qty:[1%20TO%20*]%20OR%20isVMPEnabled:true"
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
            products = data.get("response", {}).get("products", [])
            total = data.get("response", {}).get("numberOfProducts", 0)
        except Exception as e:
            self.logger.error(f"Error parsing JSON: {e}")
            return

        start = response.meta.get("start", 0)
        self.logger.info(f"Page start={start}: {len(products)} products found")

        for product in products:
            title = product.get("long_product_title", "").strip()
            seo_token = product.get("seo_token", "").strip()
            low_list_price = product.get("low_list_price", "")
            low_offer_price = product.get("low_offer_price", "")
            imagename = product.get("imagename", "")
            imagenamees = product.get("imagename", "")
            # Clean image name (remove everything after first underscore)
            base_img_name = imagename.split("_")[0] if imagename else ""
            imagenames = imagenamees

            image_url = f"https://assets.theplace.com/image/upload/t_plp_img_m,f_auto,q_auto/v1/ecom/assets/products/gym/{base_img_name}/{imagenames}.png"
            source_url = f"https://www.gymboree.com/us/p/{seo_token}"

            item = couponsDealsItem()
            item['Title'] = title
            item['Price'] = low_list_price
            item['SalePrice'] = low_offer_price
            item['Image'] = image_url
            item['SourceUrl'] = source_url
            item['Offer'] = ''
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # --- Pagination ---
        if products and (start + 90) < total:
            next_start = start + 90
            yield scrapy.Request(
                url=self.build_url(next_start),
                headers=self.headers,
                meta={"start": next_start},
                callback=self.parse
            )
