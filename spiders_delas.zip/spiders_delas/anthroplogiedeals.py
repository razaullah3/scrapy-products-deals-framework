import scrapy
import json
import datetime
import logging
from ..items import couponsDealsItem


class AnthropologieDealsSpider(scrapy.Spider):
    name = 'anthropologie'
    allowed_domains = ['anthropologie.com']
    start_url = 'https://api.anthropologie.com/api/catalog-search-service/v0/an-us/tiles/sale-all'

    Sitename = 'Anthropologie'
    siteurl = 'https://www.anthropologie.com'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.anthropologie.com/",
        "x-urbn-site-id": "an-us",
        "x-urbn-channel": "web",
        "x-urbn-country": "US",
        "x-urbn-currency": "USD",
        "x-urbn-language": "en-US",
        "x-urbn-experience": "ss",
        "content-type": "application/json",
        "x-urbn-pool": "US_DIRECT",
        "authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhbiIsImV4cCI6MTc2MDUxMjExNC44NDY1MjIzLCJpYXQiOjE3NjA1MTE1MTQuODQ2NTIyMywiZGF0YSI6IntcImNyZWF0ZWRUaW1lXCI6IDE3NjA1MDc3NzQuODUwMTI5NCwgXCJwcm9maWxlSWRcIjogXCJ3eURQRzJReUpadHpWaGprT3FYNUcwbUFpQUxZSDg3SzJ1VmNIb3UzdkRSYXJQdzZKb1FsNzljZ2tnT254T0JKNVUrM3JzMnJ4aGptNHBEMzBDY0lCdz09YmQzZmFhOTVmNzZiOWM1M2M0MmM5ZGY3MTAwYjBjMDA0MDE3NTQ1NTk5NDk2N2Y0NWEwMGU0YTM3MDQ4YWQxOFwiLCBcImFub255bW91c1wiOiB0cnVlLCBcInRyYWNlclwiOiBcIkxTN0hBWkcwR05cIiwgXCJzY29wZVwiOiBbXCJHVUVTVFwiXSwgXCJzaXRlSWRcIjogXCJhbi11c1wiLCBcImJyYW5kSWRcIjogXCJhblwiLCBcInNpdGVHcm91cFwiOiBcImFuLXVzXCIsIFwiZGF0YUNlbnRlcklkXCI6IFwiVVMtTlZcIiwgXCJnZW9SZWdpb25cIjogXCJVUy1OVlwiLCBcImVkZ2VzY2FwZVwiOiB7XCJyZWdpb25Db2RlXCI6IFwiVFhcIn0sIFwiY2FydElkXCI6IFwiTHpzOVVmVGIxSytPZWxURngzTnR0bjltOHZ3MVF4WFppNFpXanp2clVneVR0MllqOERkTlZVZG5jSWFZUVFvSzVVKzNyczJyeGhqbTRwRDMwQ2NJQnc9PTg3MjhjMjJkYzMzNDkxZDBkZGFjZDA3ZDJmNjNmMjM1MzE2ZjA2ZjU2ZTgwNjYyMTI0OWZhZGM5ZTdmY2E4ODBcIn0ifQ.cy5UvjaoHIfThgnh-MW9oOTCkbuoMiRGwzMvOjuB3RA",
        "x-urbn-primary-data-center-id": "US-NV",
        "x-urbn-geo-region": "US-NV",
        "Origin": "https://www.anthropologie.com",
        "Connection": "keep-alive",
    }

    body = {
        "pageSize": 72,
        "skip": 71,
        "projectionSlug": "categorytiles",
        "personalization": "0",
        "customerConsent": "strictlyNecessary",
        "featureProductIds": []
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.start_url,
            method="POST",
            headers=self.headers,
            body=json.dumps(self.body),
            callback=self.parse
        )

    def parse(self, response):
        self.logger.info(f"Response status: {response.status}")

        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON parsing failed: {e}")
            return

        records = data.get("records", [])
        total_products = 0

        for rec in records:
            product = rec.get("allMeta", {}).get("tile", {}).get("product", {})
            sku_info = rec.get("allMeta", {}).get("tile", {}).get("skuInfo", {})
            primary_slice = sku_info.get("primarySlice", {}).get("sliceItems", [])

            if not product:
                continue

            title = product.get("displayName", "").strip()
            slug = product.get("productSlug", "")
            list_price = sku_info.get("listPriceHigh", "")
            sale_price = sku_info.get("salePriceHigh", "")
            swatches = [sw["swatchUrl"] for sw in primary_slice if "swatchUrl" in sw]

            item = couponsDealsItem()
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["Framework"] = "3"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"
            item["Title"] = title
            item["SourceUrl"] = f"https://www.anthropologie.com/sale/{slug}"
            item["Price"] = list_price
            item["SalePrice"] = sale_price
            item["Image"] = ", ".join(swatches)

            yield item
            total_products += 1

        self.logger.info(f"✅ Extracted {total_products} products from Anthropologie API.")
