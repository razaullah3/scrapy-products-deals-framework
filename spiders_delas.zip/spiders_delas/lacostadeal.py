import scrapy
import json
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class lacostedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'lacostedeal'
    Sitename = 'Lacoste'
    siteurl = 'https://www.lacoste.com'

    # Base API endpoint
    api_url = "https://cu0iyshi42-dsn.algolia.net/1/indexes/*/queries"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://www.lacoste.com",
        "Connection": "keep-alive",
        "Referer": "https://www.lacoste.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "x-algolia-agent": "Algolia for vanilla JavaScript (lite) 3.30.0;JS Helper 2.19.0",
        "x-algolia-application-id": "CU0IYSHI42",
        "x-algolia-api-key": "7e20c005d05fe8f113d8b7e079bf34a1",
    }

    def start_requests(self):
        # Start from first page
        page = 0
        yield from self.make_request(page)

    def make_request(self, page):
        # Body with encoded JSON payload
        body = {
            "requests": [
                {
                    "indexName": "products_us_en",
                    "params": (
                        f"query=deal&hitsPerPage=32&page={page}"
                        "&analyticsTags=desktop"
                        "&attributesToRetrieve=%5B%22pid%22%2C%22name%22%2C%22colors%22%2C%22imagesHttp%22%2C%22imagesHttps%22%2C%22price%22%2C%22badges%22%2C%22urlMaster%22%2C%22urlSwatchPattern%22%2C%22urlSwatchImg%22%2C%22priceBookId%22%2C%22isCustomizable%22%2C%22categoryLabel%22%2C%22genderLabel%22%2C%22productId%22%2C%22manufacturer%22%2C%22colorId%22%2C%22colorLabel%22%2C%22categoryName%22%2C%22productRestrictions%22%5D"
                        "&distinct=true"
                        "&responseFields=%5B%22hits%22%2C%22page%22%2C%22nbPages%22%2C%22nbHits%22%5D"
                        "&clickAnalytics=true"
                        "&filters=(priceBookId%3A%20lacoste-us-sales%20OR%20priceBookId%3A%20lacoste-us)%20AND%20(price.onlineFrom%20%3C%3D%201762929605458%20AND%20price.onlineTo%20%3E%3D%201762929605458)"
                        "&facets=%5B%22categoryLabel%22%2C%22universeLabel%22%2C%22genderLabel%22%5D"
                    ),
                }
            ]
        }

        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.headers,
            body=json.dumps(body),
            callback=self.parse,
            meta={"page": page},
        )

    def parse(self, response):
        page = response.meta.get("page", 0)

        try:
            data = json.loads(response.text)
            results = data.get("results", [])[0]
        except Exception as e:
            self.logger.error(f"JSON parse error: {e}")
            return

        hits = results.get("hits", [])
        nbPages = results.get("nbPages", 0)

        self.logger.info(f"Page {page}: Found {len(hits)} products.")

        for m in hits:
            item = couponsDealsItem()
            item['Title'] = m.get('name', '').strip()
            item['Image'] = m.get('imagesHttp', {}).get('details', '')
            item['SourceUrl'] = m.get('urlMaster', '')

            price_data = m.get('price', {})
            item['Price'] = price_data.get('initialPriceMaxDisplayValue', '')
            item['SalePrice'] = price_data.get('maxDisplayValue', '')

            item['Offer'] = ''
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination handling
        if page + 1 < nbPages:
            next_page = page + 1
            yield from self.make_request(next_page)
