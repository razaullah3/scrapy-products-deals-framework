from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class urbanogdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'utopiatoolsdeal'
    start_urls = ['https://utopiatools.com/mega-deals', 'https://utopiatools.com/hot-deals']
    Sitename = 'Utopia Tools'
    siteurl = 'https://utopiatools.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//ul[@class="productGrid"]/li'
        titalxpath = './/h4[@class="card-title"]/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="price price--non-sale"]/text()'
        price2xpath = './/span[@class="price price--withoutTax"]/text()'
        otherxpath = ''
        nextpage = '//li[@class="pagination-item pagination-item--next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })