from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class acmetoolsSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'acmetoolsdeals'
    start_urls = ['https://www.acmetools.com/all/?q=clearance+']
    Sitename = 'acmetools'
    siteurl = 'https://www.acmetools.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # --- UPDATED XPATHS ---
        divxpath = '//div[@class="row equal-height product-grid m-md-0"]//div[@class="col-6 col-sm-4 col-lg-3 px-1"]'
        titalxpath = './/a[@class="tile-title"]/text()'
        imagexpath = './/img[@class="tile-image"]/@src'
        pricexpath = './/span[@class="sales"]/text()[2]'
        price2xpath = './/span[@class="list was"]/span[@class="value"]/text()'
        otherxpath = ''
        nextpage = '//span[@class="pagination-btn-wrapper"]/a/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
