import scrapy
import json
import datetime
from ..items import couponsDealsItem

class SephoraSaleSpider(scrapy.Spider):
    name = "sephora_sale"
    
    start_urls = [
        "https://www.sephora.com/api/v2/catalog/search/?type=keyword&q=sale&includeEDD=true&content=true&includeRegionsMap=true&page=60&currentPage=1&loc=en-US&ch=rwd&countryCode=US&constructorSessionID=1&constructorClientID=ffa79efd-acac-45b5-b309-7617431ef148&targetSearchEngine=nlp"
    ]

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5"
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse,
                meta={'current_page': 1}  # start pagination tracking
            )

    def parse(self, response):
        try:
            data = json.loads(response.text)
            products = data.get("products", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        for p in products:
            yield self.extract_product_item(p)

        # Pagination: increment currentPage until no more products
        current_page = response.meta.get('current_page', 1)
        if products:
            next_page = current_page + 1
            next_url = response.url.replace(f"currentPage={current_page}", f"currentPage={next_page}")
            yield scrapy.Request(
                url=next_url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse,
                meta={'current_page': next_page}
            )

    def extract_product_item(self, p):
        item = couponsDealsItem()

        item['Title'] = p.get("productName") or p.get("displayName") or ""
        sku = p.get("currentSku", {})
        item['SalePrice'] = sku.get("salePrice", "")
        item['Price'] = sku.get("listPrice", "")
        item['SourceUrl'] = p.get("targetUrl", "")
        item['Image'] = p.get("heroImage", "")

        # Standard fields
        item['SiteName'] = "Sephora US"
        item['Offer'] = ""
        item['SiteURL'] = "https://www.sephora.com"
        item['Framework'] = "3"
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = "True"

        return item
