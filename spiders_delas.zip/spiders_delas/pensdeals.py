from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class pensdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'pensdealdeal'
    start_urls = ['https://www.pens.com/us/c/clearance-promotional-items']
    Sitename = 'Pens'
    siteurl = 'https://www.pens.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[contains(@class, "product-card product")]'
        titalxpath = './/div[@class="product-card-information__name"]'
        imagexpath = './/meta/@content'
        pricexpath = './/div[@class="price-per-unit original-strikeout-price"]/text()'
        price2xpath = './/span[@class="price sale"]/text()'
        otherxpath = ''
        nextpage = '//div[@class="plp-load-next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })