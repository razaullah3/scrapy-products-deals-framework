from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bestlacewigsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bestlacewigsdeal'
    start_urls = ['https://www.bestlacewigs.com/c/Best-Super-Deals.html']
    Sitename = 'Bestlacewigs'
    siteurl = 'https://www.bestlacewigs.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//ol[@class="products list items product-items"]/li'
        titalxpath = './/strong/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@data-price-type="oldPrice"]/span/text()'
        price2xpath = './/span[@class="special-price"]//span[@class="price"]/text()'
        otherxpath = ''
        nextpage = '//a[@class="action  next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })