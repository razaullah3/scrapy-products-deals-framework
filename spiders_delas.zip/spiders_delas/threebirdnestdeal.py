from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class threebirdnestldealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'threebirdnestdeal'
    start_urls = ['https://www.threebirdnest.com/collections/sale?page=1',
                  
                  'https://www.threebirdnest.com/collections/sale?page=2',

                  'https://www.threebirdnest.com/collections/sale?page=3'
                  
                  
                  ]
    Sitename = 'Three Bird Nest'
    siteurl = 'https://www.threebirdnest.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="tSvIqLRS"]'
        titalxpath = './/div[@class="b1hb0tgk"]/text()'
        imagexpath = './/img[contains(@class, "vvSCjQFx")]/@src'
        pricexpath = './/span[@class="PtH37qZj"]/text()'
        price2xpath = './/span[@data-is-on-sale]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })