from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class petmedsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'petmedsdeal'
    start_urls = [' https://www.1800petmeds.com/']
    Sitename = 'PetMeds'
    siteurl = 'https://www.1800petmeds.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile new-tile newTile product-master-tile "]'
        titalxpath = './/a[@class="link"]/span[2]/text()'
        imagexpath = './/a/img[@class="tile-image lazy-load lazy "]/@src'
        pricexpath = '//div[@class="price-starts-at "]/span/text() | //span[@class="price-starts-at "]/span/text()'
        price2xpath = './/span[@class="text-left autoship-discounted-price-value price"]/text()[1]'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })