from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class foodservicedirectdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'foodservicedirectdeal'
    start_urls = ['https://www.foodservicedirect.com/deals']
    Sitename = 'Food Service Direct'
    siteurl = 'https://www.foodservicedirect.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="min-h-[inherit]"]'
        titalxpath = ".//a[contains(@data-testid,'product-title')]/text()[2]"
        imagexpath = './/img/@src'
        pricexpath = './/div[@class="max-400:mb-1  sm:-mb-2"]/del/text()'
        price2xpath = ".//span[contains(@class, 'max-400:text-[14px]')]/text()"
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })