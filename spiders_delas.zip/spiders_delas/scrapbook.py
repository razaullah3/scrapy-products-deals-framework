from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
from scrapy import Request

class ScrapbookSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'scrapbook'
    start_urls = ['https://www.scrapbook.com/store/page/1/f/?clearance=1']
    Sitename = 'scrapbook'
    siteurl = 'https://www.scrapbook.com'

    
    def start_requests(self):  
        self.headers = {  
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",  
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",  
            "Accept-Language": "en-US,en;q=0.5",  
            "Accept-Encoding": "gzip, deflate, br, zstd",  
            "Connection": "keep-alive",  
            "Upgrade-Insecure-Requests": "1",  
            "Sec-Fetch-Dest": "document",  
            "Sec-Fetch-Mode": "navigate",  
            "Sec-Fetch-Site": "none",  
            "Sec-Fetch-User": "?1",  
            "Priority": "u=0, i"  
        }  

        for url in self.start_urls:  
            yield Request(url, headers=self.headers, callback=self.parse, meta={'page': 1})  

    def parse(self, response):  
        item = couponsDealsItem()  
        item['getDoc'] = 'true'  
        item['SiteName'] = self.Sitename  
        yield item  
        item['getDoc'] = ''  

        divxpath = '//li[contains(@class,"pgitem pgEZitem")]'  
        titalxpath = './/div[@class="exp-reco-product-title"]/a/text()'  
        imagexpath = './/div[@class="cell"]/a/img/@src'  
        pricexpath = './/p[@class="product-price"]/span[2]/text()'  
        price2xpath = './/p[@class="product-price"]/span[1]/text()'  
        otherxpath = ''  

        yield response.follow(response.url, callback=self.Data_Collector, meta={  
            'url': self.siteurl,  
            'sname': self.Sitename,  
            'attribute': '',  
            'divxpath': divxpath,  
            'titalxpath': titalxpath,  
            'imagexpath': imagexpath,  
            'pricexpath': pricexpath,  
            'price2xpath': price2xpath,  
            'otherxpath': otherxpath,  
            'subcategorypage': '',  
            'nextpage': '',  
            'categorypage': ''  
        }, headers=self.headers, dont_filter=True)  

        # Pagination logic  
        current_page = response.meta.get('page', 1)  
        next_page = current_page + 1  
        next_url = f'https://www.scrapbook.com/store/page/{next_page}/f/?clearance=1'  

        # Follow next page only if products exist (check divxpath length)  
        if response.xpath(divxpath):  
            yield Request(next_url, headers=self.headers, callback=self.parse, meta={'page': next_page})  
    
