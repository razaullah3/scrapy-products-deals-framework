from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class AllCladDealsSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'allcladdeals'
    start_urls = ['https://www.all-clad.com/hot-deals.html']
    Sitename = 'All-Clad'
    siteurl = 'https://www.all-clad.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//li[@class="item product product-item"]'
        titalxpath = './/h2[@class="product name product-item-name product-name product-list"]/a/text()'
        imagexpath = './/div[contains(@class,"image-wrapper")]//img/@data-src'
        pricexpath = './/span[@data-price-type="finalPrice"]/@data-price-amount'
        price2xpath = './/span[@data-price-type="oldPrice"]/@data-price-amount'
        otherxpath = ''
        nextpage = ''  # Add pagination XPath if site has next page

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
