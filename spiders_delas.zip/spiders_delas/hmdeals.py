from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import random
import scrapy


class hmdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'hmdeal'
    start_urls = [
        # 'https://www2.hm.com/en_us/sale/women/view-all.html',
        'https://www2.hm.com/en_us/sale/men/view-all.html',
        # 'https://www2.hm.com/en_us/sale/baby/products.html',
        # 'https://www2.hm.com/en_us/sale/kids/products.html',
        # 'https://www2.hm.com/en_us/sale/sport/view-all.html',
        # 'https://www2.hm.com/en_us/sale/home/view-all.html'
    ]
    Sitename = 'H&M'
    siteurl = 'https://www2.hm.com'

    custom_settings = {
        'DOWNLOAD_TIMEOUT': 300,
        'RETRY_TIMES': 5,
        'DOWNLOAD_DELAY': 2,
        'CONCURRENT_REQUESTS': 2,
        'COOKIES_ENABLED': True,
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
    }

    def start_requests(self):
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
        ]
        for url in self.start_urls:
            headers = {
                'User-Agent': random.choice(user_agents),
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
            }
            yield scrapy.Request(url=url, headers=headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//article[@class="b55d17"]'
        titalxpath = './/h2/text()'
        imagexpath = './/img[1]/@src'
        pricexpath = './/del/text()'
        price2xpath = './/p[@class="a64e49"]/span/text()'
        otherxpath = ''

        # Process the current page
        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'categorypage': categorypage
        }, headers=response.request.headers, dont_filter=True)

        # # Extract and follow the next page link
        # next_page_url = response.xpath(
        #     '//li/button[@data-elid="pagination-next-page-button" and not(@disabled)]/ancestor::li/following-sibling::li/a/@href').get()
        # if next_page_url:
        #     full_next_page_url = response.urljoin(next_page_url)
        #     yield scrapy.Request(full_next_page_url, callback=self.parse, headers=response.request.headers,
        #                          dont_filter=True)
