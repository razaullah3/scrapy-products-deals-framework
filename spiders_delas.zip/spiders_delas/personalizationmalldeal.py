from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class PersonalizationMallDealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'personalizationmalldeal'
    start_urls = ['https://www.personalizationmall.com/search.aspx?sf=1&searchString=clearance&x=0&y=0']
    Sitename = 'PersonalizationMall'
    siteurl = 'https://www.personalizationmall.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # XPaths
        divxpath = '//div[@class="search-result"]//div[contains(@class,"search-item")]'
        titalxpath = './/div[@class="thumbProduct"]//a/text()[1]'
        imagexpath = './/img[@class="CAT_IMAGE"]/@src'
        pricexpath = './/div[@class="product-price"]//span//strong[@class="sale"]/text()'
        price2xpath = './/div[@class="product-price"]//span//span[@class="strike-thru"]/text()'
        otherxpath = ''
        nextpage_xpath = '//div[@class="search-paging"]//a[@class="nextArrow nextArrowActive"]/@href'
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # Send to Data_Collector
        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage_xpath,
            'categorypage': categorypage
        })

        # ---- Pagination ----
        next_page = response.xpath(nextpage_xpath).get()
        if next_page:
            yield response.follow(next_page, callback=self.parse)
