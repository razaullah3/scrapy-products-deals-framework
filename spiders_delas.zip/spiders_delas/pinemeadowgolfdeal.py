from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class pinemeadowgolfdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'pinemeadowgolfdeal'
    start_urls = ['https://www.pinemeadowgolf.com/golf-clubs/special']
    Sitename = 'Pinemeadow Golf'
    siteurl = 'https://www.pinemeadowgolf.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-box"]'
        titalxpath = './/h3[@class="product-name"]/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/small/text()'
        price2xpath = './/div[@class="current-price small-4 columns text-right"]/a/text()'
        otherxpath = './/span[@class="blurb"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })