import requests
import lxml.html
import json
import urllib3
from urllib.parse import urljoin

# Suppress insecure request warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class ShopNZDealsScraper:
    """A standalone scraper for Shop New Zealand deals that bypasses SSL issues"""

    def __init__(self):
        self.site_name = 'Shop New Zealand'
        self.site_url = 'https://www.shopnewzealand.co.nz'
        self.start_url = 'https://www.shopnewzealand.co.nz/product-flags/hot-deal'
        self.results = []

    def fetch_page(self, url):
        """Fetch page content with SSL verification disabled"""
        try:
            response = requests.get(url, verify=False, timeout=30)
            response.raise_for_status()
            return response.text
        except Exception as e:
            print(f"Error fetching {url}: {e}")
            return None

    def parse_deals(self, html_content, url):
        """Parse deal items from HTML content"""
        if not html_content:
            return []

        # Parse HTML
        doc = lxml.html.fromstring(html_content)

        # Find all deal items
        div_xpath = '//div[@class="content"]//div[@class="view-content"]/div'
        items = doc.xpath(div_xpath)

        deals = []
        for item in items:
            try:
                # Extract data using XPaths
                title = item.xpath('.//span[@class="field-content"]/a/text()')
                title = title[0].strip() if title else 'No Title'

                image = item.xpath('.//img/@src')
                image = urljoin(self.site_url, image[0]) if image else None

                list_price = item.xpath('.//div[@class="views-field views-field-list-price"]/span/text()')
                list_price = list_price[0].strip() if list_price else None

                sell_price = item.xpath('.//div[@class="views-field views-field-sell-price"]/span/text()')
                sell_price = sell_price[0].strip() if sell_price else None

                # Create deal object
                deal = {
                    'title': title,
                    'image': image,
                    'list_price': list_price,
                    'sell_price': sell_price,
                    'url': url
                }
                deals.append(deal)
            except Exception as e:
                print(f"Error parsing item: {e}")

        return deals

    def get_next_page(self, html_content, current_url):
        """Extract next page URL if available"""
        if not html_content:
            return None

        doc = lxml.html.fromstring(html_content)
        next_page = doc.xpath('//li[@class="pager-next"]/a/@href')

        if next_page:
            return urljoin(self.site_url, next_page[0])
        return None

    def scrape(self):
        """Main scraping method"""
        url = self.start_url

        while url:
            print(f"Scraping: {url}")
            html_content = self.fetch_page(url)

            if html_content:
                # Parse deals on current page
                deals = self.parse_deals(html_content, url)
                self.results.extend(deals)

                # Get next page URL
                url = self.get_next_page(html_content, url)
            else:
                url = None

        return self.results

    def save_to_json(self, filename='shop_nz_deals.json'):
        """Save results to JSON file"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2)
        print(f"Saved {len(self.results)} deals to {filename}")


if __name__ == "__main__":
    # Run the scraper
    scraper = ShopNZDealsScraper()
    results = scraper.scrape()
    scraper.save_to_json()

    # Print summary
    print(f"Total deals scraped: {len(results)}")
    for i, deal in enumerate(results[:5], 1):
        print(f"{i}. {deal['title']} - {deal['sell_price']}")