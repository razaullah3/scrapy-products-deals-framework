import scrapy
import json
import datetime
from ..items import couponsDealsItem


class PetcoDealSpider(scrapy.Spider):
    name = "petco_deal"

    # ✅ Base API (page number is dynamic)
    base_api = (
        "https://pwcdauseo-zone.cnstrc.com/browse/group_id/dog-deals?"
        "c=ciojs-client-2.64.2&key=key_afiSr5Y4gCaaSW5X&i=1eaebf32-1c4c-4b90-b6c4-00940229c66b"
        "&s=1&page={page}&num_results_per_page=48&&sort_by=relevance&sort_order=descending&_dt=1761884305652"
    )

    # ✅ Headers (exactly as you provided)
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.petco.com/",
        "Origin": "https://www.petco.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4",
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_api.format(page=1),
            headers=self.custom_headers,
            callback=self.parse,
            meta={"page": 1},
        )

    def parse(self, response):
        page = response.meta.get("page", 1)

        try:
            data = json.loads(response.text)
            results = data.get("response", {}).get("results", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON on page {page}: {e}")
            return

        total_products = 0
        for product in results:
            total_products += 1
            data_field = product.get("data", {})
            yield self.extract_product_item(data_field)

        # ✅ Pagination
        if total_products > 0:
            next_page = page + 1
            next_url = self.base_api.format(page=next_page)
            yield scrapy.Request(
                url=next_url,
                headers=self.custom_headers,
                callback=self.parse,
                meta={"page": next_page},
            )

    def extract_product_item(self, data):
        """Extract product details into couponsDealsItem"""
        item = couponsDealsItem()

        # ✅ Required fields
        item["SourceUrl"] = 'https://www.petco.com' + data.get("url", "")
        item["Title"] = data.get("itemname", "")
        item["Image"] = data.get("image_url", "")
        item["Price"] = data.get("listprice", "")
        item["SalePrice"] = data.get("offerprice", "")

        # ✅ Calculate discount if possible
        try:
            sale = float(data.get("offerprice", 0))
            reg = float(data.get("listprice", 0))
            if reg > sale > 0:
                discount = round(((reg - sale) / reg) * 100, 1)
                item["Offer"] = f"{discount}% off"
            else:
                item["Offer"] = ""
        except Exception:
            item["Offer"] = ""

        # ✅ Static metadata
        item["SiteName"] = "Petco"
        item["SiteURL"] = "https://www.petco.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
