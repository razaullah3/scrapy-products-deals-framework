import scrapy
import json
import datetime
from ..items import couponsDealsItem


class ContikiSpider(scrapy.Spider):
    name = "contiki_deals"

    # ALL API combinations to crawl
    query_list = [
        "destinations=Europe&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "destinations=Asia&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "destinations=South+America&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "destinations=Africa&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "destinations=North+America&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "destinations=Oceania&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "countries=canada&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "countries=new+zealand&brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true",
        "brands=Contiki&useEmbeddedCards=true&applySeasonFilter=true"
    ]

    # BASE API PREFIX
    base_url = "https://www.contiki.com/en-us/search/search?"

    # HEADERS
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.contiki.com/en-us/search?destinations=North+America&brands=Contiki&pageIndex=1&useEmbeddedCards=true&applySeasonFilter=true",
        "Connection": "keep-alive",
        "Cookie": "Region_Pref=en-us; Region_Cur=en-us; SiteVisitor=true; CookieConsent={stamp:%27-1%27%2Cnecessary:true%2Cpreferences:true%2Cstatistics:true%2Cmarketing:true%2Cmethod:%27implied%27%2Cver:1%2Cutc:1763529784195%2Cregion:%27US-35%27}; _ga_QMW3TEXN7N=GS2.1.s1763529789^$o1^$g1^$t1763529922^$j60^$l0^$h94580960; _ga=GA1.1.1605949670.1763529790; _gcl_au=1.1.216871672.1763529790; __pdst=435f5244d54842c3ae16748216f05aae; _sfid_c862={%22anonymousId%22:%22e1177c1509b94338%22%2C%22consents%22:[]}; _evga_c2d5={%22uuid%22:%22e1177c1509b94338%22}; IR_gbd=contiki.com; IR_21293=1763529822822%7C4866558%7C1763529822822%7C%7C; smartDash=f82a40b6-bf3f-4137-9699-708279edaf82; inside-eu2=1174787512-500023ad87c8bb109b03b77a256494b1e243c2fe756ed0a66c612e64b31e64f4-0-0; optimizelyEndUserId=oeu1763529800136r0.5966160290288425; optimizelySession=1763529827681",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0",
        "TE": "trailers"
    }

    def start_requests(self):
        """Start crawling all search combinations."""
        for query in self.query_list:
            url = f"{self.base_url}{query}&pageIndex=0"
            yield scrapy.Request(
                url=url,
                headers=self.custom_headers,
                callback=self.parse,
                meta={"page": 0, "query": query},
            )

    def parse(self, response):
        page = response.meta["page"]
        query = response.meta["query"]

        try:
            data = json.loads(response.text)
            trips = data.get("trips", [])
        except Exception as e:
            self.logger.error(f"JSON ERROR on page {page} for query: {query} → {e}")
            return

        # If no more results → stop pagination for this query
        if not trips:
            self.logger.info(f"NO MORE RESULTS for query '{query}' at page {page}")
            return

        # Yield each trip
        for trip in trips:
            yield self.extract_trip(trip)

        # Continue pagination
        next_page = page + 1
        next_url = f"{self.base_url}{query}&pageIndex={next_page}"

        yield scrapy.Request(
            url=next_url,
            headers=self.custom_headers,
            callback=self.parse,
            meta={"page": next_page, "query": query},
        )

    def extract_trip(self, trip):
        """Extract product/trip data."""
        item = couponsDealsItem()

        item["SourceUrl"] = trip.get("url", "")
        item["Price"] = trip.get("priceOld", "")
        item["SalePrice"] = trip.get("priceFrom", "")
        item["Title"] = trip.get("desc", "")
        item["Offer"] = trip.get("priceSaving", "")

        # IMAGE
        hero = trip.get("hero", {})
        image_url = hero.get("url", "")
        if image_url.startswith("/"):
            image_url = "https://www.contiki.com" + image_url
        item["Image"] = image_url

        # Static meta info
        item["SiteName"] = "Contiki"
        item["SiteURL"] = "https://www.contiki.com"
        item["Framework"] = "3"
        item["dealpage"] = "True"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()

        return item
