from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy

class jaredclearancedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'jaredclearance'
    start_urls = ['https://www.jared.com/clearance/c/7000000270?icid=COL_CLEARANCE:HERO:ShopAll']
    Sitename = 'jaredclearance'
    siteurl = 'https://www.jared.com'

    # -------------------------
    # Headers to avoid 403
    # -------------------------
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Cookie": "visitor_fpid_id=8099fcdb-24b4-4841-a5ae-92ead5ebcd17; MISCGCs=USERPC1_92_871013_87_USERLL1_92_35.0846%2C-106.65163_87_USERST1_92_NM3_87_LOCST1_92_NM3_87_USERDMA1_92_7903_87_DT1_92_PC; SEED=-5055597761874279554%7C2153-21%2C2157-21%2C2512-20%7C2113-24%2C2135-21%2C2139-21%2C2354-21%2C2483-22%2C2503-21%2C2505-21%2C2532-21%2C2546-22%2C2547-21%2C2570-21%2C2595-21%2C2635-21%2C2644-21%2C2674-21; _abck=213AC301C6AF6F275432DB61F113E9FE~-1~YAAQtDbFFyMEZIuaAQAAeYhDpQ7Px1Hgdd6byVfID7xRuAYVgsOtA0KXdtpMRqxiAfZKMSDm1RetrMHHqUelZd2AjKlBHU95h9BwMBBMLGtB8Z2finVFqSDYZepAAqFWN3FQAVRlcbm2KkhrSwmpsd9JaO2lGqnGbPVlzvkLQUaLfdN/qb2verH/avEmRdU6m47fCFDOTcUn85+R6+YmJfUebhRD27QevQwoyEQzSw4ijfq60EFmPJOmljZeVQPnzGcts70N96kJ7m/R6Rbboge9wGlqWz4yXwxLiPOnB3BBS25+WzXY++zDOCvHgZZXKjaJS9YkKLoWW2ER75QqJtBffX7jPL3lQWOSNFk+JGoOpMUreB8IIfSCgEoi7h4UPsWu4qlGVUhymiVFCVJqZLWLaIr+jyeNpDiCAE5o3weRsCOeqRArSOidh/nJKFs1JCPW53jPEEU5dXoat2V75GPI6VTCJZnLlNX0tNJOwda1K8pjldNrJS7/zQBERc/BzKuYOejGRZXpKNV8NMTg2iQ4jq8dNTleXsIlwxbK2zimzPoiHNKYemJIb7Ptc/sE8OW0DYfLRMW2TqzTuYxnHmx725SUzTtc5aC29YOw1T4HzJ+K7rsMEtPJVk0JgW3HuyP+5eOj0/MdpsbV4QJkJAX88Q0Dt8ETSxw42cOUzlWdQge7eXfjKzxhDmJb~-1~-1~1763712857~AAQAAAAE%2f%2f%2f%2f%2fyBiZ8aLVSiWPo6yB93JGJ5HcnNgz49FPyJvDFT9SwjsImMmY57s2FYZAHmH3LObadPWvtUx52ElWgcwvwy72G78N1SJw1Ggjt+a~1763709317; utag_main=v_id:019a0524b19b001535ad0fb2f8da05050009200d0086e^$_n:2^$_e:1^$_s:1^$_t:1763711061397^$ses_id:1763709261397%3Bexp-session^$_n:1%3Bexp-session; _gcl_au=1.1.1972911476.1761022884; OptanonConsent=isGpcEnabled=1&datestamp=Tue+Oct+21+2025+10%3A16%3A59+GMT%2B0500+(Pakistan+Standard+Time)&version=202509.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=9e8ea7bd-acad-43f6-a635-d99e2160cede&interactionCount=1&isAnonUser=1&landingPath=https%3A%2F%2Fwww.bloomingdales.com%2Fshop%2Ffashion-lookbooks-videos-style-guide%2Fcustomer-top-rated%2FSpecial_offers%2FBuy%2520More%25252C%2520Save%2520More%3Fid%3D1097159&groups=C0001%3A1%2CC0003%3A1%2CC0002%3A1%2CSPD_BG%3A0%2CC0005%3A0%2CC0004%3A0; RTD=9a0527eda857f09a0527eda838209a0527eda8c8709a0527eda8e6e0; GCLB=CPvs1YLqo_GUTRAD; SignedIn=0; GCs=CartItem1_92_03_87_UserName1_92_4_02_; mercury=true; shippingCountry=US; currency=USD; akavpau_www_www1_bcom=1763709554~id=24e55be5655fd16d5f108c252e77cc16; ak_bmsc=1C9B22706C1AA63C8EEC3636DCE075D1~000000000000000000000000000000~YAAQtDbFF1IEZIuaAQAADYpDpR3cLkpFiSc3juDz1ID3dN/FsD8NVyvenviuLHnPp3qd9oIyUt72f7Jj5DiXqr3XDGa7mgY7rp10sPvELw6m0R/OkpOOtRTJBeAnLl5hoh47FqscU5SCYpTUvJQEHbKTAc8V7ykvkQI8CrWY02y4i3KKxH5vtrUjntHbXv3wQU0DywxbWQrE0CUzwZf8q17gsHD9kKp+14IfmTeoTbMEWPN5mNsH1DYkF+y3DtwxyQwAeKtYOKEAg4jNg0dT1KI1FF25oggyTeo25KUFwDXzxRFkZwjRmO+SQfg5pEfxJEYEeURGmpOz0eIF5rFEDgXgVHbTXgKGKDKAqV99a6TjEx8C/mokAggjWwF3N55lR8Yo09upGClsT66LjJpgydnJH7SSgSR1B7GtuSlH9/jFiRaBhHJOdqBiTL34H5F1JSLMNf/2Sjw4d4rVK+gSjKrqGDjl8jpK; bm_sz=2D4B5987136CE7EB8451BC958863E068~YAAQtDbFF9QCZIuaAQAAoJJDpR3OUDLhUwqqRzLEK99YP6Qg3x4W962MGLRtOCrd7XtY2MJ5vWX/fObcKuZ8TRjJIogNb77TbgxbZoWlUQ6jV+FyRQW5nOid+Biw1gPEzdD43+AQRttAvSKq6Zh4BRqqin1Du26Z2leu+zlnOIzItVbKvd5JDF/gA0buIcIgZdIRRF06qMNxkCDX/RzbdnLHWkzgVTQ8Wp1qy0MyGNi+qRcCv7D8Z8dFOuqAt7qwsezdHfsokA==~1",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "DNT": "1",
    }

    # Apply headers globally
    custom_settings = {
        "DEFAULT_REQUEST_HEADERS": headers
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="row js-product-name-details"]'
        titalxpath = './/h2[@class="name product-tile-description"]//a/text()'
        imagexpath = './/img[@class="img-responsive js-lazyload with-border"]/@src'
        pricexpath = './/div[@class="plp-align"]/text()[contains(.,"$")][1]'
        price2xpath = './/div[contains(@class,"other-prices")]//div[@class="plp-align"]/text()'
        otherxpath = ''
        nextpage = ''

        # First page request
        yield scrapy.Request(
            url=response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )

        # -------------------------
        # Load More Logic (unchanged)
        # -------------------------
        current_count = response.xpath("//span[@class='js-showing-products']/text()").get()
        total_count = response.xpath("//div[contains(@class,'load-more-container__pageDetails')]/text()").re_first(r'of (\d+)')

        if current_count and total_count:
            current_count = int(current_count.strip())
            total_count = int(total_count)
            load_more = 1

            while current_count < total_count:
                next_url = f"{response.url}&loadMore={load_more}"
                yield scrapy.Request(
                    url=next_url,
                    callback=self.Data_Collector,
                    meta={
                        'url': self.siteurl,
                        'sname': self.Sitename,
                        'attribute': attribute,
                        'divxpath': divxpath,
                        'titalxpath': titalxpath,
                        'imagexpath': imagexpath,
                        'pricexpath': pricexpath,
                        'price2xpath': price2xpath,
                        'otherxpath': otherxpath,
                        'subcategorypage': subcategorypage,
                        'nextpage': nextpage,
                        'categorypage': categorypage
                    }
                )
                current_count += 42  # approx per page products
                load_more += 1
