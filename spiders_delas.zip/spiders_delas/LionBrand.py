import json
import scrapy
import datetime
from ..items import couponsDealsItem

class LionBrandSpider(scrapy.Spider):
    name = 'lionbrand_deals'
    Sitename = 'LionBrand'
    siteurl = 'https://www.lionbrand.com'
    
    start_urls = [
        'https://xna283.a.searchspring.io/api/search/search.json?userId=5f379cca-0ad4-4c61-b223-a3019a29330f&domain=https%3A%2F%2Fwww.lionbrand.com%2Fcollections/clearance&sessionId=1d5c1ede-a168-44f2-a19e-200869580f88&pageLoadId=ed7ef752-71f6-468b-b339-c72c3f5f9e27&siteId=xna283&bgfilter.collection_handle=clearance&noBeacon=true&ajaxCatalog=Snap&resultsFormat=native&page=1'
    ]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
        'userId': '5f379cca-0ad4-4c61-b223-a3019a29330f',
        'domain': 'https%3A%2F%2Fwww.lionbrand.com%2Fcollections/clearance',
        'sessionId': '1d5c1ede-a168-44f2-a19e-200869580f88',
        'pageLoadId': 'ed7ef752-71f6-468b-b339-c72c3f5f9e27',
        'siteId': 'xna283',
        'bgfilter.collection_handle': 'clearance',
        'noBeacon': 'true',
        'ajaxCatalog': 'Snap',
        'resultsFormat': 'native',
        'Accept': '*/*',
        'Connection': 'keep-alive'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get('results', [])
        self.logger.info(f"Found {len(products)} products on this page.")

        for p in products:
            item = couponsDealsItem()
            item['Title'] = p.get('name', '').strip()
            item['Image'] = p.get('imageUrl', '')
            item['SourceUrl'] = self.siteurl + p.get('url', '')  # Base URL + relative URL
            item['Price'] = p.get('price', None)    # Sale Price
            item['SalePrice'] = p.get('msrp', None) # MSRP / Old Price
            item['Framework'] = '3'
            item["Offer"] = ''
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        current_page = data.get('pagination', {}).get('currentPage', 1)
        total_pages = data.get('pagination', {}).get('totalPages', 1)
        if current_page < total_pages:
            next_page = current_page + 1
            next_url = response.url.split('&page=')[0] + f'&page={next_page}'
            yield scrapy.Request(url=next_url, callback=self.parse, headers=self.headers)
