import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class seafollydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'seafollydeal'
    start_urls = ['https://us.seafolly.com/collections/all-sale']
    Sitename = 'Seafolly'
    siteurl = 'https://us.seafolly.com'

    def start_requests(self):
        api_url = 'https://lwxsfv.a.searchspring.io/api/search/search.json?userId=0806af39-0642-4541-a688-5469057cec09&domain=https%3A%2F%2Fus.seafolly.com%2Fcollections%2Fall-sale%3Fpage%3D2&sessionId=2bf56291-e36b-4b8d-b307-7e0c408563fe&pageLoadId=8feb75d0-8e50-49b1-82a3-dfa205630822&siteId=lwxsfv&page=1&bgfilter.collection_handle=all-sale&bgfilter.ss_hide_oos=0&redirectResponse=full&resultsFormat=native'
        yield scrapy.Request(url=api_url)

    def parse(self, response):
        for req in self.getproducts(response):
            yield req

        listing_json = json.loads(response.text)
        total_page = listing_json['pagination']['totalPages']

        page = 2
        while int(total_page) >= page:
            api_url = f'https://lwxsfv.a.searchspring.io/api/search/search.json?userId=0806af39-0642-4541-a688-5469057cec09&domain=https%3A%2F%2Fus.seafolly.com%2Fcollections%2Fall-sale%3Fpage%3D2&sessionId=2bf56291-e36b-4b8d-b307-7e0c408563fe&pageLoadId=8feb75d0-8e50-49b1-82a3-dfa205630822&siteId=lwxsfv&page={str(page)}&bgfilter.collection_handle=all-sale&bgfilter.ss_hide_oos=0&redirectResponse=full\&resultsFormat=native'
            yield response.follow(api_url, callback=self.getproducts, dont_filter=True)
            page += 1

    def getproducts(self, response):
        item = couponsDealsItem()

        listing_json = json.loads(response.text)
        for m in listing_json['results']:
            if int(m['ss_available']) < 1:
                continue

            item['Title'] = m['title']
            item['Image'] = m['imageUrl']

            price = m['msrp']
            if price:
                item['Price'] = f"${price}"
            else:
                item['Price'] = ''

            item['SalePrice'] = f"${m['price']}"
            item['Offer'] = ''
            item['SourceUrl'] = f"{self.siteurl}/products/{str(m['handle'])}"
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item
