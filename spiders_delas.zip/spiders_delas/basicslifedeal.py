import datetime
import json

import requests
import scrapy
import validators

from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class basicslifeSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'basicslifedeal'
    start_urls = ['https://basicslife.com/collections/sales']
    Sitename = 'BasicsLife'
    siteurl = 'https://basicslife.com'

    def start_requests(self):
        api_url = 'https://services.mybcapps.com/bc-sf-filter/filter?t=1675768478085&_=pf&shop=basics-man.myshopify.com&page=1&limit=21&sort=manual&display=grid&collection_scope=160252035153&tag=&product_available=true&variant_available=true&build_filter_tree=false&check_cache=false'
        yield scrapy.Request(url=api_url, callback=self.getData)
        api_resp = requests.get(api_url)
        listing_json = json.loads(api_resp.text)
        page = 2
        pro_per_page = 21
        total_products = listing_json['total_product']
        if int(total_products) % pro_per_page == 0:
            total_page = int(total_products) / pro_per_page
        else:
            total_page = int(total_products) / pro_per_page + 1
        total_page = str(total_page).split('.')[0]
        while int(total_page) >= page:
            api_url = 'https://services.mybcapps.com/bc-sf-filter/filter?t=1675768478085&_=pf&shop=basics-man.myshopify.com&page=' + str(
                page) + '&limit=21&sort=manual&display=grid&collection_scope=160252035153&tag=&product_available=true&variant_available=true&build_filter_tree=false&check_cache=false'
            yield scrapy.Request(url=api_url, callback=self.getData, dont_filter=True)
            page += 1

    def getData(self, response):
        urlx = self.siteurl
        item = couponsDealsItem()
        listing_json = json.loads(response.text)
        for m in listing_json['products']:
            if not bool(m['available']):
                continue
            item['Title'] = m['title']
            image = m['images_info'][0]['src']
            if not validators.url(str(image)):
                image = urlx + str(image)
            item['Image'] = image
            sale_price = m['price_min']
            price = m['compare_at_price_max']
            if sale_price == price:
                item['Price'] = 0
            item['Price'] = '₹' + str(price)
            item['SalePrice'] = '₹' + str(sale_price)
            item['Offer'] = ''
            sourceurl = m['handle']
            sourceurl = urlx + '/products/' + str(sourceurl)
            item['SourceUrl'] = sourceurl
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'
            yield item
