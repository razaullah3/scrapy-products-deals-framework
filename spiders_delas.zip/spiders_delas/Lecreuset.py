from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class lecreusetdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'lecreusetdeal'
    start_urls = ['https://www.lecreuset.com/catalogsearch/result?q=saving&lang=null']

    Sitename = 'lecreusetdeal'
    siteurl = 'https://www.lecreuset.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '////div[@class="row product-grid"]//div[contains(@class,"col-6 col-sm-4 js-async-tile")]'
        titalxpath = './/div[@class="pdp-link"]//a/text()'
        imagexpath = './/div[@class="image-container"]//img/@src'
        pricexpath = './/span[@class="sales"]/span[@class="value"]/text()'
        price2xpath = './/span[@class="strike-through list"]/span[@class="value"]/text()'
        otherxpath = ''
        nextpage = '//button[contains(@class,"btn btn-show-more ")]/@data-url'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })