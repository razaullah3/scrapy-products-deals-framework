import datetime
import scrapy
import json
import re
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class vividracingdealSpider(GetDealsProducts):
    name = 'vividracingdeal'
    allowed_domains = ['vividracing.com']
    start_urls = ['https://www.vividracing.com/clearance-deals-c-8127.html']
    Sitename = 'vividracing'
    siteurl = 'https://www.vividracing.com'
    
    def parse(self, response):
        # Extract category URLs
        category_links = response.xpath('//div[@id="categories-body"]//li[@class="widget-list-item widget-filter-item"]/a/@href').getall()
        for link in category_links:
            full_url = response.urljoin(link)
            yield scrapy.Request(full_url, callback=self.parse_category)
    
    def parse_category(self, response):
        script_content = response.xpath('//script[contains(text(), "var VR_PRELOAD")]/text()').get()
        if not script_content:
            self.logger.warning("VR_PRELOAD script not found.")
            return
        
        try:
            # Extract and clean JSON from the script
            json_text = re.search(r'var VR_PRELOAD\s*=\s*({.*?});', script_content, re.DOTALL).group(1)
            json_data = json.loads(json_text)
            products = json_data.get('products', [])
            
            for product in products:
                self.logger.info(f"Processing product: {product.get('products_name')}")
                
                item = couponsDealsItem()
                
                # Required fields for UploadDealProduct
                item['Title'] = product.get('products_name', '')
                item['Image'] = 'https://cdn.vividracing.com/file/' + product.get('products_image', '').replace('\/', '/')
                item['Price'] = product.get('final_price', '')
                item['SalePrice'] = product.get('products_price', '')
                item['SourceUrl'] = product.get('link', '')
                item['Framework'] = '3'
                item['SiteName'] = self.Sitename
                item['SiteURL'] = self.siteurl
                
                # Calculate offer/saving if both prices are available
                try:
                    regular_price = float(item['Price']) if item['Price'] else 0
                    sale_price = float(item['SalePrice']) if item['SalePrice'] else 0
                    
                    if regular_price > 0 and sale_price > 0:
                        saving = regular_price - sale_price
                        saving_percentage = (saving / regular_price) * 100
                        item['Offer'] = f"Save ${saving:.2f} ({saving_percentage:.0f}% Off)"
                    else:
                        item['Offer'] = "CLEARANCE"
                except (ValueError, TypeError):
                    item['Offer'] = "CLEARANCE"
                
                # Dates for tracking
                item['DateAdded'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                item['DateUpdated'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                # Set the dealpage flag to True to trigger UploadDealProduct in pipeline
                item['dealpage'] = 'True'
                
                # Set Featured field
                item['Featured'] = '1'
                
                # Set Status to Active
                item['Status'] = 'Active'
                
                self.logger.info(f"Yielding product: {item['Title']} - ${item['SalePrice']}")
                yield item
                
        except Exception as e:
            self.logger.error(f"JSON parsing error: {e}")
            
        # Check for pagination
        next_page = response.xpath('//a[@rel="next"]/@href').get()
        if next_page:
            yield scrapy.Request(response.urljoin(next_page), callback=self.parse_category)