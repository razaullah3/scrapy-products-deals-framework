from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class holygrailsteakdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'holygrailsteakdeal'
    start_urls = ['https://holygrailsteak.com/collections/promotions-deals']
    Sitename = 'Holy Grail Steak Co.'
    siteurl = 'https://holygrailsteak.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="grid-item grid-product "]'
        titalxpath = './/div[@class="grid-product__title"]/text()'
        imagexpath = './/div[@class="grid-product__image-wrap"]/div/img/@srcset'
        pricexpath = './/span[@class="grid-product__price--original"]/span[@aria-hidden="true"]/text()'
        price2xpath = './/span[@class="grid-product__price--current"]/span[@aria-hidden="true"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })