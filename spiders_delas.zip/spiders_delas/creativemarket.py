from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class createmarketdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'creativemarketdeal'
    start_urls = [' https://creativemarket.com/sale']
    Sitename = 'alphabetdeal'
    siteurl = 'https://creativemarket.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="search__results"]//div[@data-module="Search Results"]'
        titalxpath = './/div[@class="product-details"]/a/text()'
        imagexpath = './/img[@class="product-thumbnail__image"]/@src'
        pricexpath = './/div[@class="product-info__price"]/span[2]'
        price2xpath = './/div[@class="product-info__price"]/span[1]'
        otherxpath = '.'
        nextpage = '//a[contains(@data-cypress,"pagination-next")]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })