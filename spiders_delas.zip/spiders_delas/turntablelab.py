from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class TurntableLabSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'turntablelab_clearance'
    start_urls = ['https://www.turntablelab.com/collections/clearance-sale-alpha']
    Sitename = 'TurntableLab'
    siteurl = 'https://www.turntablelab.com'

    def parse(self, response):
        # Initial doc item
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # XPaths & meta info
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="collection__inner"]//div[@class="product-item__inner"]'
        titalxpath = './/h3[@class="product-item__product-title fs-product-title ff-body"]/a/text()'
        sourceurlxpath = './/h3[@class="product-item__product-title fs-product-title ff-body"]/a/@href'
        imagexpath = './/div[contains(@class,"product-item__image")]//img[contains(@class,"image__img")]/@src'
        pricexpath = './/span[contains(@class,"sale")]//span[contains(@class,"money")]/text()'
        price2xpath = './/s[@class="t-subdued"]//span[@class="money"]/text()'
        otherxpath = ''
        nextpage = ''

        # Pass everything to Data_Collector
        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'sourceurlxpath': sourceurlxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
                'imageprefix': 'https:',   # ⚡ automatically prefix if URL starts with //
                'sourceprefix': 'https:'   # ⚡ automatically prefix if URL starts with //
            }
        )
