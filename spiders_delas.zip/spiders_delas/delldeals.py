import scrapy
import datetime
from ..items import couponsDealsItem


class DellSaleSpider(scrapy.Spider):
    name = 'delldeal'
    allowed_domains = ['dell.com']
    start_urls = [
        'https://www.dell.com/en-us/shop/deals',
        'https://www.dell.com/en-us/shop/deals?page=2',
        'https://www.dell.com/en-us/shop/deals?page=3',
    ]

    site_name = "Dell"
    site_url = "https://www.dell.com"

    def parse(self, response):
        """Parse Dell deals page and extract products using XPath."""
        self.logger.info(f"Scraping page: {response.url}")

        page_number = response.url.split('page=')[-1] if 'page=' in response.url else '1'
        filename = f'dell_page_{page_number}.txt'
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(response.text)
        self.logger.info(f"Saved HTML response to {filename}")

        # Select all product blocks
        product_divs = response.xpath('//article[@class="stack-system ps-stack"]')
        self.logger.info(f"Found {len(product_divs)} products on this page")

        for index, div in enumerate(product_divs, start=1):
            item = couponsDealsItem()

            # Extract product title
            title = div.xpath('.//div[@class="ps-desc"]/p/text()').get(default='').strip()
            item['Title'] = title

            # Extract product image
            image_url = div.xpath('.//img/@src').get()
            if image_url and image_url.startswith('//'):
                image_url = 'https:' + image_url
            item['Image'] = image_url or ''

            # Extract prices
            old_price = div.xpath('.//div[@class="ps-orig ps-simplified"]/del/text()').get(default='').strip()
            new_price = div.xpath('.//div[@class="ps-dell-price ps-simplified"]/span[2]/text()').get(default='').strip()
            item['Price'] = old_price
            item['SalePrice'] = new_price

            # Extract discount/offer if available
            offer_text = div.xpath('.//div[@class="ps-sav"]/span/text()').get(default='').strip()
            item['Offer'] = offer_text

            # Extract product URL
            product_url = div.xpath('.//a[@class="ps-dellprice"]/ancestor::a/@href').get()
            if product_url and product_url.startswith('/'):
                product_url = self.site_url + product_url
            item['SourceUrl'] = product_url or response.url

            # Standard meta fields
            item['Framework'] = '3'
            item['SiteName'] = self.site_name
            item['SiteURL'] = self.site_url
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            # Debug print
            print(f"[{index}] {item['Title']} | {item['SalePrice']} | {item['SourceUrl']}")
            
            yield item

        # Optional: handle pagination if there’s a next page
