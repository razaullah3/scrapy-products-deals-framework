from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class dealcatcherdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'dealcatcher'
    start_urls = ['https://www.dealcatcher.com/']
    Sitename = 'dealcatcher'
    siteurl = 'https://www.dealcatcher.com/'

    # Custom headers
    custom_headers = {
        
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Referer": "https://www.dealcatcher.com/?__cf_chl_tk=N4juJLV5eTye_GY.2pknrQuI6KfZUTu.ycckUh.D0GI-1759396641-1.0.1.1-B7si1hbfsgA0K.achZxS_wj0rNyUy.CdGAmCBaUFQvM",
    "Content-Type": "application/x-www-form-urlencoded",
    "Origin": "https://www.dealcatcher.com",
    "Connection": "keep-alive",
    
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Fetch-User": "?1",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=0, i",
    "TE": "trailers"


        
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[contains(@class, "max-w-screen-lg")]'
        titalxpath = 'string(.//h3//a)'
        imagexpath = './/img/@src'
        pricexpath = './/div//span[@class="text-gray-500 line-through"]/text()'
        price2xpath = '//div//span[@class="text-green-700 font-bold text-lg"]/text()'
        offerxpath = './/div[@class="price"]//span/text()'
        otherxpath = './/h3//a/text()[1]'
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.custom_headers,  # <-- Add headers here
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
                'offer': offerxpath
            }
        )
