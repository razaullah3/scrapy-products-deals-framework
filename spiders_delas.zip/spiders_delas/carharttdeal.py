import json
import scrapy
import datetime
from ..items import couponsDealsItem


class CarharttApiSpider(scrapy.Spider):
    name = "carharttapi"

    # FULL API (no splitting params)
    api_url = "https://api-c4prd1.carhartt.com/ws/v2/carhartt/products/search?defaultPageSizeConfigured=1&fields=products(FULL%2Cbadges(FULL)%2CpriceRange(minPrice(FULL)%2CmaxPrice(FULL))%2CmsrpRange(minPrice(FULL)%2CmaxPrice(FULL)))%2Cfacets(FULL)%2Cbreadcrumbs(FULL)%2Cpagination(FULL)%2Csorts(FULL)%2CcurrentQuery(FULL)%2CfreeTextSearch%2Ccategory(FULL)%2CparentCategoryPath(FULL)%2CkeywordRedirectUrl%2CredirectUrl&query=%3Arelevance%3AallCategories%3Asale&currentPage={}&pageSize=12&lang=en&curr=USD&countryIsoCode=US"

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.carhartt.com/c/sale",
        "X-Anonymous-Consents": "[]",
        "Origin": "https://www.carhartt.com",
        "Connection": "keep-alive",
        "Cookie": "AKA_A2=A; _abck=035EC2DD72B2F501101D0F64D359129D~-1~YAAQk/kpF0tcvKOaAQAA7lnepA5fCjL3NkGTgZcdzHi/+6adRA5tLu3o5vHWZjnZbToNHshUZDbIx/noKzDiOhlkYN8C1owjG5lo79HPXKgU5ITVWFylcSoGprGI7w/TEMln5SkoiUkSwI1cXevTAUlZwYkBmj7t/GZ8bvhXQQQPXOADEC56zsJCZo7ZSWy/LbB6SIyLhZhNvcgUrzawU6fQexRcV5P8wWP/mS5aGkJTJPFwtHWhdCZvZcPpOX+F5C/KQWCwAyvRXyNlbH//eYmB0kKlwCGyYvp09zFRu5pm5NmLQqr7ezQKOw573OzcD8gLXNGl9q2DmhMifSVUxsgfctcIo5fA6aw93i7DdHeMgtZIkEXgg9GIsV76WeLXJYHGDGXRKnXuoqnaxluvX9C93kFQiwmcxQhmA25xDgym617CW7qwwerbVOjHPoNDtUAYfIRmya+kqGaemrZUV90JycM3QMmpY2+9NP47iChN14pMNPSexPaWyAX4Flr0n+NTu9aLP4iNbZrfPUPRIiHjTC1VkCtDFrQvWJi/dgbZeuwc6FGuaoZLXRKK6xPqAUWNiZK07e1cXBjmXkqH9XSsjxcL4UWW8gQOwkjPSwE=~-1~-1~1763706222~AAQAAAAE%2f%2f%2f%2f%2f+brOR2rGkwM8QtdswenRE6ADt9%2fd2vP7R5oKZRNtrU8ubyHd8eIkAEOn9shfCJRhA39W9wbl1tETlQYe5%2fm3cqa4d86ERIXX6au~-1; ak_bmsc=8D8EA8BA045AEEACDCB9B60AD50C8711~000000000000000000000000000000~YAAQk/kpF79ZvKOaAQAAU0jepB0v5Kry9Yu/OhM1LagqPplakt1VvFCN8rrgUPdtjrJAG4kBTq9GCcHJswMvYeEc4cuO6Of3FqVAKTCTl6beKRC7CZK9nA8pRKifggtOQOtLVTVf5HvsUsQ+CSJbKCQUIYx2uov0tkiWbcc3nhAZ1ffaOI77UvV9v8FHHLeUHDIdbgOgXJcf87Yh/87PzFK3056JAfaCw8xlAo37yGVNymie0Lk+c0BLo0KuYA6glMwn8UINpcbDkScOl0L8deiDYMm+0faiVN+AS9AKrtkrw4M9dXCxMWDBV0U8BV05+/5DGsvTmxx1GL5G3TEBADFJvaShltRuyDHDwiU8b2IxMxcPyXH5P4WaKpfwGv7aACPQ8MtKtRnWvGhToOADKliV7ZpZCdyhcVhXDluqbDgJw/koFhs10WSoGyjJ1eIvRSTbb75LF+sLlpYMkNT0QOo=; bm_sz=D03B4A99A30B5E6B0D4549220DE7C937~YAAQk/kpF6xXvKOaAQAAkjzepB2F31COyAVBkCreXoYbyLev0jkJ6KU5wR8Jcw3VYl3ORGXILGFB6T8g77MVVUprqWSsFSgEvckaUdqcfz4AEbq/Yz7xbLvyqRC8gRNtbPzs/cSCc5rlp0G9Kyvvo1IKOdcrGWd1gkud7ZMQhJt37SIYNpr1+fxZhXSXWIl/fkIbCXt8LWzu6lD50IycGuwKbNm8kruevO8VENtP/ZjgZVr+KrLsrCcWKlNgOxvQrPzqU1pOrNK2+9evOIRgeXY+J3t46FOytQvt5yCI48hn5fiYGgRF52an65kRBeFCGHjdKAefZdnC6lIylDXiSSm9L70e3+0sS6ywsuw/IP2chN8ow+mwRLZAsnVa+nJ6RHZHVlUpsiGgzaQDUQpH/Q==~3618612~4403254; PIM-SESSION-ID=uu16YfGnKPDclXzL; AKA_ORIGIN=NA; C4Country=US; AKCountry=US; AKA_CONTINENT=NA; bm_sv=EA0E3A708A7BAD2111ADF21DC436902C~YAAQk/kpF7FcvKOaAQAAFF3epB1yYxGeB82FU9xGgQiztHzOjGmLqPZkDxgM881+mgp0ysskgAnRQdKZO1pYGTD8+Ius8OC/d+vCl6e6Gx+BAiE3MDnzPrbb983XfH3yRgJkmoF0N7fBToQA1YYCk+Bl3eXYhe5xQo31B1w4qpv+Wi2ieZuMM15/mB6s9KXokYXdB5zhYrz8TsTchEGJ5g8shvZINTWRVJfAOCLoBNmzXtdZ44pYc1tiLTMTuI2+DdQ=~1; ROUTE=.api-557c84cd89-td488; utag_main=v_id:019aa4de57dd000f442f86101ccf05050001f00d0086e^$_n:1^$_e:2^$_s:0^$_t:1763704430659^$ses_id:1763702626270%3Bexp-session^$_n:1%3Bexp-session; _sfid_6185={%22anonymousId%22:%220b55cc003aab8dd6%22%2C%22consents%22:[]}; _evga_58cb={%22uuid%22:%220b55cc003aab8dd6%22}; gig_bootstrap_3_8MN0gP3k6zUsc4l3yF2SVQCvvGmbbR24c8FGThfTMT5gf3Nfs8da7GyKvggXDm13=accounts-cdc_ver4; _gcl_au=1.1.1537546857.1763702629; nmstat=38a3470b-1f4a-3e4f-b3d8-cf18a9e0e5a4; s_fid=0007CE1D04E509B1-06FD0310336A0A11; s_sq=carhartt-staging%3D%2526c.%2526a.%2526activitymap.%2526page%253Dhttps%25253A%25252F%25252Fwww.carhartt.com%25252Fc%25252Fsale%2526link%253DSEE%25252024%252520MORE%2526region%253DBODY%2526.activitymap%2526.a%2526.c",   # You can keep your full cookie string here
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4",
        "TE": "trailers"
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.api_url.format(0),
            headers=self.custom_headers,
            callback=self.parse_api,
            meta={"page": 0}
        )

    def parse_api(self, response):
        data = json.loads(response.text)

        products = data.get("products", [])
        page = response.meta["page"]

        for p in products:
            item = couponsDealsItem()

            item["Title"] = p.get("name", "").strip()

            # --- IMAGE ---
            images = p.get("images", [])
            item["Image"] = images[0]["url"] if images else ""

            # --- PRICE (MSRP RANGE) ---
            msrp = p.get("msrpRange", {})
            min_msrp = msrp.get("minPrice", {}).get("formattedValue", "")
            max_msrp = msrp.get("maxPrice", {}).get("formattedValue", "")
            item["Price"] = f"{min_msrp} - {max_msrp}".replace("$", "").strip()

            # --- SALE PRICE (PRICE RANGE) ---
            pr = p.get("priceRange", {})
            min_pr = pr.get("minPrice", {}).get("formattedValue", "")
            max_pr = pr.get("maxPrice", {}).get("formattedValue", "")
            item["SalePrice"] = f"{min_pr} - {max_pr}".replace("$", "").strip()

            # --- SOURCE URL ---
            manufacturer = p.get("manufacturerAID", "")
            name = p.get("name", "").replace(" ", "-")
            item["SourceUrl"] = f"https://www.carhartt.com/product/{manufacturer}/{name}"
            item["Offer"] = ""

            # --- EXTRA FIELDS ---
            item["SiteURL"] = "https://www.carhartt.com"
            item["Framework"] = "3"
            item["SiteName"] = "Carhartt"
            item["dealpage"] = "True"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()

            yield item

        # -------------- PAGINATION SECTION -------------------
        pagination = data.get("pagination", {})
        total_pages = pagination.get("totalPages", 0)

        if page + 1 < total_pages:
            next_page = page + 1
            yield scrapy.Request(
                url=self.api_url.format(next_page),
                headers=self.custom_headers,
                callback=self.parse_api,
                meta={"page": next_page}
            )
