import json
import scrapy
import datetime
from ..items import couponsDealsItem


class pumadealSpider(scrapy.Spider):
    name = 'puma'
    start_urls = ['https://us.puma.com/us/en/sale/all-sale']
    Sitename = 'Puma US'
    siteurl = 'https://us.puma.com'
    api_url = "https://us.puma.com/api/graphql"

    def start_requests(self):
        yield from self.fetch_page(0)

    def fetch_page(self, offset):
        payload = {
            "operationName": "CategoryPLP",
            "query": """query CategoryPLP($url: String!, $isDraft: String, $sort: String, $filters: [FilterInputOption!]!, $expansions: [ProductSearchExpansion!], $includeCategoryMetadata: Boolean = true, $offset: Int!, $limit: Int!, $preview: PreviewInput) {
              categoryByUrl(url: $url, preview: $preview) {
                id
                name
                url
                products(
                  input: {sort: $sort, filters: $filters, limit: $limit, offset: $offset, expansions: $expansions, includeCategoryMetadata: $includeCategoryMetadata, isDraft: $isDraft, useScapiSearch: true}
                ) {
                  nodes {
                    variantProduct {
                      name
                      salePrice
                      productPrice { price salePrice promotionPrice }
                      images { href }
                    }
                  }
                }
              }
            }""",
            "variables": {
                "filters": [],
                "includeCategoryMetadata": True,
                "isDraft": "false",
                "limit": 24,
                "offset": offset,
                "preview": {"global": False},
                "url": "/sale/all-sale"
            }
        }

        headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
    "Accept": "application/graphql-response+json, application/graphql+json, application/json",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Referer": "https://us.puma.com/us/en/sale/all-sale",
    "locale": "en-US",
    "x-graphql-client-name": "nitro-fe",
    "x-graphql-client-version": "54ae0b44dc45139838288dbe112654d5ff6860b7",
    "bloomreach-id": "uid=6639352851474:v=12.0:ts=1759725929014:hc=3",
    "puma-request-source": "web",
    "x-operation-name": "SiblingVariants",
    "authorization": "Bearer eyJ2ZXIiOiIxLjAiLCJqa3UiOiJzbGFzL3Byb2QvYmNqcF9wcmQiLCJraWQiOiI1NzYxYzFlZS0yMDI2LTQxNDQtOTAxNS0zMTA1NTc3ODI2NmIiLCJ0eXAiOiJqd3QiLCJjbHYiOiJKMi4zLjQiLCJhbGciOiJFUzI1NiJ9.eyJhdXQiOiJHVUlEIiwic2NwIjoic2ZjYy5zaG9wcGVyLW15YWNjb3VudC5iYXNrZXRzIHNmY2Muc2hvcHBlci1teWFjY291bnQuYWRkcmVzc2VzIHNmY2Muc2hvcHBlci1wcm9kdWN0cyBzZmNjLnNob3BwZXItbXlhY2NvdW50LnJ3IHNmY2Muc2hvcHBlci1teWFjY291bnQucGF5bWVudGluc3RydW1lbnRzIHNmY2Muc2hvcHBlci1jdXN0b21lcnMubG9naW4gc2ZjYy5zaG9wcGVyLWNvbnRleHQgc2ZjYy5zaG9wcGVyLWNvbnRleHQucncgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5vcmRlcnMgc2ZjYy5zaG9wcGVyLWN1c3RvbWVycy5yZWdpc3RlciBzZmNjLnNob3BwZXItYmFza2V0cy1vcmRlcnMgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5hZGRyZXNzZXMucncgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5wcm9kdWN0bGlzdHMucncgc2ZjYy5zaG9wcGVyLXByb2R1Y3RsaXN0cyBzZmNjLnNob3BwZXItcHJvbW90aW9ucyBzZmNjLnNob3BwZXItYmFza2V0cy1vcmRlcnMucncgY19wcmljaW5nQW5kUHJvbW90aW9uc19yIHNmY2Muc2hvcHBlci1teWFjY291bnQucGF5bWVudGluc3RydW1lbnRzLnJ3IHNmY2Muc2hvcHBlci1naWZ0LWNlcnRpZmljYXRlcyBzZmNjLnNob3BwZXItcHJvZHVjdC1zZWFyY2ggc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5wcm9kdWN0bGlzdHMgc2ZjYy5zaG9wcGVyLWNhdGVnb3JpZXMgc2ZjYy5zaG9wcGVyLW15YWNjb3VudCIsInN1YiI6ImNjLXNsYXM6OmJjanBfcHJkOjpzY2lkOjFjOGM4YTNlLTY1NmUtNDFiMS04YjZmLWZiMDZjNDUxZjAxOTo6dXNpZDpiNTE1OWQ3NS0zYmYyLTRhYTgtYWIxYy1mMTExYjY0MTNlNjUiLCJjdHgiOiJzbGFzIiwiaXNzIjoic2xhcy9wcm9kL2JjanBfcHJkIiwiaXN0IjoxLCJkbnQiOiIwIiwiYXVkIjoiY29tbWVyY2VjbG91ZC9wcm9kL2JjanBfcHJkIiwibmJmIjoxNzU5NzI4MTMyLCJzdHkiOiJVc2VyIiwiaXNiIjoidWlkbzpzbGFzOjp1cG46R3Vlc3Q6OnVpZG46R3Vlc3QgVXNlcjo6Z2NpZDphYndIc1ZsckpJbFhzUmswaEtrR1lZd3VjMjo6Y2hpZDpOQSIsImV4cCI6MTc1OTcyOTk2MiwiaWF0IjoxNzU5NzI4MTYyLCJqdGkiOiJDMkMtMTg0NDYwNDc3MDA3NDA2MzQzNzIwMzc0ODMwMzc4NzM4NDUifQ.PyEZ4rjPsG7KbrBvV43CypBlOszExk4d8gqvczplnJE8jcKiJN9NrBHitz_ykZhEJmskKTytszbq4LjiP3HTTg",
    "refresh-token": "_RdJuZWLbq7xSa8bBwuQMysJEaMX0mzHP9IlAgajLrc",
    "customer-id": "abwHsVlrJIlXsRk0hKkGYYwuc2",
    "customer-group": "b8d468c045591ad602dfd02a3844ef17c6270dcf52acac46c753146a58d103ef",
    "content-type": "application/json",
    "hpm0vOKCHE-f": "A8fF-LeZAQAAt_guAVicEPqD3IOeX3w4NfX9kzIdgQUcQvYkvYtQuaLE7Zs0AY5vmKqcuGbRwH8AAEB3AAAAAA==",
    "hpm0vOKCHE-b": "-3yravb",
    "hpm0vOKCHE-c": "AABc9reZAQAAAoV8QFTdVHVreTHZ13KNXjt2uANNeiA4kuxXQBQCTlyXhZJg",
    "hpm0vOKCHE-d": "ABaAhIDBCKGFgQGAAYIQgISigaIAwBGAzvpCzi_33wcUAk5cl4WSYAAAAAAGOAAeAKyTimNQLLN-rFYTgvCA4ak",
    "hpm0vOKCHE-z": "q",
    "hpm0vOKCHE-a": "Ly16iXUWwty0Lp8LP9GCxQ8zW9c31KjTTaxTdZKVCMZ6kuQk4XMLyVaDv=u=-PpwFk0Gjppd2K9W6zTN4SeE=caWLu99owzVm9=GRLPkxb4b5acNMx0M8aQeD5akQgrhRphs1irnXN3rlRVUEwuzt_WI_VGl0jGFhWZyKoz3JiQheU4AES3zxhkQdL8iO9OGju8AJiQKysayJC79YWuirt50abL-zE2eYVKaEF10ApEoGTlB3NEuzWNmBlhhXg1IG=4abGOckwIjmmTCth82_WT__K8HwC1dg3xtaITdVBvXTU1QO006VUXK4d=KXNRAUx36hGtbt4Dpw=ppnQ-Yfl58fBX9MnXgEcFi9UnZ-FK1eF0ZDar5bzBPCPz0Ul=hK=V-6SX3rhbnE3ssFW9-p3GeZ5nd98-fiK_tHaeVZ8421nyz6coKKSu-sPTIY61G25O2sv4ON_ogWDP9XTccjAKRi=WvDUhTS9z1IcLZ_Cdd4PJgOKEK9RvUNiZJvUSp2MSLh0DyzsvXZl5MbBFvTuObaY1F..."
}

        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=headers,
            body=json.dumps(payload),
            callback=self.parse,
            cb_kwargs={'offset': offset},
        )

    def parse(self, response, offset):
        try:
            data = response.json()
        except Exception:
            self.logger.warning("⚠️ Invalid JSON response")
            return

        products = data.get("data", {}).get("categoryByUrl", {}).get("products", {}).get("nodes", [])
        if not products:
            self.logger.info(f"✅ No more products found at offset {offset}. Stopping.")
            return

        for node in products:
            item = couponsDealsItem()
            vp = node.get("variantProduct", {})
            if not vp:
                continue

            item['Title'] = vp.get("name")
            price_info = vp.get("productPrice", {})
            item['Price'] = price_info.get("price")
            item['SalePrice'] = price_info.get("salePrice") or vp.get("salePrice")
            item['Offer'] = ''
            item['SourceUrl'] = self.siteurl
            item['Image'] = ','.join(img.get("href") for img in vp.get("images", []) if img.get("href"))
            item['SiteName'] = self.Sitename
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Fetch next page
        next_offset = offset + 24
        self.logger.info(f"➡️ Fetching next page with offset {next_offset}")
        yield from self.fetch_page(next_offset)
