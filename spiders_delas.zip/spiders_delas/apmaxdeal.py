from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class apmexdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'apmaxdealdeal'
    start_urls = ['https://www.apmex.com/deals']
    Sitename = 'apmexdeal'
    siteurl = 'https://www.apmex.com'


    headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=0, i"
}

    custom_settings = {
            "DEFAULT_REQUEST_HEADERS": headers
    }

    def parse(self, response):
        with open("apmex_deal_response.txt", "w", encoding="utf-8") as f:
         f.write(response.text)
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[contains (@class, "mod-product-card ")]'
        titalxpath = '//div[@class="mod-product-title"]/span/text()'
        imagexpath = '.(//div[@class="mod-product-img"])[position() >= 22]/img/@src'
        pricexpath = './/span[@style="text-decoration: line-through;"]/text()'
        price2xpath = './/span[@class="price discounted"]/text()'
        otherxpath = ''
        nextpage = '//li/a[@title="Next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })