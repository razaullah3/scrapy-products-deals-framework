from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bluechipwrestlingdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bluechipwrestlingdeal'
    start_urls = ['https://www.bluechipwrestling.com/collections/wrestling-outlet']
    Sitename = 'Blue Chip Wrestling'
    siteurl = 'https://www.bluechipwrestling.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-wrap"]'
        titalxpath = './/span[@class="title"]/text()'
        imagexpath = './/img/@data-src'
        pricexpath = './/span[@class="was_price"]/span/text()'
        price2xpath = './/span[@class="money"]/text()'
        otherxpath = ''
        nextpage = '//span[@class="js-load-more load-more"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })