import json
import scrapy
import datetime
from ..items import couponsDealsItem

class CartersApiSpider(scrapy.Spider):
    name = "cartersapi"
    api_url = "https://www.carters.com/mobify/proxy/api/search/shopper-search/v1/organizations/f_ecom_aamk_prd/product-search?siteId=Carters&refine=cgid%3Dcarters-sale&currency=USD&locale=en-US&offset=0&limit=48"

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.carters.com/",
        "correlation-id": "48504330-697f-43a4-a405-7ee7cfb16653",
        "authorization": "Bearer eyJ2ZXIiOiIxLjAiLCJqa3UiOiJzbGFzL3Byb2QvYWFta19wcmQiLCJraWQiOiJiMWY2NDM3OC1hOWExLTQyMWUtYTBiOS1kMzc4NGQ1NjAwODUiLCJ0eXAiOiJqd3QiLCJjbHYiOiJKMi4zLjQiLCJhbGciOiJFUzI1NiJ9.eyJhdXQiOiJHVUlEIiwic2NwIjoic2ZjYy5zaG9wcGVyLW15YWNjb3VudC5iYXNrZXRzIHNmY2Muc2hvcHBlci1kaXNjb3Zlcnktc2VhcmNoIHNmY2Muc2hvcHBlci1teWFjY291bnQucGF5bWVudGluc3RydW1lbnRzIHNmY2Muc2hvcHBlci1jdXN0b21lcnMubG9naW4gc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5vcmRlcnMgc2ZjYy5zaG9wcGVyLXByb2R1Y3RsaXN0cyBzZmNjLnNob3BwZXItcHJvbW90aW9ucyBzZmNjLm9yZGVycy5ydyBzZmNjLnNlc3Npb25fYnJpZGdlIGNfY2FydGVyc19jdXN0b21fYXBpc19yIHNmY2Muc2hvcHBlci1teWFjY291bnQucGF5bWVudGluc3RydW1lbnRzLnJ3IHNmY2Muc2hvcHBlci1teWFjY291bnQucHJvZHVjdGxpc3RzIHNmY2Muc2hvcHBlci1jYXRlZ29yaWVzIHNmY2Muc2hvcHBlci1teWFjY291bnQgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5hZGRyZXNzZXMgc2ZjYy5zaG9wcGVyLXByb2R1Y3RzIHNmY2MudGFfZXh0X29uX2JlaGFsZl9vZiBzZmNjLnNob3BwZXItbXlhY2NvdW50LnJ3IHNmY2Muc2hvcHBlci1zdG9yZXMgc2ZjYy5zaG9wcGVyLWNvbnRleHQgc2ZjYy5zaG9wcGVyLWNvbnRleHQucncgc2ZjYy5zaG9wcGVyLWJhc2tldHMtb3JkZXJzIHNmY2Muc2hvcHBlci1jdXN0b21lcnMucmVnaXN0ZXIgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5hZGRyZXNzZXMucncgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5wcm9kdWN0bGlzdHMucncgc2ZjYy5zaG9wcGVyLXByb2R1Y3Qgc2ZjYy5zaG9wcGVyLWJhc2tldHMtb3JkZXJzLnJ3IHNmY2Muc2hvcHBlci1naWZ0LWNlcnRpZmljYXRlcyBzZmNjLnNob3BwZXItcHJvZHVjdC1zZWFyY2giLCJzdWIiOiJjYy1zbGFzOjphYW1rX3ByZDo6c2NpZDo4NDY4OTVkNy01ZWQ1LTRiOWUtYWRkMC1kYWE4ODdiNDFmMWM6OnVzaWQ6ODE4M2Y3YTAtOTRhOS00YTAzLTlmMDktM2RlYTYyYTA1ODc2IiwiY3R4Ijoic2xhcyIsImlzcyI6InNsYXMvcHJvZC9hYW1rX3ByZCIsImlzdCI6MSwiZG50IjoiMCIsImF1ZCI6ImNvbW1lcmNlY2xvdWQvcHJvZC9hYW1rX3ByZCIsIm5iZiI6MTc2MzcwMDc4NSwic3R5IjoiVXNlciIsImlzYiI6InVpZG86c2xhczo6dXBuOkd1ZXN0Ojp1aWRuOkd1ZXN0IFVzZXI6OmdjaWQ6YmNtYmMyazB3MXdyYVJtcnBGbXFZWXdyYVg6OmNoaWQ6Q2FydGVycyIsImV4cCI6MTc2MzcwMjYxNSwiaWF0IjoxNzYzNzAwODE1LCJqdGkiOiJDMkMtOTg2MTg1MzIzMDkzMjQ4Mjg4NDYwMTAyODY5NjkwNTMwNTIifQ.sPhUL16xN7lF-Zx1EDIVPf41TH9yaRfbbn2lLKmVcBLGDCI1RkpKK2u6U5U7hHGt1oV_2C3AlNklM5XZSM2z3w"
    }

    def start_requests(self):
        yield scrapy.Request(
            self.api_url,
            headers=self.custom_headers,
            callback=self.parse_api
        )

    def parse_api(self, response):
        data = json.loads(response.text)

        for hit in data.get("hits", []):
            item = couponsDealsItem()

            # 1. Fix image URL
            image = hit.get("image", {})
            raw_img = image.get("disBaseLink", "")

            item["Image"] = raw_img.replace(
                "https://production-direct-carters.demandware.net",
                "https://dw.cartersstorefront.com"
            )

            # 2. Product URL fix
            product_id = hit.get("productId")
            item["SourceUrl"] = f"https://www.carters.com/p/{product_id}.html"

            item["Offer"] = ""

            # 3. Basic fields
            item["Title"] = hit.get("productName")
            item["SalePrice"] = hit.get("price")
            item["Price"] = hit.get("c_listPrice")
            item["SiteName"] = "Contiki"
            item["SiteURL"] = "https://www.carters.com"
            item["Framework"] = "3"
            item["dealpage"] = "True"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()

            yield item
