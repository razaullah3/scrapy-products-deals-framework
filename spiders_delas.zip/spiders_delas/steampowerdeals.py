import scrapy
import json
import datetime
from ..items import couponsDealsItem


class SteamClearanceSpider(scrapy.Spider):
    name = 'steam_clearance'
    handle_httpstatus_list = [404]

    # Base Steam API URL
    base_url = (
        "https://store.steampowered.com/search/results/"
        "?query&start={start}&count=50&dynamic_data=&sort_by=_ASC"
        "&term=clearance&supportedlang=english&snr=1_7_7_151_7&infinite=1"
    )

    # Custom headers (standard browser headers)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://store.steampowered.com/",
        "X-Requested-With": "XMLHttpRequest",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    def start_requests(self):
        """Start from the first 50 results"""
        url = self.base_url.format(start=0)
        yield scrapy.Request(
            url=url,
            headers=self.headers,
            callback=self.parse,
            meta={'start': 0}
        )

    def parse(self, response):
        """Parse Steam search JSON response"""
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON response")
            return

        html_content = data.get("results_html", "")
        if not html_content:
            self.logger.warning("No HTML content found in response")
            return

        sel = scrapy.Selector(text=html_content)
        items = sel.css("a.search_result_row")
        self.logger.info(f"Found {len(items)} products in batch starting at {response.meta.get('start')}")

        for product in items:
            title = product.css(".title::text").get()
            image = product.css(".search_capsule img::attr(src)").get()
            release_date = product.css(".search_released::text").get()
            price = product.css(".discount_final_price::text").get()
            original_price = product.css(".discount_original_price::text").get()
            url = product.attrib.get("href")

            item = couponsDealsItem()
            item['Title'] = title.strip() if title else ''
            item['SourceUrl'] = url
            item['Image'] = image
            item['Price'] = original_price.strip() if original_price else ''
            item['SalePrice'] = price.strip() if price else ''

            # Metadata
            now = datetime.datetime.now()
            item['Framework'] = '3'
            item['Offer'] = ''
            item['SiteName'] = 'Steam'
            item['SiteURL'] = 'https://store.steampowered.com/'
            item['DateAdded'] = now
            item['DateUpdated'] = now

            # Pipeline flags
            item['dealpage'] = 'True'
            item['getDoc'] = 'True'
            item['itempage'] = 'false'
            item['urlpage'] = 'false'
            item['alllogs'] = 'false'
            item['Category'] = 'Clearance'
            item['SubCategory'] = ''

            yield item

        # Pagination — continue while products exist
        start = response.meta.get('start', 0)
        if items:
            next_start = start + 50
            next_url = self.base_url.format(start=next_start)
            yield scrapy.Request(
                url=next_url,
                headers=self.headers,
                callback=self.parse,
                meta={'start': next_start}
            )
