from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class beltedcowdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'beltedcowdeal'
    start_urls = ['https://www.beltedcow.com/sale/']
    Sitename = 'Belted Cow'
    siteurl = 'https://www.beltedcow.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = './/li[@class="grid__item scroll-trigger animate--slide-in"]'
        titalxpath = './/a[@class="full-unstyled-link"]/text()'
        imagexpath = './/img[@class="card__variant-image loaded"]/@src'
        pricexpath = './/s[@class="card__price--compare"]/text()'
        price2xpath = './/span[@class="card__price--regular"]'
        otherxpath = '//span[@class="card__savings"]/text()'
        nextpage = '//li[@class="pagination-item pagination-item--next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })