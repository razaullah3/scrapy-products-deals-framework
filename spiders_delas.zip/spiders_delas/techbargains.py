import scrapy
import json
import datetime
from ..items import couponsDealsItem

class TechBargainsSpider(scrapy.Spider):
    name = 'techbargains'
    handle_httpstatus_list = [404]

    # Base API URL
    base_url = 'https://www.techbargains.com/api/deals?pageSize=15'

    # Custom headers
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.techbargains.com/",
        "X-Requested-With": "XMLHttpRequest",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    def start_requests(self):
        """Start with page 1 and dynamic timestamp"""
        ts = datetime.datetime.now().strftime('%Y-%m-%d%%20%H:%M:%S')
        url = f"{self.base_url}&timeStamp={ts}&page=1"
        yield scrapy.Request(
            url=url,
            headers=self.headers,
            callback=self.parse,
            meta={'page': 1}
        )

    def parse(self, response):
        """Parse API JSON response"""
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON response")
            return

        items_list = data.get('items', [])
        self.logger.info(f"Found {len(items_list)} items on page {response.meta.get('page')}")

        for deal in items_list:
            item = self.extract_product_item(deal)
            print(f"Scraped Item: {item}")  # Debug print
            yield item

        # Pagination
        page = response.meta.get('page', 1)
        page_size = 15
        if len(items_list) == page_size:  # likely more pages
            next_page = page + 1
            ts = datetime.datetime.now().strftime('%Y-%m-%d%%20%H:%M:%S')
            next_url = f"{self.base_url}&timeStamp={ts}&page={next_page}"
            yield scrapy.Request(
                url=next_url,
                headers=self.headers,
                callback=self.parse,
                meta={'page': next_page}
            )

    def extract_product_item(self, deal):
        item = couponsDealsItem()
        item['Title'] = deal.get('name', '')
        item['SourceUrl'] = deal.get('url', '')
        item['Price'] = deal.get('price_list', '')
        item['SalePrice'] = deal.get('price_final', '')
        item['Offer'] = deal.get('price_discount', '')

        # Combine images
        images = [
            deal.get('image_url_sm', ''),
            deal.get('image_url_md', ''),
            deal.get('image_url_lg', '')
        ]
        item['Image'] = ','.join(filter(None, images))

        # Metadata
        now = datetime.datetime.now()
        item['Framework'] = '3'
        item['SiteName'] = 'TechBargains'
        item['SiteURL'] = 'https://www.techbargains.com/'
        item['DateAdded'] = now
        item['DateUpdated'] = now

        # Pipeline flags
        item['dealpage'] = 'True'
        item['getDoc'] = 'True'
        item['itempage'] = 'false'
        item['urlpage'] = 'false'
        item['alllogs'] = 'false'
        item['Category'] = ''
        item['SubCategory'] = ''

        return item
