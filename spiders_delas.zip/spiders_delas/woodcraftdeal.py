import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class woodcraftdealSpider(GetDealsProducts):
    name = 'woodcraftdeal'
    handle_httpstatus_list = [404]
    Sitename = 'Woodcraft'
    siteurl = 'https://www.woodcraft.com'
    base_api = (
        "https://kf8822.a.searchspring.io/api/search/search.json?"
        "userId=4f616013-685b-4796-a551-0afe8ef3fcda&"
        "domain=https%3A%2F%2Fwww.woodcraft.com%2Fcollections%2Fwood%3Ffeatured%255B%255D%3DSale&"
        "sessionId=d6e6005d-3d53-4c71-9862-8e028c5c57f9&"
        "pageLoadId=496ffe67-9966-4341-87a9-c5d4de4a9b55&"
        "siteId=kf8822&resultsPerPage=48&"
        "bgfilter.collection_handle=wood&ajaxCatalog=Snap&resultsFormat=native&page="
    )

    def start_requests(self):
        start_page = 1
        yield scrapy.Request(
            url=self.base_api + str(start_page),
            callback=self.parse,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                              '(KHTML, like Gecko) Chrome/113 Safari/537.36'
            },
            meta={'page': start_page}
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get("results", [])
        self.logger.info(f"Page {response.meta['page']}: Found {len(products)} products")

        for m in products:
            item = couponsDealsItem()

            item['Title'] = m.get('name', '').strip()
            item['Image'] = m.get('thumbnailImageUrl') or m.get('imageUrl', '')
            item['Price'] = f"${m.get('msrp', '')}" if m.get('msrp') else ''
            item['SalePrice'] = f"${m.get('price', '')}" if m.get('price') else ''
            item['Offer'] = f"{m.get('ss_pct_off', '')}% Off" if m.get('ss_pct_off') else ''
            item['SourceUrl'] = self.siteurl + m.get('url', '')
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        pagination = data.get("pagination", {})
        current_page = pagination.get("currentPage", 1)
        total_pages = pagination.get("totalPages", 1)

        if current_page < total_pages:
            next_page = current_page + 1
            yield scrapy.Request(
                url=self.base_api + str(next_page),
                callback=self.parse,
                headers=response.request.headers,
                meta={'page': next_page}
            )

