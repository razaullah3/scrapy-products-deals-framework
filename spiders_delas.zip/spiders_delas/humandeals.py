import scrapy
import json
import datetime
from ..items import couponsDealsItem


class HumbleDealSpider(scrapy.Spider):
    name = "humble_deal"

    # Base API endpoint
    base_api = "https://www.humblebundle.com/store/api/search"

    # Custom headers
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "X-Requested-With": "XMLHttpRequest",
        "Connection": "keep-alive",
        "Referer": "https://www.humblebundle.com/store/search?sort=bestselling&search=deal&page=1",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    # Parameters for the first page
    params = {
        "sort": "bestselling",
        "filter": "all",
        "search": "deal",
        "page": 0,
        "request": 1
    }

    def start_requests(self):
        """Start with the first page request."""
        url = f"{self.base_api}?{self._encode_params(self.params)}"
        yield scrapy.Request(
            url=url,
            headers=self.custom_headers,
            callback=self.parse,
            meta={'page': 0}
        )

    def parse(self, response):
        """Parse JSON data and handle pagination."""
        try:
            data = json.loads(response.text)
            results = data.get("results", [])
            total_pages = data.get("num_pages", 0)
        except Exception as e:
            self.logger.error(f"JSON parsing failed: {e}")
            return

        # Extract product info
        for product in results:
            yield self.extract_product_item(product)

        # Pagination: go to next page if exists
        current_page = response.meta.get('page', 0)
        if current_page + 1 < total_pages:
            next_page = current_page + 1
            next_params = self.params.copy()
            next_params["page"] = next_page
            next_url = f"{self.base_api}?{self._encode_params(next_params)}"
            yield scrapy.Request(
                url=next_url,
                headers=self.custom_headers,
                callback=self.parse,
                meta={'page': next_page}
            )

    def extract_product_item(self, product):
        """Extract relevant fields from each product record."""
        item = couponsDealsItem()

        title = product.get("human_name", "")
        image = product.get("standard_carousel_image", "")
        human_url = product.get("human_url", "")
        full_price = product.get("full_price", {}).get("amount", "")
        current_price = product.get("current_price", {}).get("amount", "")

        source_url = f"https://www.humblebundle.com/store/{human_url}"

        # Populate standardized item fields
        item["Title"] = title
        item["Price"] = full_price
        item["SalePrice"] = current_price
        item["Offer"] = ""  # not explicitly provided in API
        item["Image"] = image
        item["SourceUrl"] = source_url

        item["SiteName"] = "Humble Bundle Store"
        item["SiteURL"] = "https://www.humblebundle.com/store"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item

    def _encode_params(self, params):
        """Helper to encode params dict into query string."""
        return "&".join([f"{k}={v}" for k, v in params.items()])
