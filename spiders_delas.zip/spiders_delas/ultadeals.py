from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class ultadealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'ulta'
    start_urls = ['https://www.ulta.com/promotion/sale']
    Sitename = 'Ulta Sales'
    siteurl = 'https://www.ulta.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="ProductListingResults__productCard"]'
        titalxpath = './/div[@class="Image"]/img/@alt'
        imagexpath = './/div[@class="Image"]/img/@src'
        pricexpath = './/span[contains(@class,"line-through")]/text()'
        price2xpath = './/span[contains(@class,"magenta-500")]/text()'
        otherxpath = ''
        nextpage = ''

        # yield first page for processing
        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
                'page': 1,  # Start from page 1
            }
        )

    def Data_Collector(self, response):
        """Your existing Data_Collector from GetDealsProducts will extract products"""

        # Extract data normally using your parent class method
        yield from super().Data_Collector(response)

        # Handle pagination
        current_page = response.meta.get('page', 1)
        divxpath = response.meta.get('divxpath')

        # If this page still has products, go to next page
        products = response.xpath(divxpath)
        if products:
            next_page = current_page + 1
            next_url = f"https://www.ulta.com/promotion/sale?page={next_page}"
            yield response.follow(
                next_url,
                callback=self.Data_Collector,
                meta={**response.meta, 'page': next_page}
            )
