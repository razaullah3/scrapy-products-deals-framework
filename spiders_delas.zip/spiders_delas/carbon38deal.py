import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class carbon38dealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'carbon38deal'
    start_urls = ['https://www.carbon38.com/sale']
    Sitename = 'Carbon38'
    siteurl = 'https://www.carbon38.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # Define XPath selectors for product information
        categorypage = ''  # Adjust based on actual site structure
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="ProductItem__Wrapper"]'  # Main product container
        titalxpath = './/h2[@class="ProductItem__Title Heading"]/a/text()'  # Product title
        imagexpath = './/img[@class="ProductItem__Image"]/@src'  # Product image
        pricexpath = './/span[@class="ProductItem__Price Price Price--compareAt Text--subdued"]/text()'  # Original price
        price2xpath = './/span[@class="ProductItem__Price Price Price--highlight Text--subdued"]/text()'  # Sale price
        otherxpath = ''
        nextpage = '//a[@title="Next page"]/@href'  # Next page link

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })