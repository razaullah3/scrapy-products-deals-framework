import scrapy
import json
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class JockeyDealsSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'jockey_deals'
    Sitename = 'Jockey'
    siteurl = 'https://www.jockey.com'

    api_url = "https://api.jockey.com/catalog/products?q=deal&limit=74&page=0"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.jockey.com/catalog/all/all/all?q=deal",
        "x-jky-build-id": "dev",
        "x-jky-env": "AzureProd",
        "Origin": "https://www.jockey.com",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    def start_requests(self):
        """Start from first page"""
        yield scrapy.Request(
            url=self.api_url,
            method="GET",
            headers=self.headers,
            callback=self.parse,
            meta={"page": 0},
        )

    def parse(self, response):
        page = response.meta.get("page", 0)
        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON parse error on page {page}: {e}")
            return

        products = data.get("MatchingProducts", [])
        total_pages = data.get("TotalPages", 0)  # Adjust based on actual API response

        self.logger.info(f"Page {page}: Found {len(products)} products.")

        for product in products:
            item = couponsDealsItem()

            # Title
            url_id = product.get("UrlId", "").strip()
            item['Title'] = url_id

            # Source URL
            item['SourceUrl'] = f"https://www.jockey.com/catalog/product/{url_id}"

            # Prices
            list_price = product.get("Pricing", {}).get("ListPrice", {}).get("Amount")
            flashdeal_range = product.get("Pricing", {}).get("Types", {}).get("FlashDeal", {}).get("Range", [])
            item['Price'] = list_price
            item['SalePrice'] = flashdeal_range[0] if flashdeal_range else ''

            # Image URL
            prod_id = str(product.get("Id", "0")).zfill(6)  # always 6 digits
            default_color = product.get("ImageData", {}).get("DefaultColor", "")
            default_shot = product.get("ImageData", {}).get("DefaultShot", "")
            item['Image'] = f"https://dynamic.jockeycdn.com/fit=crop,width=1640,height=2048/product-img/{prod_id}/{default_color}/{default_shot}.jpg"

            # Other fields
            item['Offer'] = ''
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

       
