from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class luckyvitaminSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'luckyvitamindeal'
    start_urls = ['https://www.luckyvitamin.com/t-special-promotions']
    Sitename = 'LuckyVitamin'
    siteurl = 'https://www.luckyvitamin.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '//a[contains(@class,"deals__promo-link")]/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product-list__item"]'
        titalxpath = './/div[@class="product-card__link"]/span[2]/text()'
        imagexpath = './/div[@class="product-card "]//a/img/@data-src | //div[@class="product-card "]//a/img/@src'
        pricexpath = './/small/text()'
        price2xpath = './/div[@class="product-card--desktop"]//b/text() | .//div[' \
                      '@class="product-card--desktop"]//div[contains(@class,"price") and contains(text(),"$")]/text() '
        otherxpath = './/div[contains(@class,"product-card__savings")]'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })