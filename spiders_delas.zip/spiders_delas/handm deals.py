


import scrapy
import json
import datetime
from ..items import couponsDealsItem


class HmNewArrivalsSpider(scrapy.Spider):
    name = "hm"
    allowed_domains = ["hm.com"]
    start_urls = [
        "https://www2.hm.com/en_us/beauty/new-arrivals/view-all.html"
        'https://www2.hm.com/en_us/sale/women/view-all.html',
        'https://www2.hm.com/en_us/sale/men/view-all.html',
         'https://www2.hm.com/en_us/sale/baby/products.html',
         'https://www2.hm.com/en_us/sale/kids/products.html',
        'https://www2.hm.com/en_us/sale/sport/view-all.html',
        'https://www2.hm.com/en_us/sale/home/view-all.html'
    
    ]

    # --- Default headers for requests ---
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "DNT": "1",
        "Sec-GPC": "1"
    }

    def start_requests(self):
        """Initial request with headers."""
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                headers=self.custom_headers,
                callback=self.parse
            )

    def parse(self, response):
        """Parse H&M JSON-LD data from <script> tag."""
        try:
            json_data = response.xpath(
                '//script[@id="product-list-carousel-schema"]/text()'
            ).get()

            if not json_data:
                self.logger.warning("⚠️ Could not find JSON-LD product data")
                return

            data = json.loads(json_data)
            products = data.get("itemListElement", [])

        except Exception as e:
            self.logger.error(f"❌ Error parsing H&M JSON: {e}")
            return

        if not products:
            self.logger.warning("⚠️ No products found in JSON data.")
            return

        for entry in products:
            product = entry.get("item", {})
            if not product:
                continue

            item = self.extract_product_item(product)
            print(json.dumps(dict(item), indent=4, default=str))  # Debug print
            yield item

    def extract_product_item(self, product):
        """Extract key fields from product JSON."""
        offer = product.get("offers", {}) or {}

        item = couponsDealsItem()
        item["Title"] = product.get("name", "")
        item["Price"] = offer.get("price", "")
        item["SalePrice"] = ""  # H&M JSON-LD doesn’t include discount price directly
        item["Offer"] = offer.get("priceCurrency", "")
        item["Image"] = ", ".join(product.get("image", []))
        item["SourceUrl"] = f"https://www2.hm.com{product.get('url', '')}"

        # --- Meta Info ---
        item["SiteName"] = "H&M New Arrivals"
        item["SiteURL"] = "https://www2.hm.com"
        item["Framework"] = "3"
        item["dealpage"] = "True"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()

        return item
