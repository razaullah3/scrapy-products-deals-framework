import json
import scrapy
import datetime
import math
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class charmingcharliedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'charmingcharliedeal'
    start_urls = ['https://charmingcharlie.com/collections/sale']
    Sitename = 'Charming Charlie'
    siteurl = 'https://charmingcharlie.com'

    # Constants for API request
    API_BASE_URL = 'https://svc-16-usf.hotyon.com/search'
    API_KEY = '595fcb58-b2b5-4027-a1aa-882cbb7caee5'
    COLLECTION_ID = '163678978147'
    BATCH_SIZE = 199  # Maximum products per request

    def start_requests(self):
        # Initial API call to get total number of products
        api_url = f'{self.API_BASE_URL}?q=&apiKey={self.API_KEY}&country=US&locale=en&getProductDescription=0&collection={self.COLLECTION_ID}&skip=0&take=40&sort=bestselling'
        yield scrapy.Request(url=api_url, callback=self.parse_total)

    def parse_total(self, response):
        try:
            listing_json = json.loads(response.text)

            # Access the total count
            total_products = 0
            if 'data' in listing_json and 'total' in listing_json['data']:
                total_products = listing_json['data']['total']
                self.logger.info(f"Total products found: {total_products}")
            else:
                # Fallback if structure changes
                self.logger.error("Couldn't find total products count in the expected structure")
                total_products = 2143  # Based on your information
                self.logger.info(f"Using default total: {total_products}")

            # Calculate how many batches we need to fetch all products
            num_batches = math.ceil(total_products / self.BATCH_SIZE)
            self.logger.info(f"Will fetch data in {num_batches} batches of {self.BATCH_SIZE} products each")

            # Generate requests for each batch
            for batch in range(num_batches):
                skip = batch * self.BATCH_SIZE
                take = min(self.BATCH_SIZE, total_products - skip)  # Don't exceed total

                if take <= 0:
                    break

                self.logger.info(f"Generating request for batch {batch + 1}/{num_batches}: skip={skip}, take={take}")
                api_url = f'{self.API_BASE_URL}?q=&apiKey={self.API_KEY}&country=US&locale=en&getProductDescription=0&collection={self.COLLECTION_ID}&skip={skip}&take={take}&sort=bestselling'

                yield scrapy.Request(
                    url=api_url,
                    callback=self.parse_products,
                    meta={'batch': batch + 1, 'total_batches': num_batches},
                    dont_filter=True
                )

        except Exception as e:
            self.logger.error(f"Error parsing initial response: {str(e)}")

    def parse_products(self, response):
        try:
            batch = response.meta.get('batch', 0)
            total_batches = response.meta.get('total_batches', 0)
            self.logger.info(f"Processing batch {batch}/{total_batches}")

            # Parse the JSON response
            listing_json = json.loads(response.text)

            # Access items from the correct path
            if 'data' in listing_json and 'items' in listing_json['data']:
                items = listing_json['data']['items']
                self.logger.info(f"Found {len(items)} products in batch {batch}")

                processed_count = 0
                for product in items:
                    try:
                        # Create a new item for each product
                        item = couponsDealsItem()

                        # Basic product info
                        item['Title'] = product.get('title', '')

                        # Handle image URLs
                        if 'images' in product and product['images'] and len(product['images']) > 0:
                            image_url = product['images'][0].get('url', '')
                            if image_url and image_url.startswith('//'):
                                image_url = f'https:{image_url}'
                            item['Image'] = image_url
                        else:
                            item['Image'] = ''

                        # Process variants
                        if 'variants' in product and product['variants']:
                            # Find variants that are available
                            available_variants = [v for v in product['variants'] if v.get('available', 0) > 0]

                            if available_variants:
                                variant = available_variants[0]  # Use first available variant
                            else:
                                variant = product['variants'][0]  # Fall back to first variant

                            # Extract price information
                            compare_price = variant.get('compareAtPrice')
                            sale_price = variant.get('price')

                            if compare_price is not None:
                                item['Price'] = f"${compare_price}"
                            else:
                                item['Price'] = ''

                            if sale_price is not None:
                                item['SalePrice'] = f"${sale_price}"
                            else:
                                item['SalePrice'] = ''
                        else:
                            item['Price'] = ''
                            item['SalePrice'] = ''

                        # Build the product URL
                        url_name = product.get('urlName', '')
                        if url_name:
                            item['SourceUrl'] = f"{self.siteurl}/products/{url_name}"
                        else:
                            # Fallback to handle field
                            handle = product.get('handle', '')
                            item['SourceUrl'] = f"{self.siteurl}/products/{handle}"

                        # Set standard fields
                        item['Offer'] = ''
                        item['Framework'] = '3'
                        item['SiteName'] = self.Sitename
                        item['SiteURL'] = self.siteurl
                        item['DateAdded'] = datetime.datetime.now()
                        item['DateUpdated'] = datetime.datetime.now()
                        item['dealpage'] = 'True'

                        # Only yield if we have the essential information
                        if item['Title'] and item['SourceUrl']:
                            processed_count += 1
                            yield item

                    except Exception as e:
                        self.logger.error(f"Error processing product in batch {batch}: {str(e)}")
                        continue

                self.logger.info(f"Successfully processed {processed_count} products in batch {batch}")
            else:
                self.logger.error(f"Could not find items in the expected location for batch {batch}")

        except Exception as e:
            self.logger.error(f"Error processing batch {response.meta.get('batch', 'unknown')}: {str(e)}")