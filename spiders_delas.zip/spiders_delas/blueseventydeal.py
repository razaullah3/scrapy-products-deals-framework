from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class blueseventydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'blueseventydeal'
    start_urls = ['https://www.blueseventy.com/collections/clearance']
    Sitename = 'Blueseventy'
    siteurl = 'https://www.blueseventy.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = './/li[@class="grid__item"]'
        titalxpath = './/h3[@class="card__heading h5"]/a/text()'
        imagexpath = './/div[@class="media media--transparent media--hover-effect"]/img[1]/@srcset'
        pricexpath = './/s[@class="price-item price-item--regular price-item--last"]/text()'
        price2xpath = './/span[@class="price-item price-item--sale"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })