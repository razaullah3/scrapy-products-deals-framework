import scrapy
import json
import re

class SayWeeeSpider(scrapy.Spider):
    name = "sayweee_json"
    start_urls = ["https://www.sayweee.com/en/category/sale?ws=sidebar&filter_sub_category=sale"]

    def parse(self, response):
        # Extract the JSON part from the <script>
        script_text = response.xpath('//script[contains(text(), "__next_f.push")]/text()').get()
        json_text = re.search(r'self.__next_f.push\(\[1,(.*)\]\);', script_text, re.DOTALL).group(1)
        
        data = json.loads(json_text)
        # Navigate to product data
        products = data[3]['children'][0][3]['contents']  # adjust based on structure
        
        for p in products:
            if p['type'] == 'product':
                pdata = p['data']
                yield {
                    "name": pdata['name'],
                    "url": pdata['view_link'],
                    "price": pdata['price'],
                }
