from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class adoramasaleSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'adoramasale'
    start_urls = ['https://www.adorama.com/specials/l/?startAt=50']
    Sitename = 'adorama'
    siteurl = 'https://www.adorama.com'


    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
       
        divxpath = '//div[contains(@class,"Products_productWr__lP23N")]'
        titalxpath = './/a[@data-test-id="product-link"]/span/text()'  # comma removed
        imagexpath = './/div[@class="Products_productImgWr__mJZpb"]//img/@src'
        pricexpath = './/section[@class="Products_productPrice__vfA3t"]//span[@class="Products_price__ACYq_"]/text()'
        price2xpath = './/div[@class="Products_newItemPrice__uFTv4"]//span[@class="Products_highPrice__FPVo6"]/text()'
        nextpage = '//a[@class="PaginationProductsList_nextLink__GE_q7"]/@href'
        otherxpath = ';'
        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })