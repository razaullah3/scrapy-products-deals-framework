import scrapy
import json
import datetime
import uuid
from ..items import couponsDealsItem

class WilsonDealSpider(scrapy.Spider):
    name = "wilson_deal"
    api_url = "https://catalog-service.adobe.io/graphql"

    # Headers
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Magento-Environment-Id": "09a9b042-51bb-401d-822a-6b8689dbeb22",
        "Magento-Website-Code": "wil_us",
        "Magento-Store-Code": "wil_us",
        "Magento-Store-View-Code": "wil_us_en",
        "X-Api-Key": "7311e12332294e789b3488d27b4fd259",
        "Content-Type": "application/json",
        "Magento-Customer-Group": "b6589fc6ab0dc82cf12099d1c2d40ab994e8410c",
        "Origin": "https://www.wilson.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4"
    }

    # Use your exact JSON body
    payload_body = {
        "query": " query categoryQuery( $categoryId: String! $phrase: String! $pageSize: Int $currentPage: Int = 1 $filter: [SearchClauseInput!] $sort: [ProductSearchSortInput!] $context: QueryContextInput ) { categories(ids: [$categoryId]) { name urlKey urlPath } ...PRODUCT_SEARCH } fragment Product on ProductSearchItem { product { __typename id sku description { html } short_description{ html } name canonical_url small_image { url } image { url } thumbnail { url } price_range { minimum_price { fixed_product_taxes { amount { value currency } label } regular_price { value currency } final_price { value currency } discount { percent_off amount_off } } maximum_price { fixed_product_taxes { amount { value currency } label } regular_price { value currency } final_price { value currency } discount { percent_off amount_off } } } } } fragment ProductView on ProductSearchItem { productView { __typename sku name inStock url urlKey attributes(roles: [\"visible_in_plp\"]) { label name roles value } images { label url roles } ... on ComplexProductView { priceRange { maximum { final { amount { value currency } } regular { amount { value currency } } } minimum { final { amount { value currency } } regular { amount { value currency } } } } options { id title values { id title ... on ProductViewOptionValueSwatch { id inStock type value } } } } ... on SimpleProductView { price { final { amount { value currency } } regular { amount { value currency } } } } } highlights { attribute value matched_words } } fragment Facet on Aggregation { title attribute buckets { title __typename ... on CategoryView { name count path } ... on ScalarBucket { count } ... on RangeBucket { from to count } ... on StatsBucket { min max } } } fragment PRODUCT_SEARCH on Query { productSearch( phrase: $phrase page_size: $pageSize current_page: $currentPage filter: $filter sort: $sort context: $context ) { total_count items { ...Product ...ProductView } facets { ...Facet } page_info { current_page page_size total_pages } } attributeMetadata { sortable { label attribute numeric } } }",
        "variables": {
            "phrase": "",
            "pageSize": 48,
            "currentPage": 1,
            "filter": [
                {"attribute": "categoryPath","eq": "deals/mens-sportswear"},
                {"attribute": "visibility","in": ["Catalog","Catalog, Search"]},
                {"attribute": "pcm_product_salability","in": ["STANDARD","COMING_SOON","DRAW_CAMPAIGN","EARLY_ACCESS","SOLD_OUT","PRE_ORDER","NOT_SOLD_ONLINE"]}
            ],
            "sort":[{"attribute":"position","direction":"ASC"}],
            "categoryId":"7294",
            "context":{"customerGroup":"b6589fc6ab0dc82cf12099d1c2d40ab994e8410c","userViewHistory":[]}
        }
    }

    def start_requests(self):
        # Generate unique request ID for each request
        self.custom_headers["X-Request-Id"] = str(uuid.uuid4())
        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.custom_headers,
            body=json.dumps(self.payload_body),
            callback=self.parse,
            meta={"page": 1}
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON parse error: {e}")
            return

        products = data.get("data", {}).get("productSearch", {}).get("items", [])

        for p in products:
            item = couponsDealsItem()
            product = p.get("product", {})
            name = product.get("name", "")
            canonical_url = product.get("canonical_url", "")
            image = product.get("image", {}).get("url", "")
            product_view = p.get("productView", {})
            attributes = product_view.get("attributes", [])
            for attr in attributes:
                if attr.get("name") == "eds_images" and attr.get("value"):
                    try:
                        eds_images = json.loads(attr["value"])
                        if eds_images and "images" in eds_images[0]:
                            first_image = eds_images[0]["images"][0]["image"]
                            image = first_image  # override image
                    except:
                        pass
                    break  

            # Extract price
            price_info = product.get("price_range", {}).get("maximum_price", {})
            reg_price = price_info.get("regular_price", {}).get("value", "")
            sale_price = price_info.get("final_price", {}).get("value", "")

            item["Title"] = name
            item["SourceUrl"] = canonical_url
            item["Image"] = image
            item["Price"] = reg_price
            item["SalePrice"] = sale_price

            # Calculate discount
            try:
                if reg_price and sale_price and reg_price > sale_price:
                    discount = round(((reg_price - sale_price) / reg_price) * 100, 1)
                    item["Offer"] = f"{discount}% Off"
                else:
                    item["Offer"] = ""
            except:
                item["Offer"] = ""

            # Static metadata
            item["SiteName"] = "Wilson"
            item["SiteURL"] = "https://www.wilson.com"
            item["Framework"] = "GraphQL"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"

            yield item

        # Pagination
        page_info = data.get("data", {}).get("productSearch", {}).get("page_info", {})
        current_page = page_info.get("current_page", 1)
        total_pages = page_info.get("total_pages", 1)

        if current_page < total_pages:
            next_page = current_page + 1
            next_payload = json.loads(json.dumps(self.payload_body))  # deepcopy
            next_payload["variables"]["currentPage"] = next_page
            self.custom_headers["X-Request-Id"] = str(uuid.uuid4())
            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.custom_headers,
                body=json.dumps(next_payload),
                callback=self.parse,
                meta={"page": next_page}
            )
