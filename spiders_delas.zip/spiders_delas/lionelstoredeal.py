from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class lionelstoredealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'lionelstoredeal'
    start_urls = ['https://www.lionelstore.com/category/Special-Deals']
    Sitename = 'LionelStore'
    siteurl = 'https://www.lionelstore.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@itemprop="itemListElement"]'
        titalxpath = './/span[@itemprop="name"]/text()'
        imagexpath = './/img[@class="facets-item-cell-grid-image"]/@src'
        pricexpath = './/div[@class="MSRP_price_styles"]//strong/text()'
        price2xpath = './/div[@class="sales_price_styles"]//strong/text()'
        otherxpath = './/span[@class="sales_price-price-lead_save"]//small/text()'
        nextpage = '//li[@class="global-views-pagination-next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })