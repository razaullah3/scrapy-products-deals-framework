import scrapy
import json
import datetime
from ..items import couponsDealsItem

class AzazieDealsSpider(scrapy.Spider):
    name = 'azazie_deal'
    allowed_domains = ['azazie.com']
    base_api = 'https://www.azazie.com/prod/1.0/list/content-new'
    Sitename = 'Azazie'
    siteurl = 'https://www.azazie.com'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json"
    }

    body = {
        "format": "list",
        "cat_name": "collection",
        "dress_type": "dress",
        "page": 1,
        "limit": 60,
        "in_stock": "",
        "show_final_sale": 1,
        "only_show_final_sale": 1,
        "is_outlet": 0,
        "version": "b",
        "activityVerison": "b",
        "galleryVersion": "A",
        "sodGalleryVersion": "B",
        "topic": "azazie",
        "listColorVersion": "A",
        "multiColorVersion": "b",
        "atelier_ab_version": "b"
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_api,
            method="POST",
            headers=self.headers,
            body=json.dumps(self.body),
            callback=self.parse,
            cb_kwargs={"page": 1}
        )

    def parse(self, response, page):
        self.logger.info(f"Scraping Azazie page: {page}")

        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON parsing failed: {e}")
            return

        prod_list = data.get("data", {}).get("prodList", [])
        total_products = 0

        for prod in prod_list:
            item = couponsDealsItem()
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["Framework"] = "3"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"
            item["Title"] = prod.get("goodsSubTitle", "").strip()
            item["SourceUrl"] = f"{self.siteurl}{prod.get('goodsUrl', '')}"
            item["Price"] = prod.get("noDealPriceDisplay", "")
            item["SalePrice"] = prod.get("shopPriceDisplay", "")
            item["Offer"] = prod.get("priceOffDisplay", "")
            item["Image"] = prod.get("bigImg", {}).get("imgUrl", "")

            yield item
            total_products += 1

        self.logger.info(f"✅ Extracted {total_products} products from Azazie page {page}")

        # Pagination: check if more products exist
        if prod_list:
            next_page = page + 1
            self.body["page"] = next_page
            yield scrapy.Request(
                url=self.base_api,
                method="POST",
                headers=self.headers,
                body=json.dumps(self.body),
                callback=self.parse,
                cb_kwargs={"page": next_page}
            )
