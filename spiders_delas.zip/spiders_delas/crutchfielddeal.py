import scrapy
import json
import datetime
from ..items import couponsDealsItem


class CrutchfieldOutletSpider(scrapy.Spider):
    name = "crutchfield_outlet"

    # Base API — page, start, etc. will be injected dynamically
    api_template = (
        "https://www.crutchfield.com/handlers/product/outlet/list.ashx?"
        "c=3&pg={page}&start={start}&showBelowMap=true&IncludeFilters=true"
    )

    # Headers you provided
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "X-Requested-With": "XMLHttpRequest",
        "Connection": "keep-alive",
        "Referer": "https://www.crutchfield.com/S-DW92AsaCAgS/outlet_category_3/Car-Audio-Video-Outlet-Products.html?&pg=1",
        "Cookie": "SESSIONID=DW92AsaCAgS; SESSIONDATE=11/18/2025 23:40:00; __cf_bm=WakN8VxOIqjipAhbquxYnhH55AbHbr5BmSRyuZLvs90-1763527228-1.0.1.1-jQgGMTJLz77jOLIICK8qOMZhWPmuBMZQvvpQ5OpEBteAp9OcUXlbfd8e3ibvC7gFZtTs2xpO2RJGrmFRGmOcj1.5gWmsTi72d9Z1lYfGYvI; SYSTEMKEY=33263A79-DEE3-4BCD-9911-1A2C61D168BE; .ASPXANONYMOUS=RJrrd6CP3AEkAAAAZGY3MGViYTEtYzk2ZC00NTAxLWFmNDktMjA5MzNiMWRiZGI07kjBhS9bbGOd0GdxLIv3pwKa1b81; s_fid=5211EA85C39D2EE0-02802D1C9103C27D; cname=www; s_cc=true; OptanonConsent=isGpcEnabled=1&datestamp=Wed+Nov+19+2025+09%3A40%3A49+GMT%2B0500+(Pakistan+Standard+Time)&version=202211.2.0&isIABGlobal=false&hosts=&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A1%2CC0003%3A1%2CC0004%3A1; fs_lua=1.1763527544045; fs_uid=^#113ZWT^#43c7f6ce-29f1-4863-bef8-e06f3ccdea4c:bb5410ad-0926-4255-8300-cd6ab3e233b1:1763527245565::1^#/1795063247; OptanonAlertBoxClosed=2025-11-19T04:40:49.333Z; s_sq=crutchprod%3D%2526pid%253Doutlet%25253Aspecialsbycatid%25253A3%2526pidt%253D1%2526oid%253Djavascript%25253A%25253B%2526ot%253DA",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0",
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.api_template.format(page=1, start=0),
            headers=self.custom_headers,
            callback=self.parse,
            meta={"page": 1, "start": 0},
        )

    def parse(self, response):
        page = response.meta["page"]
        start = response.meta["start"]

        try:
            data = json.loads(response.text)
            products = data.get("Products", [])
        except Exception as e:
            self.logger.error(f"JSON Error on page {page}: {e}")
            return

        if not products:
            self.logger.info(f"No products found on page {page}")
            return

        # Extract each product
        for product in products:
            yield self.extract_product(product)

        # Pagination logic — Crutchfield returns 21 products per page
        next_start = start + len(products)
        next_page = page + 1

        next_url = self.api_template.format(page=next_page, start=next_start)

        yield scrapy.Request(
            url=next_url,
            headers=self.custom_headers,
            callback=self.parse,
            meta={"page": next_page, "start": next_start},
        )

    def extract_product(self, product):
        item = couponsDealsItem()

        computed = product.get("computed", {})
        props = product.get("properties", {})

        # ============================
        # REQUIRED FIELDS YOU ASKED FOR
        # ============================

        item["SalePrice"] = computed.get("AddToCart", {}).get("data_cf_price", "")
        item["Offer"] = computed.get("AddToCart", {}).get("data_cf_savings", "")
        item["Title"] = computed.get("AddToCart", {}).get("itemDescription", "")
        item["Price"] = ""
        

        # Primary image — FIXED URL
        photo = props.get("PrimaryPhotoUrl", "")
        item["Image"] = f"https://images.crutchfieldonline.com/ImageHandler/trim/300/225{photo}"

        # ============================
        # EXTRA FIELDS (OPTIONAL BUT GOOD)
        # ============================

        item["SourceUrl"] = computed.get("Url", "")
    

        # Meta
        item["SiteName"] = "Crutchfield"
        item["SiteURL"] = "https://www.crutchfield.com"
        item["Framework"] = "3"
        item["dealpage"] = "True"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()

        return item
