from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class schutzshoesdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'schutzshoesdeal'
    start_urls = ['https://schutz-shoes.com/search?q=deals&options%5Bprefix%5D=last']
    Sitename = 'schutzshoesdeal'
    siteurl = 'https://schutz-shoes.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="card-wrapper product-card-wrapper underline-links-hover"]'
        titalxpath = './/div[@class="card__information"]//a[@class="card__heading-title full-unstyled-link"]/text()'
        imagexpath = './/div[contains(@class,"card__media")]//img[1]/@src'
        pricexpath = ".//div[@class='price__sale order-sale']//span[@class='price-item price-item--sale price-item--last']/text()"
        price2xpath = ".//div[@class='price__sale order-sale']//s[@class='price-item price-item--regular']/text()"
        otherxpath = ''
        nextpage = "//nav[@class='pagination']//a[@aria-label='Next page']/@href"

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
