from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class toolocitydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'toolocitydeal'
    start_urls = ['https://www.toolocity.com/package-deals-2.aspx']
    Sitename = 'Applied Diamond Tools'
    siteurl = 'https://www.toolocity.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-list-item"]'
        titalxpath = './/h5/a/text()'
        imagexpath = './/img[@class="product-list-img"]/@src'
        pricexpath = './/span[@class="product-list-msrp-value"]/text()'
        price2xpath = './/span[@class="product-list-cost-value"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })