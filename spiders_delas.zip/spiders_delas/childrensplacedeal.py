import scrapy
import json
import datetime
from ..items import couponsDealsItem


class ChildrensPlaceSpider(scrapy.Spider):
    name = "childrensplace"
    allowed_domains = ["search.unbxd.io", "childrensplace.com"]
    Sitename = "Children's Place"
    siteurl = "https://www.childrensplace.com"

    limit = 90
    offset = 0

    def start_requests(self):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Origin": "https://www.childrensplace.com",
            "Connection": "keep-alive",
            "Referer": "https://www.childrensplace.com/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "cross-site",
            "DNT": "1",
            "Sec-GPC": "1",
        }
        url = self._build_api_url(self.offset)
        yield scrapy.Request(url=url, headers=headers, callback=self.parse, meta={"offset": self.offset})

    def _build_api_url(self, offset):
        return (
            "https://search.unbxd.io/8870d5f30d9bebafac29a18cd12b801d/"
            "childrensplace-com702771523455856/category"
            f"?start={offset}&rows={self.limit}&variants=true&variants.count=0&version=V2"
            "&stats=min_offer_price&facet.multiselect=true&selectedfacet=true&pagetype=boolean"
            "&fields=long_product_title,low_list_price,low_offer_price,seo_token,imagename,uniqueId,swatchimage,productid"
            "&p-id=categoryPathId:%22454010%22"
            "&filter=v_qty:[1 TO *] OR isVMPEnabled:true"
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get("response", {}).get("products", [])
        if not products:
            self.logger.info("No more products — stopping pagination.")
            return

        self.logger.info(f"Fetched {len(products)} products at offset {response.meta['offset']}")

        for product in products:
            try:
                title = product.get("long_product_title", "").strip()
                list_price = product.get("low_list_price")
                sale_price = product.get("low_offer_price")
                seo_token = product.get("seo_token", "")
                source_url = f"https://www.childrensplace.com/us/p/{seo_token}"

                unique_id = product.get("uniqueId", "").split("_")[0]
                imagename = product.get("imagename", "")
                # Build image URL using uniqueId
                image = f"https://assets.theplace.com/image/upload/t_plp_img_m,f_auto,q_auto/v1/ecom/assets/products/tcp/{unique_id}/{imagename}.jpg"

                item = couponsDealsItem()
                item["Title"] = title
                item["SourceUrl"] = source_url
                item["Image"] = image
                item["Price"] = list_price
                item["SalePrice"] = sale_price
                item["Offer"] = ""
                item["Framework"] = "3"
                item["SiteName"] = self.Sitename
                item["SiteURL"] = self.siteurl
                item["DateAdded"] = datetime.datetime.now()
                item["DateUpdated"] = datetime.datetime.now()
                item["dealpage"] = "True"

                yield item

            except Exception as e:
                self.logger.error(f"Error parsing product: {e}")

        # --- Pagination ---
        next_offset = response.meta["offset"] + self.limit
        next_url = self._build_api_url(next_offset)
        yield scrapy.Request(
            url=next_url,
            headers=response.request.headers,
            callback=self.parse,
            meta={"offset": next_offset},
        )
