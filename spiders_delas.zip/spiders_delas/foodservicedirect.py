from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class gnclivewelldealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404, 307]
    name = 'gnclivedeal'
    start_urls = ['']
    Sitename = 'GNC Live Well'
    siteurl = 'https://www.gnc.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile "]'
        titalxpath = './/a[@class="name-link"]/@title'
        imagexpath = './/img[@class="product-tile-img "]/@src | //img[@class="product-tile-img js-lazy-image observed js-lazy-image-handled fade-in"]'
        pricexpath = './/span[@title="Standard Price"]/text()'
        price2xpath = './/span[@title="Sale Price"]/text()'
        otherxpath = ''
        nextpage = '//button[@class="load-more-btn slide-type slide-type--skew"]/@data-grid-url'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })