import scrapy
import datetime
from ..items import couponsDealsItem


class WeeDealsSpider(scrapy.Spider):
    name = 'wee_deal'
    allowed_domains = ['sayweee.com']
    start_urls = ['https://www.sayweee.com/en/category/sale?ws=sidebar&filter_sub_category=sale']
    Sitename = 'WEE'
    siteurl = 'https://www.sayweee.com'

    def parse(self, response):
        self.logger.info(f"Scraping Azazie page: {response.url}")

        products = response.xpath('//a[@data-testid="wid-product-card-container"]')
        total_products = 0

        for prod in products:
            item = couponsDealsItem()
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["Framework"] = "3"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"

            item["SourceUrl"] = prod.xpath('./@href').get()
            if item["SourceUrl"] and not item["SourceUrl"].startswith("http"):
                item["SourceUrl"] = self.siteurl + item["SourceUrl"]

            item["Title"] = prod.xpath('.//div[@data-role="product-name"]/@title').get(default="").strip()
            item["Price"] = prod.xpath('.//div[@data-testid="wid-product-card-base-price"]/text()').get(default="").strip()
            item["SalePrice"] = prod.xpath('.//div[@data-testid="wid-product-card-price"]/text()').get(default="").strip()
            item["Offer"] = ""  # No explicit offer text on the page; can parse later if found
            item["Image"] = prod.xpath('.//div[@data-role="product-image"]/span/img/@src').get(default="").strip()

            yield item
            total_products += 1

        self.logger.info(f"✅ Extracted {total_products} products from {response.url}")

        # Offset-based Pagination (60 items per page)
        current_offset = response.meta.get("offset", 0)
        if total_products > 0:
            next_offset = current_offset + 60
            next_page_url = f"https://www.sayweee.com/en/category/sale?ws=sidebar&filter_sub_category=sale&offset={next_offset}&limit=60"
            self.logger.info(f"➡️ Moving to next page: {next_page_url}")
            yield scrapy.Request(
                url=next_page_url,
                callback=self.parse,
                meta={"offset": next_offset}
            )
