from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy

class ronaSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'ronadeal'
    start_urls = ['https://www.rona.ca/en/promotions/weekly-deals']
    Sitename = 'RONA'
    siteurl = 'https://www.rona.ca/en'

    # Custom headers to avoid 403 errors
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i',
        'TE': 'trailers'
    }

    def start_requests(self):
        """Override start_requests to add headers to initial requests"""
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@id="searchResults"]//div[@class="product-tile js-product-tile"]'
        titalxpath = './/a[@class="product-tile__title productLink"]/text()'
        imagexpath = './/img[@class="product-tile__image"]/@src'
        pricexpath = './/div[@class="price-box__regularPrice"]/text()'
        price2xpath = './/span[@class="price-box__price__amount"]/@data-product-price'
        otherxpath = ''
        nextpage = '//a[contains(@class,"pagination__button-arrow--next")]/@href'

        # Use response.follow with headers
        yield scrapy.Request(
            url=response.url,
            headers=self.headers,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            },
            dont_filter=True  # Prevent duplicate URL filtering for this specific request
        )
