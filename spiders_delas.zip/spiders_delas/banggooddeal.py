import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class banggooddealSpider(GetDealsProducts):
    name = 'banggooddeal'
    Sitename = 'Banggood'
    siteurl = 'https://www.banggood.com'

    # API endpoint for flash deals
    API_BASE_URL = 'https://www.banggood.com/?com=deals&t=getFdRecommendv2'
    PRODUCTS_PER_PAGE = 30  # Each page contains 30 products

    def start_requests(self):
        # Create and log initial item with getDoc flag
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        # Make initial API request to get total product count
        yield scrapy.Request(
            url=f"{self.API_BASE_URL}&page=1",
            callback=self.parse_initial_response
        )

    def parse_initial_response(self, response):
        """
        Parse the initial API response to get the total number of products,
        then generate requests for all pages.
        """
        try:
            # Parse the JSON response
            data = json.loads(response.text)

            # Check if the API response is successful
            if data.get('code') != '00' or 'result' not in data:
                self.logger.error("Initial API call failed or returned unexpected format")
                return

            # Process the first page
            yield from self.parse_products(response)

            # Extract total count information
            # Note: This is a placeholder - you'll need to adjust based on the actual API response structure
            # The API might return total count directly or we might need to calculate it

            # Method 1: If API provides total count directly
            total_products = 0
            if 'total' in data['result']:
                total_products = int(data['result']['total'])

            # Method 2: If API provides total pages directly
            elif 'total_pages' in data['result']:
                total_pages = int(data['result']['total_pages'])
                self.logger.info(f"API reports {total_pages} total pages")

                # Generate requests for remaining pages (2 to total_pages)
                for page in range(2, total_pages + 1):
                    self.logger.info(f"Generating request for page {page}/{total_pages}")
                    yield scrapy.Request(
                        url=f"{self.API_BASE_URL}&page={page}",
                        callback=self.parse_products,
                        meta={'page': page, 'total_pages': total_pages},
                        dont_filter=True
                    )
                return

            # Method 3: If we can estimate from product count
            # Get the product list from the first page
            product_list = data['result'].get('product_list', [])
            products_on_first_page = len(product_list)

            if 'total_count' in data['result']:
                total_products = int(data['result']['total_count'])
            elif products_on_first_page > 0:
                # Based on your comment: total product is 600
                # This could be hardcoded or if there's some other indicator in the response
                total_products = 600  # Default fallback based on your information
                self.logger.info(f"Using default total products: {total_products}")

            # Calculate total pages needed
            if total_products > 0:
                total_pages = (total_products + self.PRODUCTS_PER_PAGE - 1) // self.PRODUCTS_PER_PAGE
                self.logger.info(f"Calculated {total_pages} total pages for {total_products} products")

                # Generate requests for remaining pages (2 to total_pages)
                for page in range(2, total_pages + 1):
                    self.logger.info(f"Generating request for page {page}/{total_pages}")
                    yield scrapy.Request(
                        url=f"{self.API_BASE_URL}&page={page}",
                        callback=self.parse_products,
                        meta={'page': page, 'total_pages': total_pages},
                        dont_filter=True
                    )

        except Exception as e:
            self.logger.error(f"Error parsing initial response: {str(e)}")

    def parse_products(self, response):
        try:
            page = response.meta.get('page', 0)
            total_pages = response.meta.get('total_pages', 0)
            self.logger.info(f"Processing page {page}/{total_pages}")

            # Parse the JSON response
            try:
                data = json.loads(response.text)
            except json.JSONDecodeError:
                self.logger.error(f"Failed to parse JSON on page {page}")
                return

            # Check if the API response is successful
            if data.get('code') != '00' or 'result' not in data:
                self.logger.error(f"API returned error or unexpected format on page {page}")
                return

            # Get the product list
            product_list = data['result'].get('product_list', [])
            self.logger.info(f"Found {len(product_list)} products on page {page}")

            processed_count = 0
            for product in product_list:
                try:
                    # Create a new item for each product
                    item = couponsDealsItem()

                    # Basic product info
                    item['Title'] = product.get('products_name', '')

                    # Handle image URLs
                    image_url = product.get('image_url', '')
                    if image_url:
                        if image_url.startswith('//'):
                            image_url = f'https:{image_url}'
                        item['Image'] = image_url
                    else:
                        item['Image'] = ''

                    # Price information
                    products_price = product.get('products_price')
                    final_price = product.get('final_price')

                    if products_price is not None:
                        item['Price'] = product.get('format_products_price', f"US${products_price}")
                    else:
                        item['Price'] = ''

                    if final_price is not None:
                        item['SalePrice'] = product.get('format_final_price', f"US${final_price}")
                    else:
                        item['SalePrice'] = ''

                    # Offer information (discount percentage)
                    discount = product.get('discount')
                    if discount:
                        item['Offer'] = f"{discount}% OFF"
                    else:
                        item['Offer'] = ''

                    # Build the product URL
                    product_url = product.get('url', '')
                    if product_url:
                        if not product_url.startswith('http'):
                            product_url = f"{self.siteurl}{product_url}"
                        item['SourceUrl'] = product_url
                    else:
                        # Fallback using product ID
                        products_id = product.get('products_id')
                        if products_id:
                            item['SourceUrl'] = f"{self.siteurl}/p-{products_id}.html"
                        else:
                            item['SourceUrl'] = ''

                    # Set standard fields
                    item['Framework'] = '3'
                    item['SiteName'] = self.Sitename
                    item['SiteURL'] = self.siteurl
                    item['DateAdded'] = datetime.datetime.now()
                    item['DateUpdated'] = datetime.datetime.now()
                    item['dealpage'] = 'True'
                    item['getDoc'] = ''  # Reset getDoc flag

                    # Only yield if we have the essential information
                    if item['Title'] and item['SourceUrl']:
                        processed_count += 1
                        yield item

                except Exception as e:
                    self.logger.error(f"Error processing product on page {page}: {str(e)}")
                    continue

            self.logger.info(f"Successfully processed {processed_count} products on page {page}")

        except Exception as e:
            self.logger.error(f"Error processing page {response.meta.get('page', 'unknown')}: {str(e)}")

    # Legacy method kept for compatibility - redirected to API-based collection
    def parse(self, response):
        # Start API-based collection instead
        yield from self.start_requests()