from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class fashletsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'fashletsdeal'
    start_urls = ['http://www.fashlets.com/collection/deals.html']
    Sitename = 'Fashlets'
    siteurl = 'http://www.fashlets.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="list_item"]'
        titalxpath = './/div[@class="name"]/a/text()'
        imagexpath = './/img[contains(@rel,"imgshow")]/@src'
        pricexpath = './/div[@class="price_retail"]/text()'
        price2xpath = './/div[@class="price_normal"]/span/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })