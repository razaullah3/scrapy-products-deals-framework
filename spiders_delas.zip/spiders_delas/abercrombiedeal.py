from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class alphabetdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'abercrombie'
    start_urls = ['https://www.abercrombie.com/shop/us/sale']
    Sitename = 'abercrombie'
    siteurl = 'https://www.abercrombie.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '(//div[@class="button-group"]/a)[position() >= 15]/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="xp-9-11-1__productCard-module__product-image-section--rvCr2"]'
        titalxpath = '//h2[@data-aui="product-card-name"]/text()'
        imagexpath = './/div[@class="xp-9-11-1__productCard-module__hasHoverImage--xpGBA"]/a/img/@src'
        pricexpath = './/span[@data-variant="original"]/text()'
        price2xpath = './/span[@data-variant="discount"]/text()'
        otherxpath = './/span[@class="offdisc"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })