import scrapy

from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class chichiclothingdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'chichiclothingdeal'
    start_urls = ['https://us.chichiclothing.com/collections/sale?page=1']
    Sitename = 'chichiclothing'
    siteurl = 'https://us.chichiclothing.com/'

    # Add custom headers
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product-item"]/div/div'
        titalxpath = './/h3[@id="h3_override"]/text()'
        imagexpath = './/a[@class="card__media media--hover-effect"]/img[1]/@src'
        pricexpath = './/span[@class="fw-bold price-item--regular "]/text()'
        price2xpath = './/span[@class="body2 price-position-sale"]/span/text() | //span[@class="fw-bold price-item price-item--regular "]/text()'
        otherxpath = './/span[@class="price-item--save "]/text()'
        nextpage = '//ul[@class="pagination__list list-unstyled"]/li[3]/a/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.headers,  # Add headers to response.follow request
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            },
            dont_filter=True
        )