from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy

class babestadealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'ashrodeal'
    start_urls = ['https://www.ashro.com/c/sale/']
    Sitename = 'Ashro'
    siteurl = 'https://www.ashro.com'

    # Define the headers to be used in requests
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Connection': 'keep-alive'
    }

    def start_requests(self):
        """Override start_requests to include headers with initial requests"""
        for url in self.start_urls:
            yield scrapy.Request(url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile  standard-product"]'
        titalxpath = './/a[@class="name-link"]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="price-standard-range"]/text()'
        price2xpath = './/span[@class="product-standard-price basePrice"] | //span[@class="product-sales-price"]/text'
        otherxpath = ''
        nextpage = '//a[@class="page-next"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.headers,  # Add headers to response.follow request
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            },
            dont_filter=True
        )