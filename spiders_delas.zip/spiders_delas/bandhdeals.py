from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy

class bhdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bh'
    start_urls = ['https://www.bhphotovideo.com/deals-promotions-coupons?origSearch=deal']
    Sitename = 'B & H Video'
    siteurl = 'https://www.bhphotovideo.com/'

    # ✅ Add custom headers
    custom_headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'DNT': '1',
        'Sec-GPC': '1',
        'Priority': 'u=0, i',
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.custom_headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@data-selenium="miniProductPageDetailsGridView"]'
        titalxpath = './/div[@data-selenium="miniProductPageDetailsGridViewName"]/a/text()'
        imagexpath = './/img[@data-selenium="miniProductPageImg"]/@src'
        pricexpath = './/span/span[@class="text_TAw0W35QK_ compact_TAw0W35QK_ sizePrice5_TAw0W35QK_ weightNormal_TAw0W35QK_ preSavingsPrice_i3MsQsqoe0"]/span/text()'
        price2xpath = './/span[@class="price_qa8R6SFgHo"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.custom_headers,  # ✅ apply headers to this request too
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
