import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class carolwrightdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'carolwrightdeal'
    start_urls = ['https://www.carolwright.com/clearance/shop.html']
    Sitename = 'Carol Wright'
    siteurl = 'https://www.carolwright.com'

    def start_requests(self):
        api_url = 'https://lusearchapi-na.hawksearch.com/sites/CarolWrightGiftsv2/?output=json&hawkcategory=1&lpurl=%2Fclearance%2Fshop.html&pg=1'
        yield scrapy.Request(url=api_url)

    def parse(self, response):
        for req in self.getproducts(response):
            yield req

        listing_josn = json.loads(response.text)
        total_page = listing_josn['Pagination']['NofPages']
        current_page = 2
        while int(total_page) >= current_page:
            api_url = f'https://lusearchapi-na.hawksearch.com/sites/CarolWrightGiftsv2/?output=json&hawkcategory=1&lpurl=%2Fclearance%2Fshop.html&pg={str(current_page)}'
            yield response.follow(api_url, callback=self.getproducts, dont_filter=True)
            current_page += 1

    def getproducts(self, response):
        item = couponsDealsItem()

        listing_json = json.loads(response.text)
        for m in listing_json['Results']:
            item['Title'] = m['ItemName']
            item['Image'] = m['ImageURL']

            custom_token = m['Custom']
            price = custom_token['was_price']
            if price and float(price) != 0.0:
                item['Price'] = f"${float(price)}"
            else:
                item['Price'] = ''

            min_price = custom_token.get('retailpricemin', '')
            if min_price:
                max_price = m['Custom']['retailpricemax']
                if str(min_price) == str(max_price):
                    item['SalePrice'] = f"${float(min_price)}"
                else:
                    item['SalePrice'] = f"${float(min_price)} - ${float(max_price)}"
            else:
                item['SalePrice'] = f"${float(custom_token['price_retail'])}"

            item['Offer'] = ''
            item['SourceUrl'] = m['Custom']['url_detail']
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item
