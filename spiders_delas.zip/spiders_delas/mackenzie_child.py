from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class MackenzieChildsSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'mackenzie_childs'
    start_urls = ['https://www.mackenzie-childs.com/clearance/?https%3A%2F%2Fwww.mackenzie-childs.com%2Fclearance%2F=undefined&start=0&sz=312']
    Sitename = 'Mackenzie Childs'
    siteurl = 'https://www.mackenzie-childs.com'

    def parse(self, response):
        # Initial doc info
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        # Reset getDoc
        item['getDoc'] = ''

        # XPaths for scraping
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-container"]'
        titalxpath = './/a[@class="tile-link link h5"]/text()'
        imagexpath = './/img[@class="tile-image back-card"]/@src  '
        pricexpath = './/span[@class="sales promo"]/text()[normalize-space()]'
        price2xpath = './/span[@class="strike-through list"]/span[@class="value"]/text()[normalize-space()]'
        otherxpath = ''  # e.g., discount or offer if needed
        nextpage = '//button[@class="btn btn-outline-primary col-12 col-sm-4 more"]/@data-url'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
