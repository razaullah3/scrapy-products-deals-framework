import scrapy
import json
import datetime
from ..items import couponsDealsItem

class OfficeDepotSpider(scrapy.Spider):
    name = 'officedepot_sale'
    api_url = "https://pim-prod.odepotcloud.com/search"
    batch_size = 24  # number of products per request

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Content-Type": "application/json",
        "x-api-key":"TaCcwMhIj9aRaWDGpaivkaKAxA7rYe4f5k9Cm2Q8",
"jsession-id":"undefined",
"transaction-id":"brg_dyn_hlwrkgynh9-3d59b5225522_1759919517763|-OD-node9",
"x-forwarded-for":"64.64.116.8",
"Authorization":"Bearer eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ6aXBDb2RlIjoiNzcwMDEiLCJjZGFwU3RhdHVzIjoiWSIsImFwcGxJZCI6IiIsInNpZ25hdHVyZSI6ImFVUVh0IiwiaXNzIjoiT2ZmaWNlRGVwb3QiLCJpbnZMb2NEZnQiOiIxMTI3IiwiZ3NhQ3VzdG9tZXIiOiIiLCJjdXN0b21DYXRhbG9nSWQiOiIwIiwiYmlsbFRvSWQiOiIiLCJleHAiOjE3NjAwMDU5MTcsImJyYW5kIjoiT0QiLCJqdGkiOiJKd3RJZCIsInpvbmVQcmljZSI6Ijc5MDEiLCJzaXRlVHlwZSI6IkoiLCJ1c2VySGFzaCI6IiIsImNvbnRhY3RJZCI6IiIsInNlc3Npb25IYXNoIjoiJDJhJDEwJE1tUUsuZ0MzaEtxejVrQTRkSHVnek9ZWC5sNDBXWjlZR0d6VHdDNWFWN2FRWm5hMDhsZUlTIiwic2Vzc2lvbklkIjoiMDQ4OTQ5OSIsInN0b3JlSWQiOiIiLCJzaHB0b1NlcURmdCI6IjAwMDEiLCJ1c2VySWQiOiIiLCJlbnZpcm9ubWVudCI6Im5vZGU5Iiwic2FtZURheURlbGl2ZXJ5RWxpZ2libGVCeVppcENvZGUiOiJmYWxzZSIsImN1c3RUeXBlIjoiIiwiS0VZX1VTRVJOQU1FIjoiVVNFUk5BTUUiLCJ1c2VyVHlwZSI6IlAiLCJwcmljZUNoYW5uZWwiOiIiLCJsb3lhbHR5TWVtYmVyVHlwZSI6IiJ9.m4YSYfFpADrrVvacV4P796YZOoGND6VvudrsfHhUmBFi8feyedTiIAY1MBhq1JkTCLdBMd5Z7ZtfMZLb6dvfTA",
        "Origin": "https://www.officedepot.com",
        "Referer": "https://www.officedepot.com/",
    }

    def start_requests(self):
        # first page (start = 0)
        start = 0
        payload = self.get_payload(start)
        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.custom_headers,
            body=json.dumps(payload),
            callback=self.parse,
            meta={"start": start}
        )

    def get_payload(self, start):
        """Generate POST body with dynamic pagination offset."""
        return {
            "query": "brg_dyn_hlwrkgynh9",
            "brand": "od",
            "fl": "pid,url,price,description,brand,title,thumb_image,variants,Units,product_card_images,new_item,Hazmat,Eco~conscious,sku_reviews,sku_review_count,Diverse Supplier,Categories,Availability,default_nav_ids,Strategic Supplier Network,Total Quantity",
            "facetFilters": [],
            "rows": self.batch_size,
            "start": start,
            "browse": False,
            "sort": "relevance",
            "platform": "",
            "domainUrl": "",
            "isPunchout": False,
            "widgetId": "",
            "piqEnable": True,
            "isLoggedIn": False,
            "pppFlag": True,
            "inStockFilter": True,
            "BrUid2": "",
            "RequestType": "widget",
            "isSearchForInvalidCat": False,
            "retailerVisitorId": "13c1ca1f-4d17-4e68-be1e-9ebc04790f99",
            "DynamicId": "brg_dyn_hlwrkgynh9",
            "DynamicName": "brg_dyn_hlwrkgynh9"
        }

    def parse(self, response):
        start = response.meta.get("start", 0)

        try:
            data = json.loads(response.text)
            docs = data.get("response", {}).get("response", {}).get("docs", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        total_found = data.get("response", {}).get("response", {}).get("numFound", 0)
        self.logger.info(f"Processing batch starting at {start}, found {len(docs)} items")

        # Extract product info
        for p in docs:
            item = self.extract_product_item(p)
            if item:
                yield item

        # Pagination
        if len(docs) > 0 and (start + self.batch_size) < total_found:
            next_start = start + self.batch_size
            next_payload = self.get_payload(next_start)
            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.custom_headers,
                body=json.dumps(next_payload),
                callback=self.parse,
                meta={"start": next_start}
            )

    def extract_product_item(self, p):
        """Extract only required fields"""
        item = couponsDealsItem()

        br = p.get("brAttributes", {})
        cdap = p.get("cdapAttributes", {})
        global_price = cdap.get("globalPrice", {})

        item["Title"] = br.get("title", "")
        item["Image"] = br.get("thumbImage", "")
        item["SourceUrl"] = "https://www.officedepot.com" + br.get("url", "")
        item["SalePrice"] = global_price.get("sellPrice", {}).get("formattedPrice", "")
        item["Price"] = global_price.get("listPrice", {}).get("formattedPrice", "")


        # Optional metadata
        item["SiteName"] = "Office Depot"
        item["Offer"] = ""
        item["SiteURL"] = "https://www.officedepot.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
