from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class catheSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'cathedeal'
    start_urls = ['https://shop.cathe.com/dealoftheday.asp']
    Sitename = 'Cathe'
    siteurl = 'https://shop.cathe.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="deal-details"]'
        titalxpath = './/div[@class="deal-product-name"]/a/span/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="deal-regular-price-dollars"]/text()'
        price2xpath = './/span[@class="deal-price-dollars"]/text()'
        otherxpath = './/div[@class="deal-savings-value"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })