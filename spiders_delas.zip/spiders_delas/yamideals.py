import scrapy
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class yamidealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'yamideals'
    Sitename = 'Yami'
    siteurl = 'https://www.yami.com/en/'

    start_urls = [
        'https://www.yami.com/en/search?page=1&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=2&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=3&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=4&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=5&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=6&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=7&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=8&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal',
        'https://www.yami.com/en/search?page=9&track=search-input-0-deal&q=deal&sort_by=3&bu_type=search&module_name=input&index=0&content=deal'
    ]

    def parse(self, response):
        # Initial item marker for document capture
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//div[@class="search-items"]/div[contains(@class, "item-card")]'
        titalxpath = './/div[@class="item-title item-card__basics-info--item"]/a/text()'
        imagexpath = './/img[@class="item_card_image"]/@src'
        pricexpath = './/span[@class="price-invalid"]/text()'
        price2xpath = './/span[@class="price-normal price-valid word-bold-price"]/text()'
        otherxpath = ''

        # ✅ Follow to Data_Collector to extract product data
        yield scrapy.Request(
            url=response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'categorypage': categorypage,
            }
        )

        