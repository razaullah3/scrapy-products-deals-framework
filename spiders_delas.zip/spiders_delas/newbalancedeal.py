import scrapy
import datetime
from ..items import couponsDealsItem

class NewbalanceDealSpider(scrapy.Spider):
    name = "newbalance"
    start_urls = ["https://www.newbalance.com/sale/?start=0&sz=198"]

    custom_settings = {
        "PLAYWRIGHT_DEFAULT_NAVIGATION_TIMEOUT": 60000,
    }

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Cookie": "_abck=ED44BD24F528A3D5EE0EEC368A9CF09C~0~YAAQrCXAF3CbZTCaAQAAdFmPNA4PQ3GNnOxK7DAfEIYdp2W+VQ+lggMEWmZfZlAzINbqPcWgatILZn9sWWQHV6YOL8Idd8hQ4lKkXY8cPylfB+dT4t+EPD5WbW4xI+PHyCFz5lMve4sDtO5LJ4wNI52LkncHZ1syDrgEt4JnpU3KJTF1SusHqhZ28sM68ejvaw/0iny5BQjBAIs3b58RxMsZCXcj+LpIPUj7kxRjQLZJM0XabdG3h7cnDcxkobPGvtxAM7aMtLtZ5cWxQQIB8KBVBX7FyO0ZU7VUnZ0anSGelshMPz/QjJMyLIkG15qaLEmefiu5BEoN99E6X5ZSkz9Cf5c+9YAGwhYokhgZ8kAJMPwqRMrJRVwBHnE2kOvaeE6ZaDIbugrd/chYyopmtfwrGQQsqHFmk6i5adfSqtJYUndzNptXb43I1SB+241XRhDtY4Fh5H9SXXjxV/yD/rQHaIxsrQCeHRW5hA1/BoH/yYRzxLtR4wMnaZiHMAzDyd0SGIA/yXKF4w0HlRZzANJ7+4le0hOY/xRX+P8+yE5S9I/xpPKczy+Fx8HHUlAvr7OQNH4B8tEJSIqDjHyQiTg0UXJhh4FnlyBAkhzaox3VIb4aMgNhMIqgtyMqVDUPLgPIdOLYWyqavf13gJxwPq+xIw==~-1~-1~-1~AAQAAAAE%2f%2f%2f%2f%2f8+SN8gNzABwgliP8VDH3k5y4bUzY6Hh1s96TOXf4SfVE%2feGzvMSq2eqqou9J11swZ6kzxSLAq7w26HdY+hl9Sd02BpkjrFBAuq%2f~-1; ...",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0, i",
        
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                headers=self.headers,
                meta={
                "playwright": True,
                "playwright_page_coroutines": [
                    ("wait_for_load_state", "networkidle")
                     ]
                    },
                callback=self.parse
            )

    async def parse(self, response):
        cards = response.xpath('//div[@class="pgptiles col-6 col-lg-4 px-1 px-lg-2"]')
        for card in cards:
            item = couponsDealsItem()
            item['Title'] = card.xpath('.//div[@class="pdp-link"]/a/text()').get()
            item['Image'] = card.xpath(".//div[@class='image-container']/a/picture[contains(@class,'firstImage main-image')]/source[@type='image/webp']").get()
            item['Price'] = card.xpath(".//div[@class='p-lg-0']/span/span/text()[2]").get()
            item['SalePrice'] = card.xpath(".//span[@class='sales font-body-large']/span/text()").get()
            item['Offer'] = ""
            item['SourceUrl'] = card.xpath(".//div[@class='pdp-link']/a/@href").get()
            item['SiteName'] = "New Balance"
            item['SiteURL'] = "https://www.newbalance.com"
            item['Framework'] = "3"
            item['dealpage'] = "True"
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            yield item
