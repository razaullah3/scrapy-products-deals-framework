from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class vaporkingsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'vaporkingsdeal'
    start_urls = ['https://vaporking.com/collections/clouseout-huge-discounts']
    Sitename = 'vaporkings'
    siteurl = 'https://vaporking.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="productitem"]'
        titalxpath = './/h2/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/div[contains(@class,"compare-at")]/span/text()'
        price2xpath = './/div[contains(@class,"main")]/span/text()'
        otherxpath = ''
        nextpage = '//li[@class="pagination--next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
