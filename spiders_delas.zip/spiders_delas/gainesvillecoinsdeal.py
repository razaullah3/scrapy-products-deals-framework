from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class gainesvillecoinsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'gainesvillecoinsdeal'
    start_urls = ['https://www.gainesvillecoins.com/daily-deals']
    Sitename = 'Gainesville Coins'
    siteurl = 'https://www.gainesvillecoins.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@id="jsInitClearance"]/div/div'
        titalxpath = './/div[@class="title mt-3"]/a/text()'
        imagexpath = './/img/@data-src'
        pricexpath = './/div[@class="reg"]/span/text()'
        price2xpath = './/div[@class="price"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })