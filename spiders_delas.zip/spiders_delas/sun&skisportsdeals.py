from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class sunskidealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'sunskideals'
    start_urls = ['https://www.sunandski.com/c/deals']
    Sitename = 'Sun & Ski Sports'
    siteurl = 'https://www.sunandski.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product__content"] '
        titalxpath = './/a[@class="product__name product__name--grid line-clamp line-clamp--2"]/text()'
        imagexpath = './/a[@class="product__name product__name--grid line-clamp line-clamp--2"]/@href'
        pricexpath = './/span[@class="product__price product__price--inactive ml-1 "]/text()'
        price2xpath = './/span[@class="product__price product__price--sale "]/text()'
        otherxpath = './/span[@class="badge badge--med badge--percent-off"]/text()'
        nextpage = '//a[@data-mz-action="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })