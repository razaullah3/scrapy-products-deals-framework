from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy


class dwrdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'dwrdealdeal'
    start_urls = ['https://www.dwr.com/search?q=deal&search-button=&lang=en_US']
    Sitename = 'dwrdeal'
    siteurl = 'https://www.dwr.com/'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="grid-tile product"] |  //img[@class="product-asset-main tile-image js-no-hover-img"]/@src'
        titalxpath = './/div[@class="pdp-link"]/a/text()'
        imagexpath = './/div[@class="product-image-wrapper ratio ratio-1x1 has-hover-img"]/@data-originalimg'
        pricexpath = './/del//span[@class="value"]/text()'
        price2xpath = ".//div[@class='price']//span[@class='sales']/span[@class='pricing-default ']/following-sibling::span/span[@class='sales']/span/@content"

        otherxpath = ''
        nextpage = ''

        yield scrapy.Request(
            response.url,
            callback=self.Data_Collector,
            meta={
                   # light mode
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
