import scrapy
import json
import datetime
from ..items import couponsDealsItem


class AmericanMuscleDealSpider(scrapy.Spider):
    name = "americanmuscle_deal"
    start_urls = ["https://www.americanmuscle.com/am-deals.html"]

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Accept": "text/html,application/json",
        "Referer": "https://www.americanmuscle.com/",
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        # Extract all JSON-LD blocks
        products = response.xpath(
            "//script[@type='application/ld+json']/text()"
        ).getall()

        for block in products:
            try:
                data = json.loads(block)

                # Only product type JSONs
                if data.get("@type") != "Product":
                    continue

                yield self.extract_item(data)

            except Exception as e:
                self.logger.error(f"JSON parse error: {e}")

        # ---------------------------
        # PAGINATION (NEXT PAGE)
        # ---------------------------
        next_page = response.xpath('//a[@class="next"]/@href').get()

        if next_page:
            next_url = response.urljoin(next_page)
            yield scrapy.Request(
                next_url,
                headers=self.headers,
                callback=self.parse
            )

    def extract_item(self, data):

        item = couponsDealsItem()

        item["Title"] = data.get("name", "")
        item["SourceUrl"] = data.get("url", "")
        item["Image"] = data.get("image", "")
        item["SalePrice"] = data.get("offers", {}).get("price", "")
        item["Price"] = ""
        item["Offer"] = ""

        # Static fields
        item["SiteName"] = "American Muscle"
        item["SiteURL"] = "https://www.americanmuscle.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
