import scrapy
import json
import datetime
from urllib.parse import quote
from ..items import couponsDealsItem

class LulusDealsSpider(scrapy.Spider):
    name = "lulus_deal"
    base_api = "https://www.lulus.com/api/search/products"

    # ✅ EXACT HEADERS YOU PROVIDED
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.lulus.com/searchresults?p=2&q=deals&_csrf=dvTF1Ztn-PUl9YO_X5xQYL9V8IamtK-uiP3c",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
        "TE": "trailers",
        # Add all other headers you listed if needed
    }

    initial_params = {
        "p": "1",
        "q": "deals",
        "_csrf": "dvTF1Ztn-PUl9YO_X5xQYL9V8IamtK-uiP3c"
    }

    def start_requests(self):
        url = self.base_api + "?" + "&".join(f"{k}={quote(v)}" for k, v in self.initial_params.items())
        yield scrapy.Request(
            url=url,
            headers=self.custom_headers,
            callback=self.parse,
            cb_kwargs={'page': 1},
            dont_filter=True
        )

    def parse(self, response, page):
        data = json.loads(response.text)
        products = data.get("content", {}).get("products", [])
        if not products:
            return

        for p in products:
            item = couponsDealsItem()
            # Product Name
            item["Title"] = p.get("swatches", [{}])[0].get("name", "").strip()

            # Images
            images = p.get("swatches", [{}])[0].get("images", [])
            img_urls = []
            for img in images:
                url = img.get("mobileUrl") or img.get("imagePath")
                if url:
                    if url.startswith("/"):
                        url = "https://www.lulus.com" + url
                    img_urls.append(url)
            item["Image"] = img_urls

            # Price
            price_info = p.get("swatches", [{}])[0].get("productPrice", {})
            item["Price"] = price_info.get("price")
            item["SalePrice"] = price_info.get("promoPrice")

            # Source URL
            product_id = p.get("id")
            if product_id:
                item["SourceUrl"] = f"https://www.lulus.com/products/{product_id}.html"

            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["Offer"] = ""
            item["dealpage"] = "True"
            item["SiteName"] = "Lulus"
            item["SiteURL"] = "https://www.lulus.com/searchresults?q=deals"
            item["Framework"] = "3"

            yield item

        # Pagination
        next_page = page + 1
        next_params = dict(self.initial_params)
        next_params["p"] = str(next_page)
        next_url = self.base_api + "?" + "&".join(f"{k}={quote(v)}" for k, v in next_params.items())

        yield scrapy.Request(
            url=next_url,
            headers=self.custom_headers,
            callback=self.parse,
            cb_kwargs={'page': next_page},
            dont_filter=True
        )
