import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy


class carilohadealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'carilohadeal'
    start_urls = ['https://www.cariloha.com/sale.html']
    Sitename = 'Cariloha'
    siteurl = 'https://www.cariloha.com'

    # Custom headers
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Connection': 'keep-alive'
    }

    def start_requests(self):
        """Override start_requests to include custom headers"""
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # Define XPath selectors for product information
        categorypage = ''  # Category links
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product"]'  # Main product container
        titalxpath = './/h3[@class="card-title"]/a[not(contains(text(),"Placeholder"))]/text()'  # Product title
        imagexpath = './/div[@class="card-img-container"][img[not(contains(@alt,"Image coming soon"))]]/img/@src'  # Product image
        pricexpath = './/span[@class="price price--non-sale"]/text()'  # Original price
        price2xpath = './/span[@class="price price--withoutTax"]/text()'  # Sale price
        otherxpath = ''
        nextpage = '//li[@class="pagination-item pagination-item--next"]/a/@href'  # Next page link

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.headers,  # Include headers in the follow request
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }, dont_filter=True
        )