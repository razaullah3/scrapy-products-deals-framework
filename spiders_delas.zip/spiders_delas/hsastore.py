from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class  sheplersdealsSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = ' sheplersdeals'
    start_urls = ['https://www.sheplers.com/search?q=clearance']
    Sitename = ' sheplersdeals'
    siteurl = 'https://www.sheplers.com/'
    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[contains(@class,"grid-tile")]'
        titalxpath = './/h6[@class="product-name"]/a/text()'
        imagexpath = './/img[@class="tile-image"]/@src'
        pricexpath = './/span[@class="product-total-price savings"]/text()'
        price2xpath = './/span[@class="product-standard-price"]/del/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })