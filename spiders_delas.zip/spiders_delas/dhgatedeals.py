import scrapy
import json
import datetime
from urllib.parse import quote
from ..items import couponsDealsItem

class DHGateDealsSpider(scrapy.Spider):
    name = "dhgate_deal"
    base_api = "https://mrd.dhgate.com/home/web/getFdSeckillWaterfallFlow.do"

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, zstd",
        "Referer": "https://www.dhgate.com/sales/market/flashdeals.html",
        "Origin": "https://www.dhgate.com",
        "Cookie": 'vid=560A12AC16FF0269973EE79F02D1BD1A; b2b_ip_country=US; b2b_ship_country=US; last_choice=0; ref_f=; ref_df=direct; odvid=rBIKVmkC/xaf5z6XGr3RAg==; _abck=ABCA99C854D8A756FC219211C28596AA~-1~YAAQF/jNF1i/lhGaAQAA2HG0Mw49nrzQy18Mf9BoEH8iPQhI9otk3Wb2GsdAM76GcOQN4nt9snE63CmCfBMzut/O9tmkBU1Rg17tQs0TDlS2t465uB6hwsGn65uvXvJFfEScIPq53kYJHctm65IaJUJH7hSUKx2gHLvb8tQ+izXuxCwRFsZREdz1sz853MMm7zqOQqo/rgqoKmo1SqGoDVdJ1ZW5/3x3kXSAathf8+R0Bijx2G6GsZlROfWox8Aw3eWk3feZnbnLpJGCDIkNTYpPUnJoc0Wf/djNYcZFenbDYL4vSpG+5TAcK3pkgkQhR6wFCcC1T3/ISV/i2WCisTDrWKCoGyNuoiZ8YQowPiT6+NkeomTDCA8q5DMLVMMZDsFUHsRd06h2FQ2AVanTLakiWuRridwSWCCA88RI+ehEMsSrFAPrq7C36tL/NrVaQi+0UN4nS89e0khEvINx037l19xi~-1~-1~-1~-1~-1; ak_bmsc=AEE73656ED3AE2641E031AF5D359B37F~000000000000000000000000000000~YAAQF/jNF1m/lhGaAQAA2HG0Mx0UO1mwr0DO4g6ovOgyoJqOFofdM7yc0eunfkruh3WIHRPvXk1FqOdGhAaAZ+wNwgN9hKrrbLeusijMm/G6QLpVOJJc+mUF2C9q8RMbPX9+TQ2fMQo1EH0cqiTeCxUCS9c1t9gFwX8/W/97ozNyorkz1psowN4372frKbL6Zw9T7vqGfWAenxV+FiP9c0inwWgrbqcmhcMmGRpop/fTDevghHzTotlC//a0XibN7fbT5EoHCsW5QUztaiacNetyhcCxy66Z5Ahhfrk52Xo8s0QdqPDIW//aKUIKaeEL+gusF9m8bRkaGXzhKSN31j2uNSaJoZUHO2o0QlAY1YkbEkaHROWvkHYW1VAEPoYxselHEna6YNkE7Q==; bm_sz=30D217407E41DCAEA237FD2EC4528FC0~YAAQF/jNF7/ElhGaAQAAd9O0Mx3I/1xMu4R5zYaU/dqMxrQh6IdXqUqYy2wZ0cIUDnN5ugvUoN765CPxBquAjyqDuhAxLHowOtMaRkjPa/elA+bkIvA1vwuig+86X2jyZfvwf0j7OJWoazZbcNvxTgfQ89hTx8QJdsqpLCaOJZoF/4i5dZHoscYXvmjn1KthOyke1BWETuHaMmELhPH/yjEgBW1hnMwS4jRC8wTBZV+kC+VzYhy31E0Hjy7beQQ67Wl7cbiU56kTxLZfhNWjsFtz+vK0E9p4AuXnA4gB6R5MClc2odTCK80ZYMyF7ENYjAV9e0nO1oLiFq4Wgrj0NGSn68wEozMjV+OEuwa9hBry0aGWCfdrTk1o1R6uck84m8c3/ktpt4v3QXiss/mDXAYt~3425349~3356481; d1_last_vt=1761804057149; d1_session=FhUPoJ22CG9rQcJZQw8N; d1_s_vnum=3; abversions={"1073": 1, "795": 0, "861": 1, "42": 4, "383": 1, "1135": 1, "1042": 1, "1006": 1, "1044": 1, "1111": 1, "107": 1, "1119": 0, "143": 1, "1053": 2, "1038": 1, "utc": 1761818457, "1140": 1, "1033": 0, "841": 1, "1150": 0, "525": 1, "1136": 0}; abversions_pv={"sign": "1073_1", "sellercoupon": "1053_2|42_4", "st": "1053_2|42_4", "su": "1053_2|42_4", "pdlist2": "1053_2|42_4", "clp": "1053_2|42_4", "orders": "1044_1", "seo-suppliers": "1053_2|42_4", "zeros": "1053_2|42_4", "ranking": "1053_2|42_4", "hp-b": "1053_2|42_4", "groupbygroups": "1053_2|42_4", "orderlistpage": "1053_2|42_4", "mydhref": "1053_2|42_4", "store": "1053_2|42_4", "plaord": "1053_2|42_4", "drt": "1053_2|42_4", "myfav": "1053_2|42_4", "paysucc": "1053_2|42_4", "groupbuy": "1053_2|42_4", "ppc_blisting": "1053_2|42_4", "seo-onsh": "1053_2|42_4", "cart": "1053_2|42_4", "fl": "1053_2|42_4", "hp": "1006_1|1053_2|42_4", "mydhgate": "1053_2|42_4", "myacc": "1053_2|42_4", "seo-uk": "1053_2|42_4", "nbregion": "1053_2|42_4", "mydhgate_new": "1006_1", "pd": "1006_1|1053_2|1111_1|42_4|795_0", "cate": "1053_2|42_4", "paysuccess": "1053_2|42_4", "ordreview": "1053_2|42_4", "Noresult": "841_1", "dhref": "1053_2|42_4", "lp": "1053_2|42_4", "orddet": "1044_1", "crmsp": "1053_2|42_4", "seo-au": "1053_2|42_4", "seo-ca": "1053_2|42_4", "register_signin": "1073_1", "seo-srp": "1053_2|42_4", "sp": "1006_1|1033_0|1053_2|107_1|1111_1|1119_0|1135_1|1136_0|1140_1|1150_0|143_1|42_4|525_1|841_1|861_1", "ct": "1053_2|1111_1|42_4", "groupbuypd": "1053_2|42_4", "channelLp": "1053_2|42_4", "po": "1053_2|1111_1|42_4", "seo-nz": "1053_2|42_4", "sellercoup": "1053_2|42_4"}; __cf_bm=BUmkxNc8Z.4A.03VxYU8mNJgs25B_di7fLatphaFC.A-1761804058-1.0.1.1-opZQxvLZLQ8e_O2bsCWrVTAqM.sj9u7J1Psv8okFH2mqyvPZ1lAIxcAv3TbDPWw16a0fnHBDd0LPHH_P_aQXgxnYTZuju9f7U_hIWkweAUY; language=en; bm_sv=1C84CFB5B168386721AF3FFC74EC0365~YAAQF/jNF2DFlhGaAQAAWN60Mx28bw/IIxS4W60l0Lc9jJ/HUyDubJGI/jpEn0ajkmPhNxwsDWOsAk44rwZV+auR/T3L/ypKsKbGsShAV2oFiKa2r6kTyayVse7OdiPCcBzLMqC3yX9xf9vXLi7t8IfjPPU6OCCULCjvfA0H9DMJYGUi/wArVyN0XwCeIPvTpEejsSDE9AqK20RGlYmuOtTElrPbcCp/I9iDW9fkd8ZaYK3qNwIJ9g6WWpmtnxZR~1; b_u_cc=ucc=US; b2b_cart_sid=3013b57e-e73e-492e-ad98-64839a4992e3; B2BCookie=17209c74-1b29-41c0-83e0-6cfab87f6802; RT="z=1&dm=dhgate.com&si=fb42b7ba-f42d-4745-84bc-5fb578c04b1b&ss=mhd0n8gm&sl=1&tt=ghy&rl=1&ld=ghz&hd=k9m"',
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
        "TE": "trailers",
        # Include Cookie header if needed
    }

    initial_params = {
        "pageNum": "1",
        "pageSize": "25",
        "language": "en",
        "client": "pc",
        "dispCurrency": "",
        "groupingId": "one",
        "ids": "0-4119-0-1726626171672-398-0-f12",
        "opt": "null",
        "_": str(int(datetime.datetime.now().timestamp() * 1000))
    }

    def start_requests(self):
        url = self.base_api + "?" + "&".join(f"{k}={quote(str(v))}" for k, v in self.initial_params.items())
        yield scrapy.Request(
            url=url,
            headers=self.custom_headers,
            callback=self.parse,
            cb_kwargs={'page': 1},
            dont_filter=True
        )

    def parse(self, response, page):
        data = json.loads(response.text)
        products = data.get("data", [])
        if not products:
            return

        for p in products:
            item = couponsDealsItem()
            item["Title"] = p.get("imgText", "").strip()
            item["Image"] = [p.get("imgUrl")]
            item["Price"] = p.get("oPrice")
            item["SalePrice"] = p.get("price")
            item["SourceUrl"] = p.get("link", {}).get("url")
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["Offer"] = ""
            item["dealpage"] = "True"
            item["SiteName"] = "DHGate"
            item["SiteURL"] = "https://www.dhgate.com/sales/market/flashdeals.html"
            item["Framework"] = "3"

            yield item

        # Pagination
        next_page = page + 1
        next_params = dict(self.initial_params)
        next_params["pageNum"] = str(next_page)
        next_params["_"] = str(int(datetime.datetime.now().timestamp() * 1000))
        next_url = self.base_api + "?" + "&".join(f"{k}={quote(str(v))}" for k, v in next_params.items())

        yield scrapy.Request(
            url=next_url,
            headers=self.custom_headers,
            callback=self.parse,
            cb_kwargs={'page': next_page},
            dont_filter=True
        )
