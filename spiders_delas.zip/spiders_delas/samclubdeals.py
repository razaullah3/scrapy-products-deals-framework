import scrapy
import json
import datetime


class SamsClubSavingsSpider(scrapy.Spider):
    name = "savings"
    allowed_domains = ["samsclub.com"]
    base_url = "https://www.samsclub.com/shop/savings"

    Sitename = "SamsClub"
    siteurl = base_url

    def start_requests(self):
        yield from self.request_page(1)

    def request_page(self, page_number):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "DNT": "1",
            "Sec-GPC": "1",
            "Priority": "u=0, i",
        }

        url = f"{self.base_url}?page={page_number}"
        yield scrapy.Request(
            url=url,
            headers=headers,
            callback=self.parse,
            cb_kwargs={"page_number": page_number}
        )

    def parse(self, response, page_number):
        script_data = response.xpath('//script[@id="__NEXT_DATA__"]/text()').get()

        if not script_data:
            self.logger.error("Could not find __NEXT_DATA__ script tag.")
            return

        try:
            data = json.loads(script_data)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        try:
            item_stacks = data["props"]["pageProps"]["initialData"]["searchResult"]["itemStacks"]
            item_count = 0

            for stack in item_stacks:
                for raw_item in stack.get("items", []):
                    item_count += 1
                    yield {
                        "Title": raw_item.get("name"),
                        "Image": raw_item.get("imageInfo", {}).get("thumbnailUrl"),
                        "SourceUrl": f'https://www.samsclub.com{raw_item.get("canonicalUrl")}',
                        "Price": raw_item.get("priceInfo", {}).get("linePrice"),
                        "SalePrice": raw_item.get("priceInfo", {}).get("itemPrice"),
                        "Offer": raw_item.get("priceInfo", {}).get("savings"),
                        "Framework": "3",
                        "SiteName": self.Sitename,
                        "SiteURL": self.siteurl,
                        "DateAdded": datetime.datetime.now(),
                        "DateUpdated": datetime.datetime.now(),
                        "dealpage": "True"
                    }

            # If items were found, go to the next page
            if item_count > 0:
                yield from self.request_page(page_number + 1)
            else:
                self.logger.info(f"No more items found at page {page_number}. Stopping.")

        except KeyError as e:
            self.logger.error(f"Missing expected key: {e}")
