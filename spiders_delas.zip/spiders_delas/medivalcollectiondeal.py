import scrapy
import random
import csv
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class medivalcollectiondealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'medivalcollectiondeal'
    Sitename = 'Medival Collection'
    siteurl = 'https://www.medievalcollectibles.com'
    start_urls = ['https://www.medievalcollectibles.com/product-category/deals/']

    # ✅ Custom settings: enable retry + disable Playwright
    custom_settings = {
        "RETRY_ENABLED": True,
        "RETRY_TIMES": 10,  # 🔁 Retry up to 10 times
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy.core.downloader.handlers.http.HTTPDownloadHandler",
            "https": "scrapy.core.downloader.handlers.http.HTTPDownloadHandler",
        },
        "DOWNLOADER_MIDDLEWARES": {
            'scrapy.downloadermiddlewares.retry.RetryMiddleware': 90,
            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
        },
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_agents = self.load_user_agents()

    def load_user_agents(self):
        """Load user agents from useragents.csv"""
        try:
            with open("useragents.csv", "r", encoding="utf-8") as f:
                return [row[0].strip() for row in csv.reader(f) if row]
        except FileNotFoundError:
            print("⚠️ useragents.csv not found. Using default User-Agent.")
            return [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"
            ]

    def get_random_headers(self):
        """Return random User-Agent headers"""
        ua = random.choice(self.user_agents)
        return {
            'User-Agent': ua,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'DNT': '1',
            'Sec-GPC': '1'
        }

    def start_requests(self):
        """Send initial request with random headers"""
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                headers=self.get_random_headers(),
                callback=self.parse,
                dont_filter=True
            )

    def parse(self, response):
        """Main parse method"""
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = '//li[@class="product-category product first"]/a/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//ul[@class="products columns-4"]/li'
        titalxpath = './/h2/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[contains(@class, "woocommerce-Price-amount")]/bdi[1]/text()'
        price2xpath = ''
        otherxpath = ''
        nextpage = '//a[@class="next page-numbers"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.get_random_headers(),  # ✅ Rotate again for next request
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            },
            dont_filter=True
        )
