from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class greenvirginproductsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'greenvirginproductsdeal'
    start_urls = ['https://greenvirginproducts.com/collections/all']
    Sitename = 'Green Virgin Products'
    siteurl = 'https://greenvirginproducts.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="card-wrapper product-card-wrapper underline-links-hover"]'
        titalxpath = './/h3[@class="card__heading h5"]/a/text()'
        imagexpath = './/div[@class="media media--transparent media--hover-effect"]/img/@srcset[1]'
        pricexpath = ''
        price2xpath = './/div[@class="price__regular"]/span[2]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })