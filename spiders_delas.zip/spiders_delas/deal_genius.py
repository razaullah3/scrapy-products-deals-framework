from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class dealgeniusSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'dealgenius'
    start_urls = ['https://www.dealgenius.com/collections/all']
    Sitename = 'dealgenius'
    siteurl = 'https://www.dealgenius.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # -------------------------
        #      YOUR XPATHS
        # -------------------------
        divxpath = "//div[@class='product-list__inner']//product-item[contains(@class,'product-item')]"
        titalxpath = ".//a[@class='product-item-meta__title']/text()"
        imagexpath = ".//img[@class='product-item__primary-image']/@src"

        pricexpath = ".//span[@class='price price--highlight']/span/following-sibling::text()"
        price2xpath = ".//span[@class='price price--compare']/span[contains(text(),'$')]/text()"

        otherxpath = ""  # No discount text on site

        nextpage = "//link[@rel='next']/@href"

        # -------------------------
        #  SEND TO BASE COLLECTOR
        # -------------------------
        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
