from ..items import couponsDealsItem
import scrapy
from .GetDealsProducts import GetDealsProducts

class evoClearanceSpider(GetDealsProducts):
    handle_httpstatus_list = [404, 403]
    name = 'evoclearance'
    start_urls = ['https://www.evo.com/shop/clearance']
    Sitename = 'evo'
    siteurl = 'https://www.evo.com'

    custom_headers = {
        'Host': 'www.evo.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
    }

    # ✅ Scrapy 2.13+ compatible async start
    async def start(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                headers=self.custom_headers,
                meta={
                    "playwright": True,             # Playwright enable
                    "playwright_include_page": True,
                },
                callback=self.parse
            )

    async def parse(self, response):
        page = response.meta.get("playwright_page")
        if not page:
            self.logger.error("Playwright page not found in response.meta")
            return

        # Optional wait for JS to load fully
        await page.wait_for_timeout(3000)  # 3 sec

        # Get full page content
        content = await page.content()
        await page.close()

        # Replace Scrapy response body with JS rendered content
        response = response.replace(body=content.encode())

        # Yield a dummy item (getDoc)
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # XPaths for products
        divxpath = '//div[@class="product-thumb-details"]'
        titalxpath = './/span[@class="product-thumb-title"]/text()'
        imagexpath = './/img[contains(@class,"product-thumb-image js-product-thumb-image")]/@src'
        pricexpath = './/span[@class="discount"]/text()[1]'
        price2xpath = './/span[@class="product-thumb-price slash"]/text()'
        otherxpath = ''
        nextpage = '//a[@aria-label="next page"]/@href'

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # Call Data_Collector for scraping products
        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
            }
        )
