import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class toolfetchdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'toolfetchdeal'
    start_urls = ['https://www.toolfetch.com/product-categories/daily-deals']
    Sitename = 'Toolfetch'
    siteurl = 'https://www.toolfetch.com'

    def start_requests(self):
        url = (
            'https://www.toolfetch.com/api/items?c=493319&commercecategoryurl=%2Fproduct-categories%2Fdaily-deals'
            '&country=US&currency=USD&fieldset=search&include=facets&language=en&limit=34&n=2&offset=0'
            '&pricelevel=5&sort=commercecategory%3Adesc&use_pcv=F'
        )
        yield scrapy.Request(
            url=url,
            callback=self.parse,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                              '(KHTML, like Gecko) Chrome/113 Safari/537.36'
            }
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        items = data.get('items', [])
        self.logger.info(f"Found {len(items)} items.")

        for m in items:
            item = couponsDealsItem()

            item['Title'] = m.get('storedisplayname2', '').strip()

            # Safely get first image URL
            images = m.get('itemimages_detail', {}).get('urls', [])
            item['Image'] = images[0]['url'] if images else ''

            item['Price'] = m.get('pricelevel6_formatted', '') or ''
            item['SalePrice'] = m.get('onlinecustomerprice_formatted', '') or ''
            item['Offer'] = ''

            # Ensure URL is complete
            url_component = m.get('urlcomponent', '')
            item['SourceUrl'] = f"https://www.toolfetch.com/{url_component}" if url_component else self.siteurl

            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item
