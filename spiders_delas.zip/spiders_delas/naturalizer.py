import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class naturalizerSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'naturalizer'
    Sitename = 'Naturalizer'
    siteurl = 'https://www.naturalizer.com'

    page = 1   # Start from page 1

    def start_requests(self):
        url = "https://caleresproduction4uzryqju.org.coveo.com/rest/organizations/caleresproduction4uzryqju/commerce/v2/search"

        payload = {
            "q": "*",
            "page": self.page,
            "pageSize": 50  # adjust per request
        }

        yield scrapy.Request(
            url=url,
            method="POST",
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept-Encoding": "gzip, deflate, br, zstd",
                "Referer": "https://www.naturalizer.com/",
                "Content-Type": "application/json",
                "Authorization": "Bearer xx6b22c1da-b9c6-495b-9ae1-e3ac72612c6f",
                "Origin": "https://www.naturalizer.com",
                "Connection": "keep-alive",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "cross-site",
                "Priority": "u=4",
                "Pragma": "no-cache",
                "Cache-Control": "no-cache",
                "TE": "trailers"
            },
            body=json.dumps(payload),
            callback=self.parse
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except:
            self.logger.error("JSON Error")
            return

        products = data.get("products", [])
        self.logger.info(f"Found {len(products)} products on page {self.page}")

        for p in products:
            item = couponsDealsItem()
            item["Title"] = p.get("name") or p.get("ec_name", "")
            item["SourceUrl"] = p.get("clickUri", "")
            item["Image"] = p.get("ec_images", [])
            item["currentprice"] = p.get("ec_promo_price")
            item["originalprice"] = p.get("ec_price")
            item["Framework"] = '3'
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"

            yield item

        # -------------------------
        # PAGINATION
        # -------------------------
        if len(products) > 0:
            self.page += 1
            next_payload = {
                "q": "*",
                "page": self.page,
                "pageSize": 50
            }
            url = "https://caleresproduction4uzryqju.org.coveo.com/rest/organizations/caleresproduction4uzryqju/commerce/v2/search"
            yield scrapy.Request(
                url=url,
                method="POST",
                headers=response.request.headers,
                body=json.dumps(next_payload),
                callback=self.parse
            )
