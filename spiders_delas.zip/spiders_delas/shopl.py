from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class shoplcSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'shoplc'
    start_urls = ['https://www.shoplc.com/c/new-markdowns?start=0&sz=60']
    Sitename = 'ShopLC'
    siteurl = 'https://www.shoplc.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # Updated XPaths from provided list
        divxpath = '//div[@class="col-12 col-md-9 col-xl-10"]//div[@class="col-6 col-lg-4 col-xl-3 product-tile-wrapper"]'
        titalxpath = './/div[@class="pdp-link product-name"]/a/text()'
        imagexpath = './/div[@class="image-container"]//img/@src'
        pricexpath = './/span[contains(@class, "value")]/@content'
        price2xpath = './/div[@class="estimated-price"]/span[@class="list strike-through"]/text()'
        otherxpath = ''  # Agar aur koi attribute scrape karna ho to yahan daal sakte hain
        nextpage = '(//ul[@class="pagination"]//a[@rel="next"]/@href)[1]'



        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
