from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class opentipdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'opentipdealdeal'
    start_urls = ['https://www.opentip.com/buy/deals.html']
    Sitename = 'Opentipdeal'
    siteurl = 'https://www.opentip.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="prodcuts_items"]'
        titalxpath = './/h4[@class="title"]/a/text()'
        imagexpath = './/div[@class="products_image"]/a/img/@src'
        pricexpath = './/span[@aria-label="product msrp"]/text()'
        price2xpath = './/span[@aria-label="product price"]/text()  |  //span[@class="products_low_price notranslate"]/text()'
        otherxpath = ''
        nextpage = '//a[@class="pagnNext"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })