from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class quaydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'quaydeal'
    start_urls = ['https://www.quay.com/collections/sale?q=clearance']
    Sitename = 'quaydeal'
    siteurl = 'https://www.quay.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-grid-item"]'
        titalxpath = './/div[@class="product-info"]/a/p[@class="name_wrapper"]/text()[1]'
        imagexpath = './/img[@class="product-hover-image Sunglasses"]/@src'
        pricexpath = './/div[@class="product-info"]//span[@class="current-price money"]/text()'
        price2xpath = './/div[@class="product-info"]//span[@class="compare-at money"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })