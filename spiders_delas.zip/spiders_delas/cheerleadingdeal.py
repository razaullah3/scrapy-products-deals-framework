from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class cheerleadingdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'cheerleadingdeal'
    start_urls = ['https://www.cheerleading.com/on-sale']
    Sitename = 'Cheerleading'
    siteurl = 'https://www.cheerleading.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '//div[@class="apptrian-subcategories-category-image"]/a/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-item-info"]'
        titalxpath = './/a[@class="product-item-link"]/text()'
        imagexpath = './/img[@class="product-image-photo"]/@src'
        pricexpath = './/span[@data-price-type="oldPrice"]/span/text()'
        price2xpath = './/span[@data-price-type="finalPrice"]/span/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })