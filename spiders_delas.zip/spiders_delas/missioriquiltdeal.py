import scrapy
import json
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class MissouriquiltdealSpider(GetDealsProducts):
    name = 'missouriquiltdeal'
    handle_httpstatus_list = [404]
    Sitename = 'Missouri Quilt Company'
    siteurl = 'https://www.missouriquiltco.com'

    api_url = "https://e2uh153hu0-3.algolianet.com/1/indexes/*/queries"  # POST endpoint
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://www.missouriquiltco.com",
        "Referer": "https://www.missouriquiltco.com/",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "Content-Type": "application/json",
        "x-algolia-agent": "Algolia for JavaScript (4.20.0); Browser (lite); instantsearch.js (4.78.1); Shopify Integration; Shopify App Blocks; JS Helper (3.24.3)",
        "x-algolia-api-key": "7ba26e541fed1ce2087e84d65d0bcaa0",
        "x-algolia-application-id": "E2UH153HU0"
    }

    def start_requests(self):
        page = 0
        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.headers,
            body=self.build_payload(page),
            meta={"page": page},
            callback=self.parse
        )

    def build_payload(self, page):
        """Build POST payload for pagination"""
        query_params = (
            f"clickAnalytics=true&distinct=true&facetingAfterDistinct=true&"
            f"facets=%5B%22named_tags.Brand%22%2C%22named_tags.Collection%22%2C%22named_tags.Color%22%2C"
            f"%22named_tags.Designer%22%2C%22named_tags.Finish%22%2C%22named_tags.Material%22%2C"
            f"%22named_tags.Product%20Type%22%2C%22named_tags.Shop%20By%22%2C%22named_tags.Size%22%2C"
            f"%22named_tags.Skill%20Level%22%2C%22named_tags.Theme%22%2C%22named_tags.Width%22%2C"
            f"%22named_tags.bulk_discount_1%22%2C%22options.style%22%2C%22price%22%5D&"
            f"highlightPostTag=__%2Fais-highlight__&highlightPreTag=__ais-highlight__&"
            f"hitsPerPage=42&maxValuesPerFacet=30&page={page}&query=deal&userToken=anonymous"
        )
        return json.dumps({"requests": [{"indexName": "shopify_prod_products", "params": query_params}]})

    def parse(self, response):
        try:
            data = json.loads(response.text)
            hits = data["results"][0].get("hits", [])
        except Exception as e:
            self.logger.error(f"Error parsing JSON: {e}")
            return

        self.logger.info(f"Page {response.meta['page']}: {len(hits)} products found")

        for product in hits:
            item = couponsDealsItem()
            item['Title'] = product.get('title', '').strip()
            item['Price'] = f"${product.get('price', '')}" if product.get('price') else ''
            item['SalePrice'] = f"${product.get('compare_at_price', '')}" if product.get('compare_at_price') else ''
            item['Image'] = product.get('product_image', '')
            item['SourceUrl'] = f"{self.siteurl}/products/{product.get('handle', '')}"
            item['Offer'] = ''
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination handling
        page = response.meta["page"] + 1
        if len(hits) > 0:  # keep paginating until no more products
            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.headers,
                body=self.build_payload(page),
                meta={"page": page},
                callback=self.parse
            )
