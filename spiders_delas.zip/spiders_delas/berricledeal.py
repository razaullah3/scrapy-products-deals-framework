from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
from scrapy import Request

class berricledealSpider(GetDealsProducts):
    handle_httpstatus_list = [404,403]
    name = 'berricledeal'
    start_urls = ['https://www.berricle.com/collections/sales-jewelry']
    Sitename = 'BERRICLE'
    siteurl = 'https://www.berricle.com'

    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0",
    ]

    def start_requests(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Referer": "https://www.bowlingball.com/",
            "Connection": "keep-alive",
        }

        for url in self.start_urls:
            yield Request(url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="grid__item"]'
        titalxpath = './/div[@class="card-information__text h4"]/text()'
        imagexpath = './/div[contains(@class,"card--image-animate")]/picture[1]/img/@src'
        pricexpath = './/del[@class="price-item price-item--regular"]/text()'
        price2xpath = './/span[@class="price-item price-item--sale"]/text()'
        otherxpath = ''
        nextpage = '//link[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        },headers=self.headers, dont_filter=True)