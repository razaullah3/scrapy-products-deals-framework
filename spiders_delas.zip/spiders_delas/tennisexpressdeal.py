from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class tennisExpressSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'tennisexpress'
    start_urls = ['https://tennisexpress.com/collections/deals-of-the-day']
    Sitename = 'tennisexpress'
    siteurl = 'https://tennisexpress.com'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Connection": "keep-alive",
        "Cookie": "localization=US; cart_currency=USD; ede-i=18232487-11ee-457b-b398-ae2767fb0e69; ede-expid=a5bcbbf1-75b5-4f30-93c1-585febd86712; ede-expvar=Edge Delivery Enabled; _shopify_y=1f1d19e1-e737-41dd-af37-0868a8677d86; _shopify_essential=:AZrEzGw1AAEAaaNZO8JzdOOUc8HjssZ-IPt8xiHz_rbO1vlRAyQzT-_to1BL9kAghE4JMYSH2sIXgMBMTgIe93S4Z6GkJo3rhHPNUkjlcwDlNeEo9pvolY-lnSDKxr0h18xgf9cNWWCLO4VP3Ho4p_RoNcRARIEiHGgGcpA9-QCAGJss-o9cBD0FuCqYtob7SL1eSaYbkMpP6P44S4kswp9bSa_du2qYiI_XAC_K1fLQcS5ynMDBY8OkJHzTcEulA5cSvtT0BtOikjN8_D3sVurh-JwqcJlHbCUhMe7XRgz3imS0FIhEhc1V4cF2zDlr3mVxz7kk8l_2oPttYxoFPyU9u0h5JlRfWEQvRrQVKOBfp6OQI8i0GsinT6Csua2XsRYpvGMf282yM3d2gNk6Rlk:; ... (truncated for brevity) ...",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "Priority": "u=0, i",
        "TE": "trailers",
        "DNT": "1",
    }

    custom_settings = {
        "DEFAULT_REQUEST_HEADERS": headers
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[contains(@class,"column")]'
        titalxpath = './/div[@class="product-card-info"]/a/text()'
        imagexpath = './/figure[contains(@class,"product-featured")]//img[contains(@class,"product-secondary")]/@src'
        pricexpath = './/span[@class="price"]//span[@class="amount discounted"]/text()'
        price2xpath = './/span[@class="price"]/del/span/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
