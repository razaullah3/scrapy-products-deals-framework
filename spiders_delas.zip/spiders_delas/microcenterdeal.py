from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy
import random

class microcenterdealSpider(GetDealsProducts):
    handle_httpstatus_list = [403, 404]
    name = 'microcenterdeal'
    Sitename = 'Micro Center'
    siteurl = 'https://www.microcenter.com'
    base_url = 'https://www.microcenter.com/search/search_results.aspx?fq=Micro+Center+Deals:Top+Deals&page={}'

    # Multiple User-Agents for rotation
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko/20100101 Firefox/118.0",
        "Mozilla/5.0 (Windows NT 10.0; rv:120.0) Gecko/20100101 Firefox/120.0",
    ]

    def start_requests(self):
        # Start from page 1 to 2 (you can increase the range)
        for page in range(1, 3):
            url = self.base_url.format(page)
            headers = {
                "User-Agent": random.choice(self.USER_AGENTS),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Accept-Encoding": "gzip, deflate, br, zstd",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                "Priority": "u=0, i",
            }
            yield scrapy.Request(
                url=url,
                callback=self.parse,
                headers=headers,
                meta={
                    "playwright": True,
                    "playwright_include_page": True,
                    "stealth_mode": True,
                    "download_timeout": 60,
                },
            )

    async def parse(self, response):
        if response.status == 403:
            self.logger.error("403 Forbidden — site may be blocking scrapers.")
            print("\n" + "="*80)
            print("403 RESPONSE SAMPLE (first 500 chars):")
            print(response.text[:500])
            print("="*80 + "\n")
            return

        page = response.meta.get("playwright_page")

        # 🕵️ Apply stealth JS tricks directly in Playwright
        await page.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
            Object.defineProperty(navigator, 'plugins', {get: () => [1,2,3]});
            Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8});
            window.chrome = {runtime: {}};
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications'
                ? Promise.resolve({ state: Notification.permission })
                : originalQuery(parameters)
            );
        """)

        # 🎭 Simulate human behavior
        await page.wait_for_timeout(random.randint(1500, 3500))  # random delay
        await page.mouse.move(random.randint(100, 600), random.randint(100, 400))
        await page.wait_for_timeout(1000)
        await page.close()

        # Create a placeholder item (as your structure requires)
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # Set up data collection parameters
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product_wrapper"]'
        titalxpath = './/div[@class="h2"]/a/text()'
        imagexpath = './/img[@class="SearchResultProductImage"]/@src'
        pricexpath = './/div[@class="standardDiscount"]/strike/text()'
        price2xpath = './/span[@itemprop="price"]/text()'
        otherxpath = ''
        nextpage = ''

        # 🔁 Call Data_Collector with stealth meta data
        yield scrapy.Request(
            url=response.url,
            headers={"User-Agent": random.choice(self.USER_AGENTS)},
            callback=self.Data_Collector,
            meta={
                "playwright": True,
                "stealth_mode": True,
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
            },
            dont_filter=True
        )
