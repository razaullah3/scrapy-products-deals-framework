import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class shopmicasdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'shopmicasdeal'
    Sitename = 'ShopMicas'
    siteurl = 'https://shopmicas.com'

    api_url = "https://server001.recommend-display.bytem.com/cart"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://shopmicas.com/",
        "Content-Type": "application/json",
        "Origin": "https://shopmicas.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "Priority": "u=4"
    }

    def start_requests(self):
        body = {
            "version": "v1",
            "env": "shopmicas",
            "apikey": "1fa79ce72a1f4b38966179f5ab880f59",
            "uid": "a2e6317c-7bc4-4124-a48d-a368b7e82ed1",
            "cart": [""],
            "platform": "pc",
            "size": 20,
            "page": 1
        }

        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.headers,
            body=json.dumps(body),
            callback=self.parse
        )

    def parse(self, response):
        listing_json = json.loads(response.text)

        # ---- Extract products ----
        for req in self.getproducts(response):
            yield req

        # ---- Pagination ----
        total = listing_json.get("total", 0)
        size = listing_json.get("size", 20)

        total_pages = int(total / size) + 1 if total else 1

        # Page 2 se start
        for page in range(2, total_pages + 1):

            body = {
                "version": "v1",
                "env": "shopmicas",
                "apikey": "1fa79ce72a1f4b38966179f5ab880f59",
                "uid": "a2e6317c-7bc4-4124-a48d-a368b7e82ed1",
                "cart": [""],
                "platform": "pc",
                "size": 20,
                "page": page
            }

            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.headers,
                body=json.dumps(body),
                callback=self.getproducts,
                dont_filter=True
            )

    def getproducts(self, response):
        listing_json = json.loads(response.text)

        products = listing_json.get("products", [])

        for p in products:
            item = couponsDealsItem()

            item['Title'] = p.get("title", "")
            item['Image'] = p.get("img", "")
            item['SourceUrl'] = p.get("url", "")

            item['Price'] = p.get("orig_price", "")
            item['SalePrice'] = p.get("price", "")

            item['Offer'] = ""
            item['Framework'] = "3"
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = "True"

            yield item
