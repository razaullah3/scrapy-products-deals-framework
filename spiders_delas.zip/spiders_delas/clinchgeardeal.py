from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class clinchgeardealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'clinchgeardeal'
    start_urls = ['https://clinchgear.com/collections/clearance-locker']
    Sitename = 'Clinch Gear'
    siteurl = 'https://clinchgear.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="box product"]'
        titalxpath = './/a[@class="product-title"]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="original-price money"]/text()'
        price2xpath = './/span[@class="money"]/text()'
        otherxpath = ''
        nextpage = '//a[@title="layout.pagination.next_html"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })