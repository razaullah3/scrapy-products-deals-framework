from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class iherbdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'iherbdeal'
    start_urls = ['https://www.iherb.com/specials']
    Sitename = 'I Herb'
    siteurl = 'https://www.iherb.com'

    # ✅ Custom headers for all requests
    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'DNT': '1',
            'Sec-GPC': '1',
            'Priority': 'u=0, i',
        }
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-inner product-inner-wide"]'
        titalxpath = './/div[@class="absolute-link-wrapper"]/a/@aria-label'
        imagexpath = './/span[@class="product-image"]/img/@src'
        pricexpath = './/span[@class="price-olp"]/bdi/text()'
        price2xpath = './/span[@class="price discount-red"]/bdi/text()'
        otherxpath = './/span[@class="percentage-off"]/bdi/text()'
        nextpage = '//a[@class="pagination-next"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
            },
        )
