
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


# Pagination issue


class thermowebonlinedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'thermowebonlinedeal'
    start_urls = ['https://www.thermoweb.com/collections/sale-items']
    Sitename = 'thermowebonline'
    siteurl = 'https://www.thermowebonline.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[contains(@class,"product-listing")]/div'
        titalxpath = './/h2/a/text()'
        imagexpath = './/img[contains(@class, "lazyloaded") and @data-expand="-20"]/@src'
        pricexpath = './/div[@class="tt-price"]/span[@class="new-price"]/text()'
        price2xpath = './/div[@class="tt-price"]/span[@class="old-price"]/text()'
        otherxpath = './/span[@class="tt-label-sale"]/span[@class="thumb_percent"]/text()'
        nextpage = ''  # '//a[text()="Next »"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })