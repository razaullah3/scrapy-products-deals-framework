from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class revzilladealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'revzilla'
    start_urls = ['https://www.revzilla.com/search?query=deals']
    Sitename = 'Revzilla'
    siteurl = 'https://www.revzilla.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@data-qa="product-tile"]'
        titalxpath = './/div[@class="product-tile__name"]/text()'
        imagexpath = './/img[@class="product-tile__image"]/@src'
        pricexpath = './/span[@data-js="Money.parsedMoney"]/text()'
        price2xpath = './/span[@class="mny"]/text()'
        otherxpath = './/span[@class="blurb"]/text()'
        nextpage = '(//a[@aria-label="Next page"])[1]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })