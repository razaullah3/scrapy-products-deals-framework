from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bluebananadealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bluebananadeal'
    start_urls = ['https://www.bluebanana.com/en/section/900/1/sale']
    Sitename = 'Blue Banana'
    siteurl = 'https://www.bluebanana.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="productsGrid-product"]'
        titalxpath = './/div[@class="productBox-name"]/text()'
        imagexpath = './/img[@class="ui bordered image lazyload"]/@src[1]'
        pricexpath = './/span[@class="was-price"]/text()'
        price2xpath = './/div[@class="productBox-price"]/text()[1]'
        otherxpath = ''
        nextpage = '//span[@class="pageNav pageNext"]/parent::a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })