from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class opticaldealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'opticaldealdeal'
    start_urls = ['https://www.opticsplanet.com/blazin-deal.html']
    Sitename = 'Opticaldeal'
    siteurl = 'https://www.opticsplanet.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[contains(@class, "grid gtmProduct two-block-tall product e-grid-item_grid product")]'
        titalxpath = './/a/@title'
        imagexpath = './/picture[@class="grid__image_default"]/source/@srcset'
        pricexpath = './/span[@class="grid__uom-list-price grid__item-details_line-through"]/text()'
        price2xpath = './/span[@class="variant-price-dollars"]/text()'
        otherxpath = './/span[@class="grid__uom-save-text"]/text()'
        nextpage = '//link[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })