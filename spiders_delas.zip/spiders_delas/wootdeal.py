
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class wootdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'woot'
    start_urls = ['https://www.woot.com/alldeals?ref=w_ngh_et_1']
    Sitename = 'woot'
    siteurl = 'https://www.woot.com/'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div//a[@data-test-ui="offerItem"]'
        titalxpath = '//div[contains(@data-test-ui,"offerItemTitle")]/text()'
        imagexpath = './/img/@src'
        pricexpath = '//div//span[contains(@class,"r-142tt33")]/text()'

        price2xpath = '//div[contains(@class,"r-17rnw9f")]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })