import scrapy
import json
import datetime
from ..items import couponsDealsItem

class TargetPLPSpider(scrapy.Spider):
    name = 'target'
    allowed_domains = ['redsky.target.com', 'target.com']

    # Hardcoded category id
    category_id = "oejgl"

    # Starting page offset
    start_offset = 0
    count_per_page = 24  # API returns 24 items per page

    custom_headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
    "Accept": "application/json",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Referer": "https://www.target.com/c/halloween-deals/-/N-oejgl",
    "Origin": "https://www.target.com",
    "Connection": "keep-alive",
    "Cookie": "refreshToken=guBxsILnYa5SJ5NozTfz1dJTc2C4CN8E_Rtzz7IdM4W1xKaVpiDRFdDRCTzU8qW2Rw681Y3VJKz6YcdR7sxzUA; "
              "idToken=eyJhbGciOiJub25lIn0.eyJzdWIiOiI0OGJlZGJhNi05MzFmLTRjOTMtYTA5MC02YjA5ZTg3YTI5M2MiLCJpc3MiOiJNSTYiLCJleHAiOjE3NjA2ODIyMDcsImlhdCI6MTc2MDU5NTgwNywiYXNzIjoiTCIsInN1dCI6IkciLCJjbGkiOiJlY29tLXdlYi0xLjAuMCIsInBybyI6eyJmbiI6bnVsbCwiZm51IjpudWxsLCJlbSI6bnVsbCwicGgiOmZhbHNlLCJsZWQiOm51bGwsImx0eSI6ZmFsc2UsInN0IjoiVFgiLCJzbiI6bnVsbH19.; "
              "visitorId=0199EBB00D4C020183E200EB8937B772; TealeafAkaSid=VqWJTJfCuJ13NqQjDb_rlmYjkqCI1c0W; "
              "sddStore=DSI_993|DSN_Copperfield|DSZ_77084|server; fiatsCookie=DSI_993|DSN_Copperfield|DSZ_77084; "
              "sapphire=1; adScriptData=TX; accessToken=eyJraWQiOiJlYXMyIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI0OGJlZGJhNi05MzFmLTRjOTMtYTA5MC02YjA5ZTg3YTI5M2MiLCJpc3MiOiJNSTYiLCJleHAiOjE3NjA2ODIyMDcsImlhdCI6MTc2MDU5NTgwNywianRpIjoiVEdULjc1YjIxMjFiNWNiMzQ4NzM4YmM4NDY4NTNkNThlZDA1LWwiLCJza3kiOiJlYXMyIiwic3V0IjoiRyIsImRpZCI6ImJhYzNlN2U2NGQxNTk0M2Y3MjAzNTk3MzQ5MzBjZjZiYzM2NWQ4YzIxMDA4NWMxZGNiNGM4NjA0NzNmNjA0NDQiLCJzY28iOiJlY29tLm5vbmUsb3BlbmlkIiwiY2xpIjoiZWNvbS13ZWItMS4wLjAiLCJhc2wiOiJMIn0.H_vS8ehr_wZNlUYy7u29tvS7cFWI2VNgFhE3p9r2O2JJ5tEfpPRaavaGQK3K9Lek0d39JZyecIAbTe-_wrwh61WpJMQ8cXlUyU7koIY2HxnZGrcu6zmW35aT84DyYhrSjGc46pklMDT9gKAJeLo7u5kVuc_ZmF5-hYSBCRSDrwX6M3XxtJoDROOd7l2djSy-kIso-wyFBrNZ7x8jomKGjmsaCYP3hyRwhLUnofzeym09AAHWEiHNA7UzqpHCtvqMRnuouq5kZrNkjgvDegLPLQrfmiDkpJckeMWE0S2Mid6mMsZQRV3jMH_t1XCS-RmgyMcmNnMJDMiLzKuhwbSHVA; "
              "egsSessionId=903c0dbd-67db-40f6-a3b6-7fe6115f2545; UserLocation=77084|29.820|-95.640|TX|US; "
              "ffsession={%22sessionHash%22:%221670a38ef980861760595814551%22}; usprivacy=1YY-; stateprivacycontrols=Y",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=4",
    "TE": "trailers"
}


    def start_requests(self):
        url = self.get_api_url(offset=self.start_offset)
        yield scrapy.Request(
            url=url,
            method="GET",
            headers=self.custom_headers,
            callback=self.parse
        )

    def get_api_url(self, offset):
        """Build API URL with pagination"""
        return (
            f"https://redsky.target.com/redsky_aggregations/v1/web/plp_search_v2?"
            f"key=9f36aeafbe60771e321a7cc95a78140772ab3e96"
            f"&category={self.category_id}"
            f"&channel=WEB&count={self.count_per_page}"
            f"&default_purchasability_filter=true"
            f"&include_dmc_dmr=true&include_sponsored=true"
            f"&include_review_summarization=true"
            f"&new_search=false&offset={offset}"
            f"&page=%2Fc%2F{self.category_id}&platform=desktop"
            f"&pricing_store_id=993&scheduled_delivery_store_id=993"
            f"&spellcheck=true&store_ids=993%2C907%2C2882%2C2419%2C2144"
            f"&useragent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A143.0%29+Gecko%2F20100101+Firefox%2F143.0"
            f"&visitor_id=0199EBB00D4C020183E200EB8937B772&zip=77084"
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
            products = data.get("data", {}).get("search", {}).get("products", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        if not products:
            self.logger.warning("No products found on this page.")
            return

        for product in products:
            item = couponsDealsItem()

            # Buy URL
            item['SourceUrl'] = product.get("item", {}).get("enrichment", {}).get("buy_url", "")

            # Images (primary + alternates, comma separated)
            images = []
            image_info = product.get("item", {}).get("enrichment", {}).get("images", {})
            primary = image_info.get("primary_image_url")
            if primary:
                images.append(primary)
            images += image_info.get("alternate_image_urls", [])
            item['Image'] = ",".join(images)

            # Title
            item['Title'] = product.get("item", {}).get("product_description", {}).get("title", "")

            # Prices (if available)
            price_info = product.get("parent", {}).get("price", {})
            item['Price'] = price_info.get("formatted_comparison_price", "")
            item['SalePrice'] = price_info.get("formatted_current_price", "")

            # Other metadata
            item['SiteName'] = "Target"
            item['SiteURL'] = "https://www.target.com"
            item['Framework'] = "3"
            item['Offer'] = ""
            item['dealpage'] = "True"
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()

            yield item

        # --- Pagination ---
        metadata = data.get("data", {}).get("search", {}).get("search_response", {}).get("metadata", {})
        total_results = metadata.get("total_results", 0)
        current_offset = metadata.get("offset", 0)

        next_offset = current_offset + self.count_per_page
        if next_offset < total_results:
            next_page_url = self.get_api_url(offset=next_offset)
            yield scrapy.Request(
                url=next_page_url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse
            )
