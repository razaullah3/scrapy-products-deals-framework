import scrapy
import json
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class HydroflaskdealSpider(GetDealsProducts):
    name = 'hydroflaskdeal'
    handle_httpstatus_list = [404]
    Sitename = 'Hydro Flask'
    siteurl = 'https://www.hydroflask.com'

    api_url = "https://mvfvxhvmmt-1.algolianet.com/1/indexes/*/queries"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://www.hydroflask.com/",
        "x-algolia-api-key": "OTE2MzA4ZDZlZTJjZjJjN2IzZjVmYWY0ZjA0YWQ0NTQ1MGVlMTVlN2E5Y2U0MTNhNWJkMGQ5NTM0NzRhNWY5Y2ZpbHRlcnM9Y2F0YWxvZ19wZXJtaXNzaW9ucy5jdXN0b21lcl9ncm91cF8wJTIwJTIxJTNEJTIwMCZ0YWdGaWx0ZXJzPQ==",
        "x-algolia-application-id": "MVFVXHVMMT",
        "Origin": "https://www.hydroflask.com",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    def start_requests(self):
        page = 0
        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.headers,
            body=self.build_payload(page),
            meta={"page": page},
            callback=self.parse
        )

    def build_payload(self, page):
        """
        Build POST request payload for Algolia API pagination.
        The query 'deal' filters products related to deals/sales.
        """
        query_params = (
            f"clickAnalytics=true&facets=%5B%22category_type%22%2C%22hf_config_search_color%22%2C"
            f"%22hf_search_color%22%2C%22liters%22%2C%22mouth%22%2C%22price.USD.group_0%22%2C"
            f"%22spectrum_bottle_size%22%2C%22spectrum_lid_type%22%5D&highlightPostTag=__%2Fais-highlight__&"
            f"highlightPreTag=__ais-highlight__&hitsPerPage=48&maxValuesPerFacet=10&"
            f"numericFilters=%5B%22visibility_search%3D1%22%2C%22status%3D1%22%5D&page={page}&query=deal&"
            f"ruleContexts=%5B%22magento_filters%22%5D&tagFilters=&userToken=anonymous"
        )
        article_params = (
            f"clickAnalytics=true&facets=%5B%22author%22%2C%22category_type%22%2C%22hf_config_search_color%22%2C"
            f"%22hf_search_color%22%2C%22liters%22%2C%22mouth%22%2C%22post_type%22%2C%22price.USD.group_0%22%2C"
            f"%22spectrum_bottle_size%22%2C%22spectrum_lid_type%22%2C%22tags%22%5D&highlightPostTag=__%2Fais-highlight__&"
            f"highlightPreTag=__ais-highlight__&hitsPerPage=48&maxValuesPerFacet=10&"
            f"numericFilters=%5B%22visibility_search%3D1%22%2C%22status%3D1%22%5D&page=0&query=deal&"
            f"ruleContexts=%5B%22magento_filters%22%2C%22algolia_articles%22%5D&tagFilters=&userToken=anonymous"
        )

        return json.dumps({
            "requests": [
                {"indexName": "magento2_prod_hfhydroflask_products", "params": query_params},
                {"indexName": "magento2_prod_hfhydroflask_articles", "params": article_params}
            ]
        })

    def parse(self, response):
        try:
            data = json.loads(response.text)
            results = data.get("results", [])
            if not results:
                return

            hits = results[0].get("hits", [])
        except Exception as e:
            self.logger.error(f"Error parsing JSON: {e}")
            return

        page = response.meta["page"]
        self.logger.info(f"Page {page}: {len(hits)} products found")

        for product in hits:
            item = couponsDealsItem()
            item['Title'] = product.get('name', '').strip()
            item['Price'] = product.get('price', {}).get('USD', {}).get('default_formated', '')
            item['SalePrice'] = product.get('price', {}).get('USD', {}).get('group_0_formated', '')
            item['Image'] = product.get('thumbnail_url', '')
            item['SourceUrl'] = product.get('url', '')
            item['Offer'] = ''
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # --- Pagination ---
        if hits:
            next_page = page + 1
            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.headers,
                body=self.build_payload(next_page),
                meta={"page": next_page},
                callback=self.parse
            )
