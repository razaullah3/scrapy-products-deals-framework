import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class poshpeanutdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'poshpeanut'
    Sitename = 'Posh Peanut'
    siteurl = 'https://poshpeanut.com'

    page = 1   # Start from page=1

    def start_requests(self):
        url = (
            "https://1nbvpn.a.searchspring.io/api/search/search.json?"
            "resultsPerPage=36&bgfilter.ss_visible=1&page=1&bgfilter.ss_prelaunch=0&"
            "bgfilter.collection_handle=clearance&bgfilter.ss_country_us=0&"
            "bgfilter.ss_country_us_ca=0&siteId=1nbvpn&resultsFormat=json&userId=&"
            "sessionId=&pageLoadId=e6027473-4eaf-41ee-a927-2665cd1f16e1&"
            "domain=https%3A%2F%2Fposhpeanut.com%2Fen-pk%2Fcollections%2Fclearance%3Fpage%3D1"
        )

        yield scrapy.Request(
            url=url,
            callback=self.parse,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept-Encoding": "gzip, deflate, br, zstd",
                "Referer": "https://poshpeanut.com/",
                "Origin": "https://poshpeanut.com",
                "Connection": "keep-alive",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "cross-site",
                "Priority": "u=4",
                "TE": "trailers",
            }
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except:
            self.logger.error("JSON Error")
            return

        results = data.get("results", [])
        self.logger.info(f"Found {len(results)} products on page {self.page}")

        for m in results:
            item = couponsDealsItem()

            item["Title"] = m.get("name", "")
            item["Image"] = m.get("imageUrl", "")
            item["Price"] = m.get("price", "")
            item["SalePrice"] = m.get("msrp", "")
            item["Offer"] = ""

            item["SourceUrl"] = "https://poshpeanut.com/products/" + m.get("handle", "")

            item["Framework"] = '3'
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"

            yield item

        # ---------------------------------------------
        # PAGINATION (Loop pages until results end)
        # ---------------------------------------------

        if len(results) > 0:
            self.page += 1

            next_url = (
                f"https://1nbvpn.a.searchspring.io/api/search/search.json?"
                f"resultsPerPage=36&bgfilter.ss_visible=1&page={self.page}"
                "&bgfilter.ss_prelaunch=0&bgfilter.collection_handle=clearance"
                "&bgfilter.ss_country_us=0&bgfilter.ss_country_us_ca=0"
                "&siteId=1nbvpn&resultsFormat=json&userId=&sessionId="
                "&pageLoadId=e6027473-4eaf-41ee-a927-2665cd1f16e1"
                "&domain=https%3A%2F%2Fposhpeanut.com%2Fen-pk%2Fcollections%2Fclearance"
            )

            yield scrapy.Request(
                url=next_url,
                callback=self.parse,
                headers=response.request.headers
            )
