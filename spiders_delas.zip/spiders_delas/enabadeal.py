import scrapy
import json
import datetime
from ..items import couponsDealsItem
import requests

class EnebaDealSpider(scrapy.Spider):
    name = "eneba_deal"

    API_URL = "https://ihjzq5lw2r-dsn.algolia.net/1/indexes/*/queries?x-algolia-agent=Algolia%20for%20JavaScript%20(5.41.0)%3B%20Search%20(5.41.0)%3B%20Browser&x-algolia-api-key=53864095e814940ffed0f69a897331f1&x-algolia-application-id=IHJZQ5LW2R"

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.eneba.com/",
        "Content-Type": "text/plain",
        "Origin": "https://www.eneba.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1"
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.API_URL,
            method="POST",
            headers=self.HEADERS,
            body=json.dumps(self.build_payload(0)),
            callback=self.parse,
            meta={"page": 0}
        )

    def build_payload(self, page):
        return {
            "requests": [
                {
                    "indexName": "products_us",
                    "query": "deal",
                    "page": page,
                    "hitsPerPage": 20,
                    "responseFields": ["hits", "nbHits", "length"],
                    "attributesToRetrieve": [
                        "slug","translations.en_US","images.cover300.src",
                        "lowestPrice.USD","msrp.USD"
                    ],
                    "facets": ["productRegions"],
                    "clickAnalytics": True,
                    "userToken": "237043752338871758276776712888751",
                    "optionalFilters": [
                        "productRegions:global","productRegions:row",
                        "productRegions:north_america","productRegions:united_states"
                    ]
                }
            ]
        }

    def parse(self, response):
        page = response.meta.get("page", 0)
        try:
            data = json.loads(response.text)
            hits = data["results"][0]["hits"]
            nbHits = data["results"][0]["nbHits"]
        except Exception as e:
            self.logger.error(f"Failed to parse JSON on page {page}: {e}")
            return

        if not hits:
            self.logger.info(f"No products found on page {page}")
            return

        for hit in hits:
            yield self.extract_product_item(hit)

        # Pagination
        next_page = page + 1
        if next_page * 20 < nbHits:
            yield scrapy.Request(
                url=self.API_URL,
                method="POST",
                headers=self.HEADERS,
                body=json.dumps(self.build_payload(next_page)),
                callback=self.parse,
                meta={"page": next_page}
            )

    def extract_product_item(self, hit):
        item = couponsDealsItem()

        # Title
        item["Title"] = hit.get("translations", {}).get("en_US", {}).get("name")

        # Image
        item["Image"] = hit.get("images", {}).get("cover300", {}).get("src")

        # Prices
        item["SalePrice"] = self.format_price(hit.get("lowestPrice", {}).get("USD"))
        msrp = hit.get("msrp", {}).get("USD")
        item["Price"] = self.format_price(msrp) if msrp else ""

        # Source URL
        item["SourceUrl"] = f"https://www.eneba.com/{hit.get('slug')}"

        # Static metadata
        item["SiteName"] = "Eneba"
        item["SiteURL"] = "https://www.eneba.com"
        item["Framework"] = "3"
        item["Offer"] = ""
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item

    def format_price(self, price):
        if price is None:
            return None
        return f"{price/100:.2f}"  # converts 1999 -> 19.99
