from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class abtdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'abtdeal'
    start_urls = ['https://www.abt.com/Special-Deals/c/2892.html'
                  'https://www.abt.com/Special-Deals/c/2892.html?order_by_post=relevance%2Cdesc&start_index=20&per_page=20'
                  'https://www.abt.com/Special-Deals/c/2892.html?order_by_post=relevance%2Cdesc&start_index=40&per_page=20'
                  'https://www.abt.com/Special-Deals/c/2892.html?order_by_post=relevance%2Cdesc&start_index=60&per_page=20'
                  ]
    Sitename = 'ABT Deals'
    siteurl = 'https://www.abt.com'


    headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
    "Cookie": "abtVisit=ad33f3f58afbafd0fd298aa95a955733; category_order=selling; estimation_zipcode=60602; __cf_bm=F8B8d2rxdGo1R1c5_m7doYHH._BU9f4VVCOwI317FXY-1764057756-1.0.1.1-gVW5gBbKRowKQQ61aHcIYYjG1l9WlGZDyoeHiGmRwAd2vTdisaDzu8iLUFNoytFMsi_tSyUdbHazTH4IYFlnLdyAu6FetRNeKMuyxC5bTx324xuMygO5bUem18.R.FD8; _pcc=2; _aa=ABT1.ab151887e8a836925629cba952; _aalts=direct; cf_clearance=4IfJfn7dhucTTI1251zuf2FgmOflAOiPB_ymusmJLDk-1764057757-1.2.1.1-VMu2A1Kx7vFmZ7OZhFN382B0VdU76E.ZMRDerm.G6o46YCSgkVuxv51SJyv89Ayfc9tov57IGY5ohNJuatvteM0uwPMi8nalsRAWOfVAKVFP3KYf2Q7iMppAqRap0oj8M8GqPFOVlRq8za1DCb9MJTl7q.e1xOeh3JX7NMAd6XSBhP6XyairZQHL50Gy7SDv_B_SUPSsZ9NF34KQi1z7MZmJ_Z0koUdxMj2SOZnM8HQ; _gcl_au=1.1.1775093979.1764057758; _ga_3LHC55WV8L=GS2.1.s1764057757^$o1^$g1^$t1764058336^$j60^$l0^$h0; _ga=GA1.1.1710386236.1764057758; _br_uid_2=uid%3D2071152817693%3Av%3D16.1%3Ats%3D1764057758701%3Ahc%3D2; _rv=228698; BVBRANDID=86501c22-3b22-4b03-a097-bdcdf9e642d2; BVBRANDSID=59ff4212-5019-4c41-8f03-2d851dbd123e; checkout_continuity_service=fa83569f-371c-4733-b111-36e218171d0f; _ni=1; _nicc=1",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=0, i"
}


    # ✔ GLOBAL HEADERS FIX — all requests will now use headers (including first)
    custom_settings = {
        "DEFAULT_REQUEST_HEADERS": headers
    }


    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="category_list_container "]'
        titalxpath = './/div[@class="cl_title"]/a/text()'
        imagexpath = './/img[@class="category_second_image"]/@src'
        pricexpath = './/div[@class="pricing-regular-price"]/text()'
        price2xpath = './/div[@class="pricing-item-price pricing-sale-price"]/text()'
        otherxpath = './/span[@class="discount"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })