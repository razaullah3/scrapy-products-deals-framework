from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class thenorthfaceSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'thenorthface'
    start_urls = ['https://www.thenorthface.com/en-us/c/sale-829803']
    Sitename = 'thenorthface'
    siteurl = 'https://www.thenorthface.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # No category or attribute pages
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ---------------------------
        # 🔥 UPDATED XPATHS 🔥
        # ---------------------------
        divxpath = '//div[contains(@class,"grid md:grid lg:grid |grid-cols-$grid")]//div[@data-test-id="product-card"]'
        titalxpath = './/a[@data-test-id="product-card-title"]//text()[normalize-space()]'
        imagexpath = './/div[@data-test-id="product-card"]//img/@src'
        pricexpath = './/div[@data-test-id="product-card-pricing"]//ins[@class="c-red-30"]/span[@class="ws-nowrap"]/text()'
        price2xpath = ".//span[contains(@class,'gap-x-2')]//del[contains(@class,'c-grey-20')]/text()[1]"
        otherxpath = ''   # No other provided
        nextpage = '//a[@id="viewMoreCTA"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
