from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class beveragefactorydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'beveragefactorydeal'
    start_urls = ['https://www.beveragefactory.com/clearanceoutlet/index.shtml']
    Sitename = 'BeverageFactory'
    siteurl = 'https://www.beveragefactory.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '//div[@class="holder d-flex align-items-center flex-column flex-grow-1"]/a/@href'
        subcategorypage = '//div[@class="holder d-flex align-items-center flex-column flex-grow-1"]/a/@href'
        attribute = ''
        divxpath = '//div[@class="row pt-2"]/div'
        titalxpath = './/a[@class="description-link text-decoration-none"]/span/text()'
        imagexpath = './/a/img/@src'
        pricexpath = ''
        price2xpath = './/h3/text()'
        otherxpath = ''
        nextpage = '//a[contains(text(),"Next")]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })