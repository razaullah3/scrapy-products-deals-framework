from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class wholelattelovedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'wholelattelovedeal'
    start_urls = ['https://www.wholelattelove.com/pages/sale']
    Sitename = 'Whole Latte Love'
    siteurl = 'https://www.wholelattelove.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '(//div[@class="card__link"]/a[contains(text(),"SHOP NOW")] | //div[@class="multicolumn-card__info"]/a[1])/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="grid__item"]'
        titalxpath = './/h2[@class="card__heading h5"]/a/text()'
        imagexpath = './/div[@class="card__media"]/a/div/img[1]/@srcset'
        pricexpath = './/span[@class="price-item price-item--regular"]/text()'
        price2xpath = './/span[@class="price-item price-item--sale price-item--last"]/text()'
        otherxpath = ''
        nextpage = '//a[@aria-label="Page Next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })