from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class frostbuddySpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'frostbuddy'
    start_urls = ['https://frostbuddy.com/collections/clearance']
    Sitename = 'frostbuddy'
    siteurl = 'https://frostbuddy.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # No category or attribute pages
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ---------------------------
        # 🔥 YOUR PROVIDED XPATHS 🔥
        # ---------------------------
        divxpath = '//div[contains(@class,"product-list__inner")]/product-item[@class="product-item "]'
        titalxpath = './/div[@class="product-item-meta"]/a/text()[1]'
        imagexpath = './/img[@class="product-item__primary-image"]/@src'
        pricexpath = './/span[@class="price price--highlight"]/text()[2]'
        price2xpath = './/span[@class="price price--compare"]/text()[2]'
        otherxpath = ''   # You didn't provide this, so empty
        nextpage = './/a[@class="pagination__nav-item"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
