from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class fanaticsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'fanaticsdeal'
    start_urls = ['https://www.fanatics.com/?query=deals&_ref=p-SFLP:m-SEARCH']
    Sitename = 'Fanatic Deals'
    siteurl = 'https://www.fanatics.com'

    # --- Add your exact headers here ---
    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Cookie': 'akacd_PR_Iris_permanent=3939001085~rv=24~id=a08541d11f7591133f273caf4a6e8994; bm_ss=ab8e18ef4e; _abck=05BDD6F30E39D8BB2B4C72613040DEB1~-1~YAAQ0yXAF0iXD/qZAQAA9bp1JA4NywJTtfnNv09WUnSDPUOMmUHfRHklGRYC8c1nyTD6xSs48H/4mFxAPWjMl6B1MI5/tkqd9xCnzQ1AJ/oEctd3ExdV4qevpQSJPVIR/7MYYCbrhyB7wKpk9XP//g53eqt+NygLTEeGVw3+gkujVTWxnMOhAIqkPp14F7s7HBLJ9WVzsUqHuKkuZeBB2N+9nZ53s/oZQvTdJQuI9DHbiGilquW6aKZZvJzPKBOZeaEnNPhbVRyLHvVyZYZ6UdEocvf3pevPLnSfy6KYJTIYcWrrTokB831X0A9y9rSx3fEz1d8kIsJ/xxSxkCBSZd4BjBS77AhUBGW93kumrJtakF1jVtfLg642QHE6Hd+awFCbIeIyqWq118nvR8jFhS9Yf7EriogxFV93kGedcY7XQG+cN9zHUafLVZDb95SaTgVLP3dY5zMMrgw1Uh/nWbCDPmZZ6z4=~-1~-1~-1~-1~-1; ak_bmsc=25733A9474010D60A1E69FF995184DBA~000000000000000000000000000000~YAAQ0yXAF0mXD/qZAQAA9bp1JB0+TBdYbznGo4l8vmAIAPh2l0uJgQhcN8N4ORjhCA4uBKvxVgQsLwbRoJR8gUd8zenGEEnDp/+cKen3z51GvgOGgoglPrkWRljcQlomzcthqGI3rX7RF+BAoX8Kd793Rl3XEFhIgg7+y8FAVsuQ/4bSqjWFIBWMLoUWblrZi/N3kCysNnykHk5I7iUoCGOIP9JnxFwyGI3PUG96saF+icDgHdEQKPAdp4TPtBpWYVrJU0Zbp7IrNenw0m3r+SAmyVXIh889lSa9YeW+tliCsufAmjH6pvrD28wRMVJZZ3swYbWjDYoaGJ4KncLG4ygnpj6JYoE71WwNzCna2XRla1ntLNYyRW5E9nROIiPMXies; bm_s=YAAQ0yXAFwyYD/qZAQAADdt1JAQYUTqqH4q7rs4Q2eqQPQHomeiftiP/e/8yP/oVOnGZJ363RodVp/nDoJ/KAxia2iCfoPCqGno8TGGvWRn3iinHhhhVwda/0aYsbKEiwq6ea9vUyG37ibR965qWMGa+W1YDbvvmCg8s38ypT8YFsl9XqgZzV/c/m3cTK0ddyaICHXz/TsA98jn2TTuv2REGtXNKdgGzfeKK+F5Av+W8n3sMXh20kiLirmEoOWrIWUMHwPAWRdHZKXF58kd+gWBI/MUcehEcguhtSo1d9689+mlqKO0otLTksYe+BwKFBzcq5sk2JSglQCZ822kWimqDqTqiK7FzpY3RVlbIW/btOdRda0Aexzt4LXz9tG7co7+F1xywHpWuUxYwisr6wssF8vJ2lsXGmWbyxgWTMJg46GK3dBbxNkf0WNVqAyX6qYKTc7V0oKjNHMOY2jLJdIWQZ1MpLSQQuVwImacYLAr3x1UXQen053u32rAPsMF+vViiMcPTOWA4eMv0uwx0SH0HCe522mzGGKNBuBEqj/Lgrs6HC0Ct+7D4GaZU3W75ddF5SOzIPFEV; bm_sc=2~1~577663062~YAAQ0yXAFw2YD/qZAQAADdt1JAXOE1fVC0qYRzxRsQGF/HFOIXtk21jL1ybo9btnIZEZ0q/wylUNkFLsRVTw7qEvBUg9QKx0/bDa1+APzmrHvcVnjzii2VgZCIJgLrx2A6FUM+3vru7g/ModwcoNTIga0errl8aJaPNuorGBi/Pl6WDfcnwKGyrtPlzWqB8BgnrAmyQHh2IB36PEAROpnfyoIqVMo2aAUxRbAf2k/tgVoCADQDm6RrFphOYVqybOZkNC+W4/PBNcGJtFe2pLE6Yi2whQ52eB3SppKyrh1flXFLg3yn0pYsQcp1ifqhdaH1ZFIlPLTjE8LNNApVglVN4QE/s8fmL37AL27GrsrdiBOqFwGMsGk8RivtquYqzA8tkyj66Uq29Vxh1haCouUVR34L1qBq/yVkR5uNDxrv110gTxeWHNJbQcCmob9Lbrct6R74YcKlGbpw==; bm_so=9C984A767BA655E208A6099C64D0126789DD1CAA9F94221B7539CE75CAE4407B~YAAQ0yXAF0yXD/qZAQAA9bp1JAU42I6LNW6NpXc+XKPCb2dgQTwQOVi6PAyboJlLXT+S10pDTbC82geVtL5FOG5yKaXjsWeae9b1f1c/bfAPShn5Fvw/B7K2/uc9Cx4pyAqwub2UU8Z5d1rSTdp5SLucgKI63A68MuEHgs4vLPP3vizsCIN93/5AZBgfWAr+6HJiKAl+ILbJL7ObqcR3FF50es8GtQKAj2zywj7LAo9PK/cwPfGctILu6qkgejBeG+m6QWEiHMnWRUqB1dIjiyvpL7EAvrDFP8TR0TKLQhvS49nPbEXXbB0H3bPLHWQ2cgtOyBQxNd3HZm4LuqcabdW/JvCl6xsyeFClhQgccUy0mvX4E4lMWNiXloEu/z5XGAbOLHusvSxymXU4LCuBb+LzJYXz9g+Q3saHDSpaPAZZGOyI5RzDQuPj8Igkix98C5yn8nEP78qb6XTYtFyM; bm_sz=C9EABE8F1383221D5B2189B7DDB38650~YAAQ0yXAF8iXD/qZAQAAwM91JB1gIEaedPaBUlYAJ61OfbOch1i+aIYdi8XTlLITwAYQoyX7nmiCJqLL1FrUBPqUDKTlgoTxKnW1Los4FoOo4FW8eAAHg33NY3oLlGjyBu+Dg/SjGmM3F5zUVSKlEMRJOrMj5ugZRbIWx0DZTw5MmpVkfkZN3hH6gzLqNJRZ6DFkTOKBMBY9y+cxRVTPKUzHZcO0B3vKbjINXN6sVa2SyvjoHQbExhxDcYxYcce0zW56wGiJjzK62+MoJGOOEF/99kFM7xTnuqtReA3JoIvrXJqEhpIVHGz5EMH1LsEHzGQfv8dj6AHJG3RocWB6VIQ0UYimO1o8GLS9Oh9Lm8X08mAyahqVhUZFxEIXclYyJAVSRFr2HrvZaPOP/YQJn58F8A==~4600642~3753273; platform1=k; bm_lso=9C984A767BA655E208A6099C64D0126789DD1CAA9F94221B7539CE75CAE4407B~YAAQ0yXAF0yXD/qZAQAA9bp1JAU42I6LNW6NpXc+XKPCb2dgQTwQOVi6PAyboJlLXT+S10pDTbC82geVtL5FOG5yKaXjsWeae9b1f1c/bfAPShn5Fvw/B7K2/uc9Cx4pyAqwub2UU8Z5d1rSTdp5SLucgKI63A68MuEHgs4vLPP3vizsCIN93/5AZBgfWAr+6HJiKAl+ILbJL7ObqcR3FF50es8GtQKAj2zywj7LAo9PK/cwPfGctILu6qkgejBeG+m6QWEiHMnWRUqB1dIjiyvpL7EAvrDFP8TR0TKLQhvS49nPbEXXbB0H3bPLHWQ2cgtOyBQxNd3HZm4LuqcabdW/JvCl6xsyeFClhQgccUy0mvX4E4lMWNiXloEu/z5XGAbOLHusvSxymXU4LCuBb+LzJYXz9g+Q3saHDSpaPAZZGOyI5RzDQuPj8Igkix98C5yn8nEP78qb6XTYtFyM^1761548288715; bm_sv=F46A069EA0493EE2CE7B48FD710777B4~YAAQ0yXAF8eXD/qZAQAAwM91JB24i7HTn+/wJkyv/GAChz7pf9+WxSe/U75mjjWm/dGT8H5Mp1vwNqTqPAAKpi3kwMQZeH8+BRO0FltdePPwqzQOkIuh69chol3gJV+jd1p4wpBhKXET7eTEhRdirU0RrTzfFYZXYLm7I9oUgPrDpJNx3ylwvYOQjIMcQTt4lq85LayawlmaePuzo1cpGfRzl90WeXy9TvdEhFUlZhWEhyI0jw2vDxWgjxb4cTsS8gs=~1',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'cross-site',
            'DNT': '1',
            'Sec-GPC': '1',
            'Priority': 'u=0, i',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="column"]'
        titalxpath = './/div[@class="product-card-title"]/a/text()'
        imagexpath = './/div[@class="product-image-container"]/a/img/@src'
        pricexpath = './/span[@class="price primary"]/span[@class="money-value"]/text()'
        price2xpath = './/span[@class="price"]/span[@class="money-value"]/text()'
        otherxpath = './/span[@class="blurb"]/text()'
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
            }
        )
