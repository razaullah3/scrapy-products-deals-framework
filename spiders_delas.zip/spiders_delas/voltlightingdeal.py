from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class voltlightingdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'voltlightingdeal'
    start_urls = ['https://www.voltlighting.com/deals']
    Sitename = 'VOLT® Lighting'
    siteurl = 'https://www.voltlighting.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-item-info"]'
        titalxpath = './/strong[contains(@class,"name")]/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="old-price"]//span[@class="price"]/text()'
        price2xpath = './/span[@data-price-type="finalPrice"]/span | //span[contains(@id,"from")]/span'
        otherxpath = ''
        nextpage = '//a[@title="Next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })