import scrapy
import json
import datetime
import logging
from ..items import couponsDealsItem


class victoriassecretdealSpider(scrapy.Spider):
    name = 'victorias'
    allowed_domains = ['victoriassecret.com']
    start_urls = [
        'https://api.victoriassecret.com/stacks/v41/?brand=vs&collectionId=08b8367b-635e-4667-ad96-87aea7294c7c&orderBy=REC&maxSwatches=8&isPersonalized=true&isWishlistEnabled=true&recCues=true&activeCountry=US&platform=web&deviceType=&platformType=&perzConsent=true&cid=&storeId=&address=&tntId=&screenWidth=1366&screenHeight=768'
    ]

    Sitename = 'Victorias Secret'
    siteurl = 'https://www.victoriassecret.com'

    def parse(self, response):
        self.logger.info(str(response.status))

        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"❌ JSON parsing failed: {e}")
            return

        stacks = data.get("stacks", [])
        total_products = 0

        for stack in stacks:
            products = stack.get("list", [])
            if not products:
                continue

            for p in products:
                item = couponsDealsItem()
                item['SiteName'] = self.Sitename
                item['SiteURL'] = self.siteurl
                item['Framework'] = "3"
                item['DateAdded'] = datetime.datetime.now()
                item['DateUpdated'] = datetime.datetime.now()
                item['dealpage'] = "True"
                item['Offer'] = p.get("discount", "")
                item['SourceUrl'] = p.get("url", "")
                item['Title'] = p.get("name", "").strip()
                item['Price'] = p.get("price", "")
                item['SalePrice'] = p.get("salePrice", "")

                imgs = p.get("productImages", [])
                if imgs:
                    full_imgs = [f"https://media.victoriassecret.com/i/victoriassecret/{img}?wid=400&fmt=webp" for img in imgs]
                    item['Image'] = ", ".join(full_imgs)
                else:
                    item['Image'] = ""

                # Display item in terminal
                print("\n====== Extracted Product ======")
                print(f"Title: {item['Title']}")
                print(f"Price: {item['Price']}")
                print(f"SalePrice: {item['SalePrice']}")
                print(f"Images: {item['Image']}")
                print(f"SourceUrl: {item['SourceUrl']}")
                print(f"SiteURL: {item['SiteURL']}")
                print("==============================\n")

                yield item
                total_products += 1

        self.logger.info(f"✅ Extracted {total_products} products from API.")
