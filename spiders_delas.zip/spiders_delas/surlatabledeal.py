import scrapy
import json
import datetime
from ..items import couponsDealsItem


class SurLaTableDealSpider(scrapy.Spider):
    name = 'surlatable_deal'
    handle_httpstatus_list = [404]

    base_url = 'https://www.surlatable.com/mobify/proxy/slt/sfcc-bff/bloomreach/product-search?productType=hardgood&q=clearance&pageSize=24&page={}'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "x-slt-ref-url": "",
        "x-slt-url": "https://www.surlatable.com/search?q=clearance",
        "x-slt-brUID2": "uid=9117387696478:v=app:ts=0:hc=2",
        "x-slt-is-pwa-call": "true",
        "x-slt-from-server-side": "false",
        "x-slt-user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "x-api-key": "2T4VHkByol3DxuIqjou0h4p7F6xzX23i8cG0Y48W",
        "Content-Type": "application/json",
        "x-slt-cookies": "dwsid=ey_x8uLCu3vVs2xa7FGAj2C8xmqLSYm12zbZJgBtkgCEm-HVbJmjeFccMBYRN6kFjmReH7wQopQyMtsoCbCAvA%3D%3D; usid_SLT=e22cbafc-5ef8-4856-8741-f85269040e14; cc-nx-g_SLT=8WuonsaWutWkQ2ZVxA-uyHTOLy1G69vDS8QCM5MSnVY",
        "x-slt-customer-id": "abGeDk6IbRiwdOLW75QZvwk4oU",
        "x-slt-rewriteauth": "Bearer eyJ2ZXIiOiIxLjAiLCJqa3UiOiJzbGFzL3Byb2QvYmNqbF9wcmQiLCJraWQiOiJhMWQyODc4OS02YmVmLTQ3OTEtOGIwNi1hYTAyYjQ3NTJjOWUiLCJ0eXAiOiJqd3QiLCJjbHYiOiJKMi4zLjQiLCJhbGciOiJFUzI1NiJ9.eyJhdXQiOiJHVUlEIiwic2NwIjoic2ZjYy5zaG9wcGVyLW15YWNjb3VudC5iYXNrZXRzIHNmY2Muc2hvcHBlci1kaXNjb3Zlcnktc2VhcmNoIHNmY2Muc2hvcHBlci1teWFjY291bnQucGF5bWVudGluc3RydW1lbnRzIHNmY2Muc2hvcHBlci1jdXN0b21lcnMubG9naW4gc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5vcmRlcnMgY19zbHQuY3VzdG9tLWFwaS5ydyBzZmNjLnNob3BwZXItcHJvZHVjdGxpc3RzIHNmY2Muc2hvcHBlci1wcm9tb3Rpb25zIHNmY2Muc2Vzc2lvbl9icmlkZ2Ugc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5wYXltZW50aW5zdHJ1bWVudHMucncgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5wcm9kdWN0bGlzdHMgc2ZjYy5zaG9wcGVyLWJhc2tldHMtb3JkZXJzIHNmY2Muc2hvcHBlci1jdXN0b21lcnMucmVnaXN0ZXIgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5hZGRyZXNzZXMucncgc2ZjYy5zaG9wcGVyLW15YWNjb3VudC5wcm9kdWN0bGlzdHMucncgc2ZjYy5zaG9wcGVyLWJhc2tldHMtb3JkZXJzLnJ3IHNmY2Muc2hvcHBlci1naWZ0LWNlcnRpZmljYXRlcyBzZmNjLnNob3BwZXItcHJvZHVjdC1zZWFyY2ggc2ZjYy5zaG9wcGVyLXNlbyIsInN1YiI6ImNjLXNsYXM6OmJjamxfcHJkOjpzY2lkOjh mOWVkZDEzLTAxYzUtNGFkOC05MTc5LWIxMTM5ZjVhYzk0MDo6dXNpZDplMjJjYmFmYy01ZWY4LTQ4NTYtODc0MS1mODUyNjkwNDBlMTQiLCJjdHgiOiJzbGFzIiwiaXNzIjoic2xhcy9wcm9kL2JjamxfcHJkIiwiaXN0IjoxLCJkbnQiOiIwIiwiYXVkIjoiY29tbWVyY2VjbG91ZC9wcm9kL2JjamxfcHJkIiwibmJmIjoxNzYyNDEyMjE2LCJzdHkiOiJVc2VyIiwiaXNiIjoidWlkbzpzbGFzOjp1cG46R3Vlc3Q6OnVpZG46R3Vlc3QgVXNlcjo6Z2NpZDphYkdlRGs2SWJSaXdkT0xXN zVRWnZ3azRvVT o6c2VzYjpzZXNzaW9uX2JyaWRnZTo6Y2hpZDpTTEQiLCJleHAiOjE3NjI0MTQwNDYsImlhdCI6MTc2MjQxMjI0NiwianRpIjoiQzJDLTE4NDgyOTg4NTQwNzAzNjkzNTM0NzIxNDkxMzI2MTI1MDg2In0.fwGiCiplqRUj6rAvEHDyCFdUW_fr397imZIx45cXo_JLR-Zt7qR489Fp33UWIp5SpvnP5hO89Jk0hnOaQCXNyQ",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0",
        "TE": "trailers"
    }

    def start_requests(self):
        """Start with first page"""
        yield scrapy.Request(
            url=self.base_url.format(1),
            headers=self.headers,
            callback=self.parse,
            meta={'page': 1}
        )

    def parse(self, response):
        """Parse the Sur La Table clearance API JSON"""
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error(f"Invalid JSON on page {response.meta['page']}")
            return

        items = data.get('items', [])
        self.logger.info(f"Scraping {len(items)} items from page {response.meta['page']}")

        for product in items:
            yield self.extract_product_item(product)

        # Pagination (continue if items found)
        page = response.meta['page']
        if len(items) == 24:
            next_page = page + 1
            next_url = self.base_url.format(next_page)
            yield scrapy.Request(
                url=next_url,
                headers=self.headers,
                callback=self.parse,
                meta={'page': next_page}
            )

    def extract_product_item(self, deal):
        """Extract specific product details"""
        item = couponsDealsItem()

        item['Title'] = deal.get('name', '')
        item['Image'] = deal.get('c_imageUrl', '')
        item['Price'] = deal.get('prices', {}).get('regularPrice', '')
        item['SalePrice'] = deal.get('prices', {}).get('salePrice', '')
        item['SourceUrl'] = 'https://www.surlatable.com' + deal.get('c_pwaUrl', '')

        now = datetime.datetime.now()
        item['Framework'] = '3'
        item["Offer"] = ''
        item['SiteName'] = 'Sur La Table'
        item['SiteURL'] = 'https://www.surlatable.com/'
        item['DateAdded'] = now
        item['DateUpdated'] = now

        item['dealpage'] = 'True'
        item['getDoc'] = 'True'
        item['itempage'] = 'false'
        item['urlpage'] = 'false'
        item['alllogs'] = 'false'
        item['Category'] = ''
        item['SubCategory'] = ''

        return item
