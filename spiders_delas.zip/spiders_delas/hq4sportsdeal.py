import json
from datetime import datetime
import re
import string

import scrapy
import validators
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class hq4sportsdealSpider(GetDealsProducts):
    """
    Spider for scraping HQ4Sports deals using the SearchMagic API.
    Inherits from GetDealsProducts for database functionality.
    """
    handle_httpstatus_list = [404]
    name = 'hq4sportsdeal'
    start_urls = ['https://www.hq4sports.com/clearance1.html']
    Sitename = 'HQ4Sports'
    siteurl = 'https://www.hq4sports.com'

    # Required for GetDealsProducts compatibility
    data = []
    maincaturl = []
    mainurlscounter = 0
    DealsData = []
    suburls = []
    urlscounter = 0
    Deals = []
    flag = 0
    saveindb = 1  # Set to 1 to save in database

    # Define headers as a class attribute for use with methods
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Content-Type': 'application/json',
        'Origin': 'https://www.hq4sports.com',
        'Connection': 'keep-alive',
        'Referer': 'https://www.hq4sports.com/',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors'
    }

    def start_requests(self):
        """
        Starting point for the spider.
        Bypasses the GetDealsProducts flow and uses the SearchMagic API directly.
        """
        self.logger.info(f"Starting API requests for {self.Sitename}")

        # API endpoint for the search request
        api_url = 'https://app.searchmagic.com/search/v1/section'

        # Body of the POST request
        post_data = {
            "t": "yBgpLSDdDfbmXJAZTZTihLPWuD6Cv5dOmTt5IzfjS53exp4OtPvq42sX7OhY",
            "user": {
                "uid": "",
                "language": "en-US",
                "screen_width": 1263,
                "screen_height": 184,
                "local_time": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
                "browser": "Mozilla%2F5.0+(Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A138.0)+Gecko%2F20100101+Firefox%2F138.0"
            },
            "query": "c773",
            "page": 1
        }

        # Send the POST request with the JSON payload
        yield scrapy.Request(
            url=api_url,
            method='POST',
            body=json.dumps(post_data),
            headers=self.headers,
            callback=self.parse_api,
            meta={'page': 1}
        )

    def parse_api(self, response):
        """
        Parse the JSON response from the SearchMagic API.
        Processes products and handles pagination.
        """
        try:
            # Parse the JSON response
            data = json.loads(response.text)
            self.logger.info(f"Response received from API: {data.keys()}")
            current_page = response.meta.get('page', 1)

            # Updated to check for 'items' key in the response
            if 'items' in data and isinstance(data['items'], list) and len(data['items']) > 0:
                self.logger.info(f"Found {len(data['items'])} products on page {current_page}")

                for product in data['items']:
                    item = self.process_product(product)
                    if item:
                        yield item

                # Check if there are more pages
                # Extract pagination info from settings if available
                settings = data.get('settings', {})
                current_page_from_api = settings.get('current_page', current_page)
                total_pages = settings.get('total_pages', 1)

                if current_page < total_pages:
                    next_page = current_page + 1
                    self.logger.info(f"Fetching next page: {next_page} of {total_pages}")

                    # Prepare the next page's POST data
                    post_data = {
                        "t": "yBgpLSDdDfbmXJAZTZTihLPWuD6Cv5dOmTt5IzfjS53exp4OtPvq42sX7OhY",
                        "user": {
                            "uid": "",
                            "language": "en-US",
                            "screen_width": 1263,
                            "screen_height": 184,
                            "local_time": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
                            "browser": "Mozilla%2F5.0+(Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A138.0)+Gecko%2F20100101+Firefox%2F138.0"
                        },
                        "query": "c773",
                        "page": next_page
                    }

                    yield scrapy.Request(
                        url=response.url,
                        method='POST',
                        body=json.dumps(post_data),
                        headers=self.headers,
                        callback=self.parse_api,
                        meta={'page': next_page},
                        dont_filter=True
                    )
                else:
                    # All pages processed, mark completion
                    self.logger.info("All pages processed, scraping complete")
                    yield self.create_final_log_item()
            else:
                self.logger.warning("No results found in the API response or unexpected data structure")
                # Log the API response for debugging
                self.logger.debug(f"API Response structure: {json.dumps(data)[:500]}...")
                yield self.create_final_log_item()

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
            self.logger.error(f"Response text: {response.text[:500]}...")
            yield self.create_final_log_item()
        except Exception as e:
            self.logger.error(f"Error processing response: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            yield self.create_final_log_item()

    def process_product(self, product):
        """
        Process a single product from the API results and return a couponsDealsItem.
        Returns None if the product should be skipped.
        """
        try:
            item = couponsDealsItem()

            # Extract and clean title
            title = product.get('title', '')
            if title:
                title = str(title).replace("&amp;", "&")
                title = string.capwords(re.sub(r'(<.*?>)|(\&.*?\;)', " ", title)).strip()
            item['Title'] = title

            # Process image URL
            image_url = product.get('image_url', '') or product.get('image', '')  # Added fallback
            if image_url and not image_url.startswith(('http://', 'https://')):
                image_url = f"{self.siteurl}/{image_url.lstrip('/')}"
            item['Image'] = image_url

            # Process regular price
            price = product.get('price', '') or product.get('original_price', '')  # Added fallback
            if price and not isinstance(price, str):
                price = f"{price:.2f}"
            elif price:
                price = re.sub(r'[^0-9$€é£,.\-]+', "", str(price)).strip()
            item['Price'] = f"${price}" if price else ''

            # Process sale price
            sale_price = product.get('sale_price', '') or product.get('final_price', '')  # Added fallback
            if sale_price and not isinstance(sale_price, str):
                sale_price = f"{sale_price:.2f}"
            elif sale_price:
                sale_price = re.sub(r'[^0-9$€é£,.\-]+', "", str(sale_price)).strip()
            item['SalePrice'] = f"${sale_price}" if sale_price else ''

            # Skip if no sale price or price
            if not item['SalePrice'] or item['SalePrice'] == '$':
                self.logger.debug(f"Skipping product with no sale price: {title}")
                return None

            # Process offer/discount information
            offer = product.get('offer', '') or product.get('discount_percentage', '')  # Added fallback
            if offer:
                offer = re.sub(r'[^0-9$€é£,%.]+', "", str(offer)).strip()
            item['Offer'] = offer

            # Process product URL
            url = product.get('product_url', '') or product.get('url', '') or product.get('link',
                                                                                          '')  # Added more fallbacks
            if url:
                if not url.startswith(('http://', 'https://')):
                    if not url.startswith('/'):
                        url = f"{self.siteurl}/{url}"
                    else:
                        url = f"{self.siteurl}{url}"

                # Validate URL
                if not validators.url(url):
                    url = self.siteurl
            else:
                url = self.siteurl

            item['SourceUrl'] = url

            # Set standard fields
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            current_time = datetime.now()
            item['DateAdded'] = current_time
            item['DateUpdated'] = current_time
            item['Status'] = 'Online'
            item['dealpage'] = 'True'

            return item
        except Exception as e:
            self.logger.error(f"Error processing product: {e}")
            return None

    def create_final_log_item(self):
        """Create a final log item to mark scrape completion"""
        item = couponsDealsItem()
        item['dealpage'] = ''
        item['alllogs'] = 'true'
        return item

    # Override GetDealsProducts methods to ensure they don't get called
    def parse(self, response):
        """
        Override the parent class parse method to avoid conflicts.
        This should never be called directly in this spider.
        """
        self.logger.warning("Default parse method called - this should not happen")
        return self.start_requests()

    def Data_Operations(self, response):
        """
        Method required for compatibility with GetDealsProducts class.
        Called at the end of scraping to handle any final operations.
        """
        item = couponsDealsItem()
        item['dealpage'] = ''
        item['alllogs'] = 'true'
        yield item