import scrapy

class LesliespoolPriceSpider(scrapy.Spider):
    name = "lesliespool"
    start_urls = ["https://lesliespool.com/deals/"]

    # aapke diye hue XPaths
    pricexpath = './/span[@class="sales red-price"]'
    price2xpath = './/span[@class="sales red-price"]/following-sibling::span[@class="strike-through list"]'

    def parse(self, response):
        # sale price (red price)
        sale_prices = response.xpath(f"{self.pricexpath}//text()").getall()
        sale_prices = [p.strip() for p in sale_prices if p.strip()]

        # old price (strike-through)
        old_prices = response.xpath(f"{self.price2xpath}//text()").getall()
        old_prices = [p.strip() for p in old_prices if p.strip()]

        yield {
            "url": response.url,
            "sale_prices": sale_prices,
            "old_prices": old_prices,
        }
