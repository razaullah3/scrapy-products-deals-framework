import scrapy
import json
import datetime
from ..items import couponsDealsItem

class CoachSaleSpider(scrapy.Spider):
    name = "coach_sale"
    allowed_domains = ["coach.com"]
    
    # Start with page 1
    start_page = 1
    base_url = "https://www.coach.com/api/get-shop/sale/view-all?page={page}&__v__=v2eh0bGHyt8TRBkAO9EBr"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Referer": "https://www.coach.com/shop/sale/view-all?page=2",
    "x-sid": "a08e6cfe-575e-4a7e-af0e-e93f04bcafe9",
    "Connection": "keep-alive",
    "Cookie": 'opt_features=leaveonaa; opt_user=62787ba8-85a2-4471-aa74-94abc99a473c; coh-clone=true; exp-COH=COH-MW; opt_enabled=true; akavpau_NO_MA_COH_AU=1762158611~id=75db079b7b0e5c75c7ac768014d06567; akacd_coach-na-prd-new-us=2147483647~rv=37~id=f5b918598b10ef55682b5a2bc4e91525; bm_ss=ab8e18ef4e; _abck=D053162BC23D1843B6D7A7CF016DD430~0~YAAQlffTF/IzyTGaAQAAa/XRSA6jRCqY/yhG3C1tyImIXtPTpgA2hhbMnoT2U72RFfexExUEnnbNhGyYxnWs7L6PXX8dz+IGBkQc/y8ajUDtYopZDjY94VU2YYHKkJxz/yLMY9W9w+NlMh3OcieVQI4IyFFBFF+W7cF1vY310uqWibq2JXAIUhdSDU1TVsuKnthJvrFCB/c6wsIYbDMmdg6Q2tj0vMwY5Y9KkyFdaWXOui/zvF7D1XLFdrpiqrUiWiLJvvO1Pxg1DTunXOWYa/NROvIsn8JMwTpsF6phCxBjGyHu9zBofmbQVvX/X7TG2ca/a6Gpj/G0xNeWh6qEHtyWeqmIQNtUm+K8zIv6fi4Sx5DsKo/Sddpc2cEGipJXY+Hp3rDInKlZ/UY/cW2L2u19Foah8bEQfEBSQiK6RMLbws9RQG+bPo0cUnyiG58R39e1lebw/6VYQe0X8d3YeMnZ74pZcajQNyuBL1HheP49DwJsyDhLpoe1Q9ov6Qh356N/oLu/h0i++skkfMjXYJUfPpqGw2MYmeIQhpQip09TIXaA8iCAk5xga6B2ThJKqmG9GVAdqgDwvRW2HE2Czi9o8vh7OeB7R/fkqGvb1ueh4jFQSmIw69OrRIl7K065d6MBkp5ecREOjU3k69M=~-1~-1~1762161890~AAQAAAAE%2f%2f%2f%2f%2f%2fl1WwvosMyFzpTWOvEiFTiVJ2xbXZUYIh+sF8OXyb%2fE1x48UopX4VRqBESjRWw2Va1KZuFjznBe2nsb9D9r0LytTAMCYTWOpFtr~-1; bm_s=YAAQlffTF5MzyTGaAQAAWuXRSAQ0/3vQdNhg0dwPrpE739Lju7X2WGfytMLGPpvo9TviaJBLjOSMTZlTzGiHJTGEUtAU+kaMzFsdfOVLi4+oVdZbed6ArF8Dmg1uenKc5hW0iAWl7gPi4k0LU+XiOQkgC9rf9+5EeP1Y6lq7IzYXSyAguVDOcaDmatSBaYBlf6pzQJsX+6VC308mooKEYbhpwU+wKsm38TNJwubbaPH0/iBg9/vw8V6wZ84YHapDgO8oS4Kb3Hl3Tj0nddCXZ8nu0ss7d/rQilk9EIO0+KIKsQTaRtV0GxmR1lvdpj5UV8NGSdlJmbKJ8Ig7oNzrokBakCDdwHqqXVbBO5QuxO6jc/VN/RobWIJLquJtPZPuEIn0AmzXJpyS3x78CZqiYRjLwylCHml4TQPSf29Gi2ZKQVjK5qSyIjrPOG/61huIuE3/VM7anwPua+GU9QyBYQBnwpJihqmsGfkW5HM/d+eXMQMebk5FUkJZHGm66uepVjEf7Po9HcZIRLCsOPm9s/uEcgqeBbOjsb5rjUKdK9LsBjvU48TTrJ1MdEK+76Fnr9uJEhL7cMGsVQ==; bm_so=55910B15EFC665AF7E53EAA1BB87E65687BFCEE8718A88205C59E4041BBE85B9~YAAQlffTF2QxyTGaAQAAlJfRSAUKGXQmxhYiYjR+ow+ZDNO066ZCOgh/djdTnx3/l5Mob0nNiEblGIMZTztMTZxawrJfEWH/m7fb1BMtDlU30ZisQ1ToX2sxYlDejiWZPTfg1iMFy/cf7Tw/0FIlzXLVM2kEyu7Hya18HXuj0ettPkpmQzw08oNA3wvfWvwcmzQumE/cTicdo//f+9/UaFfXhIHDYBWnyKYaq912EviXgw7ZviPq7KhiO4TPK2reaYkhFRHbXhiN1y7Cj7oc5PnqEq+NeHeSiIhayVc4+Ycy92Rc0oY+yySqU7FrpMwmI+AFaVNJ061eVqXeLsaR/MBO+G6+aB9GxSQzpt51OojlcdlHY3eE9oh2omN5NHteyHQAV/+w0r28PxcSIuw+4vHjnxNYXHDo3xYREOTlc5tzEoepQK4sHjVhFXBZsXOXRLYNc7e9iIza9wFClJCs; bm_sz=3E08EA802A2C1B6B44E9DC9D1898474E~YAAQlffTF20xyTGaAQAAXZnRSB21Q6TqG4v4EJyNRAtxgqCnL1EhuiExOif3nr8TDYl6BhvRCc0gdl30ncDhhUmdqdqNlVzZBusy60EyRyEW82cBGnjqDstFqpHi238xoK+nM3RFMdt8OjiK/XYv+OPEq8ekicEAc9bu6K1Y8bfbUF7BgKU0wvu330G33MeGLvSEfw8B2UW1b0juGRAOy12cW3tSpdpRx2siWgHF0TBU7j1i9iff7Eu7R9GkLi8eMBZMuxkJXn7B+IKKs746FLx0zi3c8M13p6RiiyPW5SQW00TkjZaBOl3CBBkYKefHqmWQdMPcxYgE/sQe4KGYBHfy6Fra5jXVF3oQCR1vbfQ+Upkah6eiYua8EOAW1G4eiXJvGxgDYEBs8GfpyyiklAMfMw==~4474178~3750212; cc-rht=1; optimizelyEndUserId=oeu1762158293360r0.6053974729836078; bm_lso=55910B15EFC665AF7E53EAA1BB87E65687BFCEE8718A88205C59E4041BBE85B9~YAAQlffTF2QxyTGaAQAAlJfRSAUKGXQmxhYiYjR+ow+ZDNO066ZCOgh/djdTnx3/l5Mob0nNiEblGIMZTztMTZxawrJfEWH/m7fb1BMtDlU30ZisQ1ToX2sxYlDejiWZPTfg1iMFy/cf7Tw/0FIlzXLVM2kEyu7Hya18HXuj0ettPkpmQzw08oNA3wvfWvwcmzQumE/cTicdo//f+9/UaFfXhIHDYBWnyKYaq912EviXgw7ZviPq7KhiO4TPK2reaYkhFRHbXhiN1y7Cj7oc5PnqEq+NeHeSiIhayVc4+Ycy92Rc0oY+yySqU7FrpMwmI+AFaVNJ061eVqXeLsaR/MBO+G6+aB9GxSQzpt51OojlcdlHY3eE9oh2omN5NHteyHQAV/+w0r28PxcSIuw+4vHjnxNYXHDo3xYREOTlc5tzEoepQK4sHjVhFXBZsXOXRLYNc7e9iIza9wFClJCs^1762158294768; PIM-SESSION-ID=N1FAs9EUZkKYCbmv; brand=coach; dwsid=y8u-jys7nhUtsXiy-cj_Gf057LkWF_Cfo79ipVOo7Ug4igUDc26rMeGqZQsl3hHHLETQGc-YLvDj5kqSlDGKag==; dwanonymous_21241bba5b655b4deb452d8ed61740d2=bcwra2xrxHxKsRlrAZxqYYwrBJ; cc-nx-g=4ypgOhs9t9h16ZjW9VTKPamVeoxQvo0n4zwXQnR91Sg; customer_id=bcwra2xrxHxKsRlrAZxqYYwrBJ; usid=a08e6cfe-575e-4a7e-af0e-e93f04bcafe9; RES_TRACKINGID=232882450681983; optimizelySession=1762158298426; pageviewCount=1; day=3; dwac_90116ecd66504b22b1f8f4d3e2=NWRbJdxCILB602kZ8GYiogOWCRPhbk469N0%3D|dw-only|||USD|false|US%2FEastern|true; cqcid=bcwra2xrxHxKsRlrAZxqYYwrBJ; cquid=||; sid=NWRbJdxCILB602kZ8GYiogOWCRPhbk469N0; __cq_dnt=0; dw_dnt=0; xgen_ab_info={"testing_group_name":"constructor"}; xgen_user_id=zj0edfqdnsjmhivjyb6; xgen_session_id=98350bf3-f82c-45db-941c-8609d13f57b3; xgen_meta_data={"user_type":"new_user","access_token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcl9pZCI6Ijc4YzA0Y2Y0YzY2NGRmZDMyODRmYTJlMzA4MGEzZmQzIiwiZXhwIjoxNzYyMjAxNDk3LCJ1c2VyX2lkIjoiemowZWRmcWRuc2ptaGl2anliNiJ9.m1RPk_kymREfZkYxRh_jbU3qxYF48ywaUYKOpYERVxY","expiration_date":"2025-11-03T20:24:57"}; _ga_MHLWH1ZN9F=GS2.1.s1762158300^$o1^$g0^$t1762158315^$j53^$l0^$h208302141; _ga=GA1.1.1090060240.1762158301; FPID=FPID2.2.BwjumJAyCx1jH0kDpyuBdzlR1Cnx2OYVcDo3AJ0IFWE%3D.1762158301; FPLC=iqnvdfGoAKIyuf364U6mAWpqHR6HJRzGcrf5qJRTsTUH09%2BvQjhTB1%2FpBiqf3h0pq8ViNxqRPEQ4jOu2a5SaLGeV2P%2B739qwpAIumsNG6TTKhDcp9304Mg4gBu7U3w%3D%3D; _fbc=; _fbp=; _scid=e9c6ac74-7a0c-428c-df92-638e0182af0d; __attn_eat_id=206fc206638a47b48c464cf7918b6ac7; _attn_=eyJ1Ijoie1wiY29cIjoxNzYyMTU4MzAzMDQ3LFwidW9cIjoxNzYyMTU4MzAzMDQ3LFwibWFcIjoyMTkwMCxcImluXCI6ZmFsc2UsXCJ2YWxcIjpcIjk3MzVkNTgzYzNjYjRiZDVhN2I1YjdiNzE3MTFkMmI1XCJ9IiwiZWF0Ijoie1wiY29cIjoxNzYyMTU4MzAzMDMxLFwidW9cIjoxNzYyMTU4MzAzMDMxLFwibWFcIjozNjUwLFwiaW5cIjp0cnVlLFwidmFsXCI6XCJodHRwczovL2xscGRwLmNvYWNoLmNvbVwifSJ9; __attentive_id=9735d583c3cb4bd5a7b5b7b71711d2b5; __attentive_session_id=a1095ed84eac4dbdbaa0218e51253047; __attentive_cco=1762158303049; _attn_bopd_=none; __attentive_pv=1; __attentive_ss_referrer=ORGANIC; rmStore=atm:mop; __attentive_dv=1; __pdst=0a5369b466f1496884887d4e22f4185d; OptanonConsent=isGpcEnabled=1&datestamp=Mon+Nov+03+2025+13%3A25%3A08+GMT%2B0500+(Pakistan+Standard+Time)&version=202407.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=38edf429-c43d-4b2e-9578-e6b76d97cb5c&interactionCount=0&isAnonUser=1&landingPath=https%3A%2F%2Fwww.coach.com%2Fshop%2Fsale%2Fview-all&groups=1%3A1%2C2%3A1%2C3%3A1%2C4%3A0; kampyle_userid=3ab0-ffa5-c89c-4ce3-6df8-3633-0c43-f43c; kampyleUserSession=1762158310235; kampyleSessionPageCounter=1; kampyleUserSessionsCount=1; kampyleUserPercentile=74.48402640940441; ak_bmsc=4AAC277BA89977E3B7054E3D610010F6~000000000000000000000000000000~YAAQlffTF5IzyTGaAQAAWuXRSB3BtcVJH6Gh1DIrsvFSA0TnxMgju3H1S2Dy5tnojn6GbqaqRcZX1lMMB6tym2w3QCFQDqnizrMzaAp8VFr69YfMgQEf8drylkcDMWv8QUuqZVJ9JP+/ad+Xkz+RrXOQbECsqHlr8LfIHfXrV/eWOO5hVrOeNz31+G9ttI8zWoXgD3o9MLFHsVaI6Hhmzm7WHL8PmE/joLTYeoAOIqmbZ2EBUoSsfH+GGOWnk+2BkoRLrmL72q1geYjaHX8vTpZJOMoEhLRhzZ5Yz5XgsnMHk8CrPRHD074ANXbBk8a8P37oQUcuj8VMnSwktiXtwsqnbT8JH2tC2VMt68INj0V2RFxnVxmwB/Q9Onu2LdSNPQSs5FE9PEmVsSiFiA==',  # truncated for readability
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=4",
    "TE": "trailers",

    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_url.format(page=self.start_page),
            headers=self.headers,
            callback=self.parse
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("⚠️ JSON decode failed")
            return

        products = data.get("results", [])

        for p in products:
            title = p.get("pageTitle") or p.get("productName") or ""
            url = "https://www.coach.com" + p.get("defaultColor", {}).get("url", "")
            price = p.get("defaultVariant", {}).get("prices", {}).get("regularPrice")
            sale_price = p.get("defaultVariant", {}).get("prices", {}).get("currentPrice")
            thumbnail = p.get("defaultColor", {}).get("media", {}).get("thumbnail", {}).get("src")

            item = couponsDealsItem()
            item["Title"] = title
            item["SourceUrl"] = url
            item["Price"] = price
            item["SalePrice"] = sale_price
            item["Image"] = thumbnail
            item["SiteName"] = "Coach"
            item["SiteURL"] = "https://www.coach.com"
            item["Framework"] = "3"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"

            yield item

        # Pagination
        current_page = data.get("pageData", {}).get("page", self.start_page)
        total_pages = data.get("pageData", {}).get("totalPages", current_page)

        if current_page < total_pages:
            next_page = current_page + 1
            yield scrapy.Request(
                url=self.base_url.format(page=next_page),
                headers=self.headers,
                callback=self.parse
            )
