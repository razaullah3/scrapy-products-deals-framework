from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy

class discountmugsdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'discountmugsdealdeal'
    start_urls = ['https://www.discountmugs.com/category/deals?page=1',
                  'https://www.discountmugs.com/category/deals?page=2',
                  'https://www.discountmugs.com/category/deals?page=3',
                  'https://www.discountmugs.com/category/deals?page=4',
                  'https://www.discountmugs.com/category/deals?page=5',
                  'https://www.discountmugs.com/category/deals?page=6',
                  'https://www.discountmugs.com/category/deals?page=7',
                  'https://www.discountmugs.com/category/deals?page=8',
                  'https://www.discountmugs.com/category/deals?page=9',
                  'https://www.discountmugs.com/category/deals?page=10',
                  'https://www.discountmugs.com/category/deals?page=11'
                  
                  ]
    Sitename = 'Discount Mugs'
    siteurl = 'https://www.discountmugs.com'

    def parse(self, response):
        # --- Send site info once ---
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # --- XPaths for product details ---
        divxpath = '//li[@class="product"]/article'
        titalxpath = './/h3[@class="card-title"]/a/text()'
        imagexpath = './/div[@class="card-img-container"]/img/@src'
        pricexpath = './/span[@class="price sale"]'
        price2xpath = './/span[@class="price sale"]'
        otherxpath = '//div[@class="sale-badge"]/span/text()'

        # --- Collect products ---
        products = response.xpath(divxpath)
        if products:
            yield scrapy.Request(
                response.url,
                callback=self.Data_Collector,
                meta={
                    'url': self.siteurl,
                    'sname': self.Sitename,
                    'attribute': '',
                    'divxpath': divxpath,
                    'titalxpath': titalxpath,
                    'imagexpath': imagexpath,
                    'pricexpath': pricexpath,
                    'price2xpath': price2xpath,
                    'otherxpath': otherxpath,
                    'subcategorypage': '',
                    'nextpage': '',
                    'categorypage': ''
                }
            )

           
