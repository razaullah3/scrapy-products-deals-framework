from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class jazwaresdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'jazwaresdeal'
    start_urls = ['https://shop.jazwares.com/collections/deals-and-steals']
    Sitename = 'jazwaresdeal'
    siteurl = 'https://shop.jazwares.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[contains(@class, "boost-pfs-filter-products")]/article'
        titalxpath = './/h3[@class="title"]/a/text()'
        imagexpath = './/img[contains(@class,"boost-pfs-filter-product-item-flip-image")][1]/@src'
        pricexpath = './/p[@class="price mt-2"]//span[@class="text-red font-semibold body-1"]/text()[1]'
        price2xpath = './/p[@class="price mt-2"]//span[@class="line-through"]/text()[1]'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })