import scrapy
import json
import datetime
from ..items import couponsDealsItem


class MomentDealSpider(scrapy.Spider):
    name = "moment_deal"

    custom_headers = {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }

    api_url = (
        "https://zm0u1a8cwloebg6dp.a1.typesense.net/multi_search"
        "?use_cache=true&x-typesense-api-key=XNtd1yOYvqLibgptiwHjLqt5uk2dCGOZ"
    )

    # Base POST body (we will modify page number)
    base_body = {
        "searches": [
            {
                "typo_tokens_threshold": 1,
                "preset": "Collection Default",
                "sort_by": "price:desc,momentSearchScoreRank:desc,_text_match:desc",
                "collection": "prod_sanity_products",
                "q": "*",
                "facet_by": "brands,breadcrumbs.lvl0,isOnSale,priceRange,productMetafields.custom.condition,variantMetafields.custom.status",
                "filter_by": "categoryPageId:=['Closeout']",
                "max_facet_values": 24,
                "page": 1,
                "per_page": 24,
            }
        ]
    }

    def start_requests(self):
        page = 1

        body = self.base_body.copy()
        body["searches"][0]["page"] = page

        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.custom_headers,
            body=json.dumps(body),
            callback=self.parse,
            meta={"page": page, "body": body},
        )

    def parse(self, response):
        page = response.meta.get("page", 1)
        body = response.meta.get("body")

        try:
            data = response.json()
        except Exception as e:
            self.logger.error(f"JSON ERROR at page={page} → {e}")
            return

        results = data.get("results", [])

        if not results:
            return

        grouped = results[0].get("grouped_hits", [])

        # Extract items
        for g in grouped:
            for hit in g.get("hits", []):
                doc = hit.get("document", {})
                yield self.extract_item(doc)

        # Pagination
        found = results[0].get("found", 0)
        per_page = self.base_body["searches"][0]["per_page"]

        if page * per_page < found:
            next_page = page + 1

            next_body = self.base_body.copy()
            next_body["searches"][0]["page"] = next_page

            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.custom_headers,
                body=json.dumps(next_body),
                callback=self.parse,
                meta={"page": next_page, "body": next_body},
            )

    def extract_item(self, p):
        item = couponsDealsItem()

        slug = p.get("handle") or p.get("slug") or ""
        variant_id = p.get("_variantId", "").replace("shopifyProductVariant-", "")

        price = p.get("contextualPricing", {}).get("US", {}).get("price")
        compare_price = p.get("compareAtPrice")
        image = p.get("previewImageUrl")

        # Source URL: https://www.shopmoment.com/products/{slug}?variant={id}
        source_url = f"https://www.shopmoment.com/products/{slug}?variant={variant_id}"

        # % OFF
        try:
            if price and compare_price and float(compare_price) > float(price):
                old = float(compare_price)
                new = float(price)
                off = round(((old - new) / old) * 100)
                offer = f"{off}% OFF"
            else:
                offer = ""
        except:
            offer = ""

        item["Title"] = p.get("title") or slug
        item["Image"] = image
        item["SourceUrl"] = source_url
        item["Price"] = compare_price   # original price
        item["SalePrice"] = price       # discounted price
        item["Offer"] = offer

        item["SiteName"] = "Moment"
        item["SiteURL"] = "https://www.shopmoment.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
