import scrapy
import re
import json5
import datetime
from ..items import couponsDealsItem


class SheinFlashSaleSpider(scrapy.Spider):
    name = "shein"
    start_urls = [
        "https://us.shein.com/super-deals?pagefrom=page_home&fromPageType=home"
    ]

    # --- Default headers for all requests ---
    custom_headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/118.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        
        "Connection": "keep-alive",
        
    }

    def start_requests(self):
        """Use headers for initial requests."""
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.custom_headers, callback=self.parse)

    def parse(self, response):
        try:
            # Extract the script containing window.thriftyFindSSRData
            script_text = response.xpath(
                "//script[contains(., 'window.thriftyFindSSRData')]/text()"
            ).get()

            if not script_text:
                self.logger.warning("⚠️ Could not find script with window.thriftyFindSSRData")
                return

            # Extract JSON safely even if multiline
            match = re.search(
                r"window\.thriftyFindSSRData\s*=\s*(\{.*?\"styles\":\"\"\})",
                script_text,
                re.DOTALL,
            )

            if not match:
                self.logger.warning("⚠️ Could not extract JSON from window.thriftyFindSSRData")
                return

            json_text = match.group(1).strip()
            data = json5.loads(json_text)

            print("\n✅ JSON Extracted Successfully!")
            print("Top-level keys:", list(data.keys()))

            flash_data = (
                data.get("currentFlashSale")
                or data.get("flashSaleData")
                or data.get("data")
                or {}
            )

            print("Inner keys under flash_data:", list(flash_data.keys()))

            products = (
                flash_data.get("flashProducts")
                or flash_data.get("products")
                or flash_data.get("goodsList")
                or []
            )

            if not products:
                self.logger.warning("⚠️ No products found inside the parsed JSON.")
                return

            for p in products:
                item = couponsDealsItem()
                item["Title"] = p.get("goods_name", "")
                item["Price"] = p.get("retailPrice", {}).get("amount", "")
                item["SalePrice"] = p.get("salePrice", {}).get("amount", "")
                item["Offer"] = p.get("discountAmount", {}).get("amount", "")
                item["Image"] = p.get("goods_img", "")
                item["SourceUrl"] = (
                    f"https://us.shein.com/{p.get('goods_url_name', '')}-p-{p.get('goods_id', '')}.html"
                )
                item["SiteName"] = "SHEIN Super Deals"
                item["SiteURL"] = "https://us.shein.com"
                item['Framework'] = "3"
                item['dealpage'] = "True"
                item["DateAdded"] = datetime.datetime.now()
                item["DateUpdated"] = datetime.datetime.now()

                # --- Print extracted product details in terminal ---
                print("\n🛍️ Product Extracted:")
                print(f"Title: {item['Title']}")
                print(f"Price: {item['Price']}")
                print(f"SalePrice: {item['SalePrice']}")
                print(f"Offer: {item['Offer']}")
                print(f"Image: {item['Image']}")
                print(f"SourceUrl: {item['SourceUrl']}")
                print("-" * 80)

                return item

        except Exception as e:
            self.logger.error(f"❌ Error parsing SHEIN thriftyFindSSRData JSON: {e}")
