from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import json
import scrapy
import datetime


class twogamedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = '2gamedeal'
    start_urls = ['https://2game.com/en_us/hot-deals.html']
    Sitename = '2Game'
    siteurl = 'https://2game.com'

    # GraphQL API endpoint
    api_url = 'https://2game.com/graphql'

    # Headers required for the API request
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://2game.com/en_us/hot-deals.html',
        'Content-Type': 'application/json',
        'Content-Currency': 'USD',
        'Application-Model': 'ProductList_1747121593713',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Priority': 'u=4'
    }

    def start_requests(self):
        """
        Override start_requests to initiate the API request flow
        """
        # First, yield the document item
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        item['SiteURL'] = self.siteurl
        yield item

        # Start with page 1
        current_page = 1

        # Make API request for deals
        yield self.create_api_request(current_page)

    def create_api_request(self, page_number):
        """
        Create a GraphQL API request with proper parameters
        """
        # Construct the query parameters in the URL
        query_params = f"hash=2524944701&sort_1={{%22bestsellers%22:%22DESC%22}}&filter_1={{%22price%22:{{}},%22category_id%22:{{%22eq%22:4}}}}&pageSize_1=12&currentPage_1={page_number}&popularBlockPageSize_1=12&storeCode=%22en_us%22"
        api_url_with_params = f"{self.api_url}?{query_params}"

        self.logger.info(f"Making API request to: {api_url_with_params}")

        return scrapy.Request(
            url=api_url_with_params,
            headers=self.headers,
            callback=self.parse_api_response,
            meta={'page': page_number}
        )

    def parse_api_response(self, response):
        """
        Parse the API response to extract product data and yield items for database storage
        """
        try:
            # Parse JSON data
            data = json.loads(response.body)

            # Extract and process products from the response
            products = data.get('data', {}).get('products', {}).get('items', [])

            self.logger.info(f"Found {len(products)} products in the response")

            current_date = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            for product in products:
                item = couponsDealsItem()
                item['getDoc'] = ''
                item['dealpage'] = 'True'  # Set this to trigger UploadDealProduct in pipeline
                item['SiteName'] = self.Sitename
                item['SiteURL'] = self.siteurl
                item['Framework'] = 'Scrapy'
                item['DateAdded'] = current_date
                item['DateUpdated'] = current_date
                item['Status'] = 'Active'

                # Extract product details based on the observed JSON structure
                item['Title'] = product.get('name', '')

                # Extract image URL - first try small_capsule from steam_images if available
                steam_images_str = None
                for attr in product.get('attributes', []):
                    if attr.get('attribute_code') == 'steam_images':
                        steam_images_str = attr.get('attribute_value')
                        break

                # Parse steam_images if available
                if steam_images_str:
                    try:
                        steam_images = json.loads(steam_images_str)
                        if steam_images.get('small_capsule'):
                            item['Image'] = steam_images.get('small_capsule')
                        else:
                            # Fallback to standard image
                            item['Image'] = product.get('image', {}).get('url', '')
                    except:
                        # Fallback if JSON parsing fails
                        item['Image'] = product.get('image', {}).get('url', '')
                else:
                    # Use standard image if steam_images not found
                    item['Image'] = product.get('image', {}).get('url', '')

                # Extract prices from price_range
                price_range = product.get('price_range', {})
                regular_price = price_range.get('maximum_price', {}).get('regular_price', {}).get('value')
                final_price = price_range.get('maximum_price', {}).get('final_price', {}).get('value')

                # Get currency from response
                currency = price_range.get('maximum_price', {}).get('regular_price', {}).get('currency', 'USD')

                # Format prices with currency symbol
                currency_symbol = '£' if currency == 'GBP' else '$'

                item['Price'] = f"{currency_symbol}{regular_price:.2f}" if regular_price else ""
                item['SalePrice'] = f"{currency_symbol}{final_price:.2f}" if final_price else ""

                # Product URL - get url_key from attributes or directly
                url_key = None
                for attr in product.get('attributes', []):
                    if attr.get('attribute_code') == 'url_key':
                        url_key = attr.get('attribute_value')
                        break

                if not url_key:
                    # Fallback - try direct property
                    url_key = product.get('url_key', '')

                if url_key:
                    item['SourceUrl'] = f"{self.siteurl}/en_us/{url_key}.html"

                # Calculate discount percentage
                if regular_price and final_price and regular_price > 0:
                    discount_percent = round((regular_price - final_price) / regular_price * 100)
                    item['Discount'] = f"{discount_percent}% OFF"
                    item['PercentageOff'] = f"{discount_percent}%"
                    item['Offer'] = f"Save {currency_symbol}{(regular_price - final_price):.2f}"
                else:
                    item['Discount'] = ""
                    item['PercentageOff'] = ""
                    item['Offer'] = ""

                # Get short description if available
                short_desc = product.get('short_description', {}).get('html', '')
                if short_desc:
                    item['Description'] = short_desc

                # Set category for all products
                item['Category'] = 'Games'
                item['SubCategory'] = ''
                item['Type'] = 'Deal'
                item['SubType'] = 'Game Deal'
                item['Code'] = ''
                item['Color'] = ''
                item['Size'] = ''
                item['Specs'] = ''
                item['Quantity'] = ''
                item['ShippingFee'] = ''
                item['StartTime'] = ''
                item['EndTime'] = ''
                item['Sold'] = ''
                item['Online'] = '1'
                item['City'] = ''
                item['State'] = ''
                item['Zip'] = ''
                item['Rating'] = ''
                item['PromotionalText'] = f"Get {item['Title']} at a discounted price!"
                item['Preority'] = '1'

                # Yield the item for pipeline processing
                yield item

            # Check if there are more pages
            total_count = data.get('data', {}).get('products', {}).get('total_count', 0)
            current_page = response.meta.get('page', 1)
            items_per_page = 12  # As specified in the query
            total_pages = (total_count + items_per_page - 1) // items_per_page

            self.logger.info(f"Current page: {current_page}, Total pages: {total_pages}")

            # If there are more pages, make a request for the next page
            if current_page < total_pages:
                yield self.create_api_request(current_page + 1)
            else:
                # This is the last page, send logs item
                log_item = couponsDealsItem()
                log_item['alllogs'] = 'true'
                log_item['SiteName'] = self.Sitename
                log_item['SiteURL'] = self.siteurl
                yield log_item

        except Exception as e:
            error_message = f"Error parsing API response: {str(e)}"
            self.logger.error(error_message)

    def parse(self, response):
        """
        Original parse method - not used with API approach but kept for compatibility
        """
        # This method is now unused since we're using the API directly
        pass