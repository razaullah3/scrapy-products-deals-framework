from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy
from scrapy_playwright.page import PageMethod

class overstockdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404, 403]
    name = 'overstockdealdeal'
    start_urls = ['https://www.overstock.com/deal,/k,/results.html']
    Sitename = 'Overstock'
    siteurl = 'https://www.overstock.com'

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0, i"
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                headers=self.custom_headers,
                callback=self.parse,
                meta={
                    "playwright": True,
                    "playwright_include_page": True,
                    # ✅ Headful browser for avoiding 403
                    "playwright_context_kwargs": {"viewport": {"width": 1280, "height": 800}, "java_script_enabled": True},
                    "playwright_page_methods": [
                        PageMethod("wait_for_selector", "div.product-card, div.product-tile", timeout=60000)
                    ],
                    "playwright_page_close": True  # Close page after download
                },
            )

    def parse(self, response):
        # Handle forbidden/not found
        if response.status == 403:
            self.logger.error(f"⚠️ Received 403 Forbidden at: {response.url}")
            self.logger.error(f"Response body:\n{response.text[:1000]}")
            return
        elif response.status == 404:
            self.logger.warning(f"⚠️ 404 Not Found: {response.url}")
            return

        # ✅ Debug: print the first 500 chars of the page HTML
        self.logger.info(f"Page HTML snippet:\n{response.text[:500]}")

        # Start scraping
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//a[contains(@class, "ml product")]'
        titalxpath = './/img/@alt'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="nt"]/span/text()'
        price2xpath = './/span[@class=" product-price-amount"]/text()'
        otherxpath = './/span[contains(@class, "lc hf ab ld ordinary-selling-price-savings")]/text()'
        nextpage = '//a[@data-testid="pagination-next-button"]/@href'

        yield response.follow(
            response.url,
            headers=self.custom_headers,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
