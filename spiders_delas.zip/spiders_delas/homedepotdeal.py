from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class alphabetdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'homedepot'
    start_urls = ['https://www.homedepot.com/b/Special-Values/N-5yc1vZ7']
    Sitename = 'homedepot'
    siteurl = 'https://www.homedepot.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = '//a[@class="sui-lab-btn-base sui-block sui-text-inherit sui-w-full sui-h-full sui-focus-outline focus-visible:sui-rounded-md"]/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = "//div[@class='results-wrapped']/div/section[contains(@id,'browse-search-pods')]/div[not(contains(@class,'xl:sui-col-span-4'))]"
        titalxpath = './/span[@data-testid="attribute-product-label"]/text()'
        imagexpath = './/div[@class="sui-relative"]/img/@src'
        pricexpath = './/span[@class="sui-font-display sui-leading-none sui-px-[2px] sui-text-3xl sm:sui-text-4xl sui--translate-y-[0.35rem]"]/text()'
        price2xpath = './/span[@class="sui-line-through"]/span/text()'
        otherxpath = './/span[@class="offdisc"]/text()'
        nextpage = '//li[@class]/a[@aria-label="Skip to Next Page"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )

    
