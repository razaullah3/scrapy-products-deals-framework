import scrapy

from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class swordsswordsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'swordsswordsdeal'
    start_urls = ['https://swordsswords.com/combo-deals']
    Sitename = 'SwordsSwords'
    siteurl = 'https://swordsswords.com'

    # Define the custom User-Agent string
    custom_user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML like Gecko) Chrome/37.0.2062.120 Safari/537.36'

    def start_requests(self):
        # Loop through the start URLs and add the custom User-Agent to the headers
        for url in self.start_urls:
            yield scrapy.Request(url, headers={'User-Agent': self.custom_user_agent})

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        # Define your XPath expressions
        divxpath = '//div[@id="product-listing-container" and contains(@class, "page-content")]'
        titalxpath = './/h3[@class="card-title"]/a/text()'
        imagexpath = './/div[@class="card-img-container"]/img/@src'
        pricexpath = './/span[contains(@class, "price price--rrp")]/text()'
        price2xpath = './/span[contains(@class, "price price--withoutTax")]/text()'
        otherxpath = './/span[@class="save-percent"]/text()'
        nextpage = './/a[@class="pagination-link" and @aria-label="Next"]/@href'

        # Extract the title using the XPath selector
        title = response.xpath(titalxpath).get()

        # Print the title for debugging
        print(f"Extracted title: {title}")

        # Check if title is found and print a message if not
        if title:
            self.logger.info(f"Extracted title: {title}")
        else:
            self.logger.warning("No title found on the page")

        # Continue with your Data_Collector call
        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'categorypage':categorypage,
            'subcategorypage':subcategorypage,
            'attribute':attribute,
            'url': self.siteurl,
            'sname': self.Sitename,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'nextpage': nextpage
        },dont_filter=True)
