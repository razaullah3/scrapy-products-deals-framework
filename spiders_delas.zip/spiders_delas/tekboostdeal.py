from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy

class TekboostdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'tekboostdeal'
    start_urls = ['https://tekboost.com/']
    Sitename = 'TekBoost'
    siteurl = 'https://tekboost.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product"]'
        titalxpath = './/h3[@class="card-title"]/a/span/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="price price--rrp"]/text()'
        price2xpath = './/span[@class="price price--withoutTax"]/text()'
        otherxpath = ''
        nextpage = ''  # Adjust based on site

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )