import scrapy
import json

class NeweggDealsSpider(scrapy.Spider):
    name = "newegg_deals"
    allowed_domains = ["newegg.com"]
    start_urls = [
        "https://www.newegg.com/store/api/PageDeals?originParams=%7B%22name%22%3A%22Newegg-Deals%22%2C%22id%22%3A%229447%22%7D&originQuery=%7B%7D&index=3&from=www.newegg.com&recaptcha=pass"
    ]

    custom_settings = {
        'DOWNLOAD_DELAY': 3,
        'RETRY_HTTP_CODES': [500, 503, 504, 400, 403, 404, 408],
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    }

    def start_requests(self):
        headers = {
            
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        
        "Cookie":"NV_AB_Testing={'default':{'value':'b','expiretime':1760889600000},'store':{'value':'b','expiretime':1760889600000}}; NVTC=248326808.0001.9034cc534.1759909742.1759909742.1759909742.1; NID=9D341j4M8O4M8O9D8O1759909749a6fdb9e7965269306fdf6e1b2c412b2f3; NV_NVTCTIMESTAMP=1759909758; NE_STC_V1=37cda3dd79d444a2db17f862a6fecf022f84f704a18570ac8c375b420b709a89cb38293c; __cf_bm=E0b6q3g.aa7JUvlRmRyEFSS0MwBbQGzyxUTqFWaP2mA-1759909742-1.0.1.1-4_lCEDP7gjBevpuhAHPOT84xHWoqV_9_J36Va0yCThdtwjDDHoALYgi46sxCgvjOTP0XYzzLl915A168VS2Qbww_s1RvB3e6Ch2LrW5pD2A; cf_clearance=XNaM0gajDYasis9ziyt.4vssbAx32puKPGnYAXdw4yA-1759909745-1.2.1.1-bhyrnt8.._9pDhn08kFCTP8KboBzHObC_2L_ksuQn4FkLpD85jNVTarzM69HWUMZJ7WEMEjgpMu5fmYhSJKQ8z_HtkJJp7N0IZoIzP1JACPLRRCtbRoG9jYKQra74LGQ0SqMN.O60Lmwej20X436keN7Je60xRzJmhSVO10XgGYwPrbNJoDnUNgh1.1rarcU4RbwyUAqTuzlnFc50NmjFPqjhJZRB6ZjKNi6CQ.WhjE; osano_consentmanager_uuid=67da8ee1-1050-4501-b079-6e7655c9218b; osano_consentmanager=6fX40V44FNrg3rxa6QklMMtMRbCiLdsdZTK1Qgfvc34xX7jZqBScvv4ZrcSpfUAMBBAOnCKdkHkmfySbiUqul3krYEkmGyqNb47m51ZCMdQGCBH6C4NQ4n4GSiLRHHeQ1kBgxDaUaoZheFXlnUf82lb_MlAl5zbUpif11YbGTPv9PGFNno_p3uHOEzLI0TLRV7tL2-Ahs6EmkY6VQCwGiV53N2VgCSb032rcRcYTnXSHzmBEyWbZtizorQQbaOdBKYYYNYV_lI_gJsRfazzlBt8tyLtluJwCIFXY_FmdbzaoAEVmbhn5sAGexPDhHefPrmkVr_3cFZCsujZfSe7E6lpcY4ZdsttWT4mQlQwU0Pf7_rMm_K7RSQ==; NV%5FW57=USA; NV%5FW62=en; NV%5FCONFIGURATION=^#5%7B%22Sites%22%3A%7B%22USA%22%3A%7B%22Values%22%3A%7B%22w58%22%3A%22USD%22%7D%2C%22Exp%22%3A%222623909753%22%7D%7D%7D; NV%5FGAPREVIOUSPAGENAME=event-sale%20store%3ANewegg%20Deals; _gcl_au=1.1.1163712813.1759909755; NV_ECM_TK_LC=%7B%22icid%22%3A%7B%7D%2C%22cm_sp%22%3A%7B%22value%22%3A%22EventStore-categorydeal-_-alldeals%22%2C%22expiretime%22%3A1762501755328%7D%2C%22cm_mmc%22%3A%7B%7D%7D; _ga_TR46GG8HLR=GS2.1.s1759909756^$o1^$g0^$t1759909756^$j60^$l0^$h1780159669; _ga=GA1.1.156074910.1759909757",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache"
        }

        cookies = {
            'newegg_country': 'USA',
            'newegg_language': 'en',
        }

        for url in self.start_urls:
            yield scrapy.Request(url, headers=headers, cookies=cookies, callback=self.parse)

    def parse(self, response):
        try:
            data = json.loads(response.text)
            items = data.get("data", {}).get("PageDeals", {}).get("DealsList", [])
            if not items:
                self.logger.warning("⚠️ No items found — check API structure or headers.")
                return

            for i in items:
                item_cell = i.get("ItemCell", {})
                desc = item_cell.get("Description", {})
                images = item_cell.get("Image", {}).get("ImagePathPattern", [])
                image_list = item_cell.get("NewImage", {}).get("ImageNameList", "")

                # Construct image URLs
                img_names = image_list.split(",") if image_list else []
                img_urls = []
                if images:
                    pattern = images[-1]["PathPattern"]  # Use original size
                    for name in img_names:
                        img_urls.append(pattern.replace("{ImageName}", name).replace("{Size}", ""))

                # Product URL
                url_keywords = desc.get("UrlKeywords", "")
                product_number = item_cell.get("Item", "")
                product_url = f"https://www.newegg.com/p/{product_number}?Item={product_number}"
                if url_keywords:
                    product_url = f"https://www.newegg.com/p/{product_number}?Description={url_keywords}"

                yield {
                    "ProductName": desc.get("ProductName"),
                    "UnitCost": item_cell.get("UnitCost"),
                    "FinalPrice": item_cell.get("FinalPrice"),
                    "InstantRebateAmount": item_cell.get("InstantRebateAmount"),
                    "Images": ",".join(img_urls),
                    "ProductURL": product_url,
                }

        except Exception as e:
            self.logger.error(f"❌ Parsing failed: {e}")
            self.logger.debug(response.text)
