import scrapy
import json
import datetime
from ..items import couponsDealsItem  # make sure your item has these fields

class NordstromRackSpider(scrapy.Spider):
    name = 'nordstrom_rack'
    allowed_domains = ['nordstrom.com', 'nordstromrack.com']
    start_urls = [
        "https://www.nordstromrack.com/api/browse/query/clearance?top=72&postalCodeAvailability=77084&preferredStore=748&preferredPostalCode=77084&offset=4&page=2&isDynamicFacetsEnabled=true"
    ]

    custom_headers =  {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, zstd",
    "Referer": "https://www.nordstromrack.com/clearance?offset=4&page=2&postalCodeAvailability=77084&preferredStore=748&preferredPostalCode=77084",
    "ads-nord-context-id": "68429fc5-3892-4fac-be3d-3529f642b4a0",
    "cardmember": "Non-CardMember",
    "content-type": "application/json",
    "country-code": "US",
    "currency-code": "USD",
    "customerauthstate": "anonymous",
    "eventcustomer": '{"idType":"SHOPPER_ID","id":"4697dcdaeda5490c9fcc7ed7c8d97c5b"}',
    "eventsource": '{"channel":"RACK","channelCountry":"US","platform":"WEB"}',
    "experimentid": "be7ddace-84bb-4c1f-b1b1-028c9051199e",
    "experiments": '{"experiments":[],"optimizely":{"experiments":[{"n":"pdp_chx_paypal_bnpl_v2","v":"paypalSB2","p":"FULL_LINE_DESKTOP"}, {"n":"checkout_shoppingbag_bigger_images","v":"sb_bigger_images","p":"FULL_LINE_DESKTOP"}],"id":"be7ddace-84bb-4c1f-b1b1-028c9051199e"}}',
    "feature-flags": "isproductpinningenabled,issponsoredadsforsearchactive,issponsoredadsforbrowseactive",
    "is-security-scan": "false",
    "isauxexperiment": "true",
    "ismobile": "false",
    "isproductdropexperiment": "true",
    "issanityexperiment": "true",
    "isusereventqualified": "false",
    "loyaltylevel": "non-member",
    "newrelic": "eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjIzMDUxMjEiLCJhcCI6IjMwMjQ2MTM4NiIsImlkIjoiMWRlYTM2Y2FhYWE5YzVhYiIsInRyIjoiYjQ2YjlhMzg1MzJjN2RjMGI0M2Y3YjhkMDI3ODY5M2YiLCJ0aSI6MTc1OTgyNjc5MTM5NiwidGsiOiIyMjkxMTU0In19",
    "nord-authentication-status": "UNRECOGNIZED",
    "nord-channel-brand": "NORDSTROM_RACK",
    "nord-client-id": "APP03942",
    "nord-context-id": "aa7a76a9-de42-47b5-a1d7-d38c0e7f2778",
    "nord-country-code": "US",
    "nord-customer-experience": "DESKTOP_WEB",
    "nord-postalcode": "77084",
    "nord-request-id": "-i7MXskyQ4usQd259x5DHA",
    "nord-shopper-bearer-token": "",
    "nordapiversion": "1.0",
    "tracecontext": "882d216f-c38a-48bf-9218-1fdaf709f17a",
    "traceparent": "00-b46b9a38532c7dc0b43f7b8d0278693f-1dea36caaaa9c5ab-01",
    "tracestate": "2291154^@nr=0-1-2305121-302461386-1dea36caaaa9c5ab----1759826791396",
    "true-client-ip": "155.2.215.51",
    "true-user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
    "userauthentication": "UNRECOGNIZED",
    "userid": "4697dcdaeda5490c9fcc7ed7c8d97c5b",
    "userid-hashed": "",
    "userqualificationtype": "-1",
    "visitorstatus": "New Customer",
    "x-shopper-token": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0Njk3ZGNkYWVkYTU0OTBjOWZjYzdlZDdjOGQ5N2M1YiIsImF1ZCI6Imd1ZXN0IiwiaXNzIjoibm9yZHN0cm9tLWd1ZXN0LWF1dGgiLCJleHAiOjIwNzUzNTk0OTEsInJlZnJlc2giOjE3NTk4NDEwOTEsImp0aSI6ImRhYjZkMjVkLTczN2ItNDdjOS05NjJiLWZhODgxOTNmZTU3NyIsImlhdCI6MTc1OTgyNjY5MX0.QuAI-6GaYOvoj_nzc4sjRJFDWiJFx1va7MntTAVYbRFrT8Dm8-w4QvVLyl5Ofdy-zTrE2nKF2awSd8mg3ZBewmcKfNRNTxN0BGI520_EzbZ9fAN1Z7tbVl0ljPqo0gUUlc54oAjTMyqemXj4zeUcvtf6s82q1lHnV2M8TgGIruCCL6Q7_7K1s5S5ILNqnCPFI8zpfb3jxJXps1W6f3gWkuX0Nj6BsZcPvHYjIPxj2AxuwxMPO_j0blvxOZ1XbunNPhhO60Pmeo0yOPPKuYUnsuMNUiySdg2t70ax3p9ugo5Br3LcJ4-bapciMyGNpNnr-2BbwWId7tUGbb_iqRONfxE_BMrxX0YQG4iMqTrW2XzOJuJQKZdQt0Q_dCptgwll1APFymM7v0TuiBmhrJX_1yRcmMo_96UFo2mcy8jraRuvrFcFJ67t6Fm3n1o_M-OQM2N6LEKemHXbWEFw8KlCytZ6pyImVbbrklmpb-SamlNnxHRCts7RwQ7V2w5zvCxUVkU1Zo8wooaijJG24yQOo0pjFtqdKd5hjWWK6z6OmYDC1Iz4r3jmvyciypShpMkO4D-SoX4jurf9Y3DjgkSSJsiBs-PBrZKeh61K8NgNRWwOE-yuOi2QYfIBnPXOVBzevm77joRarv0Bdh4ARMS9p7G-55U6NgiM8I-iuRGSA0g",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=4",
    "TE": "trailers",
}


    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                headers=self.custom_headers,
                callback=self.parse
            )

    def parse(self, response):
        try:
            data = json.loads(response.text)
            products = data.get("productsById", {})
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        for product_id, product in products.items():
            item = couponsDealsItem()
            item['Title'] = product.get("name")
            
            # Get min price from regular price range
            regular = product.get("price", {}).get("regular", {}).get("priceRange", {}).get("min", {})
            item['Price'] = regular.get("units", 0) + regular.get("nanos", 0)/1e9

            # Get sale price from totalPriceRange min
            sale = product.get("price", {}).get("totalPriceRange", {}).get("min", {})
            item['SalePrice'] = sale.get("units", 0) + sale.get("nanos", 0)/1e9

            item['Offer'] = ""

            # Colors
            colors = product.get("colorsById", {})
            item['colors'] = [c.get("label") for c in colors.values()]

            # Images
            media = product.get("mediaById", {})
            images = []
            for color_id, color in colors.items():
                media_ids = color.get("mediaIds", [])
                for m_id in media_ids:
                    if m_id in media:
                        images.append(media[m_id].get("src"))
            item['Image'] = images

            # URL

            item['SiteName'] = "nordstrom"
            item['SiteURL'] = "https://www.nordstrom.com"
            item['Framework'] = "3"
            item['dealpage'] = "True"
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()

            yield item

        # Pagination
        
