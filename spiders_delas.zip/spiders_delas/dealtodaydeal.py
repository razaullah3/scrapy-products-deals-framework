from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import datetime

class dealtodaySpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'dealtodaydeal'
    start_urls = ['https://dealtoday.com.mt/']
    Sitename = 'dealtoday'
    siteurl = 'https://dealtoday.com.mt/'

    def parse(self, response):
        # Yield a 'getDoc' item first
        getdoc_item = couponsDealsItem()
        getdoc_item['getDoc'] = 'True'
        getdoc_item['SiteName'] = self.Sitename
        yield getdoc_item

        # XPaths
        divxpath = '//div[contains(@class,"inner grow")]'
        titalxpath = './/div[@class="t"]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/div[@class="value"]/text()'
        price2xpath = './/div[@class="price"]/text()'
        nextpage = ''  # Add XPath if there is a next page

        divs = response.xpath(divxpath)
        print(f"Total deals found: {len(divs)}")

        for div in divs:
            item = couponsDealsItem()
            item['Title'] = div.xpath(titalxpath).get(default='').strip()
            item['Image'] = div.xpath(imagexpath).get(default='').strip()

            # Prices
            price_text = div.xpath(pricexpath).get(default='').strip()
            sale_price_text = div.xpath(price2xpath).get(default='').strip()

            item['Price'] = price_text
            item['SalePrice'] = sale_price_text

            # Calculate offer if both prices exist
            try:
                price_val = float(price_text.replace('€','').replace('$','').replace(',',''))
                sale_val = float(sale_price_text.replace('€','').replace('$','').replace(',',''))
                if price_val > sale_val:
                    discount = ((price_val - sale_val) / price_val) * 100
                    item['Offer'] = f"{int(discount)}% off"
                else:
                    item['Offer'] = ''
            except:
                item['Offer'] = ''

            # URLs and site info
            item['SourceUrl'] = response.url
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['dealpage'] = 'True'

            # Datetime fields
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            item['DateAdded'] = now
            item['DateUpdated'] = now

            yield item

        # Handle pagination
       
