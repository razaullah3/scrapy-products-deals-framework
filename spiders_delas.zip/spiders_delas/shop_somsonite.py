from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class SamsoniteClearanceSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'samsonite_clearance'
    start_urls = ['https://shop.samsonite.com/sale/clearance/']
    Sitename = 'Samsonite'
    siteurl = 'https://shop.samsonite.com'

    def parse(self, response):
        # Initial doc item
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # XPaths & meta info
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="row product-grid"]//div[@class="col-6 col-sm-3"]'
        titalxpath = './/a[@class="link"]/text()'
        sourceurlxpath = './/a[@class="link"]/@href'
        imagexpath = './/img[@class="product-tile-image tile-image"]/@src'
        pricexpath = './/span[@class="sales"]/span[@class="value"]/text()'
        price2xpath = './/div[@class="comp-value-container"]/span[@class="comp-value-price"]/text()'
        otherxpath = ''
        nextpage = ''

        # Pass everything to Data_Collector
        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'sourceurlxpath': sourceurlxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
                'imageprefix': 'https:',   # ⚡ automatically add http/https if missing
                'sourceprefix': 'https:'   # ⚡ automatically add http/https if missing
            }
        )
