
    
import scrapy
import json
import datetime
from ..items import couponsDealsItem


class ReverbDealSpider(scrapy.Spider):
    name = "reverb_deal"
    api_url = "https://gql.reverb.com/graphql"
    limit = 45  # number of listings per page
    offset = 0  # starting offset

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://reverb.com/",
        "content-type": "application/json",
        "x-display-currency": "USD",
        "x-shipping-region": "US_CON",
        "x-context-id": "8fe870bc-7ee8-40e4-a5b7-e04717ebcfb0",
        "x-request-id": "9972575e1a3ccbf9",
        "x-reverb-app": "REVERB",
        "x-experiments": "proximity_features",
        "x-secondary-user-enabled": "false",
        "x-reverb-device-info": '{"platform":"web","app_version":0,"platform_version":null,"pathname":"/marketplace"}',
        "x-reverb-user-info": '{"mpid":null,"session_id":null,"device_id":null,"user_id":null,"ra":false,"is_bot":false}',
        "Origin": "https://reverb.com",
        "Connection": "keep-alive",
    }

    def start_requests(self):
        """Start with initial page offset=0"""
        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.custom_headers,
            body=self.make_payload(self.offset),
            callback=self.parse_api,
        )

    def make_payload(self, offset):
        """GraphQL POST body with pagination"""
        payload = {
            "operationName": "Core_Marketplace_CombinedMarketplaceSearch",
            "variables": {
                "inputListings": self.build_input(offset, self.limit),
                "inputAggs": self.build_input(offset, 0, aggs=True),
                "shouldntLoadBumps": True,
                "shouldntLoadSuggestions": False,
                "usingListView": False,
                "signalGroups": ["MP_GRID_CARD"],
                "useSignalSystem": False,
            },
            "query": """
            query Core_Marketplace_CombinedMarketplaceSearch(
                $inputListings: Input_reverb_search_ListingsSearchRequest,
                $inputAggs: Input_reverb_search_ListingsSearchRequest,
                $shouldntLoadBumps: Boolean!,
                $shouldntLoadSuggestions: Boolean!,
                $usingListView: Boolean!,
                $signalGroups: [reverb_signals_Signal_Group],
                $useSignalSystem: Boolean!
            ) {
                listingsSearch(input: $inputListings) {
                    total
                    listings {
                        _id
                        title
                        slug
                        pricing {
                            buyerPrice { display }
                            originalPrice { display }
                            ribbon { display }
                        }
                        images(input: {transform: "card_square", count: 1, scope: "photos", type: "Product"}) {
                            source
                        }
                        shop {
                            name
                        }
                    }
                }
            }
            """
        }
        return json.dumps(payload)

    def build_input(self, offset, limit, aggs=False):
        """Input structure for GraphQL"""
        data = {
            "query": "deals",
            "categorySlugs": [],
            "brandSlugs": [],
            "conditionSlugs": [],
            "shippingRegionCodes": [],
            "itemState": [],
            "itemCity": [],
            "curatedSetSlugs": [],
            "saleSlugs": [],
            "withProximityFilter": {"proximity": False},
            "boostedItemRegionCode": "US",
            "useExperimentalRecall": True,
            "traitValues": [],
            "excludeCategoryUuids": [],
            "excludeBrandSlugs": [],
            "likelihoodToSellExperimentGroup": 3,
            "countryOfOrigin": [],
            "contexts": ["INITIAL_QUERY"],
            "autodirects": "IMPROVED_DATA",
            "multiClientExperiments": [{"name": "spell_check_autocorrect", "group": "1"}],
            "canonicalFinishes": [],
            "skipAutocorrect": False,
            "limit": limit,
            "offset": offset,
            "fallbackToOr": True,
            "collapsible": "CANONICAL_PRODUCT_NEW_CONDITION_AND_TNP",
            "sort": "NONE",
        }
        if aggs:
            data["withAggregations"] = [
                "CATEGORY_SLUGS",
                "BRAND_SLUGS",
                "CONDITION_SLUGS",
                "DECADES",
                "CURATED_SETS",
                "COUNTRY_OF_ORIGIN",
            ]
        return data
    
    def debug_response(self, response):
        print("\n========== RAW RESPONSE DEBUG ==========\n")
        print(response.text[:2000])
        print("\n========================================\n")
        yield from self.parse_api(response)

    def parse_api(self, response):
        """Parse listings and handle pagination"""
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON response")
            return

        listings = data.get("data", {}).get("listingsSearch", {}).get("listings", [])

        if not listings:
            self.logger.info("No more listings found. Stopping pagination.")
            return

        for product in listings:
            item = couponsDealsItem()
            item["Sitename"] = "Reverb"
            item["Title"] = product.get("title")
            slug = product.get("slug")
            item["ProductUrl"] = f"https://reverb.com/item/{slug}"
            images = product.get("images", [])
            item["ImageUrl"] = images[0].get("source") if images else None
            price = product.get("pricing", {}).get("buyerPrice", {}).get("display")
            orig_price = product.get("pricing", {}).get("originalPrice", {}).get("display")
            item["Price"] = price
            item["ActualPrice"] = orig_price or price
            item["Discount"] = product.get("pricing", {}).get("ribbon", {}).get("display")
            item["ShopName"] = product.get("shop", {}).get("name")
            item["Date"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            yield item

        # Pagination: fetch next page
        self.offset += self.limit
        yield scrapy.Request(
            url=self.api_url,
            method="POST",
            headers=self.custom_headers,
            body=self.make_payload(self.offset),
            callback=self.parse_api,
        )
