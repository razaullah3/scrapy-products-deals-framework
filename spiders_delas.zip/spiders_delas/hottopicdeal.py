from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class hottopicdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'hottopicdeal'
    start_urls = ['https://www.hottopic.com/sale/shop-all-clearance/']
    Sitename = 'Hot Topic'
    siteurl = 'https://www.hottopic.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile"]'
        titalxpath = './/div[@class="pdp-link"]/a/text()'
        imagexpath = './/img/@src'
        pricexpath = '//div[@class="price"]//span[@class="strike-through list"]//span[@class="value"]/@content'
        price2xpath = './/div[@class="price"]//span[@class="sales " or @class="sales default-price"]//span[@class="value"]/@content'
        otherxpath = './/li[@id="promoLnOne"]/text()'
        nextpage = '//a[@class="page-next pagination-arrow "]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })