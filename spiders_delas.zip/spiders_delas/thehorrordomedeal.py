
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class thehorrordomedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'thehorrordomedeal'
    start_urls = ['https://www.thehorrordome.com/collections/halloween-package-deals']
    Sitename = 'The Horror Dome'
    siteurl = 'https://www.thehorrordome.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="grid-product__content"]'
        titalxpath = './/div[contains(@class,"title")]'
        imagexpath = './/div/@data-bgset'
        pricexpath = ''
        price2xpath = './/span[@class="money"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })