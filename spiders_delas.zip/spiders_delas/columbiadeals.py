import scrapy
import json
import datetime
from ..items import couponsDealsItem


class ColumbiaSaleSpider(scrapy.Spider):
    name = 'columbia'
    allowed_domains = ['search.unbxd.io', 'columbia.com']
    start_urls = [
        "https://search.unbxd.io/27fa0595fc0c03fe22895d52bc12e6b7/ss-unbxd-gus-prod-columbia-us35131753190941/category?p=categoryPath%3A%22sale%22&rows=47&start=0&pagetype=boolean&facet.multiselect=true&selectedfacet=true&variants.count=100"
    ]

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Referer": "https://www.columbia.com/",
        "Connection": "keep-alive"
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse
            )

    def parse(self, response):
        """Parse JSON API response and handle pagination."""
        try:
            data = json.loads(response.text)
            products = data.get("response", {}).get("products", [])
            total_products = data.get("response", {}).get("numberOfProducts", 0)
            start = data.get("response", {}).get("start", 0)
            rows = int(data.get("searchMetaData", {}).get("queryParams", {}).get("rows", 47))
        except Exception as e:
            self.logger.error(f"JSON parse error: {e}")
            return

        if not products:
            self.logger.warning("No products found on this page.")
            return

        for product in products:
            item = self.extract_product_item(product)
            print(json.dumps(dict(item), indent=4, default=str))  # Optional debug print
            yield item

        # --- Handle Pagination ---
        next_start = start + rows
        if next_start < total_products:
            next_url = f"https://search.unbxd.io/27fa0595fc0c03fe22895d52bc12e6b7/ss-unbxd-gus-prod-columbia-us35131753190941/category?p=categoryPath%3A%22sale%22&rows={rows}&start={next_start}&pagetype=boolean&facet.multiselect=true&selectedfacet=true&variants.count=100"
            yield scrapy.Request(
                url=next_url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse
            )

    def extract_product_item(self, product):
        """Extract the desired fields from each product."""
        item = couponsDealsItem()

        item['Title'] = product.get("pageTitle", "")
        item['Price'] = product.get("maxRegularPrice", "")
        item['SalePrice'] = product.get("maximumPrice", "")
        item['SourceUrl'] = product.get("masterUrl", "")
        item['Image'] = ", ".join(product.get("imageUrl", []))  # join list of images into one string

        # Additional meta info
        item['SiteName'] = "Columbia"
        item['SiteURL'] = "https://www.columbia.com"
        item['Framework'] = "3"
        item['Offer'] = ""
        item['dealpage'] = "True"
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()

        return item
