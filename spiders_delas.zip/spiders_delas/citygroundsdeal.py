import json
import scrapy
import datetime
from copy import deepcopy

from py_linq import Enumerable

from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class citygroundsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'citygroundsdeal'
    start_urls = ['https://www.citygrounds.com/collections/sale',
                  'https://www.citygrounds.com/collections/clearance-parts-and-accessories']
    Sitename = 'City Grounds'
    siteurl = 'https://www.citygrounds.com'

    def parse(self, response):
        collection_scope = response.text.split('"rid":')[1].split('}')[0]
        api_url = f'https://services.mybcapps.com/bc-sf-filter/filter?t=1668576968594&_=pf&shop=citygrounds.myshopify.com&page=1&limit=24&sort=manual&collection_scope={collection_scope}&tag=&product_available=true&variant_available=true&zero_options=true&build_filter_tree=true&check_cache=true'
        yield scrapy.Request(url=api_url, callback=self.parse_pagination, meta=response.meta, dont_filter=True)

    def parse_pagination(self, response):
        for req in self.getproducts(response):
            yield req

        api_response = json.loads(response.text)
        total_product = int(api_response['total_product'])
        if total_product % 24 == 0:
            total_page = total_product / 24
        else:
            total_page = total_product / 24 + 1

        for page in range(2, int(total_page + 1)):
            copy_url = deepcopy(response.url)
            url = copy_url.split('page=')[0] + 'page={}'.format(page) + '&limit=24' + copy_url.split('&limit=24')[1]
            yield response.follow(url, callback=self.getproducts, dont_filter=True)

    def getproducts(self, response):
        item = couponsDealsItem()

        listing_json = json.loads(response.text)
        for m in listing_json['products']:
            item['Title'] = m['title']

            available_variant = Enumerable(m['variants']).where(
                lambda x: int(x['inventory_quantity']) > 0).first_or_default()

            image = available_variant['image']
            if image:
                item['Image'] = image
            else:
                item['Image'] = m['images_info'][0]['src']

            price = available_variant['compare_at_price']
            if price:
                item['Price'] = f"${price}"
            else:
                item['Price'] = ''

            item['SalePrice'] = f"${available_variant['price']}"
            item['Offer'] = ''
            item['SourceUrl'] = f"{self.siteurl}/products/{str(m['handle'])}"
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item