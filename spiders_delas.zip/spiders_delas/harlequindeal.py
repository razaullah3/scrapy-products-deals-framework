from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class harlequindealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'harlequindeal'
    start_urls = ['https://www.harlequin.com/shop/pages/deals.html']
    Sitename = 'Harlequin'
    siteurl = 'https://www.harlequin.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="column column-block"]'
        titalxpath = './/a[@class="product__title-link"]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[contains(@class,"price--strike")]/text()'
        price2xpath = './/span[contains(@class,"our-price")]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })