from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class playstationdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'playstation'
    start_urls = ['https://store.playstation.com/en-us/category/3f772501-f6f8-49b7-abac-874a88ca4897/1']
    Sitename =' playstation'
    siteurl = 'https://www.store.playstation.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="psw-l-w-1/1"]/ul/li'
        titalxpath = './/span[@id="product-name"]/text()'
        imagexpath = './/img[@aria-hidden="true"]/@src'
        pricexpath = './/span[@class="psw-m-r-3"]/text()'
        price2xpath = './/s[@class="psw-c-t-2"]/text()'
        otherxpath = './/span[@class="offdisc"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })