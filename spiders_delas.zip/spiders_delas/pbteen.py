import json
import scrapy
import datetime
from ..items import couponsDealsItem  # Ensure this item has the fields you want

class PBTeenSpider(scrapy.Spider):
    name = 'pbteen_clearance'
    Sitename = 'PBTeen'
    siteurl = 'https://www.pbteen.com'
    
    start_urls = [
        'https://ac.cnstrc.com/browse/group_id/clearance-all?c=ciojs-client-2.66.0&key=key_QdCsKhJzRGmFMX0N&i=bd2dbde9-6235-40ed-ac90-c7b9568d5703&s=2&offset=0&num_results_per_page=20&&sort_order=descending&fmt_options%5Bhidden_facets%5D=smartDeskFeatures&pre_filter_expression=%7B%22or%22%3A%5B%7B%22or%22%3A%5B%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22COI_CMO%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22COI_SS%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22COI%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DEFAULT%22%7D%5D%7D%5D%7D&_dt=1763108427624'
    ]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://www.pbteen.com/',
        'Origin': 'https://www.pbteen.com',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
        'Priority': 'u=4'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get('results', [])
        self.logger.info(f"Found {len(products)} products on this page.")

        for p in products:
            item = couponsDealsItem()
            pdata = p.get('data', {})
            item['Title'] = pdata.get('title', '').strip()
            item['SourceUrl'] = pdata.get('url', '')
            item['thumb_image'] = pdata.get('thumb_image', '')
            item['salePriceMin'] = pdata.get('salePriceMin', None)
            item['highestPrice'] = pdata.get('highestPrice', None)
            item['Framework'] = '3'
            item["Offer"] = ''
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination / Load more
        offset = int(response.url.split('&offset=')[1].split('&')[0])
        total_results = data.get('total_results', None)
        num_results_per_page = data.get('num_results_per_page', 20)

        if total_results and (offset + num_results_per_page) < total_results:
            next_offset = offset + num_results_per_page
            next_url = response.url.replace(f'&offset={offset}', f'&offset={next_offset}')
            yield scrapy.Request(url=next_url, callback=self.parse, headers=self.headers)
