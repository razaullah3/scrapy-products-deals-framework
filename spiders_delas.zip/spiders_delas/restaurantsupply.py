import json
import scrapy
import datetime
from ..items import couponsDealsItem

class RestaurantSupplySpider(scrapy.Spider):
    name = 'restaurantsupply_deals'
    Sitename = 'RestaurantSupply'
    siteurl = 'https://www.restaurantsupply.com'
    
    start_urls = [
        'https://92xckf.a.searchspring.io/api/search/search.json?userId=70b41de3-d0af-4ab3-b20a-a20dc404156f&domain=https%3A%2F%2Fwww.restaurantsupply.com%2Fcollections%2Fclearance&sessionId=5e599722-e07e-40ba-8ba9-f0339b62410a&pageLoadId=9537554c-fe23-46c8-888e-7057ea3154c0&siteId=92xckf&resultsPerPage=24&bgfilter.collection_handle=clearance&ajaxCatalog=Snap&resultsFormat=native&page=1'
    ]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://www.restaurantsupply.com/',
        'Origin': 'https://www.restaurantsupply.com',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
        'Priority': 'u=4'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get('results', [])
        self.logger.info(f"Found {len(products)} products on this page.")

        for p in products:
            item = couponsDealsItem()
            item['Title'] = p.get('name', '').strip()
            item['Image'] = p.get('imageUrl', '')
            item['SourceUrl'] = self.siteurl + p.get('url', '')  # concatenate with base_url
            item['Price'] = p.get('price', None)     # Sale Price
            item['SalePrice'] = p.get('msrp', None)  # Old Price
            item['Framework'] = '3'
            item["Offer"] = ''
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        current_page = data.get('pagination', {}).get('currentPage', 1)
        total_pages = data.get('pagination', {}).get('totalPages', 1)
        if current_page < total_pages:
            next_page = current_page + 1
            next_url = response.url.split('&page=')[0] + f'&page={next_page}'
            yield scrapy.Request(url=next_url, callback=self.parse, headers=self.headers)
