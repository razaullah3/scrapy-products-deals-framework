from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class tacticsldealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'tacticsdeal'
    start_urls = ['https://www.tactics.com/search/deal']
    Sitename = 'Tactics'
    siteurl = 'https://www.tactics.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="browse-grid-item"]'
        titalxpath = './/img/@alt'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="browse-grid-item-price"]/text() | //span[@class="browse-grid-item-sale-price"]/text()'
        price2xpath = ''
        otherxpath = ''
        nextpage = '//a[@class="pagination-next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })