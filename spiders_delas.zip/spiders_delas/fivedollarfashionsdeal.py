from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class fivedollarfashionsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = '5dollarfashionsdeal'
    start_urls = ['https://5dollarfashions.com/new-deals/']
    Sitename = '5DollarFashions'
    siteurl = 'https://5dollarfashions.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//form/div[@class="module-wrapper"]/div/div'
        titalxpath = './/h4/a/text()'
        imagexpath = './/img/@data-src'
        pricexpath = './/span[@class="price price--rrp"]/text()'
        price2xpath = './/span[@class="price price--withoutTax"]/text()'
        otherxpath = ''
        nextpage = '//li[@class="pagination-item pagination-item--next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
