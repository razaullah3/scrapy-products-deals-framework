import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class lgdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'lgdeal'
    start_urls = ['https://www.lg.com/us/promotions']
    Sitename = 'LG'
    siteurl = 'https://www.lg.com'

    def start_requests(self):
        api_url = 'https://platform.cloud.coveo.com/rest/search/v2?organizationId=lgelectronicsusaproductionh9cyypz4'

        # Headers including the authorization token
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyR3JvdXBzIjpbIk9CUyJdLCJ2OCI6dHJ1ZSwiZW5mb3JjZWREaWN0aW9uYXJ5RmllbGRDb250ZXh0Ijp7ImVjX21lbWJlcnNfZXhjbHVzaXZlX2VuYWJsZSI6Ik9CUyIsImVjX2RlbGl2ZXJ5X3RleHQiOiJPQlMiLCJlY19vYnNfc2VsbF9mbGFnIjoiT0JTIiwiZWNfcHJpY2VfdHlwZV9jb2RlIjoiT0JTIiwiZWNfaXNfYmFja29yZGVyIjoiT0JTIiwiY2xpY2thYmxldXJpIjoiT0JTIiwiZWNfa2xhcm5hIjoiT0JTIiwiZWNfcHJvbW90aW9uc19saXN0IjoiT0JTIiwiZWNfaGFuZHlfZW5hYmxlIjoiT0JTIiwiZWNfbWRza3UiOiJPQlMiLCJlY19maW5hbF9wcmljZSI6Ik9CUyIsImVjX29iX2ZsYWciOiJPQlMiLCJlY19jdGFfdHlwZV9jb2RlIjoiT0JTIiwiZWNfbWVtYmVyc19leGNsdXNpdmUiOiJPQlMiLCJlY19pc19tZXIiOiJPQlMiLCJlY19yZXdhcmRfcG9pbnRzX2VuYWJsZSI6Ik9CUyIsImVjX21lbWJlcnNoaXBfcHJpY2UiOiJPQlMiLCJlY19kZWZhdWx0X3Byb2R1Y3RfdGFnIjoiT0JTIiwiZWNfZXJwX3R5cGUiOiJPQlMiLCJlY19pc19tZW1iZXJzaGlwX3ByaWNlIjoiT0JTIiwiZWNfaXNfc3Vic2NyaXB0aW9uIjoiT0JTIiwiZWNfcmV3YXJkX3BvaW50c19kZXRhaWwiOiJPQlMifSwidG9rZW5JZCI6InZnd3k0eXJpdTRqeG83aWxld3VhYWUyZWE0Iiwib3JnYW5pemF0aW9uIjoibGdlbGVjdHJvbmljc3VzYXByb2R1Y3Rpb25oOWN5eXB6NCIsInVzZXJJZHMiOlt7InR5cGUiOiJVc2VyIiwibmFtZSI6Im9yZGVyc0BsZ3N1cHBvcnQuY29tIiwicHJvdmlkZXIiOiJFbWFpbCBTZWN1cml0eSBQcm92aWRlciJ9XSwicm9sZXMiOlsicXVlcnlFeGVjdXRvciJdLCJpc3MiOiJTZWFyY2hBcGkiLCJleHAiOjE3NTc0ODYwMDgsImlhdCI6MTc1NzM5OTYwOH0.ABxp2shcSLhjePpf03kK1pcl6Tg5WMJEsm0eFfPqaX0'
        }

        # Building request body based on the provided JSON
        post_data = {
            "locale": "en-US",
            "debug": False,
            "tab": "Top Deals",
            "referrer": "default",
            "timezone": "UTC",
            "visitorId": "89f6c795-55e6-4074-a084-d62cf251e625",
            "cq": "@ec_store_code=\"OBS\" @ec_model_status_code===ACTIVE",
            "context": {
                "organization": "OBS"
            },
            "fieldsToInclude": [
                "ec_model_display_name", "ec_medium_image_addr", "ec_small_image_addr",
                "ec_msrp", "ec_final_price", "ec_promotions_list", "clickableuri",
                "ec_in_stock", "title"
            ],
            "dictionaryFieldContext": {
                "organization": "OBS",
                "ec_in_stock": "OBS.N1F"
            },
            "searchHub": "LG.com - Commerce - PDS - Listing",
            "sortCriteria": "relevancy",
            "numberOfResults": 300,  # Increased number of results to get more items in a single request
            "firstResult": 0
        }

        # Send the POST request with JSON data
        yield scrapy.Request(
            url=api_url,
            method='POST',
            body=json.dumps(post_data),
            headers=headers,
            callback=self.parse
        )

    def parse(self, response):
        try:
            # Parse the Coveo API response
            data = json.loads(response.text)

            # Extract results from the response
            results = data.get('results', [])
            self.logger.info(f"Total number of results: {len(results)}")

            for product in results:
                # Skip items not in stock
                if product.get('raw', {}).get('ec_in_stock') != 'Y':
                    continue

                item = couponsDealsItem()

                # Basic product information
                raw_data = product.get('raw', {})

                # Get the title
                item['Title'] = raw_data.get('ec_model_display_name', product.get('title', ''))

                # Handle image - prioritize medium image, fall back to small image
                item['Image'] = raw_data.get('ec_medium_image_addr', raw_data.get('ec_small_image_addr', ''))

                # Price handling
                msrp = raw_data.get('ec_msrp')
                if msrp:
                    item['Price'] = f"${msrp}"
                else:
                    item['Price'] = ''

                # Sale price
                final_price = raw_data.get('ec_final_price')
                if final_price:
                    item['SalePrice'] = f"${final_price}"
                else:
                    item['SalePrice'] = ''

                # Get promotions
                promotions = raw_data.get('ec_promotions_list', [])
                if promotions and len(promotions) > 0:
                    item['Offer'] = promotions[0]  # Use the first promotion
                else:
                    item['Offer'] = ''

                # URL handling
                url = product.get('clickUri', '')
                if not url:
                    url = raw_data.get('clickableuri', product.get('uri', ''))

                if url.startswith('//'):
                    url = f"https:{url}"
                elif not url.startswith('http'):
                    url = f"{self.siteurl}{url}"

                item['SourceUrl'] = url
                item['Framework'] = '3'
                item['SiteName'] = self.Sitename
                item['SiteURL'] = self.siteurl
                item['DateAdded'] = datetime.datetime.now()
                item['DateUpdated'] = datetime.datetime.now()
                item['dealpage'] = 'True'

                yield item

            # Log total count information
            total_count = data.get('totalCount', 0)
            self.logger.info(f"Total items available from API: {total_count}")
            self.logger.info(f"Items processed in this request: {len(results)}")

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
        except Exception as e:
            self.logger.error(f"Error processing response: {e}")
            import traceback
            self.logger.error(traceback.format_exc())