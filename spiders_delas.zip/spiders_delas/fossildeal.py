import scrapy
import re
import math
import urllib.parse

from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class fossildealSpider(GetDealsProducts):
    handle_httpstatus_list = [404, 403]
    name = 'fossildeal'
    start_urls = ['https://www.fossil.com/en-us/sale/']
    Sitename = 'Fossil'
    siteurl = 'https://www.fossil.com'

    # Custom headers to avoid anti-bot detection
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Referer': 'https://www.fossil.com/',
        'Origin': 'https://www.fossil.com',
        'Sec-Ch-Ua': '"Not.A/Brand";v="8", "Chromium";v="112", "Google Chrome";v="112"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Priority': 'u=0, i',
        'TE': 'trailers'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                headers=self.headers,
                callback=self.parse_total_results,
                dont_filter=True
            )

    def decode_url(self, url_string):
        """Decode URL to handle special characters and URL encoding"""
        url_string = url_string.replace("&amp;", "&")
        parsed = urllib.parse.urlparse(url_string)
        query_params = urllib.parse.parse_qs(parsed.query)
        decoded_query = urllib.parse.urlencode(query_params, doseq=True)
        decoded_url = urllib.parse.urlunparse((
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            parsed.params,
            decoded_query,
            parsed.fragment
        ))
        return decoded_url

    def parse_total_results(self, response):
        # Extract total number of results
        total_results_text = response.xpath('//span[@class="d-none d-lg-block"]/text()').get('')
        total_results = 0

        # Extract numeric value using regex
        match = re.search(r'\d+', total_results_text)
        if match:
            total_results = int(match.group())
        else:
            # If we can't find the count, try to look for another element
            total_results_alt = response.xpath('//div[@class="result-count"]//text()[contains(., "Results")]').get('')
            match_alt = re.search(r'\d+', total_results_alt)
            if match_alt:
                total_results = int(match_alt.group())
            else:
                # Default to a high number to ensure we capture all products
                total_results = 1000
                self.logger.warning("Couldn't extract total results, defaulting to 1000")

        # Calculate total pages (12 products per page)
        total_pages = math.ceil(total_results / 12)

        # First, process the initial page
        yield from self.parse_page(response)

        # Look for "View More" button and its URL
        view_more_url = response.xpath('//div[@class="show-more"]/div/button/@data-url').get()

        if view_more_url:
            # If view more URL exists, start processing pagination through AJAX
            decoded_url = self.decode_url(view_more_url)

            # Extract base URL for pagination
            base_url_match = re.match(r'(.*start=)(\d+)(&.*)', decoded_url)
            if base_url_match:
                base_url_prefix = base_url_match.group(1)
                base_url_suffix = base_url_match.group(3)

                # Use AJAX pagination pattern
                for offset in range(12, total_results, 12):
                    ajax_url = f"{base_url_prefix}{offset}{base_url_suffix}"
                    yield scrapy.Request(
                        url=ajax_url,
                        headers=self.headers,
                        callback=self.parse_ajax_page,
                        dont_filter=True
                    )
            else:
                # Fallback to standard pagination if URL pattern doesn't match
                for page in range(1, total_pages + 1):
                    page_url = f'{self.start_urls[0]}?&page={page}'
                    yield response.follow(
                        page_url,
                        callback=self.parse_page,
                        headers=self.headers,
                        dont_filter=True
                    )
        else:
            # Fallback to standard pagination if "View More" button not found
            for page in range(1, total_pages + 1):
                page_url = f'{self.start_urls[0]}?&page={page}'
                yield response.follow(
                    page_url,
                    callback=self.parse_page,
                    headers=self.headers,
                    dont_filter=True
                )

    def parse_ajax_page(self, response):
        """Parse AJAX loaded pages from 'View More' button"""
        # Process data from AJAX response
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile "]'
        titalxpath = './/div[@class="pdp-link truncated-product-name"]/a/text()'
        imagexpath = './/a[@class="slide-link"]/img/@data-src'
        pricexpath = './/span[@class="strike-through list like-style-messaging"]/span/text()'
        price2xpath = './/div[@class="sales like-style-price"]/span/text()'
        otherxpath = './/span[@class="like-style-percent-off"]/text()'
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.headers,
            dont_filter=True,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
                'ajax_response': True  # Flag to indicate this is an AJAX response
            }
        )

    def parse_page(self, response):
        """Parse standard pages"""
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile "]'
        titalxpath = './/div[@class="pdp-link truncated-product-name"]/a/text()'
        imagexpath = './/a[@class="slide-link"]/img/@data-src'
        pricexpath = './/span[@class="strike-through list like-style-messaging"]/span/text()'
        price2xpath = './/div[@class="sales like-style-price"]/span/text()'
        otherxpath = './/span[@class="like-style-percent-off"]/text()'
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.headers,
            dont_filter=True,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )