import scrapy
import json
import datetime
from ..items import couponsDealsItem


class WestElmClearanceSpider(scrapy.Spider):
    name = "westelm"
    allowed_domains = ["ac.cnstrc.com", "westelm.com"]
    Sitename = "WestElm"
    siteurl = "https://www.westelm.com"

    # Pagination parameters
    num_results_per_page = 20
    offset = 0

    def start_requests(self):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Referer": "https://www.westelm.com/",
            "Origin": "https://www.westelm.com",
            "Connection": "keep-alive",
            "DNT": "1",
            "Sec-GPC": "1",
        }

        url = self._build_api_url(self.offset)
        yield scrapy.Request(url=url, headers=headers, callback=self.parse, meta={"offset": self.offset})

    def _build_api_url(self, offset):
        """Helper to build paginated API URL."""
        return (
            f"https://ac.cnstrc.com/browse/group_id/clearance"
            f"?c=ciojs-client-2.66.0"
            f"&key=key_SQBuGmXjiXmP0UNI"
            f"&i=f119bd62-afa9-47a5-a434-e7f66b221b7c"
            f"&s=1"
            f"&offset={offset}"
            f"&num_results_per_page={self.num_results_per_page}"
            f"&sort_order=descending"
            f"&fmt_options%5Bhidden_facets%5D=smartDeskFeatures"
            f"&pre_filter_expression=%7B%22or%22%3A%5B%7B%22or%22%3A%5B%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_SS%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_CMO%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DEFAULT%22%7D%5D%7D%5D%7D"
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        # Navigate to $..response..results
        results = []
        if "response" in data and "results" in data["response"]:
            results = data["response"]["results"]

        if not results:
            self.logger.info("No more results found — stopping pagination.")
            return

        self.logger.info(f"Found {len(results)} products at offset {response.meta['offset']}")

        for res in results:
            prod = res.get("data", {})
            item = couponsDealsItem()

            item["Title"] = prod.get("title", "").strip()
            item["SourceUrl"] = prod.get("url", "")
            item["Image"] = prod.get("image_url", "")
            item["Price"] = prod.get("regularPriceMax", "")
            item["SalePrice"] = prod.get("salePriceMax", "")
            item["Offer"] = ""
            item["Framework"] = "3"
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"

            yield item

        # Handle pagination
        next_offset = response.meta["offset"] + self.num_results_per_page
        next_url = self._build_api_url(next_offset)

        yield scrapy.Request(
            url=next_url,
            headers=response.request.headers,
            callback=self.parse,
            meta={"offset": next_offset},
        )
