from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class totaldiabetessupplyealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'touchofclassdeal'
    start_urls = ['https://www.touchofclass.com/bedding-deals/c/20517/',
                  'https://www.touchofclass.com/clearance/c/209/']
    Sitename = 'Touch of Class'
    siteurl = 'https://www.touchofclass.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-grid-item"]'
        titalxpath = './/div[@class="prod-title"]/text()'
        imagexpath = './/a/img/@data-src'
        pricexpath = './/div[@class="price-was"]/text()'
        price2xpath = './/div[@class="price-sale"]/text()'
        otherxpath = ''
        nextpage = ''#'//div[@class="col-2 text-right"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })