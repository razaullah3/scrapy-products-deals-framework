import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class davidsbridalSpider(GetDealsProducts):
    name = 'davidsbridaldeal'
    start_urls = ['https://www.davidsbridal.com/sale/all-sale',
                  'https://www.davidsbridal.com/sale/all-sale-accessories']
    Sitename = 'Davids Bridal'
    siteurl = 'https://www.davidsbridal.com'

    def start_requests(self):
        # Updated category IDs and API structure
        cat_configs = {
            'https://www.davidsbridal.com/sale/all-sale': {
                'category_id': '296',
                'rows': 1450  # Adjust based on expected number of products
            },
            'https://www.davidsbridal.com/sale/all-sale-accessories': {
                'category_id': '286',
                'rows': 592  # Based on your example showing 592 products
            }
        }

        for start_url, config in cat_configs.items():
            # New API URL structure
            api_url = (f"https://www.davidsbridal.com/api/plp/category?"
                       f"q={config['category_id']}&page=1&rows={config['rows']}&"
                       f"offset=0&customBRFilter=null&efq=")

            yield scrapy.Request(
                url=api_url,
                callback=self.parse,
                meta={'original_url': start_url}
            )

    def parse(self, response):
        """Parse the API response and extract product data"""
        try:
            data = json.loads(response.text)
            docs = data.get('response', {}).get('docs', [])

            for product in docs:
                yield self.extract_product_item(product)

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
        except Exception as e:
            self.logger.error(f"Error parsing response: {e}")

    def extract_product_item(self, product):
        """Extract product information and create item"""
        item = couponsDealsItem()

        # Extract basic product information
        item['Title'] = product.get('product_name', '')
        item['Image'] = product.get('thumb_image', '')

        # Extract pricing information
        regular_price = product.get('price', 0)
        sale_price = product.get('sale_price', 0)
        price_range = product.get('price_range', [])
        sale_price_range = product.get('sale_price_range', [])

        # Format regular price
        if price_range and len(price_range) >= 2:
            min_price, max_price = price_range[0], price_range[1]
            if min_price == max_price:
                item['Price'] = f"${min_price}"
            else:
                item['Price'] = f"${min_price} - ${max_price}"
        else:
            item['Price'] = f"${regular_price}" if regular_price else ""

        # Format sale price
        if sale_price_range and len(sale_price_range) >= 2:
            min_sale, max_sale = sale_price_range[0], sale_price_range[1]
            if min_sale == max_sale:
                item['SalePrice'] = f"${min_sale}"
            else:
                item['SalePrice'] = f"${min_sale} - ${max_sale}"
        else:
            item['SalePrice'] = f"${sale_price}" if sale_price else ""

        # Calculate discount percentage if both prices are available
        if regular_price and sale_price and regular_price > sale_price:
            discount_percent = round(((regular_price - sale_price) / regular_price) * 100)
            item['Offer'] = f"{discount_percent}% off"
        else:
            item['Offer'] = ''

        # Extract product URL
        product_url = product.get('url', '')
        if product_url:
            item['SourceUrl'] = product_url
        else:
            # Fallback: construct URL from handle if available
            handle = product.get('handle', '')
            if handle:
                item['SourceUrl'] = f"{self.siteurl}/products/{handle}"
            else:
                item['SourceUrl'] = ""

        # Set standard fields
        item['Framework'] = '3'
        item['SiteName'] = self.Sitename
        item['SiteURL'] = self.siteurl
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = 'True'

        return item

    def get_total_products(self, response):
        """Helper method to get total number of products (for logging)"""
        try:
            data = json.loads(response.text)
            return data.get('response', {}).get('numFound', 0)
        except:
            return 0