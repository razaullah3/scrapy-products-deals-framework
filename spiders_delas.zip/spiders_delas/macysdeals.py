from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class lionelstoredealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'macys'
    start_urls = ['https://www.macys.com/shop/sale/clearance-closeout?id=54698']
    Sitename = 'Macys store'
    siteurl = 'https://www.macys.com'

    # ✅ Custom headers for all requests
    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Cookie': 'visitor_fpid_id=0174f7c2-bbb3-4543-83c9-f75a4abf26a0; MISCGCs=USERPC1_92_606023_87_USERLL1_92_41.883886%2C-87.6262783_87_USERST1_92_IL3_87_LOCST1_92_IL3_87_USERDMA1_92_6023_87_DT1_92_PC3_87_BOPSPICKUPSTORE1_92_45923_87_BTZIPCODE1_92_606023_87_PDDST1_92_IL; SEED=1345772221601433682%7C2152-21%2C2157-21%2C2512-21%7C1162-21%2C2111-21%2C2135-21%2C2137-21%2C2161-21%2C2465-23%2C2483-22%2C2486-20%2C2490-21%2C2504-21%2C2528-11%2C2545-21%2C2547-21%2C2550-21%2C2570-21%2C2601-21%2C2634-21%2C2635-20; _abck=58B0DE1BD287CE507884869CAA5CC441~-1~YAAQLx/XFxR7JKaZAQAA6wCzww7KtcLkOVksUey1sI8nZJFQirIg1WLKFYUqewDs5RNa/6o+sjaBIlrkn/dIW/qdkUD6On9QAxkQWDl9Pupcr0BgL1XikoAE5javTrFN5fuAD9cZeFciwV2FtvWerhrCZYaDM35ptrKPZBhkq3qCyXusJxzdIFz1oBUCpOYZ6uL24MyTY2wB43jd/gYLWhaKDhXN83ZuJ1MB63Cxm7wDCnN0p5s1YO3ikPA+9sh1RVYVZiRO0qCpTAGlSS1z5Cn/CSdmcCrE8M3n+U/ovOPc9uEPns7aTj02KndVgYXfhXwI6wPsMKssoz9suW/IYQBIsrTsqlInkn51Zx0CLp5n382CGIDuZUfafi+Kv5TQiuLJOFehfWWRXPj9PnSV9UouKs3HmJTzDYzUYtUGzWdkK8GVCozm7w60d0WSNNwHT4x+iFDA5UZuzV1qRYK4DaWitpMLaSIBNQWFWe0o2/R8CJjdUzhtIPLPJqXw5wo4y0j2CCcI/GEiPZEgwA+NZlXGVqF+ZzdBFeYr5X1HbmNcoqdSWzfLmPOUtR+ajPPfdpnTKSWDMuH+v2XELYqdrn6Rk9Mm/9n8aDYkG+nLxsJ6jiQ5gXSzAjkDt3F5hkGe7C7TIusH4ak9KlOj668K0q0vG6kp5OLQhJ+dFIj2jwP7tmFijJNbEMj+TlAHilahbMaf5XMIXKKBZ/jmZe6tltyr~-1~-1~1759928512~AAQAAAAE%2f%2f%2f%2f%2f2S228YhFXtINfwIr%2fx2jIXIQhbu8Mcd2+5OUUPzgx3egObiWQC97ekouRjoxPRY4A4iADzGNq3Y2GxDa+0lO46lgBHbXeTHH6Km3641012J%2fu%2f5JNahqwuIzhlvj7O+WPvG5YU%3d~1759924972; RT="z=1&dm=macys.com&si=848b8091-9646-4469-97be-b619db227bef&ss=mghw4dj9&sl=0&tt=0&bcn=%2F%2F17de4c1f.akstat.io%2F"; utag_main=v_id:0199be42dbf60016f1cf21cb181f05050002700d0086e^$_n:2^$_e:3^$_s:0^$_t:1759923808572^$ses_id:1759921311789%3Bexp-session^$_n:3%3Bexp-session; OptanonConsent=isGpcEnabled=1&datestamp=Wed+Oct+08+2025+16%3A13%3A29+GMT%2B0500+(Pakistan+Standard+Time)&version=202502.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=f2cd6367-2927-42c0-bfae-5dcaf1e3f7c0&interactionCount=1&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0002%3A1%2CSPD_BG%3A0%2CC0005%3A0%2CC0004%3A0&AwaitingReconsent=false; RTD=99be44bc75059099be44bc7599b099be44bc758cd099be44bc75a170; BVBRANDID=c074893b-429f-45a5-b326-46e14afe7a78; GCLB=CNyrtKbnvsyoKRAD; shippingCountry=US; currency=USD; SignedIn=0; GCs=CartItem1_92_03_87_UserName1_92_4_02_; mercury=true; akavpau_www_www1_macys=1759922306~id=fcb6d54111fe235f78b6c86789537804; ak_bmsc=6036C0AE795DEAD2F36C4DCAA5FEC752~000000000000000000000000000000~YAAQMh/XF7mYmayZAQAAfxN8wx1yCpYKvsf05Isir+YFazao7UVXHT32pITACNDTgM5JBfsKQYuHPy2cu3ATOAK/p8mcckQI43OIdlTRqL2lUxnOSHmI/sJZj41+LQz92lvENAF5FWHBvSGH5vgeSW62k8XJ3GQYSI4hkV5w8hJpARVIaT2NBHzuQT98ttoIwIub8jc18ey1AKd7RcVMaYqiyhDc4dACUvcLvWGTk+SYn0+OEQG4uV+v0OsPQOqEgym9prv3alDMF0NDHmqk1qZuQOy7WAQGMl2+S+ABqf9YnZjzAtF868Cv7aq4gxIDwS/slcJilVizM0qTaHgImDcG7E40AOSg57BeTIRkZvlc220vBVdPkcWCBH0CJf3FlNTRw/fJAfGp3RY7yQ+/YQAFT0rjwwb2mirvC+KWnyFoRmYqHhGDSUOexWo1qOrHjtNiM6S4epmI3g==; bm_sz=541305A356A72CE828F4A567E62CE7BD~YAAQLx/XFxV7JKaZAQAA7ACzwx32VnkLdBDdjYvqYBcKYYi7Y4btfcexntKs0VfuDp01vR3GFShrYCl3hIFlB62O4vzvU+zZPfytnKapHvFQeXe3y21LDZyJZ4IaQy09r7B5yXajrhXHaXVzxsmjFwbN9jmtqYhkvobMnb25QythoupPoLc+jIvQ+6JbkQRsIze/Woq15ALmU+dmdcKhJ3dhsMW62SWpczZ+VnQVCIyKefBrUuoz48clmxZBHGe7v1Ao/PMY4h3o84GE019OCdqIfvjGzvSLh+OeF4MbhwcUoIN9nRN4hTUcJ0I+HHkMq/MEG3F0AhOke5GcKMjr9WBQctZsUR7Ru5nZq9ccoC9MdCk4o8BfYIrVSOZWU1tpmeQV6RBz/CmE2ztyNhzE4wP3n/vBGse5bEQDPaSjNmjsJbohLQM3rG5bI6c/~4469304~4469561; bm_sv=0465F404497CF60AB5E5DEB897EA3FBD~YAAQLh/XF084uqWZAQAAJymjwx2LXETYtWkO1rQ5Sar5ZGhuUHh71cau0v28w6YTN4OQoSopg1tmuALDOl5YvpgoEjRlZyXvwQGrJBHwRe8veNJfeJaWedo3JDPN/839wwdRn4MDL3Vo5rG9ZUhf1zn+bUOPlkd2U0GLxldeiZUyuri1eBL81bz18V4VVj9JZ094ngJROrgyLd1RchvABGQQXf0NDCX+mmPcUHqLoAP959DIKFblL8mxnsQdjbX2~1; CSL=4592'
        }
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="cell sortablegrid-product"]'
        titalxpath = './/div[@class="description-spacing"]/a/@title'
        imagexpath = '//div[@class="description-spacing"]/a/@href'
        pricexpath = './/div[@class="current-prev-value-labels"]/@aria-label'
        price2xpath = './/span[@class="discount is-tier2"]/@aria-label'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
