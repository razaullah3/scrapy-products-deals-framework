from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class babestadealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'babestadeal'
    start_urls = ['https://babesta.com/collections/all-sales']
    Sitename = 'Babesta'
    siteurl = 'https://www.babesta.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="grid-product__content"]'
        titalxpath = './/div[@class="grid-product__title grid-product__title--body"]/text()'
        imagexpath = './/image-element[@data-aos="image-fade-in"]/img/@src'
        pricexpath = './/span[@class="grid-product__price--original"]/text()'
        price2xpath = './/div[contains(@class, "grid-product__price")]/text()[not(parent::span)][normalize-space()]'
        otherxpath = './/span[@class="grid-product__price--savings"]/text()'
        nextpage = '//a[@title="Next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })