from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bottleblingdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'idealfitdeal'
    start_urls = ['https://www.myprotein.com/c/all-offers/clearance-multibuy/']
    Sitename = 'myprotein'
    siteurl = 'https://www.myprotein.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="byob-item-card h-full max-w-[350px] relative group flex flex-col justify-start w-full cursor-pointer shadow-md rounded-xl"]'
        titalxpath = './/div[@class="mt-3 flex flex-col text-left gap-1 p-1"]/button/text()'
        imagexpath = './/div[@class="byob-item-picture-wrapper aspect-square product-item"]/figure/picture/img/@src'
        pricexpath = './/s[@class="mt-6 mr-1 text-gray-500 font-normal text-base"]/text()'
        price2xpath = './/span[@class="item-display-price text-primary font-bold text-base"]/text() | //p[@class="item-display-price mt-1 font-bold text-base"]/text()'
        otherxpath = './/p[@class="text-red-900 text-base font-bold"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })