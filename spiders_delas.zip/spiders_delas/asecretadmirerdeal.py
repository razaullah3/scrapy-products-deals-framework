from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class asecretadmirerdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'asecretadmirerdeal'
    start_urls = ['https://asecretadmirer.com/collections/clearance-sale']
    Sitename = 'A Secret Admirer'
    siteurl = 'https://www.asecretadmirer.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-block__inner"]'
        titalxpath = './/div[@class="product-block__title-price"]/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="theme-money"]/text()'
        price2xpath = './/span[@class="amount theme-money"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })

        def parse(self, response):
            item = couponsDealsItem()
            item['getDoc'] = 'True'
            item['SiteName'] = self.Sitename
            yield item
            item['getDoc'] = ''
            categorypage = ''
            subcategorypage = ''
            attribute = ''
            divxpath = '//div[@class="product-block__inner"]'
            titalxpath = './/div[@class="product-block__title-price"]/a/text()'
            imagexpath = './/img/@src'
            pricexpath = './/span[@class="theme-money"]/text()'
            price2xpath = './/span[@class="amount theme-money"]/text()'
            otherxpath = ''
            nextpage = ''

            yield response.follow(response.url, callback=self.Data_Collector, meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            })