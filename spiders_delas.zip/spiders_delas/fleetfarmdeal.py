from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy


class fleetfeetdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'fleetfarmdeal'
    start_urls = ['https://www.fleetfarm.com/search?Ntt=d&_=1763103387350&No=24']
    Sitename = 'Fleet Farm'
    siteurl = 'https://www.fleetfarm.com'

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                headers=self.custom_headers,
                callback=self.parse
            )

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li/div[@class="product-tile-desktop"]'
        titalxpath = './/div[@class="product-name"]/a/text()'
        imagexpath = './/picture/img/@src'
        pricexpath = './/strike/span/text()'
        price2xpath = './/div[@class="regular-price regular-price-bold"]/span[1]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.custom_headers,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            },
            dont_filter=True  # <<< Prevent duplicate filtering
        )
