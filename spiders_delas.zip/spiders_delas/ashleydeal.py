from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
from scrapy import Request
import random

class ashleydealSpider(GetDealsProducts):
    name = 'ashleydeal'
    start_urls = ['https://www.ashleyfurniture.com/c/clearance-furniture/']
    Sitename = 'Ashley'
    siteurl = 'https://www.ashleyfurniture.com'


    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0",
    ]

    def start_requests(self):
        self.headers = {
            "User-Agent": random.choice(self.user_agents),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.ashleyfurniture.com/",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-User": "?1",
        }

        for url in self.start_urls:
            yield Request(url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ""
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile"]'
        titalxpath = './/a[@class="name-link"]/text()'
        imagexpath = './/img[@class="primary-image"]/@src'
        pricexpath = './/span[@class="product-standard-price"]/del/text()'
        price2xpath = './/span[@class="product-sales-price"]/span/text()'
        otherxpath = ''
        nextpage = '//a[@rel="next"]/@href'
        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
            },headers=self.headers, dont_filter=True)