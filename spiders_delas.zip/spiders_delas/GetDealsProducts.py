import datetime
import re
import string
import scrapy
import validators
from ..Oprfunction import Textfunctions
from ..items import couponsDealsItem


class GetDealsProducts(scrapy.Spider):
    ########################################### REQUIRED DATA GETTING COLLECTED ############################################
    handle_httpstatus_list = [404]
    data = []
    maincaturl = []
    mainurlscounter = 0
    DealsData = []
    suburls = []
    urlscounter = 0
    Deals = []
    flag = 0
    saveindb = 0

    def use_headers(self):
        """Check if headers are defined and should be used"""
        return hasattr(self, 'headers') and self.headers

    def get_follow_kwargs(self):
        """Generate keyword arguments for resp.follow based on headers availability"""
        kwargs = {'dont_filter': True}
        if self.use_headers():
            kwargs['headers'] = self.headers
        return kwargs

    def Data_Collector(self, resp):
        global attributex
        global divxpathx
        global titalxpathx
        global imagexpathx
        global pricexpathx
        global price2xpathx
        global otherxpathx
        global subcategorypagex
        global nextpagex
        global categorypagex
        global urlx
        global snamex
        attributex = resp.meta.get('attribute')
        divxpathx = resp.meta.get('divxpath')
        titalxpathx = resp.meta.get('titalxpath')
        imagexpathx = resp.meta.get('imagexpath')
        pricexpathx = resp.meta.get('pricexpath')
        price2xpathx = resp.meta.get('price2xpath')
        otherxpathx = resp.meta.get('otherxpath')
        subcategorypagex = resp.meta.get('subcategorypage')
        nextpagex = resp.meta.get('nextpage')
        categorypagex = resp.meta.get('categorypage')
        urlx = resp.meta.get('url')
        snamex = resp.meta.get('sname')
        self.logger.info(f"attribute = {attributex}")
        self.logger.info(f"divxpath = {divxpathx}")
        self.logger.info(f"titalxpath = {titalxpathx}")
        self.logger.info(f"imagexpath = {imagexpathx}")
        self.logger.info(f"pricexpath = {pricexpathx}")
        self.logger.info(f"price2xpath = {price2xpathx}")
        self.logger.info(f"otherxpath = {otherxpathx}")
        self.logger.info(f"url = {urlx}")
        self.logger.info(f"nextpage = {nextpagex}")
        self.logger.info(f"categorypage = {categorypagex}")
        if categorypagex != '':
            print('NevigateToCategory')
            follow_kwargs = self.get_follow_kwargs()
            yield resp.follow(resp.url, callback=self.NevigateToCategory, **follow_kwargs)
        else:
            try:
                print('getdeals starting')
                follow_kwargs = self.get_follow_kwargs()
                yield resp.follow(resp.url, callback=self.Get_Deals, **follow_kwargs)
            except Exception as e:
                print(e)

    ############################################## MULTI DATA COLLECTORS ###################################################

    def NevigateToCategory(self, resp):
        print('arrived')
        self.maincaturl = resp.xpath(categorypagex).extract()
        follow_kwargs = self.get_follow_kwargs()

        if subcategorypagex != '':
            meta_kwargs = {'callfrom': 'maincategory'}
            yield resp.follow(
                self.maincaturl[0],
                callback=self.NevigateTosubCategory,
                meta=meta_kwargs,
                **follow_kwargs
            )
        else:
            try:
                print('Get Deals')
                meta_kwargs = {'callfrom': 'maincategory'}
                yield resp.follow(
                    self.maincaturl[0],
                    callback=self.Get_Deals,
                    meta=meta_kwargs,
                    **follow_kwargs
                )
            except Exception as e:
                print(e)

    def NevigateTosubCategory(self, resp):
        suburl = resp.xpath(subcategorypagex).extract()
        self.suburls.extend(suburl)
        self.mainurlscounter += 1
        follow_kwargs = self.get_follow_kwargs()

        if self.mainurlscounter < len(self.maincaturl):
            meta_kwargs = {'callfrom': 'maincategory'}
            yield resp.follow(
                self.maincaturl[self.mainurlscounter],
                callback=self.NevigateTosubCategory,
                meta=meta_kwargs,
                **follow_kwargs
            )
        else:
            meta_kwargs = {'callfrom': 'subcategory'}
            yield resp.follow(
                self.suburls[0],
                callback=self.Get_Deals,
                meta=meta_kwargs,
                **follow_kwargs
            )

    def Get_Deals(self, resp):
        item=couponsDealsItem()
        xf = Textfunctions()
        if resp.status == 404:
            print('status 404 skiping')
            return

        print('in get deals')
        try:
            if resp.meta.get('callfrom') == 'maincategory':
                self.flag = 1
            if resp.meta.get('callfrom') == 'subcategory':
                self.flag = 2
        except:
            pass

        mainxpath = ''
        self.logger.info("Above Condition aproved................")

        if attributex != '':
            mainxpath = attributex
        if divxpathx != '':
            mainxpath = divxpathx

        maindivs = resp.xpath(mainxpath)
        count = 1
        items_processed = 0

        for m in maindivs:
            count += 1
            title = m.xpath(titalxpathx).get()
            title = str(title).replace("&amp;", "&")
            title = string.capwords(re.sub(r'(<.*?>)|(\&.*?\;)', " ", title)).strip()

            if title is not None:
                self.logger.info("in Title................")

                # Process image
                try:
                    image = m.xpath(imagexpathx).get()
                    if image is None:
                        if urlx == 'https://shop.cathe.com':
                            imageScript = m.xpath(".//div[@class='deal-buy-now']/a/@href").get()
                            imageId = str(imageScript).split("form_")[1].split("')")[0]
                            image = resp.xpath(
                                "//div[@id='Deal_" + imageId + "']//div[@class='deal-image']/img/@src").get()
                        elif urlx == 'https://www.bluebanana.com':
                            imageScript = m.xpath('.//a[@class="thumbnail-rollover"]/@style').get()
                            image = str(imageScript).split("url(")[1].split(')')[0]
                        elif urlx == 'https://www.bbqguys.com':
                            image = m.xpath('.//img/@src').get()
                        elif urlx == 'https://www.touchofclass.com':
                            image = m.xpath('.//a/img/@src').get()
                        else:
                            image = ''
                    elif urlx == 'https://2game.com' and 'placeholder.png' in image:
                        image = m.xpath('.//img/@data-defer-src').get()
                    elif urlx == 'https://shop.bluffworks.com' or urlx == 'https://tddisplays.com':
                        image = str(image).split("url(")[1].split(')')[0]
                    elif urlx == 'https://www.bowlingball.com':
                        image = str(image).replace('micro', 'medium')
                    elif urlx == 'https://www.coastfashion.com' or urlx == 'https://www.game.co.uk' or urlx == 'https://www.barnesandnoble.com':
                        if not str(image).startswith('https:'):
                            image = f'https:{image}'
                    elif urlx == 'https://www.wholelattelove.com':
                        image = str(image).replace('_100x.', '_600x.')
                    elif urlx == 'https://www.thehorrordome.com':
                        image = list(str(image).strip().split(','))[-2]
                        if '?' in image:
                            image = image.split('?')[0]
                    else:
                        Domains = ['.nz/', '.CO/', '.ca/', '.com/', '.net/', '.org/', '.us/', '.edu/', '.fr/', '.au/',
                                   '.uk/', '.ge/']
                        Found = False
                        for Domain in Domains:
                            if Domain in image:
                                Found = True
                        if Found or 'http' in image:
                            image = str(image).replace("{width}", "600")
                        else:
                            image = urlx + str(image).replace("{width}", "600")
                except:
                    image = ''

                # Process regular price
                if pricexpathx != '':
                    try:
                        price = str(m.xpath(pricexpathx).get())
                        if urlx == 'https://shop.cathe.com':
                            price = price + "." + str(m.xpath(
                                './/span[@class="deal-regular-price-cents"]/text()').get().strip())
                        elif urlx == 'https://www.bhphotovideo.com':
                            price = price + "." + str(m.xpath(
                                './/span[@data-selenium="uppedDecimalPriceSecond"]/text()').get().strip())
                        PriceLst = price.split('–')
                        if len(PriceLst) > 1:
                            price = PriceLst[1]
                        else:
                            price = PriceLst[0]
                        price = re.sub(r'[^0-9$€é£,.\-]+', "", price).strip()
                    except:
                        price = ''
                else:
                    price = ''

                # Process sale price
                if price2xpathx != '':
                    try:
                        price2 = str(m.xpath(price2xpathx).get())
                        if urlx == 'https://shop.cathe.com':
                            price2 = price2 + "." + m.xpath('.//span[@class="deal-price-cents"]/text()').get().strip()
                        if urlx == 'https://www.beveragefactory.com':
                            price2 = price2 + m.xpath('.//h3//sup[2]/text()').get().strip()
                        PriceLst = price2.split('–')
                        if len(PriceLst) > 1:
                            price2 = PriceLst[1]
                        else:
                            price2 = PriceLst[0]
                        price2 = re.sub(r'[^0-9$€é£,.\-]+', "", price2).strip()
                    except:
                        price2 = ''
                else:
                    price2 = ''

                # Process savings
                if otherxpathx != '':
                    try:
                        saving = m.xpath(otherxpathx).get()
                        saving = re.sub(r'[^0-9$€é£,%.]+', "", saving).strip()
                    except:
                        saving = ''
                else:
                    saving = ''

                # Process source URL
                if urlx == 'https://unshy.com':
                    sourceurl = m.xpath('.//a[@class="grid__image as-grid-image-url"]/@href').get()
                elif urlx == 'http://www.fashlets.com':
                    sourceurl = m.xpath('.//div[@class="name"]/a/@href').get()
                elif urlx == 'https://www.ghbass.com':
                    sourceurl = m.xpath('.//a[@class="product-item-link"]/@href').get()
                elif urlx == 'https://www.touchofclass.com':
                    sourceurl = m.xpath('.//a[img]/@href').get()
                elif urlx == 'https://www.bluebanana.com':
                    sourceurl = m.xpath('./div[@class="productName"]/a/@href').get()
                elif urlx == 'https://www.christopherandbanks.com':
                    sourceurl = m.xpath('.//a[@class="name-link"]/@href').get()
                else:
                    sourceurl = m.xpath('.//a/@href').get()

                if sourceurl is None or str(sourceurl).strip() == '#':
                    if urlx == 'https://shop.bluffworks.com':
                        sourceurl = m.xpath('./@href').get()
                    elif urlx == 'https://www.ashleyfurniture.com':
                        sourceurl = m.xpath('.//a[@class="thumb-link"]/@href').get()
                    else:
                        sourceurl = resp.url
                if str(sourceurl).startswith('//'):
                    sourceurl = "https:" + sourceurl
                if not validators.url(sourceurl):
                    if not str(sourceurl).startswith('/'):
                        sourceurl = urlx + '/' + str(sourceurl)
                    else:
                        sourceurl = urlx + str(sourceurl)

                # DEBUG: Log what we're about to save
                self.logger.info(f"Item {items_processed + 1} data:")
                self.logger.info(f"Title: {repr(title)}")
                self.logger.info(f"Price: {repr(price)}")
                self.logger.info(f"Price2: {repr(price2)}")
                self.logger.info(f"Image: {repr(image)}")
                self.logger.info(f"SourceUrl: {repr(sourceurl)}")

                # MODIFIED LOGIC: Save item even if price2 is empty
                # Use price2 as sale price, fall back to price if price2 is empty
                final_sale_price = str(price2).strip() if price2 and len(str(price2).strip()) > 0 and str(
                    price2).strip() != "None" else str(price).strip()

                # Only skip if we have absolutely no price information at all
                if not final_sale_price or final_sale_price == "None":
                    self.logger.info(f"Skipping item - no price data available")
                    continue

                # Create and yield item
                item = couponsDealsItem()
                item['Title'] = str(title).strip()
                item['Image'] = str(image).strip()
                item['Price'] = str(price).strip()
                item['SalePrice'] = final_sale_price
                item['Offer'] = str(saving).strip()
                item['SourceUrl'] = str(sourceurl).strip()
                item['Framework'] = '3'
                item['SiteName'] = snamex
                item['SiteURL'] = urlx
                item['DateAdded'] = datetime.datetime.now()
                item['DateUpdated'] = datetime.datetime.now()
                item['Status'] = 'Online'
                item['dealpage'] = 'True'

                self.logger.info(f"Successfully yielding item {items_processed + 1}")
                yield item
                items_processed += 1

        self.logger.info(f"Total items processed and yielded: {items_processed}")

        # Pagination logic continues...
        nextpage = ''
        if nextpagex != '':
            nextpage = str(resp.xpath(nextpagex).get())

        follow_kwargs = self.get_follow_kwargs()

        if nextpage is not None and (urlx == 'https://www.wholelattelove.com' and (
                'sale' in nextpage or 'deal' in nextpage or 'clearance' in nextpage or 'outlet' in nextpage)):
            yield resp.follow(nextpage, callback=self.Get_Deals, **follow_kwargs)
        elif nextpage is not None and 'javascript' not in nextpage and nextpage != '' and 'none' not in nextpage.lower():
            yield resp.follow(nextpage, callback=self.Get_Deals, **follow_kwargs)
        else:
            if self.flag == 1:
                self.urlscounter += 1
                if self.urlscounter < len(self.maincaturl):
                    meta_kwargs = {'callfrom': 'maincategory'}
                    yield resp.follow(
                        self.maincaturl[self.urlscounter],
                        callback=self.Get_Deals,
                        meta=meta_kwargs,
                        **follow_kwargs
                    )
                else:
                    item['dealpage'] = ''
                    item['alllogs'] = 'true'
                    yield item
            else:
                if self.flag == 2:
                    self.urlscounter += 1
                    if self.urlscounter < len(self.suburls):
                        meta_kwargs = {'callfrom': 'subcategory'}
                        yield resp.follow(
                            self.suburls[self.urlscounter],
                            callback=self.Get_Deals,
                            meta=meta_kwargs,
                            **follow_kwargs
                        )
                    else:
                        item['dealpage'] = ''
                        item['alllogs'] = 'true'
                        yield item
                else:
                    item['dealpage'] = ''
                    item['alllogs'] = 'true'
                    yield item

    def Data_Operations(self, response):
        item = couponsDealsItem()
        item['dealpage'] = ''
        item['alllogs'] = 'true'
        yield item