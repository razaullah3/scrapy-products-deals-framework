from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class firstphormSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'firstphorm'
    start_urls = ['https://1stphorm.com/collections/deals']
    Sitename = '1stphorm'
    siteurl = 'https://1stphorm.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//div[contains(@class,"grid-product__content")]'
        titalxpath = './/div[@class="grid-product__title grid-product__title--body"]/text()'
        imagexpath = './/div[@class="grid__image-ratio grid__image-ratio--square"]//img[contains(@class,"grid__image-contain")]/@data-src'
        pricexpath = './/div[@class="grid-product__price"]/text()[normalize-space()][last()] | .//span[@class="igPrice"]/text()'
        price2xpath = './/span[@class="grid-product__price--original"]/text()'
        otherxpath = ''
        nextpage = '//button[@id="load-more-buttn-collection"]'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
