import scrapy
import json
import datetime
from ..items import couponsDealsItem


class FreePeopleClearanceSpider(scrapy.Spider):
    name = "freepeople"
    allowed_domains = ["api.freepeople.com", "freepeople.com"]
    Sitename = "FreePeople"
    siteurl = "https://www.freepeople.com"

    # Pagination parameters
    page_size = 72
    skip = 0

    def start_requests(self):
        url = "https://api.freepeople.com/api/catalog-search-service/v0/fp-us/tiles/sale-all"
        headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Referer": "https://www.freepeople.com/",
    "x-urbn-site-id": "fp-us",
    "x-urbn-channel": "web",
    "x-urbn-country": "US",
    "x-urbn-currency": "USD",
    "x-urbn-language": "en-US",
    "x-urbn-experience": "ss",
    "content-type": "application/json",
    "x-urbn-pool": "US_DIRECT",
    "authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJmcCIsImV4cCI6MTc2MTEyODAwMi4yNjg5MDg3LCJpYXQiOjE3NjExMjc0MDIuMjY4OTA4NywiZGF0YSI6IntcImNyZWF0ZWRUaW1lXCI6IDE3NjExMjUxNTMuNjAxMDYzNywgXCJwcm9maWxlSWRcIjogXCJudFRvWS9xOVlDMGR1WkNWaWVZTEZMVTA0bnlVZ05IUUo3QU8yLzJVcW9NZ1EyTFJycVBSdkVhZ0lSaWUvSTAyNVUrM3JzMnJ4aGptNHBEMzBDY0lCdz09NTBlNWZlOTlmMzcyYThmMWZmNWM3YjYzMjJlZWQyMjhjN2U3NmM4Y2JiNjA4Y2Y1ZWY5OTNmMGRlZTM5YjdjOVwiLCBcImFub255bW91c1wiOiB0cnVlLCBcInRyYWNlclwiOiBcIkNBR1lLWjJGUEhcIiwgXCJzY29wZVwiOiBbXCJHVUVTVFwiXSwgXCJzaXRlSWRcIjogXCJmcC11c1wiLCBcImJyYW5kSWRcIjogXCJmcFwiLCBcInNpdGVHcm91cFwiOiBcImZwXCIsIFwiZGF0YUNlbnRlcklkXCI6IFwiVVMtTlZcIiwgXCJnZW9SZWdpb25cIjogXCJBUy1TR1wiLCBcImVkZ2VzY2FwZVwiOiB7XCJyZWdpb25Db2RlXCI6IFwiSVNcIn0sIFwiY2FydElkXCI6IFwiZmVuRjJZRFRRKzlaT3pKM1Brbjg3c092d05ldTRiNERmMDRoTnRCSWNaRmszc3pqVlh0VUdERThmTG9KY1BwNTVVKzNyczJyeGhqbTRwRDMwQ2NJQnc9PTkzZDIzZGY0YTBiMTU4NDhiM2RmZjYxYzI1MjlkN2U5NzUwNjRmYjYyNzMzYWUwYTIwOWQ3YWNmMTJhZTJmZDFcIn0ifQ.7eHdCRiJrlHL0RKzryYKMVkmldOWzU_dQAHNyKg2e8E",
    "x-urbn-primary-data-center-id": "US-NV",
    "x-urbn-geo-region": "AS-SG",
    "Origin": "https://www.freepeople.com",
    "Alt-Used": "api.freepeople.com",
    "Connection": "keep-alive",
    "Cookie": "SS_Qualtrics_Load=1; ss-enable-bisn-confirmation=1; ss-enable-checkout-recognized-login=1; SSLB=1; SSID_BE=CQCVCB1GAAAAAAAho_ho41bAECGj-GgBAAAAAABNQNNqIaP4aADRnI9nAQMPbisAIaP4aAEACGcBAwlkKwAho_hoAQDQZQEDVUorACGj-GgBABFjAQERDCsAIaP4aAEAUFwBAdJ-KgAho_hoAQA; SSSC_A15=513.G7563974936579036899.1|89168.2784978:90897.2821137:91600.2837077:91912.2843657:92047.2846223; SSRT_A15=6qv4aAADAA; urbn_data_center_id=US-NV; urbn_geo_region=AS-SG; urbn_tracer=CAGYKZ2FPH; urbn_auth_payload=%7B%22authToken%22%3A%22eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJmcCIsImV4cCI6MTc2MTEyODAwMi4yNjg5MDg3LCJpYXQiOjE3NjExMjc0MDIuMjY4OTA4NywiZGF0YSI6IntcImNyZWF0ZWRUaW1lXCI6IDE3NjExMjUxNTMuNjAxMDYzNywgXCJwcm9maWxlSWRcIjogXCJudFRvWS9xOVlDMGR1WkNWaWVZTEZMVTA0bnlVZ05IUUo3QU8yLzJVcW9NZ1EyTFJycVBSdkVhZ0lSaWUvSTAyNVUrM3JzMnJ4aGptNHBEMzBDY0lCdz09NTBlNWZlOTlmMzcyYThmMWZmNWM3YjYzMjJlZWQyMjhjN2U3NmM4Y2JiNjA4Y2Y1ZWY5OTNmMGRlZTM5YjdjOVwiLCBcImFub255bW91c1wiOiB0cnVlLCBcInRyYWNlclwiOiBcIkNBR1lLWjJGUEhcIiwgXCJzY29wZVwiOiBbXCJHVUVTVFwiXSwgXCJzaXRlSWRcIjogXCJmcC11c1wiLCBcImJyYW5kSWRcIjogXCJmcFwiLCBcInNpdGVHcm91cFwiOiBcImZwXCIsIFwiZGF0YUNlbnRlcklkXCI6IFwiVVMtTlZcIiwgXCJnZW9SZWdpb25cIjogXCJBUy1TR1wiLCBcImVkZ2VzY2FwZVwiOiB7XCJyZWdpb25Db2RlXCI6IFwiSVNcIn0sIFwiY2FydElkXCI6IFwiZmVuRjJZRFRRKzlaT3pKM1Brbjg3c092d05ldTRiNERmMDRoTnRCSWNaRmszc3pqVlh0VUdERThmTG9KY1BwNTVVKzNyczJyeGhqbTRwRDMwQ2NJQnc9PTkzZDIzZGY0YTBiMTU4NDhiM2RmZjYxYzI1MjlkN2U5NzUwNjRmYjYyNzMzYWUwYTIwOWQ3YWNmMTJhZTJmZDFcIn0ifQ.7eHdCRiJrlHL0RKzryYKMVkmldOWzU_dQAHNyKg2e8E%22%2C%22expiresIn%22%3A600%2C%22scope%22%3A%22GUEST%22%2C%22tracer%22%3A%22CAGYKZ2FPH%22%2C%22dataCenterId%22%3A%22US-NV%22%2C%22geoRegion%22%3A%22AS-SG%22%2C%22reauthToken%22%3A%22eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJmcCIsImV4cCI6MTc3NjY3OTQwMi4yNjkzMzgxLCJpYXQiOjE3NjExMjc0MDIuMjY5MzM4MSwiZGF0YSI6IntcImNyZWF0ZWRUaW1lXCI6IDE3NjExMjc0MDIuMjY5MzIxNywgXCJzY29wZVwiOiBbXCJHVUVTVFwiXSwgXCJ0cmFjZXJcIjogXCJDQUdZS1oyRlBIXCIsIFwicHJvZmlsZUlkXCI6IFwibnRUb1kvcTlZQzBkdVpDVmllWUxGTFUwNG55VWdOSFFKN0FPMi8yVXFvTWdRMkxScnFQUnZFYWdJUmllL0kwMjVVKzNyczJyeGhqbTRwRDMwQ2NJQnc9PTUwZTVmZTk5ZjM3MmE4ZjFmZjVjN2I2MzIyZWVkMjI4YzdlNzZjOGNiYjYwOGNmNWVmOTkzZjBkZWUzOWI3YzlcIn0ifQ.rcnpOn4PdPcpI8-XbyCVtzr29VYsJI_OtmpswNVeEEk%22%2C%22reauthExpiresIn%22%3A15552000%2C%22edgescape%22%3A%7B%22regionCode%22%3A%22IS%22%2C%22country%22%3A%22PK%22%2C%22city%22%3A%22Islamabad%22%2C%22zipCodes%22%3A%2244040%22%7D%2C%22trueClientIp%22%3A%22154.57.219.112%22%2C%22createdAt%22%3A1761127402277%2C%22authExpiresTime%22%3A1761127882.277%2C%22reauthExpiresTime%22%3A1776679402.277%7D; _pxhd=CwnpuMnAUbU8rsW1zlKwMAZDo6H1qgRPSZPnwylaPeqIPvYM/OFgwVzw2vTjozoJwkre6ppdIPglu2ceKGfIoA==:5HUxIirMyJCYUPRxcDxV1Lt9jM-pSZuDS26YQaVcCHJ5BrPyqNEIR66UnpHphy/d-I3tghPBK0BZMk4O6vfOAM4hbTRlXR90ndM0YUAY0gw=; utag_main__sn=1; utag_main__se=9%3Bexp-session; utag_main__ss=0%3Bexp-session; utag_main__st=1761129208160%3Bexp-session; utag_main_ses_id=1761125160760%3Bexp-session; utag_main__pn=3%3Bexp-session; split_tag_control=Conversant; utag_main_marketing_split_test=tdd; utag_main_isLoggedIn=false%3Bexp-session; _attn_=eyJ1Ijoie1wiY29cIjoxNzYxMTI1MTY1MzAzLFwidW9cIjoxNzYxMTI1MTY1MzAzLFwibWFcIjoyMTkwMCxcImluXCI6ZmFsc2UsXCJ2YWxcIjpcImVkMTYwNDU5YWM3ZjQ1YzA4MDM5MGVhMWRkM2YxOTIxXCJ9In0=; __attentive_id=ed160459ac7f45c080390ea1dd3f1921; __attentive_session_id=83017ad70edc4e80b20d67c855e85d37; __attentive_cco=1761125165307; __attentive_pv=3; __attentive_dv=1; OptanonConsent=isGpcEnabled=1&datestamp=Wed+Oct+22+2025+15%3A03%3A26+GMT%2B0500+(Pakistan+Standard+Time)&version=202403.1.0&browserGpcFlag=1&isIABGlobal=false&identifierType=Cookie+Unique+Id&hosts=&consentId=3ecdff4e-555a-414a-9fb8-0f7d279f6330&interactionCount=0&isAnonUser=1&landingPath=https%3A%2F%2Fwww.freepeople.com%2Fsale-all%2F%3Fq%3Dclearance&groups=C0001%3A1%2CC0002%3A0%2CC0003%3A0%2CC0004%3A0; __attentive_ss_referrer=ORGANIC",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=0",
    "TE": "trailers"
}


        payload = {
            "pageSize": self.page_size,
            "skip": self.skip,
            "projectionSlug": "categorytiles",
            "personalization": "0",
            "customerConsent": "strictlyNecessary",
            "featureProductIds": [],
        }

        yield scrapy.Request(
            url=url,
            method="POST",
            headers=headers,
            body=json.dumps(payload),
            callback=self.parse,
            meta={"skip": self.skip},
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("Failed to decode JSON response.")
            return

        records = data.get("records", [])
        if not records:
            self.logger.info("No records found, stopping pagination.")
            return

        self.logger.info(f"Fetched {len(records)} records at skip={response.meta['skip']}")

        for record in records:
            try:
                tile = record["allMeta"]["tile"]
                product = tile.get("product", {})
                sku_info = tile.get("skuInfo", {})

                display_name = product.get("displayName", "").strip()
                list_price = sku_info.get("listPriceHigh")
                sale_price = sku_info.get("salePriceHigh")
                slug = product.get("productSlug", "")
                face_out_image = tile.get("faceOutImage", "")

                item = couponsDealsItem()
                item["Title"] = display_name
                item["Price"] = list_price
                item["SalePrice"] = sale_price
                item["SourceUrl"] = f"https://www.freepeople.com/shop/{slug}/"
                item["Image"] = f"https://images.urbndata.com/is/image/FreePeople/{face_out_image}"
                item["Offer"] = ""
                item["Framework"] = "3"
                item["SiteName"] = self.Sitename
                item["SiteURL"] = self.siteurl
                item["DateAdded"] = datetime.datetime.now()
                item["DateUpdated"] = datetime.datetime.now()
                item["dealpage"] = "True"

                yield item

            except Exception as e:
                self.logger.warning(f"Error parsing record: {e}")

        # Pagination
        next_skip = response.meta["skip"] + self.page_size
        if len(records) == self.page_size:
            next_payload = {
                "pageSize": self.page_size,
                "skip": next_skip,
                "projectionSlug": "categorytiles",
                "personalization": "0",
                "customerConsent": "strictlyNecessary",
                "featureProductIds": [],
            }
            yield scrapy.Request(
                url=response.url,
                method="POST",
                headers=response.request.headers,
                body=json.dumps(next_payload),
                callback=self.parse,
                meta={"skip": next_skip},
            )
        else:
            self.logger.info("No more pages to scrape — finished.")
