from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class purehockeydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'purehockydeal'
    start_urls = ['https://www.purehockey.com/c/hockey-apparel-sale']
    Sitename = 'Pure Hockey'
    siteurl = 'https://www.purehockey.com'

    # ✅ Add custom headers
    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'DNT': '1',
            'Sec-GPC': '1',
            'Priority': 'u=0, i'
        }
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="item"]'
        titalxpath = './/div[@class="name"]/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/div[@class="price-was"]/text()'
        price2xpath = './/div[@class="price-is"]/text()'
        otherxpath = ''
        nextpage = '//a[@title="Go forward one page"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.custom_settings['DEFAULT_REQUEST_HEADERS'],  # ✅ Explicitly pass headers
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
