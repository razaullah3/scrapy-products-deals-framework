import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class beltoutletdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'beltoutletdeal'
    start_urls = ['https://www.beltoutlet.com/collections/clearance']
    Sitename = 'BeltOutlet'
    siteurl = 'https://www.beltoutlet.com'

    def start_requests(self):
        api_url = 'https://90pjzu4czy-dsn.algolia.net/1/indexes/*/queries?x-algolia-agent=Algolia%20for%20JavaScript%20(3.35.1)%3B%20Browser%20(lite)%3B%20instantsearch.js%20(4.48.0)%3B%20Shopify%20Integration%3B%20JS%20Helper%20(3.11.1)&x-algolia-application-id=90PJZU4CZY&x-algolia-api-key=f6ffcd67c3af145f2437d7deda6664e7'

        post_data = {
            "requests": [
                {
                    "indexName": "shopify_beltoutletproducts",
                    "params": "clickAnalytics=true&distinct=true&facetingAfterDistinct=true&facets=%5B%22named_tags.badge%22%2C%22named_tags.department%22%2C%22named_tags.upcat%22%2C%22named_tags.category%22%2C%22vendor%22%2C%22named_tags.standardizedsize%22%2C%22named_tags.color%22%2C%22named_tags.material%22%2C%22named_tags.beltwidth%22%2C%22named_tags.suspenderend%22%2C%22named_tags.suspenderwidth%22%2C%22named_tags.suspendertype%22%2C%22price%22%5D&filters=collection_ids%3A%22324997831%22%20AND%20inventory_quantity%20%3E%200&highlightPostTag=__%2Fais-highlight__&highlightPreTag=__ais-highlight__&hitsPerPage=500&maxValuesPerFacet=100&page=0&query=&ruleContexts=%5B%22clearance%22%5D&tagFilters=&userToken=anonymous-3fbf4710-bcab-4fa2-b855-42c344777027"
                }
            ]
        }

        # Send the POST request with JSON data
        yield scrapy.Request(
            url=api_url,
            method='POST',
            body=json.dumps(post_data),
            headers={'Content-Type': 'application/json'},
            callback=self.parse
        )

    def parse(self, response):
        try:
            # Parse the Algolia API response
            data = json.loads(response.text)

            # Extract hits from the proper path in the Algolia response
            if 'results' in data and len(data['results']) > 0:
                hits = data['results'][0].get('hits', [])
                self.logger.info(f"Total no of Hits : {len(hits)}")

                for m in hits:
                    # Check inventory - Algolia uses inventory_quantity instead of ss_available
                    inventory = m.get('inventory_quantity', 0)
                    if inventory < 1:
                        continue

                    item = couponsDealsItem()

                    # Basic product information
                    item['Title'] = m.get('title', '')

                    # Handle image - Algolia uses product_image instead of image
                    item['Image'] = m.get('product_image', m.get('image', ''))

                    # Price handling
                    compare_price = m.get('compare_at_price', m.get('msrp', None))
                    if compare_price:
                        item['Price'] = f"${compare_price}"
                    else:
                        item['Price'] = ''

                    # Sale price
                    price = m.get('price', 0)
                    item['SalePrice'] = f"${price}"

                    # Other fields
                    item['Offer'] = ''

                    # URL handling
                    url = m.get('url', '')
                    if not url:
                        # If no direct URL, construct from handle
                        handle = m.get('handle', '')
                        if handle:
                            url = f"https://www.beltoutlet.com/products/{handle}"

                    if url.startswith('//'):
                        url = url.lstrip('//')

                    item['SourceUrl'] = url
                    item['Framework'] = '3'
                    item['SiteName'] = self.Sitename
                    item['SiteURL'] = self.siteurl
                    item['DateAdded'] = datetime.datetime.now()
                    item['DateUpdated'] = datetime.datetime.now()
                    item['dealpage'] = 'True'

                    yield item

                # Check if we need to fetch more pages
                current_page = data['results'][0].get('page', 0)
                total_pages = data['results'][0].get('nbPages', 0)

                if current_page < total_pages - 1:
                    # Get the next page
                    post_data = json.loads(response.request.body)
                    params = post_data['requests'][0]['params']

                    # Update the page parameter
                    if 'page=' in params:
                        new_params = params.replace(f"page={current_page}", f"page={current_page + 1}")
                    else:
                        new_params = params + f"&page={current_page + 1}"

                    post_data['requests'][0]['params'] = new_params

                    self.logger.info(f"Fetching next page: {current_page + 1} of {total_pages}")

                    yield scrapy.Request(
                        url=response.url,
                        method='POST',
                        body=json.dumps(post_data),
                        headers={'Content-Type': 'application/json'},
                        callback=self.parse,
                        dont_filter=True
                    )
            else:
                self.logger.warning("No results found in the API response")

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
        except Exception as e:
            self.logger.error(f"Error processing response: {e}")
            import traceback
            self.logger.error(traceback.format_exc())