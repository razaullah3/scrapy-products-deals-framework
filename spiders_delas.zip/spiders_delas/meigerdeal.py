import scrapy
import json
import datetime
from ..items import couponsDealsItem

class MeijerDealsSpider(scrapy.Spider):
    name = 'meijer_deal'
    allowed_domains = ['meijer.com']
    base_api = 'https://digital.meijer.com/graphql/'
    Sitename = 'Meijer'
    siteurl = 'https://www.meijer.com'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Content-Type": "application/json",
        "Referer": "https://www.meijer.com/",
        "x-meijer-gql-query": "search",
        "Origin": "https://www.meijer.com",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1"
    }

    # GraphQL query
    full_query = """
    query SearchQuery($term: String!, $storeId: Int!, $first: Int, $after: String, $filters: [ProductFilterInput!], $sort: ProductSortInput, $context: ProductQueryContextInput!) {
      search(term: $term, sort: $sort, filters: $filters, context: $context) {
        __typename
        ... on SearchProductDisplayResult {
          itemConnection(first: $first, after: $after) {
            items {
              __typename
              ... on ProductExtended {
                productName
                upc
                thumbnailImage { url }
                storeSpecificProductDetails(storeId: $storeId) {
                  productStore {
                    basePrice
                    customerPrice
                  }
                }
              }
            }
            pageInfo { hasNextPage endCursor }
          }
        }
      }
    }
    """

    def start_requests(self):
        body = {
            "query": self.full_query,
            "variables": {
                "term": "deal",
                "storeId": 20,
                "first": 52,
                "after": None,
                "filters": [],
                "sort": {
                    "by": "relevance",
                    "order": "descending"
                },
                "context": {
                    "storeId": 20,
                    "constructorSessionId": 1,
                    "constructorClientId": "d621a2b3-3ebe-429f-8eb4-2f5ead1753de",
                    "userSegments": ["web"]
                }
            }
        }

        yield scrapy.Request(
            url=self.base_api,
            method="POST",
            headers=self.headers,
            body=json.dumps(body),
            callback=self.parse
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON parsing failed: {e}")
            return

        items = data.get("data", {}).get("search", {}).get("itemConnection", {}).get("items", [])
        for prod in items:
            item = couponsDealsItem()
            item["SiteName"] = self.Sitename
            item["SiteURL"] = self.siteurl
            item["Framework"] = "3"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["dealpage"] = "True"
            item["Offer"] = ""

            productName = prod.get("productName", "").strip()
            upc = prod.get("upc", "")
            thumbnail = prod.get("thumbnailImage", {}).get("url", "")
            storeDetails = prod.get("storeSpecificProductDetails", {}).get("productStore", {})

            item["Title"] = productName
            item["SourceUrl"] = f"{self.siteurl}/shopping/product/{productName.replace(' ', '-')}/{upc}.html"
            item["Price"] = storeDetails.get("basePrice")
            item["SalePrice"] = storeDetails.get("customerPrice")
            item["Image"] = thumbnail

            yield item
