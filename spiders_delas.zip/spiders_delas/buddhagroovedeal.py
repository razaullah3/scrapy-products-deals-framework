from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class buddhagroovedealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'buddhagroovedeal'
    start_urls = ['https://www.buddhagroove.com/sale/']
    Sitename = 'Buddha Groove'
    siteurl = 'https://www.buddhagroove.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="js-pagination-result"]'
        titalxpath = '//product-card[@class="card card--product h-full card--no-lines relative flex"]/div[@class="card__info-container flex flex-col flex-auto relative"]/div[@class="card__info w-full"]/div/p/a/text()'
        imagexpath = '//div[@class="card__media has-hover-image relative"]/a/img[1]'
        pricexpath = '//product-card[@class="card card--product h-full card--no-lines relative flex"]/div[@class="card__info-container flex flex-col flex-auto relative"]/div/div/div/div[@class="price__default"]/s/text()'
        price2xpath = '//product-card[@class="card card--product h-full card--no-lines relative flex"]/div[@class="card__info-container flex flex-col flex-auto relative"]/div/div/div/div[@class="price__default"]/span[@class="price__current"]/text()'
        otherxpath = '//span[@class="product-label product-label--sale"]/text()[2]'
        nextpage = '//link[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })