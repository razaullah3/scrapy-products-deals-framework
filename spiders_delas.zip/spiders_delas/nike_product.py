import scrapy
import json
import datetime
from ..items import couponsDealsItem

class NikeSaleSpider(scrapy.Spider):
    name = 'nike_sale'
    start_urls = [
        "https://api.nike.com/discover/product_wall/v1/marketplace/US/language/en/consumerChannelId/d9a5bc42-4b9c-4976-858a-f159cf99c647?path=/w/sale-3yaep&attributeIds=5b21a62a-0503-400c-8336-3ccfbff2a684&queryType=PRODUCTS&anchor=0&count=24"
    ]

    batch_size = 24  # Number of products per request

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept-Language": "en-US,en;q=0.5",
        "Content-Type": "application/json",
        "nike-api-caller-id": "com.nike.commerce.nikedotcom.web",
        # Add any other required headers
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse,
                meta={"anchor": 0}  # Start anchor
            )

    def parse(self, response):
        anchor = response.meta.get("anchor", 0)
        try:
            data = json.loads(response.text)
            product_groupings = data.get("productGroupings", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        total_products = 0
        for grouping in product_groupings:
            products = grouping.get("products", [])
            total_products += len(products)
            for p in products:
                yield self.extract_product_item(p)

        # Pagination: if we received products, request next batch
        if total_products > 0:
            next_anchor = anchor + self.batch_size
            next_url = response.url.replace(f"anchor={anchor}", f"anchor={next_anchor}")
            yield scrapy.Request(
                url=next_url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse,
                meta={"anchor": next_anchor}
            )

    def extract_product_item(self, p):
        """Extract product data into couponsDealsItem"""
        item = couponsDealsItem()

        # Title
        item['Title'] = p.get("copy", {}).get("title", "")

        # Prices
        item['SalePrice'] = p.get("prices", {}).get("currentPrice")
        item['Price'] = p.get("prices", {}).get("initialPrice")
        discount = p.get("prices", {}).get("discountPercentage")
        item['Offer'] = f"{discount}% off" if discount else ""

        # Images
        images = []
        colorway_imgs = p.get("colorwayImages", {})
        for url in colorway_imgs.values():
            if url:
                images.append(url)
        item['Image'] = ",".join(images)

        # Product URL
        item['SourceUrl'] = p.get("pdpUrl", {}).get("url", "")

        # Standard fields
        item['SiteName'] = "Nike US"
        item['SiteURL'] = "https://www.nike.com"
        item['Framework'] = "3"
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = "True"

        return item
