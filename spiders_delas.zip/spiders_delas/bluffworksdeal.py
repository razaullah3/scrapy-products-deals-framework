from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bluffworksdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bluffworksdeal'
    start_urls = ['https://shop.bluffworks.com/collections/womens-sale', 'https://shop.bluffworks.com/collections/sale']
    Sitename = 'Bluffworks'
    siteurl = 'https://shop.bluffworks.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="collections-products-grid"]/a'
        titalxpath = './/span[@class="product-text product-title font-bold"]/text()'
        imagexpath = './/div[@class="product-img"]/@style'
        pricexpath = './/span[@class="price-old"]/text()'
        price2xpath = './/span[@class="product-text font-regular product-price price-sale"]/text()'
        otherxpath = ''
        nextpage = '//a[@title="Next »"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })