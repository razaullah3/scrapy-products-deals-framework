import scrapy
import json
import datetime
from ..items import couponsDealsItem


class StockXDealsSpider(scrapy.Spider):
    name = 'stockx_deals'
    handle_httpstatus_list = [404]

    # GraphQL endpoint
    api_url = "https://stockx.com/api/p/e"

    # Collection IDs to loop through
    collection_ids = [
        "bltd9c7f79960220934",
        "blt1bcd0649db2b75fe",
        "bltbcefc1ffd524b877",
        "blt7d6df9373d9957a2"
    ]

    headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
    "Accept": "application/json",
    "Accept-Language": "en-US",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Referer": "https://stockx.com/dp/deals",
    "apollographql-client-name": "Iron",
    "apollographql-client-version": "2025.10.19.02",
    "App-Platform": "Iron",
    "App-Version": "2025.10.19.02",
    "x-stockx-device-id": "3426b777-3e0c-4bf0-bcab-1e5be887205b",
    "x-stockx-session-id": "67a36610-12d5-401a-8298-342b55f791f6",
    "selected-country": "PK",
    "Content-Type": "application/json",
    "Origin": "https://stockx.com",
    "Connection": "keep-alive",
    "Cookie": "stockx_device_id=3426b777-3e0c-4bf0-bcab-1e5be887205b; stockx_session_id=67a36610-12d5-401a-8298-342b55f791f6; stockx_session=0fd8b96a-c3c8-417a-9c41-caba62368eb8; language_code=en; stockx_selected_region=PK; __cf_bm=iaabO9djJB_46VPyc59eCKA5p.93j_Lq.j6P2_9D2Ew-1761545562-1.0.1.1-Zo1e2s76atDkNEcTRC5bFhVYD5J_m5HKuYyfefORcy8OIV28bS7zZGm_7oZZEC8HaKvZ3o2cB6D9Xd3pYlnE0p.zJQuDCWNNER7wNhPElZ8; _dd_s=aid=39ff2d56-71c7-48bd-8d42-4f768fddee83&rum=0&expire=1761546638184&logs=1&id=20915e43-7c81-4b59-88fe-894ff63da6a6&created=1761545563645; chakra-ui-color-mode=light; is_gdpr=false; stockx_ip_region=PK; OptanonConsent=isGpcEnabled=1&datestamp=Mon+Oct+27+2025+11%3A12%3A45+GMT%2B0500+(Pakistan+Standard+Time)&version=202410.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=31549a93-ca05-439a-8483-be1d1b263be3&interactionCount=0&isAnonUser=1&landingPath=https%3A%2F%2Fstockx.com%2Fdp%2Fdeals&groups=C0001%3A1%2CC0002%3A1%2CC0004%3A0%2CC0003%3A1; pxcts=f3e16a65-b2fb-11f0-858b-8d834a020b86; _pxvid=f3e1619c-b2fb-11f0-858b-52b2a3c59800; _pxde=1d37d75a021f25198e8b305652cc6ef1ea784c83ffd5221c3ef2169e39d9a91e:eyJ0aW1lc3RhbXAiOjE3NjE1NDU2NjMzODAsImZfa2IiOjB9; cf_clearance=TVbMox464viihG6yZ06yvBK85AaAZTsaYjpleiErRds-1761545564-1.2.1.1-Ro.C6ZUp7wisFGl4fHlrYrQjR9cjPjVbT_jLh96EML9mNvgSM71tPt2nIOTmRsV1BkA1niZ9qCUebuyKvWCpYuIAj.FBGrwd9e5V4cVB4OBcKhVsRCYNO_VkRsVOTe60TWfaJmYdwOPnrpJu9ceE.ZTO_PQUzbgEibYYuWuLQ19X8gcYIJIEbTwKFLOBg8ZT9ykZLt31VfYjZNtfqJs_uhVM.1GPsOGMCMITJ.0Lwe4; _px3=95d44aab3b37656ae696a51ba2e906e75d62e66fa96891e3345e6d3fa75604b0:YB2wmS2uMIxH0B1Nha+bZR0r2Vu5tFI5vMNayehQJrACX/z+E4mrMfnd4yEvge+mQbsltBR0xP5/pCeQR5MALA==:1000:nxkC0NVXM84mCZfVR0Bj5nKzc6KZYW6dRJ1PzCqBVHZAt/LN7JdgIodiJFv1keOfiw1mfOxGf/Lo8R6Etf/fSRNsqOaAQWBDbE+iXJ5+w6cjSUWCsxCX9ROKhlZXlcIZGs8+IPtdkJ8UrDZjSs4H4UnV9tJSQ8gB+FdSjNpuegUsqg/DDXx/nmIgbmWlvZUG+7WIT4GZi9rn3gpnyYw+EDK9b80rNp0BxtdIBDMQ0jgiutZkNDXMyvJkzBDey1Kz",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=4"
}


    # GraphQL query string
    query =  """ getDiscoveryCampaignModule($id: String, $country: String!, $currencyCode: CurrencyCode!, $limit: Int!, $marketName: String, $page: Int!) {
  productCollection(id: $id) {
    trackingEvent
    results(
      limit: $limit
      market: $marketName
      page: $page
      placement: LANDING_PAGE
    ) {
      edges {
        isAd
        adIdentifier
        adInventoryId
        adServiceLevel
        node {
          ... on AuctionItem {
            __typename
            biddingOpenAt
            biddingClosedAt
            state {
              bidCount
              highestBid {
                amount
                amountWithBuyerFee
              }
            }
            variant {
              product {
                id
                title
                urlKey
                media {
                  smallImageUrl
                }
                traits(filterTypes: [RELEASE_DATE, RETAIL_PRICE]) {
                  name
                  value
                }
              }
            }
          }
          ... on Product {
            __typename
            id
            title
            brand
            browseVerticals
            gender
            productCategory
            categories {
              default {
                alias
              }
            }
            primaryCategory
            listingType
            name
            urlKey
            uuid
            sizeDescriptor
            favorite
            variants {
              id
            }
            media {
              smallImageUrl
            }
            market(currencyCode: $currencyCode) {
              state(country: $country, market: $marketName) {
                askServiceLevels {
                  expressExpedited {
                    count
                    lowest {
                      amount
                      inventoryType
                    }
                  }
                  expressStandard {
                    count
                    lowest {
                      amount
                      inventoryType
                    }
                  }
                }
              }
              currencyCode
              state(country: $country, market: $marketName) {
                highestBid {
                  amount
                  updatedAt
                }
                lowestAsk {
                  amount
                  updatedAt
                }
                askServiceLevels {
                  expressExpedited {
                    lowest {
                      amount
                      inventoryType
                    }
                  }
                  expressStandard {
                    lowest {
                      amount
                      inventoryType
                    }
                  }
                }
              }
              statistics {
                lastSale {
                  amount
                }
                last72Hours {
                  salesCount
                }
                annual {
                  salesCount
                }
                last90Days {
                  averagePrice
                  salesCount
                }
              }
            }
            traits(filterTypes: [RELEASE_DATE, RETAIL_PRICE]) {
              name
              value
            }
          }
          ... on Variant {
            __typename
            id
            sizeChart {
              baseSize
              baseType
              displayOptions {
                size
                type
              }
            }
            product {
              id
              title
              brand
              browseVerticals
              gender
              productCategory
              categories {
                default {
                  alias
                }
              }
              primaryCategory
              listingType
              name
              urlKey
              uuid
              sizeDescriptor
              favorite
              variants {
                id
              }
              media {
                smallImageUrl
              }
              market(currencyCode: $currencyCode) {
                state(country: $country, market: $marketName) {
                  askServiceLevels {
                    expressExpedited {
                      count
                      lowest {
                        amount
                        inventoryType
                      }
                    }
                    expressStandard {
                      count
                      lowest {
                        amount
                        inventoryType
                      }
                    }
                  }
                }
                currencyCode
                state(country: $country, market: $marketName) {
                  highestBid {
                    amount
                    updatedAt
                  }
                  lowestAsk {
                    amount
                    updatedAt
                  }
                  askServiceLevels {
                    expressExpedited {
                      lowest {
                        amount
                        inventoryType
                      }
                    }
                    expressStandard {
                      lowest {
                        amount
                        inventoryType
                      }
                    }
                  }
                }
                statistics {
                  lastSale {
                    amount
                  }
                  last72Hours {
                    salesCount
                  }
                  annual {
                    salesCount
                  }
                  last90Days {
                    averagePrice
                    salesCount
                  }
                }
              }
              traits(filterTypes: [RELEASE_DATE, RETAIL_PRICE]) {
                name
                value
              }
            }
            market(currencyCode: $currencyCode) {
              currencyCode
              state(country: $country, market: $marketName) {
                highestBid {
                  amount
                  updatedAt
                }
                lowestAsk {
                  amount
                  updatedAt
                }
                askServiceLevels {
                  expressExpedited {
                    lowest {
                      amount
                      inventoryType
                    }
                  }
                  expressStandard {
                    lowest {
                      amount
                      inventoryType
                    }
                  }
                }
              }
              statistics {
                lastSale {
                  amount
                }
                last72Hours {
                  salesCount
                }
                annual {
                  salesCount
                }
                last90Days {
                  averagePrice
                  salesCount
                }
              }
            }
            favorite
          }
        }
      }
      pageInfo {
        total
      }
    }
  }
}
"""

    def start_requests(self):
        """Start requests for each collection ID"""
        for coll_id in self.collection_ids:
            payload = {
                "query": self.query,
                "variables": {
                    "id": coll_id,
                    "country": "PK",
                    "currencyCode": "USD",
                    "limit": 20,
                    "marketName": "PK",
                    "page": 1
                }
            }
            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.headers,
                body=json.dumps(payload),
                callback=self.parse,
                meta={"page": 1, "coll_id": coll_id}
            )

    def parse(self, response):
        """Parse product results and paginate"""
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON response.")
            return

        results = (
            data.get("data", {})
            .get("productCollection", {})
            .get("results", {})
            .get("edges", [])
        )

        if not results:
            self.logger.warning(f"No products found on page {response.meta['page']} for {response.meta['coll_id']}")
            return

        for edge in results:
            node = edge.get("node", {})
            title = node.get("title", "")
            url_key = node.get("urlKey", "")
            image = node.get("media", {}).get("smallImageUrl", "")
            traits = node.get("traits", [])
            retail_price = ""

            for trait in traits:
                if trait.get("name") == "Retail Price":
                    retail_price = trait.get("value")
                    break

            item = couponsDealsItem()
            item["Title"] = title
            item["SourceUrl"] = f"https://stockx.com/{url_key}" if url_key else ""
            item["Image"] = image
            item["Price"] = retail_price
            item["SalePrice"] = ""
            item["Offer"] = ""

            now = datetime.datetime.now()
            item["Framework"] = "3"
            item["SiteName"] = "StockX"
            item["SiteURL"] = "https://stockx.com/"
            item["DateAdded"] = now
            item["DateUpdated"] = now
            item["dealpage"] = "True"
            item["getDoc"] = "True"
            item["itempage"] = "false"
            item["urlpage"] = "false"
            item["alllogs"] = "false"
            item["Category"] = ""
            item["SubCategory"] = ""

            yield item

        # Pagination
        total = (
            data.get("data", {})
            .get("productCollection", {})
            .get("results", {})
            .get("pageInfo", {})
            .get("total", 0)
        )

        page = response.meta["page"]
        limit = 20
        coll_id = response.meta["coll_id"]
        next_page = page + 1

        if total > page * limit:
            payload = {
                "query": self.query,
                "variables": {
                    "id": coll_id,
                    "country": "PK",
                    "currencyCode": "USD",
                    "limit": limit,
                    "marketName": "PK",
                    "page": next_page
                }
            }
            yield scrapy.Request(
                url=self.api_url,
                method="POST",
                headers=self.headers,
                body=json.dumps(payload),
                callback=self.parse,
                meta={"page": next_page, "coll_id": coll_id}
            )
