from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class clogoutletdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'clogoutletdeal'
    start_urls = ['https://clogoutlet.com/collections/last-call']
    Sitename = 'ClogOutlet'
    siteurl = 'https://clogoutlet.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="grid grid--uniform grid-products grid--view-items"]/div'
        titalxpath = './/a[@class="grid-view-item__title"]/text()'
        imagexpath = './/img/@data-src'
        pricexpath = './/s[@class="product-price__price"]/text()'
        price2xpath = './/span[@class="product-price__price product-price__sale"]/text()'
        otherxpath = ''
        nextpage = '//div[@class="infinitpagin"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })