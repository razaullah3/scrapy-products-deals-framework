import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class grouponGraphqlSpider(GetDealsProducts):
    name = 'groupon'
    handle_httpstatus_list = [404]
    start_urls = ['https://www.groupon.com/mobilenextapi/graphql']
    Sitename = 'groupon'
    siteurl = 'https://www.groupon.com/'

    # Default POST body
    body = [
        {
            "operationName": "BrowseDealFeed",
            "variables": {
                "dealFeedParams": {
                    "limit": 186,
                    "division": "houston",
                    "filters": [
                        {"key": "query", "subKey": None, "value": {"static": "deals"}},
                        {"key": "exclude_deals", "values": []}
                    ],
                    "offset": 0,
                    "feedToken": "38627060-d703-4de1-a602-1d920df6ea0f",
                    "includeLocationsCount": True,
                    "includeDealOptions": True,
                    "disableFacets": True
                },
                "browseParams": {"pathName": "/search", "isFetchMore": True},
                "allLocations": False
            },
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "1e93b5ef1b9698ab8959de4ac894065b8e99716c29f4790063197d00f8be8d11"
                }
            }
        }
    ]

    def start_requests(self):
        """Initial POST request to GraphQL API"""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
        }
        yield scrapy.Request(
            url=self.start_urls[0],
            method='POST',
            headers=headers,
            body=json.dumps(self.body),
            callback=self.parse
        )

    def parse(self, response):
        """Parse GraphQL response"""
        # Yield getDoc item for framework
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        # Extract cards from GraphQL response
        data = json.loads(response.text)
        cards = data[0].get('data', {}).get('browseDealFeed', {}).get('cards', [])

        for card in cards:
            item = self.extract_product_item(card)
            # Print item to terminal
            print(f"Scraped Item: {item}")
            yield item

        # Pagination
        dealFeedParams = self.body[0]['variables']['dealFeedParams']
        offset = dealFeedParams.get('offset', 0)
        limit = dealFeedParams.get('limit', 186)
        if len(cards) == limit:  # more deals likely available
            dealFeedParams['offset'] = offset + limit
            yield scrapy.Request(
                url=self.start_urls[0],
                method='POST',
                headers={"Content-Type": "application/json"},
                body=json.dumps(self.body),
                callback=self.parse
            )

    def extract_product_item(self, card):
        item = couponsDealsItem()
        
        # Basic info
        item['Title'] = card.get('title', '')
        item['SourceUrl'] = card.get('url', self.siteurl)
        
        # Prices (handle None safely)
        price_obj = card.get('prices', {}).get('price') or {}
        strike_obj = card.get('prices', {}).get('strikeThroughPrice') or {}

        amount = price_obj.get('amount', 0)
        strike_amount = strike_obj.get('amount', 0)
        exponent = price_obj.get('currencyExponent', 2)

        item['Price'] = amount / (10 ** exponent) if amount else 0
        item['SalePrice'] = strike_amount / (10 ** exponent) if strike_amount else item['Price']

        # Discount / offer
        discount = card.get('discountPercentage', 0)
        item['Offer'] = f"{discount}% off" if discount else ''

        # Images
        images = card.get('imageUrls', {})
        medium_all = images.get('mediumAll', [])
        item['Image'] = ','.join(medium_all) if medium_all else ''

        # Other metadata
        item['Framework'] = '3'
        item['SiteName'] = self.Sitename
        item['SiteURL'] = self.siteurl
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = 'True'
        
        return item
