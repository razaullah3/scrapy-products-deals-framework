import scrapy
import json
import datetime
from ..items import couponsDealsItem


class FinnishDesignShopSpider(scrapy.Spider):
    name = 'finnish_design_shop'
    handle_httpstatus_list = [404]

    # Use your given API URL exactly
    base_url = 'https://ac.cnstrc.com/browse/productCollectionIds/1676?key=key_HVBsk8vDh0XKDU0q&c=cio-fe-web-finnish-design-shop&origin_referrer=www.finnishdesignshop.com%2Fen-us%2Fblack-friday&_dt=1763109142726&qs=%7B%22page%22:1,%22num_results_per_page%22:60,%22fmt_options%22:%7B%22hidden_fields%22:[%22name___en_us%22,%22urlPath___en_us%22,%22description___en_us%22,%22availabilityTextShort___en_us%22,%22imageAltText___en_us%22,%22prices__finalPrice:5%22,%22prices__currencyCode:5%22,%22prices__countryCodes:5%22,%22prices__origPrice:5%22,%22prices__partPaymentFromPrice:5%22,%22prices__taxPercent:5%22,%22prices__discountPercent:5%22,%22prices__campaignId:5%22,%22prices__activeUntil:5%22,%22prices__stickerId:5%22],%22hidden_facets%22:[%22prices__finalPrice:5%22,%22prices__discountPercent:5%22],%22groups_start%22:%22top%22,%22groups_max_depth%22:5%7D,%22filters%22:%7B%22productCollectionIds%22:[1676]%7D,%22sort_by%22:%22relevance%22,%22sort_order%22:%22descending%22,%22pre_filter_expression%22:%7B%22not%22:%7B%22name%22:%22restrictedRegions%22,%22value%22:%22US%22%7D%7D%7D'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://www.finnishdesignshop.com",
        "Connection": "keep-alive",
        "Referer": "https://www.finnishdesignshop.com/",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    def start_requests(self):
        # Start with page 1
        yield scrapy.Request(url=self.base_url, headers=self.headers, callback=self.parse, meta={'page': 1})

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON response")
            return

        results = data.get('response', {}).get('results', [])
        self.logger.info(f"Found {len(results)} products on page {response.meta.get('page')}")

        for product in results:
            prod_data = product.get('data', {})

            # Check variations first for price
            variations = prod_data.get('variations', [])
            price = prod_data.get('prices__finalPrice:5', '')
            sale_price = prod_data.get('prices__origPrice:5', '')

            if variations and isinstance(variations, list):
                var_data = variations[0].get('data', {})
                price = var_data.get('prices__finalPrice:5', price)
                sale_price = var_data.get('prices__origPrice:5', sale_price)

            item = couponsDealsItem()
            item['Image'] = prod_data.get('image_url', '')
            item['SourceUrl'] = "https://www.finnishdesignshop.com/en-us/" + prod_data.get('url', '')
            item['Title'] = prod_data.get('imageAltText', '')
            item['Price'] = price
            item['SalePrice'] = sale_price

            now = datetime.datetime.now()
            item['Framework'] = '3'
            item['Offer'] = ''
            item['SiteName'] = 'Finnish Design Shop'
            item['SiteURL'] = 'https://www.finnishdesignshop.com/en-us/'
            item['DateAdded'] = now
            item['DateUpdated'] = now
            item['dealpage'] = 'True'
            item['getDoc'] = 'True'
            item['itempage'] = 'false'
            item['urlpage'] = 'false'
            item['alllogs'] = 'false'
            item['Category'] = 'Decor'
            item['SubCategory'] = ''

            yield item

        # Pagination: replace "page" number in the URL string
       # Pagination: replace the page number in the URL-encoded string
        page = response.meta.get('page', 1)
        if results:
            next_page = page + 1
            # Replace %22page%22:<current_page> with %22page%22:<next_page>
            next_url = response.url.replace(f'%22page%22:{page}', f'%22page%22:{next_page}')
            yield scrapy.Request(url=next_url, headers=self.headers, callback=self.parse, meta={'page': next_page})
