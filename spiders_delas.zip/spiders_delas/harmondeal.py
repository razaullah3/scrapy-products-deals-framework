import json
import scrapy
import datetime
from ..items import couponsDealsItem


class harmondealsSpider(scrapy.Spider):
    name = 'harmondeals'
    start_urls = ['https://www.harmonfacevalues.com/store/category/deals/shop-all-deals/70226']
    sitename = 'Harmon'
    siteurl = 'https://www.harmonfacevalues.com'

    def start_requests(self):
        api_url = 'https://www.harmonfacevalues.com/apis/services/composite/product-listing/v1.0/all?site=HarmonUS&currencyCode=USD&country=US&rT=xtCompat&tz=-300&displayAdsAt=6&categoryId=70226&categoryType=plp_l2&countOnly=false&higherShippingThreshhold=0.1&pageURI=%2Fstore%2Fcategory%2Fdeals%2Fshop-all-deals%2F70226&solrCat=true&view=grid&web3feo=true&noFacet=false&facets=%7B%7D&start=0&perPage=24&sws=&storeOnlyProducts=false&customPriceRange=false&__amp_source_origin=https%3A%2F%2Fwww.harmonfacevalues.com'
        yield scrapy.Request(url=api_url)

    def parse(self, response):
        for req in self.getproducts(response):
            yield req

        api_response = json.loads(response.text)
        total_product = int(api_response['response']['numFound'])
        start_index = 24
        while total_product >= start_index:
            api_url = f'https://www.harmonfacevalues.com/apis/services/composite/product-listing/v1.0/all?site=HarmonUS&currencyCode=USD&country=US&rT=xtCompat&tz=-300&displayAdsAt=6&categoryId=70226&categoryType=plp_l2&countOnly=false&higherShippingThreshhold=0.1&pageURI=%2Fstore%2Fcategory%2Fdeals%2Fshop-all-deals%2F70226&solrCat=true&view=grid&web3feo=true&noFacet=false&facets=%7B%7D&start={str(start_index)}&perPage=24&sws=&storeOnlyProducts=false&customPriceRange=false&__amp_source_origin=https%3A%2F%2Fwww.harmonfacevalues.com'
            yield response.follow(api_url, callback=self.getproducts, dont_filter=True)
            start_index = start_index + 24

    def getproducts(self, response):
        item = couponsDealsItem()

        listing_json = json.loads(response.text)
        for m in listing_json['response']['docs']:
            item['Title'] = m['DISPLAY_NAME']
            item['Image'] = m['scene7imageUrl']
            item['Price'] = m['PRICE_RANGE_STRING']
            item['SalePrice'] = m['isPriceRangeStr']
            item['Offer'] = ''
            item['SourceUrl'] = f"{self.siteurl}/store{str(m['url'])}"
            item['Framework'] = '3'
            item['SiteName'] = self.sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item
