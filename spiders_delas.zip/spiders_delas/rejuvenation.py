import json
import datetime
import scrapy
from ..items import couponsDealsItem

class RejuvenationSpider(scrapy.Spider):
    name = 'rejuvenation_deals'
    Sitename = 'Rejuvenation'
    siteurl = 'https://www.rejuvenation.com'
    
    # ------------------ Generate URLs with offset 0, 20, 40 ... up to 10 pages ------------------
    start_urls = [
        f'https://ac.cnstrc.com/search/clearance?c=ciojs-client-2.66.0&key=key_9BhS51IOFNhJejk4&i=6cbadd1b-9800-4b57-a474-38e282cba67e&s=1&offset={i*20}&num_results_per_page=20&&sort_order=descending&fmt_options%5Bhidden_facets%5D=smartDeskFeatures&pre_filter_expression=%7B%22or%22%3A%5B%7B%22or%22%3A%5B%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22COI%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22COI_CMO%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22COI_SS%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DEFAULT%22%7D%5D%7D%5D%7D&_dt=1763357243366'
        for i in range(10)  # 10 pages
    ]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://www.rejuvenation.com/',
        'Origin': 'https://www.rejuvenation.com',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
        'Priority': 'u=4'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = []
        response_list = data.get('response', {}).get('results', [])

        for result in response_list:
            data_field = result.get('data', None)
            if isinstance(data_field, dict):
                products.append(data_field)       # single dict
            elif isinstance(data_field, list):
                products.extend(data_field)       # list of dicts

        self.logger.info(f"Found {len(products)} products on this page.")

        for p in products:
            item = couponsDealsItem()
            item['Title'] = p.get('title', '').strip()
            item['Image'] = p.get('image_url', '')
            item['SourceUrl'] = p.get('url', '')
            item['Price'] = p.get('salePriceMin', None)
            item['SalePrice'] = p.get('regularPriceMax', None)
            
            item['Framework'] = '3'
            item['Offer'] = ''
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item
