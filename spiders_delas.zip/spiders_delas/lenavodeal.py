import scrapy
import json
import datetime
from urllib.parse import quote
from ..items import couponsDealsItem
from w3lib.html import remove_tags

class LenovoDealSpider(scrapy.Spider):
    name = "lenovo_deal"
    base_api = "https://openapi.lenovo.com/us/en/ofp/search/dlp/product/query/get/_tsc"

    # ✅ EXACT HEADERS
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.lenovo.com/us/en/d/deals/doorbusters/?sortBy=bestSelling",
        "Origin": "https://www.lenovo.com",
        "Connection": "keep-alive",
        "Cookie": "zipcode=90009; city=Los+Angeles; timezone=America/Los_Angeles; _abck=1DFA189B33D955E7614FE48B9DD42C1A~-1~YAAQqiXAF/oYwOiZAQAAA2iWJA7h+QAinNfuQA7HNOEq/DwWdv2gyV5QHL5tl/SmHM49STP+/PRkFHcP0Fwp4cUwcv0s8Fq+4CscRHfN5en58btT9gfMxzmU/3hX2F7Ub7+7zjegfKOd56wjmuuql5HBOoalsYoI9AXM7uNZb+/Hk5+xBysQjridfQpph724xdW5UiMsvugTjgu0850bIOuetgjaEws9zvobwmc815JoDkU6OFW3i1aTOmL0o0VkRoqjiuAymTohwxqqHsu8Cpr99PLt5+4TbCJvKBJqhYBlLIiMKShdHTk+AjzAEExj2hJhHPrz2HCY1SJNL+/aS0PAtaakiXSAdXBpjRtRfoHe1uglTdD1KMpLOzbBnGap7TDSsS/0My077icNecViwiccc8w8JnvlsppTdotwv8NDKuBXeD3C8XTyy60PQ5qYNllL/RnhWJ0UZNLUzDt1TnIIdQdY9OR6ZJiYdBg6jZBUSlxOYftUI7kSC0JmR9MeFpw1N1MzYHTDbOPXeichugemu3GwYqeqv/Fe9Iuc/4w6uoU+5VKCqQGDLTHf/VXT3DFuIbsXUjAQGZ3iPZLMIoqL323at3df5KxByg4ryPcAzQ==~-1~-1~1761554028~AAQAAAAE/////2cyyM8dALI3rfua7N8bGRpgcemgyJvveZuNIcVkB4CdGKpvL1V5kXlrNKRABmNQnZG1zB5G9YJPa1A35Vv12liftGpr2LYRjTaQ~-1; ak_bmsc=3DF4755F60FAD6CE3AE9FFEAB70F8A64~000000000000000000000000000000~YAAQqiXAF0wZwOiZAQAAQGuWJB0GAfojKcvKsDq0/Udqs6/UG2akpGBR83ovryMXAA+y9yLpelV5qPjSwKpTd8KZHl7sTndZZDSRaP9RXtYNVl6+OpbCnf+KuobOvVVdtCZsIJ45H5FQorAsGB2wVz1Z0DElUfxKITK4s494/5DFcIxWaMj698nb5JrmJYEACcqMmgfuTSl1Ji3Ci9uskogQofBPt97nYhmo+4ODcVR7necvsOVf28NRdW1ZdQH65bfANnewMiqzSJnPXES7/I2QmL5no8VxoQi/2MNb30VFDIfWshvko7MGdcPMeZAW2Sbl0nvFtIhVSblQhHY0atWJNWyz6hGzr1f9TYGA2EpECm77kX9mN1cQujOQhhAyuNitIMtO+eIF9LX5G4uPVxLisUqG8O+VfS7+RLuXCFBFI3CQi/7LeZ35EyPtKkSBQTLgC4d9hIhnKp1+9nD66Sw=; bm_sz=44ECCFD780EA30BB7AADCDEB8DCACB81~YAAQqiXAF2IXwOiZAQAAuliWJB2YOie9CHVABsyaM25Qs0qFIbUw/LOczh5DmN3GB2J5vc4er/scP/Uxxp1MwEntAoc1Tckn1EBNvcpmLs1bFQHBbG75xkEk2L4lj3HElpNE2mWb8Zgd3oQHUGWfdW0zFap7EZKGm+7hWlFuoCHtKev+DLQP6EHzNPU9fSmkf9tZYWVS5BMCVYS9QjCeQh9LxQBs84VXu5fXwCe0p+Fyh6tzrZnoCe4G6GK02LY5nHHUGjfP22z3cct8K+afAuNeIhMaGJjouxoMx6SEJDi0wVA1/apeO1lm0FCgUUsBV+NxF3ewhcvhms7MK+etT3XWhhAx+GEKNm0OqgI7vW5YgS+yuZIHvRRo4ycnTT68V4DsbSH/zgpG996IiUMf~3487280~3488048; leid=2.9/w4rr7+1RB; bm_sv=120F57E91A87B6D5E378139A312E0B8C~YAAQyiXAF9xAL/uZAQAAKmuWJB1ywfXlD9S0wx88kmx7UmsLdyx1dMBJa6HSV11xdcq5e/3pbcWwyXoMSe+sFv0JVwX1XIScIAX6ZELDKHoTCA0pdTlNSQCXCqMaivqGjV8z5TJ4E3IHq45VM7U4W5R9wyhRrPfzQV7Pp/QHC2U9ny/JBlSGngzrEAd5abGdeJd5SLVloBXDqJs6o5Uy85gBkI3rN6cxrEghfdb/lfFFu7OoTOjk0+GoVUjvyuFY~1; cartCount=%7B%220e49db5e-0834-41ba-84fe-f796497ba9fc%23%23null%23%23null%22%3A0%7D; PublicAlertPublicFirst=1; PublicAlertStoreFirst=isPublic; searchabran=44; grid=11; fsid=7",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "TE": "trailers"
    }

    initial_params = {
        "pageFilterId": "ccfb38c4-d92d-41f8-bb21-27c9efa4c2e7",
        "subSeriesCode": "",
        "loyalty": "false",
        "params": json.dumps({
            "classificationGroupIds": "400001",
            "pageFilterId": "ccfb38c4-d92d-41f8-bb21-27c9efa4c2e7",
            "facets": [],
            "page": 1,
            "pageSize": 40,
            "groupCode": "",
            "init": False,
            "sorts": ["bestSelling"],
            "version": "v2",
            "enablePreselect": True,
            "subseriesCode": ""
        })
    }

    def start_requests(self):
        url = self.base_api + "?" + "&".join(f"{k}={quote(v)}" for k, v in self.initial_params.items())
        yield scrapy.Request(
            url=url,
            headers=self.custom_headers,
            callback=self.parse,
            cb_kwargs={'page': 1},
            dont_filter=True
        )

    def parse(self, response, page):
        data = json.loads(response.text)
        products = data.get("data", {}).get("data", [])
        if not products:
            return

        for prod in products:
            for p in prod.get("products", []):
                item = couponsDealsItem()
                item["Title"] = p.get("summary", "").strip()
                item["SourceUrl"] = "https://www.lenovo.com/us/en" + p.get("url", "")
                item["SalePrice"] = p.get("finalPrice", "")
                item["Price"] = p.get("webPrice", "")
                item["Offer"] = p.get("saveAmount", "")
                img = p.get("media", {}).get("thumbnail", {}).get("imageAddress", "")
                if img.startswith("//"):
                    img = "https:" + img
                item["Image"] = img
                desc = remove_tags(p.get("marketingLongDescription", ""))
                #item["Description"] = " ".join(desc.split())
                item["DateAdded"] = datetime.datetime.now()
                item["DateUpdated"] = datetime.datetime.now()
                item["dealpage"] = "True"
                item["SiteName"] = "Lenavo"
                item["SiteURL"] = "https://www.lenovo.com/us/en/d/deals/doorbusters/?sortBy=bestSelling"
                item["Framework"] = "3"
                yield item

        # Pagination
        next_page = page + 1
        params_dict = json.loads(self.initial_params["params"])
        params_dict["page"] = next_page
        new_params = dict(self.initial_params)
        new_params["params"] = json.dumps(params_dict)
        next_url = self.base_api + "?" + "&".join(f"{k}={quote(v)}" for k, v in new_params.items())
        yield scrapy.Request(
            url=next_url,
            headers=self.custom_headers,
            callback=self.parse,
            cb_kwargs={'page': next_page},
            dont_filter=True
        )
