import scrapy
import json
import datetime
from ..items import couponsDealsItem


class SephoraDealsSpider(scrapy.Spider):
    name = 'sephoradeals'
    allowed_domains = ['sephora.com']
    start_page = 1
    max_page = 2
    Sitename = 'Sephora'
    siteurl = 'https://www.sephora.com'

    def start_requests(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            #'Accept-Encoding': 'gzip, deflate, br, zstd',
            'x-requested-source': 'rwd',
            'Connection': 'keep-alive',
            'Referer': 'https://www.sephora.com/search?keyword=deal',
            'DNT': '1',
            'Sec-GPC': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'TE': 'trailers',
        }

        for page in range(1, self.max_page + 1):
            url = (
                f'https://www.sephora.com/api/v2/catalog/search/?type=keyword&q=deal&includeEDD=true'
                f'&content=true&includeRegionsMap=true&page=60&currentPage={page}&loc=en-US&ch=rwd'
                f'&countryCode=US&callAdSvc=true&adSvcSlot=2503111'
                f'&adSvcSession=82f759df-5781-41bc-91d5-357d1f3aecb0'
                f'&constructorSessionID=1&constructorClientID=ffa79efd-acac-45b5-b309-7617431ef148'
                f'&targetSearchEngine=nlp'
            )
            yield scrapy.Request(url=url, headers=headers, callback=self.parse)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get("products", [])
        self.logger.info(f"Found {len(products)} products on this page.")

        for product in products:
            item = couponsDealsItem()
            sku = product.get("currentSku", {})

            # Core fields
            item['Title'] = product.get("displayName", "").strip()
            item['SourceUrl'] = f"https://www.sephora.com{product.get('targetUrl', '')}"
            item['Price'] = sku.get("listPrice", "")
            item['SalePrice'] = sku.get("valuePrice", "")
            
            # Combine image URLs
         
            
            item['Image'] = product.get("heroImage", "")

            # Metadata
            item['Offer'] = ''
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item
