from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class gouletpensdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'gouletpensdeal'
    start_urls = ['https://www.gouletpens.com/collections/pen-sales-deals']
    Sitename = 'Goulet Pen'
    siteurl = 'https://www.gouletpens.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//product-item[@class="product-item "]'
        titalxpath = './/a[@class="product-item__title"]/text()'
        imagexpath = './/a[@class="product-item__img-wrap allow-hover"]/img[@src][1]'
        pricexpath = './/s/text()'
        price2xpath = './/span[@class="product-item__price -sale"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })