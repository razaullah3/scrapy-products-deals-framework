import json
import scrapy
import datetime
import time
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class cheapesteesdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'cheapesteesdeal'
    start_urls = ['https://www.cheapestees.com/']
    Sitename = 'cheapestees'
    siteurl = 'https://www.cheapestees.com'
    api_url = 'https://rbzizsivxfkend3njx686e6n-fast.searchtap.net/v2'

    # API configuration
    headers = {
        'Authorization': 'Bearer 8WXTMFADKTXR9CL3BWHUXU6E',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    def start_requests(self):
        """Start with the API request instead of the website"""
        # Initial API payload
        payload = {
            "query": "",
            "fields": ["*"],
            "textFacets": ["variants.option2", "sq_color", "system_producttype", "system_vendor", "ss_category"],
            "highlightFields": [],
            "searchFields": ["title", "description", "productType", "vendor", "variants.option1", "style"],
            "filter": f"priorityScore >= 0 AND publishedTimestamp < {int(time.time() * 1000)} AND publishedTimestamp > 0 AND collectionHandles = \"products\" AND tags='Parent'",
            "sort": ["sortOrderFor_products"],
            "skip": 0,
            "count": 100,  # Increased from 32 to get more products per request
            "collection": "WHJ6PFE5X7V1JCP3C7VXSURK",
            "facetCount": 100,
            "groupCount": -1,
            "typoTolerance": 1,
            "textFacetFilters": {},
            "numericFacets": {
                "price": ["[0,10)", "[10,20)", "[20,30)", "[30,40)", "[40,50)", "[50,1.7976931348623157e+308)"]
            },
            "numericFacetFilters": {},
            "textFacetQuery": None,
            "geo": {
                "around": None,
                "polygon": None
            }
        }

        yield scrapy.Request(
            url=self.api_url,
            method='POST',
            headers=self.headers,
            body=json.dumps(payload),
            callback=self.parse_api_response,
            meta={'skip': 0, 'page': 1}
        )

    def parse_api_response(self, response):
        """Parse the API response and extract product data"""
        try:
            data = json.loads(response.text)
            results = data.get('results', [])

            # Extract products from current page
            for product in results:
                yield self.extract_product_item(product)

            # Handle pagination
            current_skip = response.meta.get('skip', 0)
            current_page = response.meta.get('page', 1)
            count_per_page = 100

            # If we got a full page of results, there might be more
            if len(results) >= count_per_page:
                next_skip = current_skip + count_per_page

                # Create payload for next page
                payload = {
                    "query": "",
                    "fields": ["*"],
                    "textFacets": ["variants.option2", "sq_color", "system_producttype", "system_vendor",
                                   "ss_category"],
                    "highlightFields": [],
                    "searchFields": ["title", "description", "productType", "vendor", "variants.option1", "style"],
                    "filter": f"priorityScore >= 0 AND publishedTimestamp < {int(time.time() * 1000)} AND publishedTimestamp > 0 AND collectionHandles = \"products\" AND tags='Parent'",
                    "sort": ["sortOrderFor_products"],
                    "skip": next_skip,
                    "count": count_per_page,
                    "collection": "WHJ6PFE5X7V1JCP3C7VXSURK",
                    "facetCount": 100,
                    "groupCount": -1,
                    "typoTolerance": 1,
                    "textFacetFilters": {},
                    "numericFacets": {
                        "price": ["[0,10)", "[10,20)", "[20,30)", "[30,40)", "[40,50)", "[50,1.7976931348623157e+308)"]
                    },
                    "numericFacetFilters": {},
                    "textFacetQuery": None,
                    "geo": {
                        "around": None,
                        "polygon": None
                    }
                }

                yield scrapy.Request(
                    url=self.api_url,
                    method='POST',
                    headers=self.headers,
                    body=json.dumps(payload),
                    callback=self.parse_api_response,
                    meta={'skip': next_skip, 'page': current_page + 1},
                    dont_filter=True
                )

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
        except Exception as e:
            self.logger.error(f"Error parsing API response: {e}")

    def extract_product_item(self, product):
        """Extract product information and create item"""
        item = couponsDealsItem()

        # Extract basic product information
        item['Title'] = product.get('title', '')

        # Extract image - look for primary image
        images = product.get('images', [])
        if images:
            # Get the first image or look for a primary image
            item['Image'] = images[0].get('src', '') if isinstance(images[0], dict) else str(images[0])
        else:
            item['Image'] = ''

        # Extract pricing information from variants
        variants = product.get('variants', [])
        prices = []
        compare_prices = []

        for variant in variants:
            if variant.get('price'):
                try:
                    price = float(variant['price'])
                    prices.append(price)
                except (ValueError, TypeError):
                    pass

            if variant.get('compare_at_price'):
                try:
                    compare_price = float(variant['compare_at_price'])
                    compare_prices.append(compare_price)
                except (ValueError, TypeError):
                    pass

        # Format pricing
        if prices:
            min_price = min(prices)
            max_price = max(prices)
            if min_price == max_price:
                item['SalePrice'] = f"${min_price:.2f}"
            else:
                item['SalePrice'] = f"${min_price:.2f} - ${max_price:.2f}"
        else:
            item['SalePrice'] = ''

        if compare_prices:
            min_compare = min(compare_prices)
            max_compare = max(compare_prices)
            if min_compare == max_compare:
                item['Price'] = f"${min_compare:.2f}"
            else:
                item['Price'] = f"${min_compare:.2f} - ${max_compare:.2f}"
        else:
            item['Price'] = item['SalePrice']  # If no compare price, use sale price as regular price

        # Calculate discount if available
        discount = product.get('discount', 0)
        if discount and discount > 0:
            item['Offer'] = f"{discount:.0f}% off"
        elif prices and compare_prices:
            # Calculate discount based on price difference
            avg_price = sum(prices) / len(prices)
            avg_compare = sum(compare_prices) / len(compare_prices)
            if avg_compare > avg_price:
                discount_percent = ((avg_compare - avg_price) / avg_compare) * 100
                item['Offer'] = f"{discount_percent:.0f}% off"
            else:
                item['Offer'] = ''
        else:
            item['Offer'] = ''

        # Extract product URL
        handle = product.get('handle', '')
        if handle:
            item['SourceUrl'] = f"{self.siteurl}/products/{handle}"
        else:
            # Fallback: try to construct URL from other fields
            product_id = product.get('id', '')
            if product_id:
                item['SourceUrl'] = f"{self.siteurl}/products/{product_id}"
            else:
                item['SourceUrl'] = self.siteurl

        # Set standard fields
        item['Framework'] = '3'
        item['SiteName'] = self.Sitename
        item['SiteURL'] = self.siteurl
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = 'True'

        return item

    def parse(self, response):
        """Legacy parse method - redirects to API scraping"""
        # Generate a getDoc item first (if needed for your framework)
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        # The actual scraping is handled by start_requests() -> parse_api_response()
        # This method is kept for compatibility with your existing framework