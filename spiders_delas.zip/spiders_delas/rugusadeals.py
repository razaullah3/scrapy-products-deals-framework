import scrapy
import json
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class rugsusadealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'rugsusadeal'
    Sitename = 'RugsUSA'
    siteurl = 'https://www.rugsusa.com'
    api_url = 'https://6azk7kfpnt-dsn.algolia.net/1/indexes/*/queries?x-algolia-agent=Algolia%20for%20JavaScript%20(4.23.3)%3B%20Browser%20(lite)%3B%20instantsearch.js%20(4.71.1)%3B%20react%20(18.3.1)%3B%20react-instantsearch%20(7.11.1)%3B%20react-instantsearch-core%20(7.11.1)%3B%20JS%20Helper%20(3.21.0)&x-algolia-api-key=720f827f359fa79d47ccaf1512e4288f&x-algolia-application-id=6AZK7KFPNT'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate,zstd",
        "Origin": "https://www.rugsusa.com",
        "Connection": "keep-alive",
        "Referer": "https://www.rugsusa.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Content-Type": "application/json"
    }

    def start_requests(self):
        """Start with first page of RugsUSA API"""
        payload = {
            "requests": [
                {
                    "indexName": "prod_rugs_usa_products",
                    "params": "query=&hitsPerPage=60&page=0"
                }
            ]
        }

        yield scrapy.Request(
            url=self.api_url,
            method='POST',
            headers=self.headers,
            body=json.dumps(payload),
            callback=self.parse_api,
            meta={'page': 0}
        )

    def parse_api(self, response):
        """Parse JSON and paginate"""
        try:
            data = json.loads(response.text)
            results = data.get('results', [])[0]
            hits = results.get('hits', [])
            current_page = results.get('page', 0)
            nb_pages = results.get('nbPages', 0)

            for product in hits:
                yield self.extract_product_item(product)

            # Handle pagination
            if current_page + 1 < nb_pages:
                next_page = current_page + 1
                payload = {
                    "requests": [
                        {
                            "indexName": "prod_rugs_usa_products",
                            "params": f"query=&hitsPerPage=60&page={next_page}"
                        }
                    ]
                }

                yield scrapy.Request(
                    url=self.api_url,
                    method='POST',
                    headers=self.headers,
                    body=json.dumps(payload),
                    callback=self.parse_api,
                    meta={'page': next_page},
                    dont_filter=True
                )

        except Exception as e:
            self.logger.error(f"Error parsing API: {e}")

    def extract_product_item(self, product):
        """Extract product data"""
        item = couponsDealsItem()

        item['Title'] = product.get('title', '').strip()
        item['Image'] = product.get('product_image', '')
        item['SalePrice'] = product.get('variants_max_price', '')
        item['Price'] = product.get('variants_compare_at_price_min', '')
        handle = product.get('handle', '')

        if handle:
            item['SourceUrl'] = f"{self.siteurl}/products/{handle}"
        else:
            item['SourceUrl'] = self.siteurl

        # Calculate discount if both prices are present
        try:
            max_price = float(product.get('variants_max_price', 0))
            compare_price = float(product.get('variants_compare_at_price_min', 0))
            if compare_price > max_price > 0:
                discount = round(((compare_price - max_price) / compare_price) * 100)
                item['Offer'] = f"{discount}% off"
            else:
                item['Offer'] = ''
        except:
            item['Offer'] = ''

        # Add standard fields
        item['Framework'] = '3'
        item['SiteName'] = self.Sitename
        item['SiteURL'] = self.siteurl
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = 'True'

        return item

    def parse(self, response):
        """Compatibility parse method"""
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
