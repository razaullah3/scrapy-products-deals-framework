from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class rihoasdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'rihoasdeal'
    start_urls = ['https://www.rihoas.com/collections/final-sale']
    Sitename = 'Rihoas'
    siteurl = 'https://www.rihoas.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="block-inner"]'
        titalxpath = './/div[@class="product-block__title"]/text()'
        imagexpath = './/div[@class="lazyload--manual rimage-background fade-in"]/@data-lazy-bgset-src'
        pricexpath = './/div[@class="product-price"]//span[contains(@class, "product-price__compare")]//span[@class="money"]/text()'
        price2xpath = './/div[@class="product-price"]//span[contains(@class, "product-price__amount--on-sale")]//span[@class="money"]/text()'
        otherxpath = './/span[@class="blurb"]/text()'
        nextpage = '//a[@class="pagination__next inh-col underline underline--on-hover"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })