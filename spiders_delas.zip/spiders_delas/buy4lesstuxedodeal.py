from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class buy4lesstuxedodealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'buy4lesstuxedodeal'
    start_urls = ['https://www.buy4lesstuxedo.com/collections/sale']
    Sitename = 'Buy4LessTuxedo'
    siteurl = 'https://www.buy4lesstuxedo.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="grid-view-item product-card"]'
        titalxpath = './/a[@class="grid-view-item__link grid-view-item__image-container product-card__link"]/span/text()'
        imagexpath = './/img[@class="grid-view-item__image lazyautosizes lazyloaded"]/@src'
        pricexpath = './/div[@class="product-price"]/dd[1]/s/text()'
        price2xpath = './/div[@class="product-price"]/dd[2]/span/text()[1]'
        otherxpath = ''
        nextpage = '//link[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })