from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class calcuttaoutdoorsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'calcuttaoutdoorsdeal'
    start_urls = ['https://www.calcuttaoutdoors.com/collections/fishing-gear-sale',
                  'https://www.calcuttaoutdoors.com/collections/cyber-sale',
                  'https://www.calcuttaoutdoors.com/collections/clearance-fishing-gear',
                  'https://www.calcuttaoutdoors.com/collections/calcutta-clearance-fishing-gear',
                  'https://www.calcuttaoutdoors.com/collections/womens-clearance-apparel',
                  'https://www.calcuttaoutdoors.com/collections/clearance-coolers',
                  'https://www.calcuttaoutdoors.com/collections/clearance-sunglasses']
    Sitename = 'Calcutta Outdoors'
    siteurl = 'https://www.calcuttaoutdoors.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-card__figure"]'
        titalxpath = './/span[@class="product-card__title"]/a/text()'
        imagexpath = './/div[@class="product-card__figure"]/a/img[1]/@src'
        pricexpath = './/compare-at-price[@class="text-subdued line-through"]/text()[2]'
        price2xpath = './/sale-price[@class="text-on-sale"]/text()[2] | //sale-price[@class="text-subdued"]/text()[2]'
        otherxpath = './/span[@class="product-label product-label--on-sale"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })