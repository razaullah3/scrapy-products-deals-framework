from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class hamiltonbeachdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'hamiltonbeachdeal'
    start_urls = ['https://hamiltonbeach.com/factory-recertified-products']
    Sitename = 'Hamilton Beach'
    siteurl = 'https://hamiltonbeach.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="row product"]'
        titalxpath = './/span[@class="product-name"]/text()'
        imagexpath = './/img[contains(@class,"product-image-small")]/@src'
        pricexpath = ''
        price2xpath = './/div[@class="price"]/text()[1]'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })