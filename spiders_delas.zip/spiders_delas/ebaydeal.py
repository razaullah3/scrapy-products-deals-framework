from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class ebaydealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'ebaydeal'
    start_urls = ['https://www.ebay.com/globaldeals']
    Sitename = 'eBay'
    siteurl = 'https://www.ebay.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '//div[@class="dne-show-more-link"]/a/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="item-grid-spoke"]//div[@itemscope="itemscope"]'
        titalxpath = './/span[@itemprop="name"]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/span[@class="itemtile-price-strikethrough"]/text()'
        price2xpath = './/span[@itemprop="price"]/text()'
        otherxpath = './/span[@class="itemtile-price-bold"]/text()'
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })