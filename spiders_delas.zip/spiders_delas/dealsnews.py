from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class alphabetdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'dealnews'
    start_urls = ['https://www.dealnews.com/']
    Sitename = 'dealnews'
    siteurl = 'https://www.dealnews.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//section[@aria-label="All Offers"]'
        titalxpath = './/a[@class="title-link"]/text()'
        imagexpath = './/div[@class="native-lazy-img-container  native-lazy-img-size-square "]/img[@src]'
        pricexpath = './/span[@class="callout-comparison"]/text()'
        price2xpath = './/div[@class="callout limit-height limit-height-large-1 limit-height-small-1"]/text()'
        otherxpath = './/span[@class="offdisc"]/text()'
        nextpage = './/a[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })