import json
import scrapy
import datetime
import re
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class beyondpolishdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'beyondpolishdeal'
    start_urls = ['https://www.beyondpolish.com/collections/all-sale']
    Sitename = 'Beyond Polish'
    siteurl = 'https://www.beyondpolish.com'

    def start_requests(self):
        base_api_url = 'https://services.mybcapps.com/bc-sf-filter/filter?_=pf&shop=beyond-polish.myshopify.com&page=1&limit=30&sort=manual&locale=en&event_type=init&pg=collection_page&build_filter_tree=true&collection_scope=153223888947&money_format=%26%2336%3B{{amount}}&money_format_with_currency=%3Cspan+class%3Dmoney%3E%26%2336%3B{{amount}}+USD%3C%2Fspan%3E&viewAs=grid--5&device=&first_load=false&productImageWidth=200&productPerRow=5&widget_updated_at=1746044514&templateId=qUFYyLQIJR&current_locale=&simplifiedIntegration=false&return_all_currency_fields=false&isMobile=false&isTabletPortraitMax=false&behavior=refresh&tag=&t=1746692989696&sid=b508139c-2b1c-0066-c6d6-6b76e16cfcf0&product_available=false&variant_available=false'

        # Send the GET request to the API for page 1
        yield scrapy.Request(
            url=base_api_url,
            method='GET',
            callback=self.parse_api_response,
            meta={'page': 1}  # Track current page in meta
        )

    def parse_api_response(self, response):
        try:
            # Parse the API response
            data = json.loads(response.text)

            # Extract products from the response
            products = data.get('products', [])
            current_page = response.meta.get('page', 1)
            self.logger.info(f"Processing page {current_page} with {len(products)} products")

            for product in products:
                # Check if the product is available
                available = product.get('available', False)
                if not available:
                    continue

                item = couponsDealsItem()

                # Basic product information
                item['Title'] = product.get('title', '')

                # Handle image
                image_url = product.get('images_info', [{}])[0].get('src', '') if product.get('images_info') else ''
                item['Image'] = image_url

                # Price handling - Check variants for price info
                variants = product.get('variants', [])
                if variants:
                    compare_price = variants[0].get('compare_at_price')
                    if compare_price:
                        item['Price'] = f"${compare_price}"
                    else:
                        item['Price'] = ''

                    # Sale price
                    price = variants[0].get('price')
                    if price:
                        item['SalePrice'] = f"${price}"
                    else:
                        item['SalePrice'] = ''
                else:
                    item['Price'] = ''
                    item['SalePrice'] = ''

                # Other fields
                item['Offer'] = ''

                # URL handling
                handle = product.get('handle', '')
                if handle:
                    url = f"https://www.beyondpolish.com/products/{handle}"
                else:
                    url = ''

                item['SourceUrl'] = url
                item['Framework'] = '3'
                item['SiteName'] = self.Sitename
                item['SiteURL'] = self.siteurl
                item['DateAdded'] = datetime.datetime.now()
                item['DateUpdated'] = datetime.datetime.now()
                item['dealpage'] = 'True'

                yield item

            # Continue fetching next page if we have products
            if products:
                next_page = current_page + 1
                # Generate a new URL for the next page by replacing the page parameter
                next_page_url = re.sub(r'page=\d+', f'page={next_page}', response.url)

                self.logger.info(f"Fetching next page: {next_page}")

                yield scrapy.Request(
                    url=next_page_url,
                    method='GET',
                    callback=self.parse_api_response,
                    meta={'page': next_page},  # Pass the new page number
                    dont_filter=True
                )
            else:
                self.logger.info(f"No more products found, finished at page {current_page}")

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
        except Exception as e:
            self.logger.error(f"Error processing response: {e}")
            import traceback
            self.logger.error(traceback.format_exc())

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
