import scrapy
import json
import datetime
from ..items import couponsDealsItem

class LowesGiftingSpider(scrapy.Spider):
    name = 'lowes_gifting'
    start_urls = [
        "https://www.lowes.com/pl/gifting/1711264269779/products?facets=2,982555940,982555941,982555943&offset=0&adjustedNextOffset=0&nearByStores=1058,1570,1128,1131,0555&ac=false&algoRulesAppliedInPageLoad=false"
    ]

    batch_size = 24  # Number of products per request

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept-Language": "en-US,en;q=0.5",
        "Content-Type": "application/json",
        # Add any other required headers
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse,
                meta={"offset": 0}  # Starting point for pagination
            )

    def parse(self, response):
        offset = response.meta.get("offset", 0)
        try:
            data = json.loads(response.text)
            products = data.get("products", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        total_products = 0
        for product in products:
            total_products += 1
            yield self.extract_product_item(product)

        # Pagination: if we received products, request the next batch
        if total_products > 0:
            next_offset = offset + self.batch_size
            next_url = response.url.replace(f"offset={offset}", f"offset={next_offset}")
            yield scrapy.Request(
                url=next_url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse,
                meta={"offset": next_offset}
            )

    def extract_product_item(self, product):
        """Extract product data into couponsDealsItem"""
        item = couponsDealsItem()

        # Description
        item['Description'] = product.get("description", "")

        # Original Price
        item['Price'] = product.get("price", {}).get("wasPrice", "")

        # Discount Price
        item['DiscountPrice'] = product.get("price", {}).get("sellingPrice", "")

        # Savings
        savings = product.get("price", {}).get("savings", {})
        item['Savings'] = savings.get("totalSaving", "")

        # Images
        images = []
        additional_images = product.get("images", [])
        for image in additional_images:
            if image.get("src"):
                images.append(image["src"])
        item['Images'] = ",".join(images)

        # Product URL
        item['ProductUrl'] = f"https://www.lowes.com{product.get('url', '')}"

        # Standard fields
        item['SiteName'] = "Lowes"
        item['SiteURL'] = "https://www.lowes.com"
        item['Framework'] = "3"
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = "True"

        return item
