from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class artbeadsdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'artbeadsdeal'
    start_urls = ['https://artbeads.com/discounts-deals/on-sale-now/']
    Sitename = 'Artbeads'
    siteurl = 'https://artbeads.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product"]'
        titalxpath = './/h4[@class="card-title"]/a/text()'
        imagexpath = './/img/@data-src'
        pricexpath = './/span[@class="price price--non-sale"]/text()'
        price2xpath = './/span[@class="price price--withoutTax price--main"]/text()'
        otherxpath = ''
        nextpage = '//link[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })