from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class bowlerstoreSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bowlerstoredeal'
    start_urls = ['https://www.bowlerstore.com/c-1-bowling-balls.aspx']
    Sitename = 'BowlerStore'
    siteurl = 'https://www.bowlerstore.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//product-card[@class="card card--product h-full card--product-compare relative flex"]'
        titalxpath = './/a[@class="card-link text-current js-prod-link"]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/s[@class="price__was"]/text()'
        price2xpath = './/strong[@class="price__current"]/text()'
        otherxpath = ''
        nextpage = "//a[contains(@class,'pagination__arrow')]/@href"

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })