import scrapy
import json
import datetime
from ..items import couponsDealsItem


class OldNavySaleSpider(scrapy.Spider):
    name = 'oldnavy_sale'
    allowed_domains = ['api.gap.com', 'oldnavy.gap.com']
    start_urls = [
        "https://api.gap.com/commerce/search/products/v2/cc?pageSize=50&pageNumber=1&ignoreInventory=false&cid=3039764&vendor=constructorio&client_id=0&session_id=0&trackingid=788124850924459&includeMarketingFlagsDetails=true&enableDynamicPhoto=true&brand=on&locale=en_US&market=us"
    ]

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://oldnavy.gap.com/",
        "x-client-application-name": "Browse",
        "Origin": "https://oldnavy.gap.com",
        "Connection": "keep-alive"
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                method="GET",
                headers=self.custom_headers,
                callback=self.parse
            )

    def parse(self, response):
        try:
            data = json.loads(response.text)
            products = data.get("products", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON: {e}")
            return

        if not products:
            self.logger.warning("No products found on this page.")
            return

        for product in products:
            for color in product.get("styleColors", []):
                item = self.extract_product_item(product, color)
                print(json.dumps(dict(item), indent=4, default=str))  # ✅ fixed serialization
                yield item

        #

    def extract_product_item(self, product, color):
        """Extract individual product variant info."""
        item = couponsDealsItem()

        # --- Basic Info ---
        item['Title'] = color.get("styleName") or product.get("styleName", "")
        item['SiteName'] = "Old Navy"
        item['SiteURL'] = "https://oldnavy.gap.com"
        item['Framework'] = "3"
        item['dealpage'] = "True"
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()

        # --- Pricing ---
        item['SalePrice'] = color.get("effectivePrice")
        item['Price'] = color.get("regularPrice")
        discount = color.get("percentageOff")
        item['Offer'] = f"{discount}% off" if discount else ""

        # --- Images ---
        images = []
        for img in color.get("images", []):
            path = img.get("path", "")
            if path:
                if not path.startswith("http"):
                    path = f"https://oldnavy.gap.com{path}"
                images.append(path)
        item['Image'] = ",".join(images)

        item['SourceUrl'] = ""

        return item
