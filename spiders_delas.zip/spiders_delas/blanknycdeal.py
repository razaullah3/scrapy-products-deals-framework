import json
import scrapy
import datetime
from py_linq import Enumerable
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class blanknycdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'blanknycdeal'
    start_urls = ['https://blanknyc.com/collections/spring-2025-sale']
    Sitename = 'BlankNYC'
    siteurl = 'https://www.blanknyc.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = "//product-card[@class='product-card']"
        titalxpath = ".//div[@class='v-stack justify-items-center gap-1']/a/text()"
        imagexpath = './/div[@class="product-card__figure"]/a/img[1]/@src'
        pricexpath = ""
        price2xpath = ".//price-list[@class='price-list ']/sale-price/text()[2]"
        otherxpath = ''
        nextpage = "//a[@class='pagination__link h6']/@href"

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })