from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class eloquiidealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'eloquiidealdeal'
    Sitename = 'Eloquii'
    siteurl = 'https://www.eloquii.com/'
    max_pages = 15

    # ---- APPLY PAGINATION DIRECTLY IN start_urls ----
    start_urls = [
        f"https://www.eloquii.com/zq/deals/?start={15 + i*10}&sz=10"
        for i in range(max_pages)
    ]

    def parse(self, response):
        # first document item
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        divxpath = '//div[@class="product-tile h-100 d-flex flex-column  product-tile-browse"]'
        titalxpath = './/a[@class="link text-black name-link d-block product-tile-name"]/text()'
        imagexpath = './/picture[@class="tile-image-picture"]/source[1]/@data-srcset'
        pricexpath = './/span[@class="strike-through list"]/span/@content'
        price2xpath = './/span[@class="finalprice mb-0 font-weight-bold font-size-md product-tile-final-price-min"]/span/@content'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': '',
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': '',
                'subcategorypage': '',
                'nextpage': '',
                'categorypage': '',
            }
        )
