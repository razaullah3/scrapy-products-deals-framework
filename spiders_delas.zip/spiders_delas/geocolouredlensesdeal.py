from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class geocolouredlensesdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'geocolouredlensesdeal'
    start_urls = ['https://geocolouredlenses.com/collections/deals']
    Sitename = 'Geo Coloured Lenses'
    siteurl = 'https://geocolouredlenses.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//product-item[@class="product-item "]'
        titalxpath = './/a[@class="product-item-meta__title"]/text()'
        imagexpath = './/div[@class="product-item__image-wrapper "]/a/img[@src] |//div[@class="product-item__image-wrapper product-item__image-wrapper--multiple"]/a/img[@src][1]'
        pricexpath = './/span[@class="price price--compare"]/text()[2]'
        price2xpath = './/span[@class="price price--highlight"]/text()[2] | //span[@class="price"]/text()[2]'
        otherxpath = ''
        nextpage = '//li[@class="pagination-item pagination-item--next"]/a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })