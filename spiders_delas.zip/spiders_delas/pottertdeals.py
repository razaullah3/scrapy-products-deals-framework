import json
import scrapy
import datetime
import time
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class PotteryBarnClearanceSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'potterybarndeal'
    start_urls = ['https://www.potterybarn.com/']
    Sitename = 'potterybarn'
    siteurl = 'https://www.potterybarn.com'
    
    # API endpoint
    api_url = (
        'https://ac.cnstrc.com/browse/group_id/shop-all-clearance'
        '?c=ciojs-client-2.66.0'
        '&key=key_w3v8XC1kGR9REv46'
        '&i=7d356dbd-0cdb-44c9-9598-3fddfbca3c91'
        '&s=1&offset=0&num_results_per_page=20'
        '&&sort_order=descending'
        '&fmt_options%5Bhidden_facets%5D=smartDeskFeatures'
        '&pre_filter_expression=%7B%22or%22%3A%5B%7B%22or%22%3A%5B%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A0184%22%7D%2C%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A0385%22%7D%2C%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A0940%22%7D%2C%7B%22name%22%3A%22store_ids%22%2C%22value%22%3A%22ST%3A0752%22%7D%5D%7D%2C%7B%22or%22%3A%5B%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_CMO%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_SS%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DEFAULT%22%7D%5D%7D%5D%7D'
    )

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.potterybarn.com/',
        'Origin': 'https://www.potterybarn.com',
        'Connection': 'keep-alive',
    }

    def start_requests(self):
        """Start scraping from Pottery Barn API"""
        yield scrapy.Request(
            url=self.api_url,
            headers=self.headers,
            callback=self.parse_api_response,
            meta={'offset': 0}
        )

    def parse_api_response(self, response):
        """Parse API response and extract product data"""
        try:
            data = json.loads(response.text)
            results = data.get('response', {}).get('results', [])
            if not results:
                self.logger.info("No results found.")
                return

            for result in results:
                product_data = result.get('data', {})
                yield self.extract_product_item(product_data)

            # Pagination (20 per page)
            current_offset = response.meta.get('offset', 0)
            total_count = data.get('response', {}).get('total_num_results', 0)
            next_offset = current_offset + 20

            if next_offset < total_count:
                next_url = self.api_url.replace(f"offset={current_offset}", f"offset={next_offset}")
                yield scrapy.Request(
                    url=next_url,
                    headers=self.headers,
                    callback=self.parse_api_response,
                    meta={'offset': next_offset},
                    dont_filter=True
                )

        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
        except Exception as e:
            self.logger.error(f"Error parsing API response: {e}")

    def extract_product_item(self, product):
        """Extract product information"""
        item = couponsDealsItem()

        # Extract required fields
        item['Title'] = product.get('title', '').strip()
        item['Image'] = product.get('image_url', '').strip()
        item['SourceUrl'] = product.get('url', '').strip()

        # Prices
        lowest = product.get('salePriceMax')
        sale_max = product.get('regularPriceMax')

        item['SalePrice'] = f"${lowest:.2f}" if lowest else ''
        item['Price'] = f"${sale_max:.2f}" if sale_max else ''

        # Offer calculation
        if lowest and sale_max and sale_max > lowest:
            discount_percent = round(((sale_max - lowest) / sale_max) * 100)
            item['Offer'] = f"{discount_percent}% off"
        else:
            item['Offer'] = ''

        # Standard metadata
        item['Framework'] = '3'
        item['SiteName'] = self.Sitename
        item['SiteURL'] = self.siteurl
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = 'True'

        return item

    def parse(self, response):
        """Compatibility entry point"""
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
