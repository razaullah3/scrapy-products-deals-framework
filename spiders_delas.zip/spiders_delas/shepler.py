import scrapy
from ..items import couponsDealsItem

class SheplersSpider(scrapy.Spider):
    name = 'sheplers_playwright'
    allowed_domains = ['sheplers.com']
    
    base_url = "https://www.sheplers.com/search?q=clearance"
    page_offset = 0
    step = 24   # 24 products per page = next offset

    custom_settings = {
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
            "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
        },
        "TWISTED_REACTOR": "twisted.internet.asyncioreactor.AsyncioSelectorReactor",
        "PLAYWRIGHT_DEFAULT_NAVIGATION_TIMEOUT": 60000,
    }

    def start_requests(self):
        url = f"{self.base_url}&start={self.page_offset}"
        yield scrapy.Request(
            url,
            meta={
                "playwright": True,
                "playwright_include_page": True,
                "playwright_context": "default",
                "playwright_page_goto_kwargs": {"wait_until": "networkidle"}
            },
            callback=self.parse,
            dont_filter=True
        )

    async def parse(self, response):
        page = response.meta["playwright_page"]
        await page.wait_for_selector("li.grid-tile")
        await page.close()

        products = response.xpath('//li[contains(@class,"grid-tile")]')

        for product in products:
            item = couponsDealsItem()
            item['title'] = product.xpath('.//h6[@class="product-name"]/a/text()').get(default="").strip()
            item['image'] = product.xpath('.//img[@class="tile-image"]/@src').get()

            price_saving = product.xpath('.//span[@class="product-total-price savings"]/text()').get()
            price_no_saving = product.xpath('.//span[@class="product-total-price no-savings"]/text()').get()
            price_old = product.xpath('.//span[@class="product-standard-price"]/del/text()').get()

            if price_saving:
                item['price1'] = price_saving.strip()
                item['price2'] = price_old.strip() if price_old else None
            else:
                item['price1'] = price_no_saving.strip() if price_no_saving else None
                item['price2'] = None

            yield item

        # Pagination: offset increase
        if products:
            self.page_offset += self.step
            next_url = f"{self.base_url}&start={self.page_offset}"

            yield scrapy.Request(
                next_url,
                meta={
                    "playwright": True,
                    "playwright_include_page": True,
                    "playwright_page_goto_kwargs": {"wait_until": "networkidle"}
                },
                callback=self.parse,
                dont_filter=True
            )
