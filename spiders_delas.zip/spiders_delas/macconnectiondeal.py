from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy


class macconnectiondealSpider(GetDealsProducts):
    handle_httpstatus_list = [403, 404]
    name = 'macconnectiondeal'
    start_urls = ['https://www.macconnection.com/promotions/clearance-center']
    Sitename = 'MacConnection'
    siteurl = 'https://www.macconnection.com'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        if response.status == 403:
            self.logger.error("Received 403 Forbidden. The website might be blocking scrapers.")
            return

        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # Collect page data
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="ProductTile basic-tile tagline-hover"]'
        titalxpath = './/a[@class="product-name"]/text()'
        imagexpath = './/img[@class="img-responsive prodDetailImage"]/@src'
        pricexpath = './/div[@class="was-price"]/span[@class="line-through"]/text()'
        price2xpath = './/span[@class="product-price"]/span[@class="priceDisplay"]/text()'
        otherxpath = ''
        nextpage = ''

        # Use Data_Collector to handle data collection consistently
        yield scrapy.Request(
            url=response.url,
            headers=self.headers,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            },
            dont_filter=True
        )
