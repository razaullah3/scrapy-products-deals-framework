from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class fleetfeetdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'fleetfeetdeal'
    start_urls = ['https://www.fleetfeet.com/browse/mens?page=1&q=deal']
    Sitename = 'Fleet Feet'
    siteurl = 'https://www.fleetfeet.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-list-item"] '
        titalxpath = './/div[@class="product-tile-title"]/text()'
        imagexpath = './/img[@class="product-tile-image"]/@src'
        pricexpath = './/h3[@class=" product-tile-price  "]/text()  | //span[@class="original"]/text()'
        price2xpath = './/span[@class="discounted"]/text()'
        otherxpath = ''
        nextpage = '//a[@class="button pagination-next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })