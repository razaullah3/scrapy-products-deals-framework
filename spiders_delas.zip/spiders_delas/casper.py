from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class casperclearanceSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'casper'
    start_urls = ['https://casper.com/search?type=product&q=clearance']
    Sitename = 'casper'
    siteurl = 'https://casper.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ----- XPATHS (Your Provided) -----
        divxpath = '//div[@class="collection__results"]//product-card[contains(@class,"product-card product")]'
        titalxpath = './/a[@class="bold"]/text()'
        imagexpath = './/img[contains(@class,"product-card__image product-card__image--pr")]/@src'
        pricexpath = './/sale-price[@class="text-on-sale"]/text()[2]'
        price2xpath = './/compare-at-price[@class="text-subdued line-through"]/text()[2]'
        otherxpath = ''     # Not available
        nextpage = ''       # Pagination not available in search page

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,

                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,

                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
