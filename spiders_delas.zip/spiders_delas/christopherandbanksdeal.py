from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class christopherandbanksdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'christopherandbanksdeal'
    start_urls = [
        'https://www.christopherandbanks.com/collections/missy-4-16-clearance?icid=meganav-_-sale-_-clearance-_-4_28']
    Sitename = 'Christopher & Banks'
    siteurl = 'https://www.christopherandbanks.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-grid-item mb-30"]'
        titalxpath = './/h3[@class="product-grid-item__title h6"]/a/text()'
        imagexpath = './/img[@class="motion-reduce"]/@srcset'
        pricexpath = '//s[@class="price-item price-item--regular"]/text()'
        price2xpath = './/span[@class="price-item price-item--sale price-item--last"]/text()'
        otherxpath = ''
        nextpage = '//a[@aria-label="Next page"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
