import datetime
import validators
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class benshermandealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'benshermandeal'
    start_urls = ['https://www.bensherman.com/collections/sale']
    Sitename = 'Ben Sherman'
    siteurl = 'https://www.bensherman.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # Define XPath selectors for product information
        categorypage = ''  # Category links
        subcategorypage = ''
        attribute = ''
        divxpath = '//li[@class="product"]'  # Main product container
        titalxpath = './/h3[@class="card-title"]/a/text()'  # Product title
        imagexpath = './/div[@class="card-img-container"]/img/@src'  # Product image
        pricexpath = './/div[@class="price-section price-section--withTax non-sale-price--withTax"]/span[2]/text()'  # Original price
        price2xpath = './/span[@class="price"]/text()'  # Sale price
        otherxpath = ''

        # Added pagination XPath
        nextpage = '//li[@class="pagination-item pagination-item--next"]/a/@href'  # Next page link

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })