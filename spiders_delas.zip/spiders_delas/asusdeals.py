import json
import scrapy
import datetime
from ..items import couponsDealsItem


class AsusDealsApiSpider(scrapy.Spider):
    name = "asusdealsapi"

    # ============================================================
    # FULL API URL (DO NOT BREAK PARAMETERS)
    # ============================================================
    api_url = (
        "https://odinapi.asus.com/recent-data/apiv2/DealsFilterResult?"
        "SystemCode=asus&WebsiteCode=us&ProductLevel1Code=laptops&ProductLevel2Code="
        "&DealsLevelID=99&Type=2&PageSize=20&PageIndex={}"
        "&CategoryName=&SeriesName=&SubSeriesName=&Spec=&SubSpec=&PriceMin=&PriceMax="
        "&Sort=Most+Popular&siteID=www&sitelang="
    )

    # ============================================================
    # CUSTOM HEADERS
    # ============================================================
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.asus.com/",
        "Origin": "https://www.asus.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0",
    }

    # ============================================================
    # START REQUEST
    # ============================================================
    def start_requests(self):
        yield scrapy.Request(
            url=self.api_url.format(1),
            headers=self.custom_headers,
            callback=self.parse_api,
            meta={"page": 1}
        )

    # ============================================================
    # MAIN PARSER
    # ============================================================
    def parse_api(self, response):
        data = json.loads(response.text)

        results = (
            data.get("Result", {})
                .get("ProductList", [])
        )

        page = response.meta["page"]

        # ---------------------------------------------------------
        # Loop through ProductList
        # ---------------------------------------------------------
        for p in results:

            # -----------------------------
            # Basic fields
            # -----------------------------
            product_url = p.get("ProductURL", "")
            pdwebpath = p.get("PDWebPath", "")
            sort_price = p.get("SortPrice", "")

            # Convert SortPrice -> float
            try:
                sort_price = float(sort_price)
            except:
                sort_price = None

            # -----------------------------
            # ImageURL[] from ImageList
            # -----------------------------
            image_list = []
            imgs = p.get("ImageList", [])
            if imgs and "ImageURL" in imgs[0]:
                image_list = imgs[0]["ImageURL"]

            # -----------------------------
            # Product title
            # (Name contains HTML; you can clean later)
            # -----------------------------
            title = p.get("Name", "")

            # -----------------------------
            # Map to your item
            # -----------------------------
            item = couponsDealsItem()
            item["Title"] = title
            item["Image"] = image_list
            item["SalePrice"] = sort_price
            item["Price"] = sort_price
            item["SourceUrl"] = product_url

            # custom fields
            

            item["Offer"] = ""
            item["SiteURL"] = "https://www.asus.com"
            item["Framework"] = "3"
            item["SiteName"] = "ASUS Deals API"
            item["dealpage"] = "True"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()

            yield item

        # ============================================================
        # PAGINATION — Stop when results < 20
        # ============================================================
        if len(results) == 20:
            next_page = page + 1
            yield scrapy.Request(
                url=self.api_url.format(next_page),
                headers=self.custom_headers,
                callback=self.parse_api,
                meta={"page": next_page}
            )
