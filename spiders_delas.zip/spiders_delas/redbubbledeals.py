import scrapy
import datetime
from ..items import couponsDealsItem

class RedbubbleDealSpider(scrapy.Spider):
    name = "redbubledeal"
    start_urls = ["https://www.redbubble.com/shop?query=deals&ref=search_box"]

    custom_settings = {
        "PLAYWRIGHT_DEFAULT_NAVIGATION_TIMEOUT": 60000,
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                meta={"playwright": True, "playwright_page_methods": [{"method": "wait_for_load_state", "state": "networkidle"}]},
                callback=self.parse
            )

    async def parse(self, response):
        cards = response.xpath('//div[@data-testid="search-result-card"]')
        for card in cards:
            item = couponsDealsItem()
            item['Title'] = card.xpath('div[@class="styles_box__54ba70e3 SearchResultCard_titleBlock__w1i7W"]/span/text()').get()
            item['Image'] = card.xpath('.//img/@src').get()
            item['Price'] = card.xpath(".//span[@data-testid='line-item-price-price']/text()").get()
            item['SalePrice'] = item['Price']
            item['Offer'] = ""
            item['SourceUrl'] = card.xpath(".//a/@href").get()
            item['SiteName'] = "RedBubble"
            item['SiteURL'] = "https://www.redbubble.com"
            item['Framework'] = "3"
            item['dealpage'] = "True"
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            yield item
