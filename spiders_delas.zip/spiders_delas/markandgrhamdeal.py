import scrapy
import json
import datetime
from ..items import couponsDealsItem


class MarkAndGrahamDealsSpider(scrapy.Spider):
    name = 'markandgraham_deals'
    handle_httpstatus_list = [404]

    # Base API URL with pagination offset support
    base_url = (
        "https://ac.cnstrc.com/browse/group_id/sale-view-all?"
        "c=ciojs-client-2.66.0&key=key_e5IgOecJtURpZGtP&i=bd8c4fb0-3e3a-4e36-a959-70e3b4c05916"
        "&s=1&offset={offset}&num_results_per_page=20&sort_order=descending"
        "&fmt_options%5Bhidden_facets%5D=smartDeskFeatures"
        "&pre_filter_expression=%7B%22or%22%3A%5B%7B%22or%22%3A%5B%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_CMO%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DTX_SS%22%7D%2C%7B%22name%22%3A%22fulfillment_locations%22%2C%22value%22%3A%22DEFAULT%22%7D%5D%7D%5D%7D&_dt=1762840465490"
    )

    # Headers as requested
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.markandgraham.com/",
        "Origin": "https://www.markandgraham.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4"
    }

    def start_requests(self):
        """Start from offset 0"""
        yield scrapy.Request(
            url=self.base_url.format(offset=0),
            headers=self.headers,
            callback=self.parse,
            meta={'offset': 0}
        )

    def parse(self, response):
        """Parse JSON response from Constructor.io API"""
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError:
            self.logger.error("❌ Invalid JSON response")
            return

        # Navigate to the results array
        results = data.get('response', {}).get('results', [])
        self.logger.info(f"✅ Found {len(results)} products at offset {response.meta.get('offset')}")

        for product in results:
            value = product.get('value', {})
            data_dict = product.get('data', {})

            item = couponsDealsItem()
            item['Title'] = value or data_dict.get('title', '')
            item['SourceUrl'] = data_dict.get('url', '')
            item['Image'] = data_dict.get('image_url', '')
            item['Price'] = data_dict.get('regularPriceMax', '')
            item['SalePrice'] = data_dict.get('lowestPrice', '')

            # Metadata
            now = datetime.datetime.now()
            item['Framework'] = '3'
            item['Offer'] = ''
            item['SiteName'] = 'Mark & Graham'
            item['SiteURL'] = 'https://www.markandgraham.com/'
            item['DateAdded'] = now
            item['DateUpdated'] = now

            # Pipeline flags
            item['dealpage'] = 'True'
            item['getDoc'] = 'True'
            item['itempage'] = 'false'
            item['urlpage'] = 'false'
            item['alllogs'] = 'false'
            item['Category'] = 'Sale'
            item['SubCategory'] = ''

            yield item

        # Pagination: continue if results exist
        offset = response.meta.get('offset', 0)
        if results:
            next_offset = offset + 20
            yield scrapy.Request(
                url=self.base_url.format(offset=next_offset),
                headers=self.headers,
                callback=self.parse,
                meta={'offset': next_offset}
            )
