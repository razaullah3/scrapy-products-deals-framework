from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class livingsocialdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'livingsocial'
    start_urls = ['https://www.livingsocial.com/']
    Sitename = 'livingsocial'
    siteurl = 'https://www.livingsocial.com/'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div//figure[@data-bh-viewport="respect"]'
        titalxpath = './/div[contains(@class, "cui-udc-title")]/text()'
        imagexpath = './/img/@src'
        pricexpath = ".//div[@class='cui-price']//div[contains(@class, 'cui-price-original') and contains(@class, 'c-txt-gray-dk')]/text()"
        price2xpath = ".//div[@class='cui-price']//div[contains(@class, 'cui-price-discount') and contains(@class, 'c-txt-price')]/text()"
        otherxpath = ''
        nextpage = '//div[@class="pagination-links"]//div//a/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })