from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


# ---------- GLOBAL HEADERS ----------
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Priority": "u=0, i"
}


class abddealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'abddeal'
    start_urls = ['https://www.abt.com/Special-Deals/c/2892.html',
                  'https://www.abt.com/Special-Deals/c/2892.html?order_by_post=selling%2Cdesc&start_index=20&per_page=20'

                  ]
    Sitename = 'abddeal'
    siteurl = 'https://www.abt.com'

    # ---------- APPLY HEADERS TO ALL REQUESTS ----------
    custom_settings = {
        "DEFAULT_REQUEST_HEADERS": headers
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//div[@class="category_list_container "]'
        titalxpath = './/div[@class="cl_title"]/a/text()'
        imagexpath = './/div[@class="category_image_container"]//img[@class="category_second_image"]/@src'
        pricexpath = './/div[contains(@class,"pricing-item-price")]/text()'
        price2xpath = './/div[contains(@class,"pricing-regular-price")]/text()'
        otherxpath = ''
        nextpage = '//div[@class="pagination"]/a[@data-page-index="20"]/@href'

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
