import json
import scrapy
import datetime
from ..items import couponsDealsItem

class MoenSpider(scrapy.Spider):
    name = 'moen_deals'
    Sitename = 'Moen'
    siteurl = 'https://shop.moen.com'
    
    start_urls = [
        'https://shop.moen.com/apps/br-search?q=*&fl=pid%2Curl%2Cname%2Cdescription%2Cthumb_image%2Cv_thumb_image%2Cprice%2Cprice_range%2Csale_price_range%2Csale_price%2Ccolors%2Cv_colorUrlLookup%2Cv_image_alt1%2Cv_url%2Cv_urlDev%2Csizes%2Cskuid%2Cv_requiresAPart_flag%2Cv_statusFlag%2Cv_exclusivityType%2Cv_badges%2Csku_color%2Cv_colorSwatchUrl%2Cv_webLiveDate%2Cp_maxWebLiveDate%2Cp_isPart&ref_url=&url=https%3A%2F%2Fshop.moen.com%2Fcollections%2Fspecial-clearance%3F&request_id=2025-11-10T03%3A48%3A48.618Z-lwhu7sax&start=0&rows=36&domain_key=moen&pxid=uid%3D7797686432023%3Av%3D11.5%3Ats%3D1428617911187%3Ahc%3D55&fq=v_variantStatus%3A%22ACTIVE%22&fq=v_isOSMI%3A%22true%22&fq=p_maxWebLiveDate%3A%5B*+TO+20251110%5D'
    ]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://shop.moen.com/',
        'Origin': 'https://shop.moen.com',
        'Connection': 'keep-alive'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get('response', {}).get('docs', [])
        self.logger.info(f"Found {len(products)} products on this page.")

        for p in products:
            item = couponsDealsItem()
            item['Title'] = p.get('description', '').strip()             # Description as title
            item['Image'] = p.get('thumb_image', '')                     # Thumbnail image
            item['SourceUrl'] = self.siteurl + p.get('url', '').replace(self.siteurl, '')  # Full product URL

            # ------------------- Updated Price Code -------------------
            price_range = p.get('price_range', [])
            sale_price_range = p.get('sale_price_range', [])

            if price_range:
                item['Price'] = min(price_range)        # Web Price (chhoti value)
                item['SalePrice'] = max(price_range)    # List Price (bari value)
            elif sale_price_range:
                item['Price'] = min(sale_price_range)
                item['SalePrice'] = max(sale_price_range)
            else:
                item['Price'] = p.get('sale_price', None)
                item['SalePrice'] = p.get('price', None)
            # -----------------------------------------------------------

            item['Framework'] = '3'
            item["Offer"] = ''
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        start = int(response.url.split('start=')[1].split('&')[0])
        rows = int(response.url.split('rows=')[1].split('&')[0])
        numFound = data.get('response', {}).get('numFound', 0)
        next_start = start + rows
        if next_start < numFound:
            next_url = response.url.replace(f'start={start}', f'start={next_start}')
            yield scrapy.Request(url=next_url, callback=self.parse, headers=self.headers)
