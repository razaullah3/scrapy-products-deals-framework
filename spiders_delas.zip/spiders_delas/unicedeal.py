import scrapy
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class unicedealSpider(GetDealsProducts):
    name = 'unicedeal'
    start_urls = [
        'https://www.unice.com/search?q=deals',
        'https://www.unice.com/search?q=deals&page=2'
    ]
    Sitename = 'UNICE'
    siteurl = 'https://www.unice.com'

    # ✅ Custom headers applied globally for all requests
    custom_settings = {
        'DEFAULT_REQUEST_HEADERS': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'DNT': '1',
            'Sec-GPC': '1',
            'Priority': 'u=0, i',
        }
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-card-list"]'
        titalxpath = './/div[@class="product-card-title text"]/text() | //div[@class="product-card-title text line2"]'
        imagexpath = './/div[@class="img position-relative product-card-img--img"]/img/@src'
        pricexpath = './/div[@class="product-card-origin-price"]/text()'
        price2xpath = './/div[@class="product-card-final-price"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
