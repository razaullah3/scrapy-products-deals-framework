import json
import scrapy
import datetime
import urllib.parse
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class focuscameradealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'focuscameradeal'
    start_urls = ['https://focuscamera.com/collections/cameras?filters=On+Sale,True']
    Sitename = 'Focus'
    siteurl = 'https://www.focuscamera.com'

    # API configuration
    api_base_url = 'https://api.fastsimon.com/categories_navigation'
    store_id = '62232199216'
    category_id = '295939997744'
    uuid = 'a9acbb48-a08d-44c2-b2a1-de19dc94e37d'

    def start_requests(self):
        """Start with the API request instead of the website"""
        # Build API URL with parameters
        params = {
            'request_source': 'v-next',
            'src': 'v-next',
            'UUID': self.uuid,
            'uuid': self.uuid,
            'store_id': self.store_id,
            'api_type': 'json',
            'category_id': self.category_id,
            'narrow': '[["On Sale","True"]]',
            'facets_required': '1',
            'products_per_page': '100',  # Start with reasonable number, will adjust based on response
            'page_num': '1',
            'qs': 'false'
        }

        api_url = f"{self.api_base_url}?{urllib.parse.urlencode(params)}"

        yield scrapy.Request(
            url=api_url,
            callback=self.parse_api_response,
            meta={'page_num': 1}
        )

    def parse_api_response(self, response):
        """Parse the API response and extract product data"""
        try:
            data = json.loads(response.text)
            items = data.get('items', [])

            # Extract products from current page
            for product in items:
                yield self.extract_product_item(product)

            # Handle pagination
            current_page = response.meta.get('page_num', 1)
            products_per_page = 100

            # If we got a full page of results, there might be more
            if len(items) >= products_per_page:
                next_page = current_page + 1

                # Build URL for next page
                params = {
                    'request_source': 'v-next',
                    'src': 'v-next',
                    'UUID': self.uuid,
                    'uuid': self.uuid,
                    'store_id': self.store_id,
                    'api_type': 'json',
                    'category_id': self.category_id,
                    'narrow': '[["On Sale","True"]]',
                    'facets_required': '1',
                    'products_per_page': str(products_per_page),
                    'page_num': str(next_page),
                    'qs': 'false'
                }

                api_url = f"{self.api_base_url}?{urllib.parse.urlencode(params)}"

                yield scrapy.Request(
                    url=api_url,
                    callback=self.parse_api_response,
                    meta={'page_num': next_page},
                    dont_filter=True
                )

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse JSON response: {e}")
        except Exception as e:
            self.logger.error(f"Error parsing API response: {e}")

    def extract_product_item(self, product):
        """Extract product information and create item"""
        item = couponsDealsItem()

        # Extract basic product information
        item['Title'] = product.get('l', '')  # 'l' seems to be the title/label

        # Extract image
        item['Image'] = product.get('t', '')  # 't' appears to be the main image URL

        # Extract pricing information
        current_price = product.get('p', '')  # Current/sale price
        compare_price = product.get('p_c', '')  # Compare at price (original price)

        # Format current price
        if current_price:
            try:
                price_val = float(current_price)
                item['SalePrice'] = f"${price_val:.2f}"
            except (ValueError, TypeError):
                item['SalePrice'] = f"${current_price}"
        else:
            item['SalePrice'] = ''

        # Format compare/original price
        if compare_price:
            try:
                compare_val = float(compare_price)
                item['Price'] = f"${compare_val:.2f}"
            except (ValueError, TypeError):
                item['Price'] = f"${compare_price}"
        else:
            item['Price'] = item['SalePrice']  # If no compare price, use current price

        # Calculate discount if both prices are available
        if current_price and compare_price:
            try:
                current_val = float(current_price)
                compare_val = float(compare_price)
                if compare_val > current_val:
                    discount_percent = ((compare_val - current_val) / compare_val) * 100
                    item['Offer'] = f"{discount_percent:.0f}% off"
                else:
                    item['Offer'] = ''
            except (ValueError, TypeError):
                item['Offer'] = ''
        else:
            item['Offer'] = ''

        # Extract product URL
        product_url = product.get('u', '')
        if product_url:
            # Ensure URL is complete
            if product_url.startswith('/'):
                item['SourceUrl'] = f"{self.siteurl}{product_url}"
            else:
                item['SourceUrl'] = product_url
        else:
            item['SourceUrl'] = self.siteurl

        # Set standard fields
        item['Framework'] = '3'
        item['SiteName'] = self.Sitename
        item['SiteURL'] = self.siteurl
        item['DateAdded'] = datetime.datetime.now()
        item['DateUpdated'] = datetime.datetime.now()
        item['dealpage'] = 'True'

        return item

    def parse(self, response):
        """Legacy parse method - generates getDoc item and redirects to API scraping"""
        # Generate a getDoc item first (if needed for your framework)
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        # The actual scraping is handled by start_requests() -> parse_api_response()
        # This method is kept for compatibility with your existing framework

    def get_additional_categories(self):
        """
        Helper method to add more categories if needed
        Returns a list of category configurations
        """
        categories = [
            {
                'category_id': '295939997744',  # Current cameras category
                'name': 'cameras',
                'narrow': '[["On Sale","True"]]'
            },
            # Add more categories here if needed
            # {
            #     'category_id': 'ANOTHER_CATEGORY_ID',
            #     'name': 'accessories',
            #     'narrow': '[["On Sale","True"]]'
            # }
        ]
        return categories

    def start_requests_multiple_categories(self):
        """
        Alternative start_requests method to handle multiple categories
        Use this if you need to scrape multiple categories
        """
        categories = self.get_additional_categories()

        for category in categories:
            params = {
                'request_source': 'v-next',
                'src': 'v-next',
                'UUID': self.uuid,
                'uuid': self.uuid,
                'store_id': self.store_id,
                'api_type': 'json',
                'category_id': category['category_id'],
                'narrow': category['narrow'],
                'facets_required': '1',
                'products_per_page': '100',
                'page_num': '1',
                'qs': 'false'
            }

            api_url = f"{self.api_base_url}?{urllib.parse.urlencode(params)}"

            yield scrapy.Request(
                url=api_url,
                callback=self.parse_api_response,
                meta={'page_num': 1, 'category': category['name']}
            )