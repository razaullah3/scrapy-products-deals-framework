import json
import scrapy
import datetime
from ..items import couponsDealsItem

class UnclaimedBaggageSpider(scrapy.Spider):
    name = 'unclaimedbaggage_deals'
    Sitename = 'UnclaimedBaggage'
    siteurl = 'https://www.unclaimedbaggage.com'

    # Base URL (page=1,2,3… will be added automatically)
    base_url = (
        "https://a6kz84.a.searchspring.io/api/search/search.json"
        "?userId=925381a7-46e2-44a0-a1dd-0a9785ace4de"
        "&domain=https%3A%2F%2Fwww.unclaimedbaggage.com%2Fcollections%2Fclearance"
        "&sessionId=81066c57-60a7-4785-b19a-6106c5c31b6c"
        "&pageLoadId=bad578c9-8e85-43de-bb0d-0e5b970e5e50"
        "&excludedFacets=ss_sizefilter_shoes"
        "&excludedFacets=ss_sizefilter_jewelry"
        "&excludedFacets=ss_sizefilter_youth"
        "&excludedFacets=ss_sizefilter_infant_toddler"
        "&excludedFacets=ss_sizefilter_general"
        "&siteId=a6kz84"
        "&bgfilter.collection_handle=clearance"
        "&noBeacon=true"
        "&ajaxCatalog=Snap"
        "&resultsFormat=native"
        "&page={page}"
    )

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',
        'Accept': '*/*',
        'Connection': 'keep-alive'
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_url.format(page=1),
            callback=self.parse,
            headers=self.headers,
            meta={'page': 1}
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except:
            self.logger.error("JSON decode error")
            return

        products = data.get("results", [])
        self.logger.info(f"Page {response.meta['page']} → {len(products)} products found")

        for p in products:
            item = couponsDealsItem()

            item['Title'] = p.get('name', '')
            item['Image'] = p.get('imageUrl', '')
            item['SourceUrl'] = p.get('url', '')

            # ---------------- PRICES ----------------
            item['Price'] = p.get('price', None)  # Web price
            item['SalePrice'] = (
                p.get('msrp') or
                p.get('mfield_product_retail_price') or None
            )
            # -----------------------------------------

            item['Framework'] = '3'
            item["Offer"] = ''
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # ------------------ PAGINATION ------------------
        current_page = response.meta['page']
        total_pages = data.get("pagination", {}).get("totalPages", 1)

        if current_page < total_pages:
            next_page = current_page + 1
            next_url = self.base_url.format(page=next_page)

            yield scrapy.Request(
                url=next_url,
                callback=self.parse,
                headers=self.headers,
                meta={'page': next_page}
            )
        # ------------------------------------------------
