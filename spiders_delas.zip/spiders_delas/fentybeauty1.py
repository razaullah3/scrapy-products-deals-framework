import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class FentyBeautyDealSpider(GetDealsProducts):
    name = 'fentybeautydeal'
    handle_httpstatus_list = [404]
    Sitename = 'Fenty Beauty'
    siteurl = 'https://fentybeauty.com'
    
    # Base API URL (page number will be appended)
    base_api = (
        'https://cv6gyn.a.searchspring.io/api/search/search.json?'
        'userId=2f46e841-a7a5-4951-8724-67c39b597e62&'
        'domain=https%3A%2F%2Ffentybeauty.com%2Fcollections%2Fshop%3Fs%3Ddeal&'
        'sessionId=b55352b0-fb28-44cb-b228-0b2fb53656f7&'
        'pageLoadId=04e07ad0-e347-4f39-a0d3-527b32af7e47&'
        'siteId=cv6gyn&resultsPerPage=24&bgfilter.ss_hide_from_search=0&'
        'q=deal&noBeacon=true&ajaxCatalog=Snap&resultsFormat=native&page='
    )

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://fentybeauty.com/",
        "Origin": "https://fentybeauty.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "Priority": "u=4"
    }

    def start_requests(self):
        start_page = 1
        yield scrapy.Request(
            url=self.base_api + str(start_page),
            callback=self.parse,
            headers=self.custom_headers,
            meta={'page': start_page}
        )

    def parse(self, response):
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            return

        products = data.get("results", [])
        self.logger.info(f"Page {response.meta['page']}: Found {len(products)} products")

        for m in products:
            item = couponsDealsItem()

            item['Title'] = m.get('name', '').strip()
            item['Image'] = m.get('thumbnailImageUrl') or m.get('imageUrl', '')
            item['Price'] = f"${m.get('msrp', '')}" if m.get('msrp') else ''
            item['SalePrice'] = f"${m.get('price', '')}" if m.get('price') else ''
            item['Offer'] = f"{m.get('ss_pct_off', '')}% Off" if m.get('ss_pct_off') else ''
            item['SourceUrl'] = self.siteurl + m.get('url', '')
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        pagination = data.get("pagination", {})
        current_page = pagination.get("currentPage", 1)
        total_pages = pagination.get("totalPages", 1)

        if current_page < total_pages:
            next_page = current_page + 1
            yield scrapy.Request(
                url=self.base_api + str(next_page),
                callback=self.parse,
                headers=self.custom_headers,
                meta={'page': next_page}
            )
