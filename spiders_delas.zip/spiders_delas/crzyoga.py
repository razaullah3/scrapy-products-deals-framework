from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class uscrzyogaSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'crzyoga'
    start_urls = ['https://us.crzyoga.com/search?q=deals&usf_view=grid']
    Sitename = 'uscrzyoga'
    siteurl = 'https://us.crzyoga.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # No category or attribute pages
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        # ---------------------------
        # 🔥 UPDATED XPATHS 🔥
        # ---------------------------
        divxpath = '//div[contains(@class,"product-block") and contains(@class,"cc-product-block")]'
        titalxpath = '..//span[@class="title"]/text()'
        imagexpath = './/div[@class="rimage-wrapper "]/img/@src'
        pricexpath = './/div[@class="price"]//span[@class="theme-money ql-red ql-weight500"]/text()'
        price2xpath = './/div[@class="price"]//span[@class="was-price theme-money"]/text()'
        otherxpath = ''   # No other provided
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
