from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class abercrombieSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'abercrombie'
    start_urls = ['https://www.abercrombie.com/shop/wd/mens-clearance?originalStore=us']
    Sitename = 'abercrombie'
    siteurl = 'https://www.abercrombie.com'

    def parse(self, response):
        # Initial doc
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # XPaths
        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//div[contains(@class,"xp-9-12-2__productCard-module__template--UsV8l ")]'
        titalxpath = './/h2[@data-aui="product-card-name"]/text()'
        imagexpath = './/img[@data-aui="product-card-image"]/@src'
        pricexpath = './/span[@class="product-price-text product-price-font-size"][2]/text()'
        price2xpath = './/span[@class="product-price-text product-price-font-size"][1]/text()'
        otherxpath = ''

        # Pagination enabled
        nextpage = 'custom_pagination'

        # Start from page 1
        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage,
                "total_pages": 13,
                "current_page": 1
            }
        )

    # -------------------------
    # CUSTOM PAGINATION LOGIC
    # -------------------------
    def Data_Collector(self, response):
        """Your original Data_Collector will handle item extraction.
           Below we only add pagination logic at end.
        """

        # ---- Run the parent class item extraction ----
        for item in super().Data_Collector(response):
            yield item

        # ---- Pagination block ----
        if response.meta.get('nextpage') == 'custom_pagination':

            current_page = response.meta.get("current_page")
            total_pages = response.meta.get("total_pages")

            if current_page < total_pages:
                next_page = current_page + 1

                next_url = (
                    "https://www.abercrombie.com/shop/wd/mens-clearance"
                    f"?originalStore=us&page={next_page}"
                )

                yield response.follow(
                    next_url,
                    callback=self.Data_Collector,
                    meta={
                        **response.meta,
                        "current_page": next_page
                    }
                )
