from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class rugdirectdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'rugdirectdeal'
    start_urls = ['https://www.rugs-direct.com/store/search?w=deal']
    Sitename = 'Rug Direct'
    siteurl = 'https://www.rugs-direct.com/'

    # Add headers here
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, zstd",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=0,i"
    }

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="rd-col-6 rd-col-md-4 rd-col-lg-3"] '
        titalxpath = './/div[@class="rd-card-body rd-product-data"]/a/text()'
        imagexpath = './/div[@class="nav-results-icons"]/img/@src'
        pricexpath = './/span[@class="strike"]/text()'
        price2xpath = './/span[@class="sell-price"]/text()'
        otherxpath = './/p[@class="discount"]/text()'
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.headers,  # Pass headers here
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
