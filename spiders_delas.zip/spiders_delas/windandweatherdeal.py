import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class windandweatherdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'windandweatherdeal'
    start_urls = ['https://www.windandweather.com/category/clearance']
    Sitename = 'Wind & Weather'
    siteurl = 'https://www.windandweather.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="card mb-7"]'
        titalxpath = './/a[@class="text-body"]/text()'
        imagexpath = './/img[@class="card-img-top card-img-front"]/@src'
        pricexpath = ".//div[@class='fw-bold']/span[contains(@class,'text-gray-350')]/text()"
        price2xpath = './/span[@class="text-primary"]/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })
