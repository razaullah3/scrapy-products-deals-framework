from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class sixpmdealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = '6pmdeal'
    start_urls = ['https://www.6pm.com/null/4gIBMpIDC1s3MCBUTyAxMDBd.zso?s=recentSalesStyle%2Fdesc%2F']
    Sitename = '6 PM '
    siteurl = 'https://www.6pm.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="LA-z"]/article[@class="Q7-z MA-z"]'
        titalxpath = './/a[@class="zX-z"]/text()[1]'
        imagexpath = '. //div[@class="yF-z Lo-z"]/picture/img/@src'
        pricexpath = './/a[@class="zX-z"]/text()[contains(., "MSRP $")]'
        price2xpath = './/a[@class="zX-z"]/text()[contains(., "On sale for $")]'
        otherxpath = '.'
        nextpage = '//a[@rel="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })