from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy
from scrapy_playwright.page import PageMethod


class cigarinternationaldealSpider(GetDealsProducts):
    handle_httpstatus_list = [404, 403]
    name = 'cigarsinternationaldeal'
    start_urls = ['https://www.cigarsinternational.com/shop/?q=deals&p=1']
    Sitename = 'Cigar International'
    siteurl = 'https://www.cigarsinternational.com'

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        'Cookie': 'sessionId=04niuktfasvsyb4ssig5aiau; SourceCode=Value=WEB&SourceDate=11/19/2025 02:05:29; SearchView=List; WebAnalyticsUser={"loginStatus":"logged-out","isLoggedIn":false,"sourceKey":"WEB","ip":"142.111.152.186","loyaltyMemberStatus":"Unspecified"}; NSC_WT_QSPE_DJ_TTM=fZ23NUboc_|aR1tt|aR1sP; __cf_bm=GfShOrXNgO5mmS1Qj9UnSvS3h.Ljw9osF7DspScKAfw-1763535930-1.0.1.1-XGVA7qjLU.nwd575shTTN2vnpp2VeEGzxDt3eT9HAT9c4gU4RHGKtuI.O6gld7ZnpBqhAy1mjS_1ioN.jmlBfM72y2BZMeLb7_Ps7Hbp6aBOgnuZSExGWZUSwfexLypz; AMCV_21D43BC7524454090A490D4D%40AdobeOrg=179643557%7CMCIDTS%7C20412%7CMCMID%7C73433932770317436929191991398654429301%7CMCOPTOUT-1763543657s%7CNONE%7CvVersion%7C5.5.0; mbox=session^#a9fd6d4cb0e5452bbc3e4080e539207b^#1763538166; at_check=true; AMCVS_21D43BC7524454090A490D4D%40AdobeOrg=1; _ga_1VVKYECG4Q=GS2.1.s1763535933^$o1^$g1^$t1763536326^$j39^$l0^$h0; _ga=GA1.1.1326086994.1763535934; promoCode=WEB; dtm_consent=NO; cf_clearance=hi8Pe32b.wxp2HHJgtnZKxiNPovAMUC9RiIWlBGTawk-1763535934-1.2.1.1-IdGqRWhzMAdPhrTdjQkfKKIFFIOPDlpjzMVDrVvddntUsNN_hBy7LJoA6RCSI7wtcRrnZ8Iytzrl1HPtvsx7BL.r_czN.tpxgV3UbLkTPxDCbl9cyW5bF6I1jpetvpshiONRaguD9OFTfyedW88gfONsKNgdE1vYYymgpAo9gdX6zNK_eda0xv9opi6xg.tJrqR73MQVfwdgofoiMeJdF.bOBhv3X_HfgZVPTroDOjI; SC_LINKS=%5B%5BB%5D%5D; s_nr=1763536457586-New; s_vnum=1764529200056%26vn%3D1; s_invisit=true; s_lv=1763536457588; s_lv_s=First%20Visit; s_cc=true; rr_rcs=eF5jYSlN9jBPSzE0MrK00E22tEzUNTFKTdY1SzEz1k1JMjNLNEtKNLQ0MuLKLSvJTBEwtDAw1jXUNQQAnSwOaw; s_sq=ci-prod%3D%2526c.%2526a.%2526activitymap.%2526page%253Dsearch%252520-%252520cigars%252520international%2526link%253D3%2526region%253Dsearch-compare-form%2526pageIDType%253D1%2526.activitymap%2526.a%2526.c%2526pid%253DSearch%252520-%252520Cigars%252520International%2526pidt%253D1%2526oid%253Dhttps%25253A%25252F%25252Fwww.cigarsinternational.com%25252Fshop%25252F%25253Fq%25253Ddeals%252526p%25253D3%2526ot%253DA',
        "DNT": "1",
        "Sec-GPC": "1",
    }

    # -------------------------------
    # Start requests with Playwright
    # -------------------------------
    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                headers=self.custom_headers,
                callback=self.parse,
                dont_filter=True,
                meta={
                    "playwright": True,
                    "playwright_include_page": True,
                    "playwright_page_methods": [
                        # Wait for products container to load
                        PageMethod("wait_for_selector", '//div[@class="item col-6 col-sm-6 col-md-4 col-lg-3 custom-width list-group-item"]')
                    ],
                    "playwright_page_kwargs": {"timeout": 120000}  # 2 min
                }
            )

    # -------------------------------
    # Parse main page
    # -------------------------------
    def parse(self, response):
        # Send basic site info
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        # XPaths for Data_Collector
        divxpath = '//div[@class="item col-6 col-sm-6 col-md-4 col-lg-3 custom-width list-group-item"]'
        titalxpath = './/div[@class="category-details detailslist"]/div/a/div/span[1]/text()'
        imagexpath = './/a[@class="d-block thumb-img "]/img/@src'
        pricexpath = './/div[@class="d-md-flex align-items-center justify-content-between only-text text-left"]/div/span/span/@data-value'
        price2xpath = './/div[@class="d-md-flex align-items-center justify-content-between only-text text-left"]/div/span/span/@data-value'

        # Forward to Data_Collector
        yield response.follow(
            response.url,
            headers=self.custom_headers,
            callback=self.Data_Collector,
            dont_filter=True,
            meta={
                "playwright": True,
                "playwright_include_page": True,
                "playwright_page_methods": [
                    PageMethod("wait_for_selector", divxpath)
                ],
                "playwright_page_kwargs": {"timeout": 120000},
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': '',
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': '',
                'subcategorypage': '',
                'nextpage': '',
                'categorypage': ''
            }
        )
