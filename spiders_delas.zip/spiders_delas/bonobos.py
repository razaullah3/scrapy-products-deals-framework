import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class BonobosDealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'bonobosdeal'
    Sitename = 'Bonobos'
    siteurl = 'https://bonobos.com'

    # BASE API URL
    base_api_url = (
        "https://ac.cnstrc.com/search/deal?c=ciojs-client-2.15.0&key=key_Mp65OJnW8U79Olpq&i=7e64dde9-5474-4cc7-bae3-d1e706a3a03d"
        "&us=ecomm"
    )

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://bonobos.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site"
    }

    num_results_per_page = 90  # fetch max results in one go

    def start_requests(self):
        url = self.base_api_url + f"&s=0&num_results_per_page={self.num_results_per_page}"
        yield scrapy.Request(
            url=url,
            method="GET",
            headers=self.headers,
            callback=self.getproducts,
            dont_filter=True
        )

    def getproducts(self, response):
        listing_json = json.loads(response.text)
        products = listing_json.get("response", {}).get("results", [])

        for p in products:
            data = p.get("data", {})
            if not data:
                continue

            item = couponsDealsItem()
            item['Title'] = p.get("value", "")
            item['Image'] = data.get("image_url", "")
            
            url = data.get("url", "")
            if url.startswith("/"):
                item['SourceUrl'] = self.siteurl + url
            else:
                item['SourceUrl'] = self.siteurl + "/" + url

            item['SalePrice'] = data.get("current_price", 0)
            item['Price'] = data.get("full_price", 0)

            item['Offer'] = ""
            item['Framework'] = "3"
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = "True"

            yield item
