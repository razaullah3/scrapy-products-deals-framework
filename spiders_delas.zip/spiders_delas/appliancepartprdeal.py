from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class appliancedealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'appliacegdeal'
    start_urls = ['https://www.appliancepartspros.com/search.aspx?q=deal']
    Sitename = 'Appliance parts pro'
    siteurl = 'https://www.appliancepartspros.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-item-hold"]'
        titalxpath = './/div[@class="product-item-heading"]/h3/a/text()'
        imagexpath = './/img/@src'
        pricexpath = './/dd[@class="price old-price"]/text()'
        price2xpath = './/strong[@class="price text-success"]/text()'
        otherxpath = './/dd[@class="discount text-danger"]/text()'
        nextpage = '//a[@class="next"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })