import scrapy
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
from urllib.parse import urljoin

class sierradealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'sierradeal'
    start_urls = ['https://www.sierra.com/clearance~1/']
    Sitename = 'sierra'
    siteurl = 'https://www.sierra.com'

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1"
        
        # Cookies can be added if absolutely needed, but sometimes Scrapy handles sessions automatically
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, headers=self.custom_headers, callback=self.parse)

    def parse(self, response):

        
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''

        divxpath = '//div[contains(@class,"productThumbnailContainer item m-b")]'
        titalxpath = './/div[@class="productCard-title-name"]/a/text()'
        sourceurlxpath = './/div[@class="productCard-title-name"]/a/@href'
        imagexpath = './/div[@class="productImageContainer MediumLargerG4"]//img/@data-src'
        pricexpath = './/div[@class="productPricing prices priceBlock pricingRightBorder"]/span[@class="ourPrice  text-sale"]/text()'
        price2xpath = './/div[@class="productPricing savingsBlock"]/span[@class="retailPrice"]/text()'
        otherxpath = ''
        nextpagexpath = '//a[@aria-label="Go to Next Page"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            
            'sourceurlxpath': sourceurlxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpagexpath': nextpagexpath,
            'categorypage': categorypage
        }, headers=self.custom_headers)

    def Data_Collector(self, response):
        divxpath = response.meta['divxpath']
        titalxpath = response.meta['titalxpath']
        sourceurlxpath = response.meta['sourceurlxpath']
        imagexpath = response.meta['imagexpath']
        pricexpath = response.meta['pricexpath']
        price2xpath = response.meta['price2xpath']
        otherxpath = response.meta['otherxpath']

        for product in response.xpath(divxpath):
            item = couponsDealsItem()
            title = product.xpath(titalxpath).get()
            source_url = product.xpath(sourceurlxpath).get()
            image = product.xpath(imagexpath).get()
            price1 = product.xpath(pricexpath).get()
            price2 = product.xpath(price2xpath).get()

            # prepend http if missing
            if source_url and not source_url.startswith('http'):
                source_url = urljoin(self.siteurl, source_url)
            if image and not image.startswith('http'):
                image = urljoin(self.siteurl, image)

            # clean price2 extra text
            if price2:
                price2 = price2.replace('Compare at ', '').strip()

            item['Title'] = title.strip() if title else ''
            item['SourceURL'] = source_url
            item['Image'] = image
            item['Price1'] = price1.strip() if price1 else ''
            item['Price2'] = price2 if price2 else ''
            item['Other'] = product.xpath(otherxpath).get() if otherxpath else ''

            yield item

        # handle next page
        next_page = response.xpath(response.meta['nextpagexpath']).get()
        if next_page:
            next_page = urljoin(self.siteurl, next_page)
            yield response.follow(next_page, callback=self.Data_Collector, meta=response.meta, headers=self.custom_headers)
