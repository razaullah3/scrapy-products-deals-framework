import scrapy
import random
import csv
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class luckybranddealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'luckybranddeal'
    Sitename = 'Lucky Brand'
    siteurl = 'https://www.luckybrand.com'
    start_urls = ['https://www.luckybrand.com/search?q=deal&lang=en_US']

    # ✅ Custom settings: enable retry + disable Playwright
    custom_settings = {
        "RETRY_ENABLED": True,
        "RETRY_TIMES": 10,  # 🔁 Retry up to 10 times
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy.core.downloader.handlers.http.HTTPDownloadHandler",
            "https": "scrapy.core.downloader.handlers.http.HTTPDownloadHandler",
        },
        "DOWNLOADER_MIDDLEWARES": {
            'scrapy.downloadermiddlewares.retry.RetryMiddleware': 90,
            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
        },
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_agents = self.load_user_agents()

    def load_user_agents(self):
        """Load user agents from useragents.csv"""
        try:
            with open("useragents.csv", "r", encoding="utf-8") as f:
                return [row[0].strip() for row in csv.reader(f) if row]
        except FileNotFoundError:
            print("⚠️ useragents.csv not found. Using default User-Agent.")
            return [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"
            ]

    def get_random_headers(self):
        """Return random User-Agent headers"""
        ua = random.choice(self.user_agents)
        return {
            'User-Agent': ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
    "Cookie": 'analyticsAnonymusCustomer=abXoBKlwc8VYszGgDZwUOFt2Gc; dwanonymous_daf97866bcb36047de9f0e88cb49cc50=abXoBKlwc8VYszGgDZwUOFt2Gc; _abck=5BCAEB7BBAA306E67D962D764845AEE0~0~YAAQryXAF3GfY2CaAQAAy4eucQ5NXVQdx/SurpJ0VrO3U1ITEZgjk/bM4YbffL5LphIrlW2OSPtnm1609XOSUCiGg7iAOxo4VYNEM4VGX2qXZJAMVneybxn2VZsEB6vQZsZInPt6GxJ8s+9QLhC8lUoNyNRQ/P8O3+lnRDewqg93sDBXxzTj7P7o4Gngyp2rACm6A1hrftCoq1UDIezcYxgSO3JFg1pp3e/ahwRTnWNqcOGGlT8kNy4JwCmV/74/BqozeRxoLi39Nvp2F2lvsC1M6u8Z3IDV9Bn+Q2RvsI7VfMY3CJfN1Rnltr2XXEjwcwA8x2XtvcmqT3CyyXRdqPKQlwWD67lk7U0Nj3RNV4yEj8Pog7ZIt97tSzj/K9mIvFsUMFEHWmCmElKf5v6iKIkzRsuVnMyaPJX3jDshsSNlDAT4bqphLuQMh/s2FC1rtX5nj9moO/qk8K6hk9wAfZLikkmhp4jKKhi5baeS6ztxY9E9U1ElZDA57DfGKty4SoZ0/bH+kabw7eMAk/6soX72AHk6Lg+HrLdjxhTmwJ83uvaFA0uH4XUp0YGWE0tpuwcTX0AQliEG1TGFQtUPCZxG/ea7tVi6EH4n1xyU9Xh6kyfze5eiWPLoM5UX7iFCmZQKSVzqIuGL5ZUvAB0/yVNTmg==~-1~-1~-1~AAQAAAAE%2f%2f%2f%2f%2f0pUppF42aelLnQG90FwGNi0Q50ufuvR37dMex3z2zlRKSdLnBLEEatmCuNIGan5Ldv7q4VTeCLVw80ENicy24xmtSdkipch5LSb~-1; bm_sz=F2926542160868C3FDE4B269FE0D7158~YAAQryXAF+KMY2CaAQAATiiucR1B6Ry+s+2RwDP0QiAVfyw6DQFjcKrsIYWiWab+bq/12wgzfC+G2f0/kdeLuHkPttZEsXYCzNkEqpytxzIFcerNSxgoNiy9SjzDwW/rsYOLucuTuWZ7iitGKIhgLlAbnIDREcvvAcwkjcb/czKxAOZavJ733SSmUqNT5xaYVXnwyZl2YXlRvhGWvVn6EXFLXh57R4KWjC+mhli7XhS/scdKMlJ0PuArmOH1rEOuVEzrBoMqIqKcUK8Pfo5+yrZfmBQooNczoNmHAfKPfHCP1cazS5ms8Q+YS75eYaRZO8GXTqYmhPvwxG/bsyhNKK9ebfGmnrvVSNgTa37vgbvWXC+TDYHxpaCownF/QrgGL3JjV61ixmRYz4fE9jwAwUg=~3356985~4272454; optimizelyEndUserId=oeu1762843832492r0.3700041195598225; optimizelySession=1762844375995; gtm_sess_params=?q=deal&lang=en_US; gtm_sess_ts=2025-11-11T06:50:33.502Z; _gcl_au=1.1.1075578207.1762843834; __attn_eat_id=925f5a37402e45bbbfb90fc976e844db; _ga_JVY795T7Z5=GS2.1.s1762843834^$o1^$g1^$t1762844376^$j60^$l0^$h0; _ga=GA1.1.2035761220.1762843835; __pr.bb6=9KkC6prS_x; _attn_=eyJ1Ijoie1wiY29cIjoxNzYyODQzODM1NTU4LFwidW9cIjoxNzYyODQzODM1NTU4LFwibWFcIjoyMTkwMCxcImluXCI6ZmFsc2UsXCJ2YWxcIjpcIjE2Mzk5MjYyNjEwMTQ4Mzg4ZTg1NWQ3MDIyZmZmOWFiXCJ9IiwiZWF0Ijoie1wiY29cIjoxNzYyODQzODYwNTQyLFwidW9cIjoxNzYyODQzODYwNTQyLFwibWFcIjozNjUwLFwiaW5cIjp0cnVlLFwidmFsXCI6XCJodHRwczovL21uYW9tLmx1Y2t5YnJhbmQuY29tXCJ9In0=; __attentive_id=16399262610148388e855d7022fff9ab; __attentive_cco=1762843835559; _attn_bopd_=unknown; OptanonConsent=isGpcEnabled=1&datestamp=Tue+Nov+11+2025+11%3A51%3A01+GMT%2B0500+(Pakistan+Standard+Time)&version=202504.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=4fd9ea7b-c2d3-47cb-9f1c-47baa1da47b8&interactionCount=1&isAnonUser=1&landingPath=https%3A%2F%2Fwww.luckybrand.com%2Fsearch%3Fq%3Ddeal%26lang%3Den_US&groups=C0004%3A0%2CC0001%3A1%2CC0002%3A1%2CC0003%3A1; __attentive_dv=1; _rdt_uuid=1762843839294.ad75aaaa-5430-4286-a4cd-da55a8011507; __pdst=da931e78695d4340acafd2e25c1cfe7c; _sfid_bf17={%22anonymousId%22:%227cfa06bbac21a413%22%2C%22consents%22:[]}; _evga_f6e8={%22uuid%22:%227cfa06bbac21a413%22}',
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "DNT": "1",
    "Sec-GPC": "1",
    "Priority": "u=0, i"
        }

    def start_requests(self):
        """Send initial request with random headers"""
        for url in self.start_urls:
            yield scrapy.Request(
                url=url,
                headers=self.get_random_headers(),
                callback=self.parse,
                dont_filter=True
            )

    def parse(self, response):
        """Main parse method"""
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-tile__anchor"]'
        titalxpath = './/div[@class="product-tile__body-section"]/a/@title'
        imagexpath = './/link[@rel="preload"]/@href'
        pricexpath = './/span[@class="price__original text-decoration--strike strike-through list"]/span/@content'
        price2xpath = './/span[@class="price__sales sales"]/span/text()'
        otherxpath = './/ul[@class="product-promotions list--reset"]/li/text()'
        nextpage = ''

        yield response.follow(
            response.url,
            callback=self.Data_Collector,
            headers=self.get_random_headers(),  # ✅ Rotate again for next request
            meta={
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            },
            dont_filter=True
        )
