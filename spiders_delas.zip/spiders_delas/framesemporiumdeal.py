from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class framesemporiumdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'framesemporiumdeal'
    start_urls = ['https://emporiumframes.com/product-category/5-panel-islamic-calligraphy/']
    Sitename = 'Emporium Frames'
    siteurl = 'https://emporiumframes.com/'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="product-block grid"]'
        titalxpath = './/div[@class="clearfix"]/h3/a/text()'
        imagexpath = './/figure[@class="image"]/a/img/@src'
        pricexpath = './/span[@class="price"]/span[2]/bdi/text()'
        price2xpath = './/span[@class="price"]/span[1]/bdi/text()'
        otherxpath = ''
        nextpage = '//a[@class="next page-numbers"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })