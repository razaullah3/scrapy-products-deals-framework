from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class cavendersdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'cavendersdeal'
    start_urls = ['https://www.cavenders.com/shop/clearance/']
    Sitename = "Cavender's"
    siteurl = 'https://www.cavenders.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = '//a[@class="chakra-link css-1f1fa8n"]/@href'
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@class="css-79elbk"]'
        titalxpath = './/p[@class="chakra-text css-qhlfht"]/text()'
        imagexpath = './/img/@src'
        pricexpath = './/s/text()'
        price2xpath = './/b/text()'
        otherxpath = ''
        nextpage = ''

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })