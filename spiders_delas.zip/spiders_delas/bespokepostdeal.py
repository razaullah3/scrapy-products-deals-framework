import json
import scrapy
import datetime
from ..items import couponsDealsItem


class BespokePostApiSpider(scrapy.Spider):
    name = "bespokepostapi"

    # ============================================================
    # FULL API URL (DO NOT BREAK PARAMETERS)
    # ============================================================
    api_url = (
        "https://ac.cnstrc.com/search/deals?"
        "c=ciojs-client-bundled-2.67.4&key=key_5trIuPaC5StD9uQx&"
        "i=b00eefdd-3fb2-432c-a72a-4ff8de17ddc2&s=1&us=visitor&page={}"
        "&num_results_per_page=32&pre_filter_expression=%7B%22not%22%3A%7B%22name%22%3A%22sold_out_at%22%2C%22range%22%3A%5B%22-inf%22%2C1761123947%5D%7D%7D&_dt=1763715948622"
    )

    # ============================================================
    # CUSTOM HEADERS
    # ============================================================
    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Referer": "https://www.bespokepost.com/",
        "Origin": "https://www.bespokepost.com",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4",
    }

    # ============================================================
    # START REQUEST
    # ============================================================
    def start_requests(self):
        yield scrapy.Request(
            url=self.api_url.format(1),  # page=1
            headers=self.custom_headers,
            callback=self.parse_api,
            meta={"page": 1}
        )

    # ============================================================
    # MAIN PARSER
    # ============================================================
    def parse_api(self, response):
        data = json.loads(response.text)

        results = (
            data.get("response", {})
                .get("results", [])
        )

        page = response.meta["page"]

        # ---------------------------------------------------------
        # Loop all results
        # ---------------------------------------------------------
        for r in results:

            d = r.get("data", {})
            p = d.get("payload", [{}])[0]    # FIRST PAYLOAD BLOCK
            
            # -----------------------------
            # Title from payload.name
            # -----------------------------
            title = p.get("name", "")

            # -----------------------------
            # Prices from variants
            # -----------------------------
            variants = p.get("variants", [])
            if variants:
                mem_price = variants[0].get("member_price")   # 7500
                ret_price = variants[0].get("retail_price")   # 11600
            else:
                mem_price = None
                ret_price = None

            # -----------------------------
            # Convert price → decimal format 7500 → 75.00
            # -----------------------------
            def format_price(v):
                if v is None:
                    return None
                return float(f"{v/100:.2f}")

            sale_price = format_price(mem_price)
            original_price = format_price(ret_price)

            # -----------------------------
            # Image
            # -----------------------------
            image_url = d.get("image_url")

            # -----------------------------
            # Source URL from data.url
            # -----------------------------
            source_url = d.get("url")

            # -----------------------------
            # Map to your item
            # -----------------------------
            item = couponsDealsItem()
            item["Title"] = title
            item["Image"] = image_url
            item["SalePrice"] = sale_price
            item["Price"] = original_price
            item["SourceUrl"] = source_url

            item["Offer"] = ""
            item["SiteURL"] = "https://www.bespokepost.com"
            item["Framework"] = "3"
            item["SiteName"] = "BespokePost"
            item["dealpage"] = "True"
            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()

            yield item

        # ============================================================
        # PAGINATION — STOP WHEN results < 32
        # ============================================================
        if len(results) == 32:
            next_page = page + 1
            yield scrapy.Request(
                url=self.api_url.format(next_page),
                headers=self.custom_headers,
                callback=self.parse_api,
                meta={"page": next_page}
            )
