import json
import scrapy
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class RocklerDealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'rocklerdeal'
    Sitename = 'Rockler'
    siteurl = 'https://www.rockler.com'

    api_url = "https://rn129l.a.searchspring.io/api/search/search.json?ajaxCatalog=v3&resultsFormat=native&siteId=rn129l&domain=https%3A%2F%2Fwww.rockler.com%2Fsearch%3Fw%3Dclearance&bgfilter.ss_cat_visible=1&q=clearance&userId=77e35686-5348-4450-a1aa-c70a7660f449&sessionId=60b46127-6438-493c-b9ff-8cff25e1b048&pageLoadId=36164fca-88e6-4e1b-816f-3111edc9e357&noBeacon=true"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Origin": "https://www.rockler.com",
        "Connection": "keep-alive",
        "Referer": "https://www.rockler.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site"
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.api_url,
            method="GET",
            headers=self.headers,
            callback=self.parse
        )

    def parse(self, response):
        listing_json = json.loads(response.text)

        # Extract products
        for req in self.getproducts(response):
            yield req

        # Pagination
        pagination = listing_json.get("pagination", {})
        total_pages = pagination.get("totalPages", 1)
        current_page = pagination.get("currentPage", 1)

        # Loop through remaining pages
        for page in range(current_page + 1, total_pages + 1):
            next_page_url = self.api_url + f"&page={page}"
            yield scrapy.Request(
                url=next_page_url,
                method="GET",
                headers=self.headers,
                callback=self.getproducts,
                dont_filter=True
            )

    def getproducts(self, response):
        listing_json = json.loads(response.text)
        products = listing_json.get("results", [])

        for p in products:
            item = couponsDealsItem()
            
            item['Title'] = p.get("name", "")
            # Use imageUrl field
            item['Image'] = p.get("imageUrl", "")
            
            # Combine base URL + URL if relative
            url_path = p.get("url", "")
            if url_path.startswith("/"):
                item['SourceUrl'] = self.siteurl + url_path
            else:
                item['SourceUrl'] = url_path

            # Price fields
            item['SalePrice'] = p.get("price", "0")
            item['Price'] = p.get("regular_price", "0")

            item['Offer'] = ""
            item['Framework'] = "3"
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = "True"

            yield item
