from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts
import scrapy


class dysondealdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'dysondealdeal'
    start_urls = ['https://www.dyson.com/deals/air-purifier-deals']
    Sitename = 'dysondeal'
    siteurl = 'https://www.dyson.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item

        item['getDoc'] = ''

        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//div[@aria-label="Product"]'
        titalxpath = './/h3[@class="h5 promotional-hero__line1"]/a/span/text()'
        imagexpath = './/div[@class="responsive-image js-responsive-image-container"]/img/@src'
        pricexpath = './/span[@class="promotional-hero__reduced-price typography-body--small"]/text()'
        del_text = response.xpath('//del//text()').getall()
        price2xpath = ''.join([t.strip() for t in del_text if t.strip()])

        otherxpath = './/span[@class="promotional-hero__savings typography-body--small "]/text()'
        nextpage = ''

        yield scrapy.Request(
            response.url,
            callback=self.Data_Collector,
            meta={
                "playwright": True,                 # <<< REQUIRED FOR PRICES
                "playwright_include_page": False,   # light mode
                'url': self.siteurl,
                'sname': self.Sitename,
                'attribute': attribute,
                'divxpath': divxpath,
                'titalxpath': titalxpath,
                'imagexpath': imagexpath,
                'pricexpath': pricexpath,
                'price2xpath': price2xpath,
                'otherxpath': otherxpath,
                'subcategorypage': subcategorypage,
                'nextpage': nextpage,
                'categorypage': categorypage
            }
        )
