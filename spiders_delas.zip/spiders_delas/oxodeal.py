import scrapy
import json
import datetime
from ..items import couponsDealsItem

class OxoDealSpider(scrapy.Spider):
    name = "oxo_deal"
    base_api = "https://mvfvxhvmmt-3.algolianet.com/1/indexes/*/queries"

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "x-algolia-api-key": "OTE2MzA4ZDZlZTJjZjJjN2IzZjVmYWY0ZjA0YWQ0NTQ1MGVlMTVlN2E5Y2U0MTNhNWJkMGQ5NTM0NzRhNWY5Y2ZpbHRlcnM9Y2F0YWxvZ19wZXJtaXNzaW9ucy5jdXN0b21lcl9ncm91cF8wJTIwJTIxJTNEJTIwMCZ0YWdGaWx0ZXJzPQ==",
        "x-algolia-application-id": "MVFVXHVMMT",
        "Origin": "https://www.oxo.com",
        "Connection": "keep-alive",
        "Referer": "https://www.oxo.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "DNT": "1",
        "Sec-GPC": "1",
    }

    def start_requests(self):
        yield self.make_request(page=1)

    def make_request(self, page):
        body = {
            "requests": [
                {
                    "indexName": "magento2_prod_oxooxo_products",
                    "params": (
                        "clickAnalytics=true&facets=%5B%22brand%22%2C%22categories.level0%22%2C%22oxo_color%22%2C%22price.USD.group_0%22%5D"
                        "&highlightPostTag=__%2Fais-highlight__&highlightPreTag=__ais-highlight__"
                        f"&hitsPerPage=48&maxValuesPerFacet=10&numericFilters=%5B%22visibility_search%3D1%22%2C%22status%3D1%22%5D"
                        f"&page={page}&query=deal&ruleContexts=%5B%22magento_filters%22%5D&tagFilters="
                        "&userToken=anonymous-81f26cfa-2705-4ee1-b6b7-169a04667336"
                    )
                }
            ]
        }

        return scrapy.Request(
            url=self.base_api,
            method="POST",
            headers=self.custom_headers,
            body=json.dumps(body),
            callback=self.parse,
            meta={"page": page},
        )

    def parse(self, response):
        page = response.meta.get("page", 1)
        try:
            data = json.loads(response.text)
            hits = data.get("results", [])[0].get("hits", [])
        except Exception as e:
            self.logger.error(f"Failed to parse JSON on page {page}: {e}")
            return

        if not hits:
            self.logger.info(f"No more hits found at page {page}. Stopping pagination.")
            return

        for product in hits:
            yield self.extract_product_item(product)

        # next page
        yield self.make_request(page + 1)

    def extract_product_item(self, data):
        item = couponsDealsItem()

        item["SourceUrl"] = data.get("url", "")
        item["Title"] = data.get("name", "")
        item["Image"] = data.get("thumbnail_url", "")

        # price fields
        price_info = data.get("price", {}).get("USD", {})
        sale_price = price_info.get("default", "")
        regular_price = price_info.get("default_original_formated", "")

        item["Price"] = regular_price
        item["SalePrice"] = sale_price

        # calculate discount %
        try:
            sale = float(sale_price)
            reg = float(price_info.get("default_original_float", sale))
            if reg > sale > 0:
                discount = round(((reg - sale) / reg) * 100, 1)
                item["Offer"] = f"{discount}% off"
            else:
                item["Offer"] = ""
        except Exception:
            item["Offer"] = ""

        # meta fields
        item["SiteName"] = "OXO"
        item["SiteURL"] = "https://www.oxo.com"
        item["Framework"] = "3"
        item["DateAdded"] = datetime.datetime.now()
        item["DateUpdated"] = datetime.datetime.now()
        item["dealpage"] = "True"

        return item
