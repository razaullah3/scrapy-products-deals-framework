from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts


class ghbassdealSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'ghbassdeal'
    start_urls = ['https://www.ghbass.com/sale/shop-all-sale']
    Sitename = 'G.H.BASS'
    siteurl = 'https://www.ghbass.com'

    def parse(self, response):
        item = couponsDealsItem()
        item['getDoc'] = 'True'
        item['SiteName'] = self.Sitename
        yield item
        item['getDoc'] = ''
        categorypage = ''
        subcategorypage = ''
        attribute = ''
        divxpath = '//product-tile-root[@class="product--root"]'
        titalxpath = './/p[@class="product--title"]/text()'
        imagexpath = './/div[@class="product--hover-image"]/img[@src]'
        pricexpath = './/span[@class="product--compare-price money"]/text()'
        price2xpath = './/span[@class="product--price money"]/text()'
        otherxpath = ''
        nextpage = '//a[@class="pagination--link"]/@href'

        yield response.follow(response.url, callback=self.Data_Collector, meta={
            'url': self.siteurl,
            'sname': self.Sitename,
            'attribute': attribute,
            'divxpath': divxpath,
            'titalxpath': titalxpath,
            'imagexpath': imagexpath,
            'pricexpath': pricexpath,
            'price2xpath': price2xpath,
            'otherxpath': otherxpath,
            'subcategorypage': subcategorypage,
            'nextpage': nextpage,
            'categorypage': categorypage
        })