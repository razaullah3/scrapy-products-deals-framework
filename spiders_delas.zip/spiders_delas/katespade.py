import scrapy
import json
import datetime
from ..items import couponsDealsItem
from .GetDealsProducts import GetDealsProducts

class katespade_clearanceSpider(GetDealsProducts):
    handle_httpstatus_list = [404]
    name = 'katespade_clearance'
    Sitename = 'Kate Spade'
    siteurl = 'https://www.katespade.com'

    api_url = "https://www.katespadeoutlet.com/api/get-shop/deals/clearance"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "x-sid": "aecddae4-ce3f-412f-bb24-1f46db6e16a3",
        "Cookie": 'opt_features=abtest1234-abtest4800-abtest4843_a; opt_user=cd34cc03-882d-40a2-9bad-7f7b92ea7b53; KSOexp=OutletMW; opt_enabled=true; akavpau_NO_MA_KSO_NEW=1762932348~id=99773d7c99f8decaac84f2aabf99a023; akacd_kate-na-prod-new=2147483647~rv=38~id=26273774f4fdf2ae6a3a50c9ee9370c8; bm_ss=ab8e18ef4e; _abck=F505536AFD1DDB90218467A062EDC119~0~YAAQhm0+FwMvjjWaAQAAei/udg7HGKOCZoJaCLkZdFgKRSb/6o8p8QDQxWOO3GgEgsTeahAJ5bmBJ3/Rc9+heik9AvqICfnHyDVM5lHZUw9vH2tA5VkB0HJZFvbN9TFbG+2r5m5FfQhiSK23fAijwAfFV22qQ2U9dUxjG+rqzvpgbSnlZw94MgVxfAIz8DP70J41q5Qb58dxLnh3tL8w5BgzfJ0LzvoEEOPFSHdw0kcu9OrJNl2diOx5QleqTMBYCN9dru843YKIqs548fWTfbAlWoVdn1jN9rg8eBJg6LvWa9bxoVBwGCllr4ZsNEpi6Cuk2ioNn81e1C/+D00QgJP4CXajsosLu3FuJx+luOP0kKh/hLMfd1jvnXrsJnVuogMqt8YjmfL9Ofs/jkaz1j/TmF4nWrOwH4NiOsWv/WfzgzTEH9ooWA8w0wkdQ1+1z+6QN573gpG2oaqX7Ayh1hLhRmMaQ3rdv4Q1CrpHvktvpr9i69NQVou2sa3ojcl6iGNUjOjJZWiVXxGF4BAVJKD8RGFKDFaqycgJ5mD80hu+zc54bl5tdFOmhYuGSgVFpRHTyU796um6+5EEK8Q2kcYDLkDOI2GLzR2kh9vGcfPfq35ZblO0OI0fzVEObznSU/lcYJ026dWhBehZKoZMqu2T0UiYbd+C~-1~-1~1762935425~AAQAAAAE%2f%2f%2f%2f%2fxQVWC24GiGV6CMddlrhmZSBkfpp+TBWxDP36SFG08qdpPSDRFKOVCtS9oAnjKuon5gt8xauW9Ku%2fXS6%2f6G%2fUU65lF6rm%2f3FcVXw~-1; bm_s=YAAQhm0+FxEYjjWaAQAAFAbtdgRP1mObYSntXT5QYP78CJ1S2idTmjYJQaWdaJQbO6Ptf6uAOrkgi97D+i6jmrlUmTkAeo6see7ZEKKhwwIk4k9ZPnc8al6RjA0YETbdzxoyxZ+hD7kcXxRPXV9LnJ8kHg0XU7jRu170CzMzR90wxjaPzb5yTSkzGXcirp4qdZ+ZhbjZgKncXeKp7+JtE6+SwPkPyqiDgEH4sFqLg7BBWTOc7hX9G61/JHvU41QM49XtIIL+AHHV9/3wFNn5Of7kjvYoW3aTlRcoVRVVkiHAN+rIeap3u+CplILhpw0iM3UzKRxv/eKrpu5c8917R0umVccICaiVr2C0zlR1pnuRwlKtsT1ljUJVCT2CRGbcsrTDxqLdA+SA/tv5EsPUC7jZlPxF9xS7NRHX+w6kqMIvguVitHiGrcNQBNOE59/61hpYUK8+1Dn4jBOISKo6HJeg8lKbsWRw/4mMjwgac7Icd5olCiLFqIWMPu8uHi3AejM4990z+xTi5X1ASJV5l/qvFitDW46bssIpIjf1RcZ5RJX7MnYppl9q69YxVm7OnSB52vaUYlP3BlXFqLHbzg==; bm_so=3D5D35A41D8EF94C298FDC263E87D67264440507132F9D3409B8FCE88EB0A48C~YAAQhm0+F00TjjWaAQAABM3sdgW4wXgtlTKHXDqSTJPUgA+NRLo1/3hyTsmxKxjiQjVrXsvx3qG0jB65q4XaUN1irmYivO1qaCKEZjFYNVO2/io9shhBFN7OtrmuVyiC8n8XNb8POdZglPCngQd0YFDijYezQtnD++A0HlHKbrFabihqKczcuGYG/ra0yIHZE8Ja86amdxcRYS/nHczBb0RBOqFQpScbRoJqMvaENrHye78ZzrwJcLFhdqFcRJ/skgRPnj3SYl4ACv12XA8QwjtY21H2U2KhrJB9OaXxn1Km3i3sGP3hpWZln5EEgkMTAQ1mN1R24Ka2Cq1qSZq6EmroYw+r/WeV3/pNvdneEBLAO/XQONeeWEEo6l7aQtLdX+yeJbJvjJp3xgLWV3YJkc1EuIn7RBCmcKn2q5i+rhkmyhDntlj6kuIfT5xoTA1bs97Y7ZZQxTw4vHgOH5ccAY7NB95Uce0=; bm_sz=CE2C38970ED2CEF55D6526ABC71F6888~YAAQhm0+F+kTjjWaAQAAjNHsdh0gzxv2ZVN4VPeVowW8J3BpMP9lBEBZzjvocWKbxDxNt20X3yxhyUZq+/D4m/ooUfh1nvTXsGKYM2V/x3m3w6eLC+iRHn3zsNZ3N+o2To8NGq6J83SGNk4VBqHoj1+48dyQvtV1wpc7gdTeXIElOveFggJWfcl9cxe943SYXnDQf4qVQpQOc4Wb3WgZJFC15a3VKg20n43+a5UPwBwZqNxBf2lkkjQOu6eZrDhB8dwSt/ZEuibu6y6+wgfTyIjrnyRv6hLa4RUFTAh1cIyZxOAYfu0hthkIA2n4NyqeA7Lk2z5MyI10cGzpKjIkyJyZCFrkTkAALRBwrb4WubnljuNx2+StuXOGfHN/6gQn6K56vHbLyRrP5xSxozG80tJOG61LmdkSAl/1~3622211~4338232; optimizelyEndUserId=oeu1762931825698r0.05994971375135261; bm_lso=3D5D35A41D8EF94C298FDC263E87D67264440507132F9D3409B8FCE88EB0A48C~YAAQhm0+F00TjjWaAQAABM3sdgW4wXgtlTKHXDqSTJPUgA+NRLo1/3hyTsmxKxjiQjVrXsvx3qG0jB65q4XaUN1irmYivO1qaCKEZjFYNVO2/io9shhBFN7OtrmuVyiC8n8XNb8POdZglPCngQd0YFDijYezQtnD++A0HlHKbrFabihqKczcuGYG/ra0yIHZE8Ja86amdxcRYS/nHczBb0RBOqFQpScbRoJqMvaENrHye78ZzrwJcLFhdqFcRJ/skgRPnj3SYl4ACv12XA8QwjtY21H2U2KhrJB9OaXxn1Km3i3sGP3hpWZln5EEgkMTAQ1mN1R24Ka2Cq1qSZq6EmroYw+r/WeV3/pNvdneEBLAO/XQONeeWEEo6l7aQtLdX+yeJbJvjJp3xgLWV3YJkc1EuIn7RBCmcKn2q5i+rhkmyhDntlj6kuIfT5xoTA1bs97Y7ZZQxTw4vHgOH5ccAY7NB95Uce0=^1762931826727; PIM-SESSION-ID=AziLkyDtl8qdjPTe; dwsid=gqeygtc2iy959kgSyEvGKLoVRrVPpDgzfyQZoRGSMDC_0Z5khtil_QeAch0n6wsRjW6UQN0-X5E73als0wFyxw==; dwanonymous_d3441c5ef1db3a63e41a1cb3741a7634=abwutHxepFxroRw0sXxGYYkrhK; cc-nx-g=I9SLo6iIceKFd8HZzwId0SZWn95Oppk10TJZbjqia94; customer_id=abwutHxepFxroRw0sXxGYYkrhK; usid=aecddae4-ce3f-412f-bb24-1f46db6e16a3; RES_TRACKINGID=870492301515826; optimizelySession=1762931828487; pageviewCount=1; day=12; xgen_ab_info={"testing_group_name":"constructor"}; xgen_user_id=n587k6iuh6mhvo3cvv; xgen_session_id=f03999cb-0dde-4a7c-982e-67fafd5d5885; xgen_meta_data={"user_type":"new_user","access_token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcl9pZCI6ImMzZDlkNzAzYWQ1YTEyNmUxMWUzZDUzOTBhNGJmNDliIiwiZXhwIjoxNzYyOTc1MDI5LCJ1c2VyX2lkIjoibjU4N2s2aXVoNm1odm8zY3Z2In0.kmX1LvIBJRiDco7L-VRFTi9TEoFLhnvB8F3_vTOxOUY","expiration_date":"2025-11-12T19:17:09"}; dwac_94969434a38a7ca8a026e1e7cb=8AuVfJkM0QrGLwajoeCYt8i5YUsBnmIWwP0%3D|dw-only|||USD|false|US%2FEastern|true; cqcid=abwutHxepFxroRw0sXxGYYkrhK; cquid=||; sid=8AuVfJkM0QrGLwajoeCYt8i5YUsBnmIWwP0; __cq_dnt=0; dw_dnt=0; CGSlot=notEXTRA20,notEXTRA25,notPAID,notSAVE20; ak_bmsc=41FF25B7E42D933329DB9CC805F89EB0~000000000000000000000000000000~YAAQhm0+F2gVjjWaAQAAF+Tsdh2lzDkG3aMtUfjUelkbJbdldQvR2EjGWuFKlNJkLCL/QomVzl8u9Y4UqctlGbGq2bSkfqwbz34WZ31jOs37t01zXggy4WNmE997NQiqjdxdGvly5ZOrNtx7LqW+r7whDlhpisPd31dYna9EVgeKhNkMjWht/BfuuSmShN0lmyKITwo5m/qST9SHQZfVCltyErVd+VHVgid7uecK1j70mK2IHYYJhfaQdGN1xE1iWcCqqFtmn3Zox7w2gdxUQUIfM/xGjSoi+b3dRSmXuRZ15TabtpCYASc3IH6SaBt3Y/IN5Tnkt9wzlVShTQ/v1PQJSr0aR2KwzVChiRWcQgIKCwONRXgdN+ewVEthNzSA33INAPQazDSaSp6SIb3igmsdIDxN; _ga_62L4TV2KXZ=GS2.1.s1762931829^$o1^$g0^$t1762932048^$j60^$l0^$h1860807025; _ga=GA1.1.1448973564.1762931830; FPID=FPID2.2.dYLTku7FAUD9%2FUF1FLc%2F%2FpFyISmn%2FwyLvgFIWvsemxU%3D.1762931830; FPLC=EMH7sdQwQKqnoxng8lioXTRGR1x88TFTfotCcBjZnN5qqPPrpLZgHPJ%2FkLNFA9wrNQvv%2B48Vw%2FRFNpkzMpndmXJgBTGkMcyssOEZS9BfVJuzuakgtV9pAD7eN1W0zw%3D%3D; _scid=8e1da304-37ce-4a0c-185c-edaad047636b; __attn_eat_id=1a20dc16e0b741558055dfa0bc080b8f; _attn_=eyJ1Ijoie1wiY29cIjoxNzYyOTMxODMzODE2LFwidW9cIjoxNzYyOTMxODMzODE2LFwibWFcIjoyMTkwMCxcImluXCI6ZmFsc2UsXCJ2YWxcIjpcImIwNGZhYWMwOWQyYTRhY2ViZGFjM2ZlZDkwMWE1ZmFjXCJ9IiwiZWF0Ijoie1wiY29cIjoxNzYyOTMxODMzODEyLFwidW9cIjoxNzYyOTMxODMzODEyLFwibWFcIjozNjUwLFwiaW5cIjp0cnVlLFwidmFsXCI6XCJodHRwczovL29udmFzLmthdGVzcGFkZW91dGxldC5jb21cIn0ifQ==; __attentive_id=b04faac09d2a4acebdac3fed901a5fac; __attentive_session_id=e4545a9fa9464168a78f2ff19faab0b9; __attentive_cco=1762931833817; __pdst=b16de57df15b490abc6873184c18c0cb; _attn_bopd_=unknown; __attentive_pv=1; __attentive_ss_referrer=ORGANIC; __attentive_dv=1; kampyle_userid=d61e-babc-cf10-0e2b-e0f2-3bcd-08dc-807d; kampyleUserSession=1762931836916; kampyleSessionPageCounter=1; kampyleUserSessionsCount=1; kampyleUserPercentile=97.92582540100355; OptanonConsent=isGpcEnabled=1&datestamp=Wed+Nov+12+2025+12%3A17%3A19+GMT%2B0500+(Pakistan+Standard+Time)&version=202407.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=bf8b660b-4217-4775-aa94-61a419bad2d9&interactionCount=0&isAnonUser=1&landingPath=https%3A%2F%2Fwww.katespadeoutlet.com%2Fshop%2Fdeals%2Fclearance&groups=1%3A1%2C2%3A1%2C3%3A1%2C4%3A0',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=4"
        
    }

    def start_requests(self):
        yield scrapy.Request(
            url=f"{self.api_url}?page=1",
            headers=self.headers,
            callback=self.parse,
            meta={
                "page": 1,
                "playwright": True,
                # Use new tuple-based coroutine syntax
                "playwright_page_coroutines": [
                    ("wait_for_selector", "body")
                ],
            }
        )

    def parse(self, response):
        page = response.meta.get("page", 1)

        try:
            data = json.loads(response.text)
        except Exception as e:
            self.logger.error(f"JSON parse error on page {page}: {e}")
            return

        hits = data.get("hits", [])
        nbPages = data.get("nbPages", 0)

        self.logger.info(f"Page {page}: Found {len(hits)} clearance products.")

        for m in hits:
            item = couponsDealsItem()
            item['Title'] = m.get('name', '').strip()
            item['Image'] = (
                m.get('images', {}).get('main', '') or
                (m.get('images', {}).get('url', '') if isinstance(m.get('images'), dict) else '')
            )
            item['SourceUrl'] = m.get('url', '')

            price_data = m.get('price', {})
            item['Price'] = price_data.get('original', '')
            item['SalePrice'] = price_data.get('current', '')

            item['Offer'] = ''
            item['Framework'] = '3'
            item['SiteName'] = self.Sitename
            item['SiteURL'] = self.siteurl
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['dealpage'] = 'True'

            yield item

        # Pagination
        if page < nbPages:
            next_page = page + 1
            yield scrapy.Request(
                url=f"{self.api_url}?page={next_page}",
                headers=self.headers,
                callback=self.parse,
                meta={
                    "page": next_page,
                    "playwright": True,
                    "playwright_page_coroutines": [
                        ("wait_for_selector", "body")
                    ],
                }
            )
