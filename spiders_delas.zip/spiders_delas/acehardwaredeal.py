import scrapy
import json
import datetime
from ..items import couponsDealsItem

class AcehardwareDealsSpider(scrapy.Spider):
    name = "acehardware_deal"
    base_api = "https://www.acehardware.com/graphql"

    custom_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, zstd",
        "Content-Type": "application/json",
        "Origin": "https://www.acehardware.com",
        "Connection": "keep-alive",
        "DNT": "1",
        "Sec-GPC": "1",
        "Priority": "u=6",
        "TE": "trailers",
        "Cookie": "_mzvr=CY5YVgc8xEW3O2PhyJ5dFw; gbi_visitorId=cmh9282d200012a6o0kgthbam; cf_clearance=G8agBGTbHLsJR6clBISDKMyFdA1u0d..foUBomVmExg-1761798250-1.2.1.1-SoX9UMuDpV48yKPI5LOJ92vZL_NXItH0RUoIUW4yFW4FN6vMRlRwpTsiq3hQsw8WK2KDbUHMPfktSNkBUFfgj8fPgiGZIGzLcwF4dt9SYXRYGQ9xTxWa3ERrmAHc1CiZeVTsA.6_h8b4RQ9PjoYp7yJKy.RcoAnhvK483.6zi9.hSaQDM6Eyoy6vyF65BC9dEbdjcGeBNRZfgwtygT7Vgo4dGR2C7wKloi1OyO5eAHE; OptanonConsent=isGpcEnabled=1&datestamp=Thu+Oct+30+2025+09%3A24%3A12+GMT%2B0500+(Pakistan+Standard+Time)&version=202503.2.0&browserGpcFlag=1&isIABGlobal=false&hosts=&landingPath=NotLandingPage&groups=C0003%3A1%2CC0001%3A1%2CC0004%3A1%2CC0002%3A1%2CSSPD_BG%3A1&geolocation=%3B&AwaitingReconsent=false; _ga_KQ8PQ6JEPH=GS2.1.s1761798271^$o3^$g1^$t1761798873^$j60^$l0^$h0; _ga=GA1.1.84483822.1761564846; uws_storage=%22cookie%22; uws_visitor=%7B%22vid%22%3A%22176156484824478869%22%2C%22start%22%3A1761564848243%2C%22count%22%3A4%7D%7C1769574291841; _ga_CRGJ6H77X9=GS2.1.s1761798271^$o3^$g1^$t1761798873^$j60^$l0^$h480556956; FPID=FPID2.2.k1oGPZV3OAYoIC3wsU5vpKs4j0UrGwcLvtWvcOGN7vI%3D.1761564846; OptanonAlertBoxClosed=2025-10-27T12:05:54.371Z; mt.v=5.1052079552.1761798232474; _mzvs=nn; _mzPc=eyJjb3JyZWxhdGlvbklkIjoiYWIwZTdiOTg5MDFhNGExMGIyOTYyNTViZDA0Nzk5ZDkiLCJpcEFkZHJlc3MiOiIyNDA3OmFhODA6MzE0Ojg4N2E6YTRjNDo5M2Q5OjRiYzE6NTk2ZCIsImlzRGVidWdNb2RlIjpmYWxzZSwiaXNDcmF3bGVyIjpmYWxzZSwiaXNNb2JpbGUiOmZhbHNlLCJpc1RhYmxldCI6ZmFsc2UsImlzRGVza3RvcCI6dHJ1ZSwidmlzaXQiOnsidmlzaXRJZCI6IlowVDluZWl4RjBpaXgyLU1FWVpLUUEiLCJ2aXNpdG9ySWQiOiJDWTVZVmdjOHhFVzNPMlBoeUo1ZEZ3IiwiaXNUcmFja2VkIjpmYWxzZSwiaXNVc2VyVHJhY2tlZCI6ZmFsc2V9LCJ1c2VyIjp7ImlzQXV0aGVudGljYXRlZCI6ZmFsc2UsInVzZXJJZCI6Ijc4MmM3OGNjNDhlNDQ3NDdhNDlhNGMyOTczOTdkNmE2IiwiZmlyc3ROYW1lIjoiIiwibGFzdE5hbWUiOiIiLCJlbWFpbCI6IiIsImlzQW5vbnltb3VzIjp0cnVlLCJiZWhhdmlvcnMiOlsxMDE0LDIyMl0sImlzU2FsZXNSZXAiOmZhbHNlfSwidXNlclByb2ZpbGUiOnsidXNlcklkIjoiNzgyYzc4Y2M0OGU0NDc0N2E0OWE0YzI5NzM5N2Q2YTYiLCJmaXJzdE5hbWUiOiIiLCJsYXN0TmFtZSI6IiIsImVtYWlsQWRkcmVzcyI6IiIsInVzZXJOYW1lIjoiIn0sImlzRWRpdE1vZGUiOmZhbHNlLCJpc0FkbWluTW9kZSI6ZmFsc2UsIm5vdyI6IjIwMjUtMTAtMzBUMDQ6MjQ6MjUuMjMwNTkwMVoiLCJjcmF3bGVySW5mbyI6eyJpc0NyYXdsZXIiOmZhbHNlfSwiY3VycmVuY3lSYXRlSW5mbyI6e319; __cf_bm=RPXSDYaZxGn0IbRgx9I_tJ6rYeDNfVuHmY6U5FyJ7ss-1761798385-1.0.1.1-MSk4UZklUkKmwJgjSUUE_WJuPa2felBw4EeMuzV0Vdb3uhIrJotX0mfhWZGEDt.ukE.6m1kwVKDgwM7jolzZjA_Fn6iuqH046YWHFqxgoCE; sb-sf-at-prod-s=at=jyOUu8YTqLef4g6clXmRQiqSqbCfECqhTs7U3jlOBg%2FyeVOZNaHBNg6VACcA1JEQx1ITCfTUko08sMefy42h0AooAok0k4lWHbTyOSXjDmkjBrS8JP7Q3DLglILwDXygnoLk3n4xnP9NmFGRRBWNGcHb5GMgh6viG1pH6jqfA605FfCSGb915ZtJ6cSoICGywsll3sqEegy6%2BHed7VFVV1NbYMzxDn0FFonKBEn9U0Qd7Oa6rjAgS5iMUfLqbETxyg6iA41sSWtS6st4fQ1IlNBVjEqilEGcH0iAevi6XsVOJOSAPVvPee517bXGqkOl69uZpb%2BmPzlblhJtuU8WlQ%3D%3D&dt=2025-10-30T04%3A23%3A53.9944266Z; sb-sf-at-prod=at=jyOUu8YTqLef4g6clXmRQiqSqbCfECqhTs7U3jlOBg%2FyeVOZNaHBNg6VACcA1JEQx1ITCfTUko08sMefy42h0AooAok0k4lWHbTyOSXjDmkjBrS8JP7Q3DLglILwDXygnoLk3n4xnP9NmFGRRBWNGcHb5GMgh6viG1pH6jqfA605FfCSGb915ZtJ6cSoICGywsll3sqEegy6%2BHed7VFVV1NbYMzxDn0FFonKBEn9U0Qd7Oa6rjAgS5iMUfLqbETxyg6iA41sSWtS6st4fQ1IlNBVjEqilEGcH0iAevi6XsVOJOSAPVvPee517bXGqkOl69uZpb%2BmPzlblhJtuU8WlQ%3D%3D; gbi_sessionId=cmhcx6p6n00002a6nnxr0pkbx; userBehaviors=[1014]; _dd_s=rum=0&expire=1761799777842; closestStoreCode=16606; myStore={%22name%22:%22Ace%20Hardware%20-%20Top%20of%20the%20World%22%2C%22address%22:{%22address1%22:%221611%20B%20Okpik%20Street%22%2C%22address2%22:%22%22%2C%22address3%22:%22%22%2C%22address4%22:%22%20%22%2C%22cityOrTown%22:%22Barrow%22%2C%22stateOrProvince%22:%22AK%22%2C%22postalOrZipCode%22:%2299723%22%2C%22countryCode%22:%22US%22%2C%22addressType%22:%22Commercial%22%2C%22isValidated%22:false}%2C%22delivery%22:%22unknown%20delivery%20date%22%2C%22code%22:%2216606%22%2C%22normalizedStoreHours%22:{%22open%22:true%2C%22openUntil%22:%226:00%20PM%22%2C%22closeTime%22:%222025-10-30T13:00:00.938Z%22%2C%22tomorrowDate%22:%2231%22%2C%22todayDate%22:30%2C%22nextOpenDay%22:{%22isoString%22:%222025-10-31T03:00:21.938Z%22%2C%22date%22:31%2C%22openTime%22:%228:00%20AM%22%2C%22day%22:%22Friday%22%2C%22earlyMorning%22:false%2C%22notTomorrow%22:false}}%2C%22geo%22:{%22lat%22:71.288332%2C%22lng%22:-156.783654}%2C%22curbsideFl%22:%22N%22%2C%22limitationFl%22:%22N%22%2C%22nearestLocations%22:%22%22%2C%22storeNameOverride%22:%22Barrow%20-%20B%20Okpik%20Street%22%2C%22fulfillmentTypes%22:[{%22code%22:%22SP%22%2C%22name%22:%22In%20Store%20Pickup%22}]}; _gcl_au=1.1.2062248549.1761798264; myStoreText=||---||; cartCount=0; _mzvt=Z0T9neixF0iix2-MEYZKQA; IR_gbd=acehardware.com; IR_PI=5fb97dbb-b548-11f0-a446-49f8bd173be9%7C1761798287842; irclid=%7B%22clickid%22%3A%22%7E9dg-8Z475a-562WPRSIPGxywpknorvAxwzGBCrsmlc76YWVRIEBr%22%2C%22utm_medium%22%3Anull%2C%22utm_source%22%3Anull%2C%22utm_campaign%22%3Anull%2C%22utm_keyword%22%3Anull%7D; uws_session=%7B%22start%22%3A1761798291765%2C%22count%22%3A1%2C%22referrer%22%3A%22%22%7D%7Csession_timeout; uws_rate_comparators=%7B%22global%22%3A51784648%7D%7Csession_timeout; uws_story_an3b8qk3_step=%7B%22step%22%3A1%7D%7Csession_timeout; IR_9988=1761798287842%7C1437429%7C1761798287842%7C%7C; FPLC=4Gq5PthdXNP43fOXebA1nBUJnQU4d%2FqqpvhS7t%2F2B29h8Bl9DFsvZfTDKW6K3gzZiAxyYbrAshmCN09Ve5MvE%2B2E4YR7Upzf0vDzWlWmSeu5TMpjXL%2FRVIkoZL%2FhaA%3D%3D; FPGSID=1.1761798875.1761798875.G-CRGJ6H77X9.AA-e9YVVgbwatJaUfXFnyw",
                }

    json_body = {
        "variables": {},
        "query": """{
  familyProducts: products(
    pageSize: 500
    filter: "productCode in [f004669,f004845,f004619] or tenant~parent-family-code in [f004669,f004845,f004619]"
  ) {
    items {
      ...FAceProductDetail
      __typename
    }
    __typename
  }
}

fragment FAceProductDetail on Product {
  content {
    productName
    productImages {
      imageUrl
    }
  }
  price {
    price
    salePrice
  }
  properties {
    values {
      stringValue
    }
  }
}"""
    }

    def start_requests(self):
        yield scrapy.Request(
            url=self.base_api,
            method="POST",
            headers=self.custom_headers,
            body=json.dumps(self.json_body),
            callback=self.parse,
            dont_filter=True
        )

    def parse(self, response):
        data = json.loads(response.text)
        products = data.get("data", {}).get("familyProducts", {}).get("items", [])

        for content in products:
            item = couponsDealsItem()

            # ✅ Extract product name
            item["Title"] = content.get("content", {}).get("productName", "").strip()

            # ✅ Extract all image URLs (comma-separated)
            images = content.get("content", {}).get("productImages", [])
            img_urls = [img.get("imageUrl") for img in images if img.get("imageUrl")]
            item["Image"] = ", ".join(img_urls)

            # ✅ Extract price and sale price
            price_info = content.get("price", {})
            item["Price"] = price_info.get("price")
            item["SalePrice"] = price_info.get("salePrice")

            # ✅ Extract source code from properties > values
            properties = content.get("properties", [])
            source_code = None
            for prop in properties:
                for val in prop.get("values", []):
                    if val.get("stringValue"):
                        source_code = val.get("stringValue")
                        break
                if source_code:
                    break
            item["SourceCode"] = source_code

            item["DateAdded"] = datetime.datetime.now()
            item["DateUpdated"] = datetime.datetime.now()
            item["Offer"] = ""
            item["dealpage"] = "True"
            item["SiteName"] = "Ace Hardware"
            item["SiteURL"] = "https://www.acehardware.com/clearance?pageSize=60"
            item["Framework"] = "3"

            yield item
